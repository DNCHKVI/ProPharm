export const DISEASES = [
  {
    "id": "heart-failure",
    "title": "Сердечная недостаточность",
    "systemId": "cardiovascular",
    "sectionIds": [
      "heart-failure"
    ],
    "theoryIds": [
      "hf-core"
    ]
  },
  {
    "id": "hypertension",
    "title": "Артериальная гипертензия",
    "systemId": "cardiovascular",
    "sectionIds": [
      "hypertension"
    ],
    "theoryIds": [
      "htn-core"
    ]
  },
  {
    "id": "ihd-acs",
    "title": "ИБС и острый коронарный синдром",
    "systemId": "cardiovascular",
    "sectionIds": [
      "ihd-acs"
    ],
    "theoryIds": [
      "ihd-core"
    ]
  },
  {
    "id": "arrhythmias",
    "title": "Аритмии",
    "systemId": "cardiovascular",
    "sectionIds": [
      "antiarrhythmics"
    ],
    "theoryIds": [
      "arrhythmia-core"
    ]
  },
  {
    "id": "atrial-fibrillation",
    "title": "Фибрилляция предсердий",
    "systemId": "cardiovascular",
    "sectionIds": [
      "af"
    ],
    "theoryIds": [
      "arrhythmia-core"
    ]
  },
  {
    "id": "parkinson",
    "title": "Болезнь Паркинсона",
    "systemId": "nervous",
    "sectionIds": [
      "parkinson"
    ],
    "theoryIds": [
      "parkinson-theory"
    ]
  },
  {
    "id": "psychosis",
    "title": "Психотические расстройства",
    "systemId": "nervous",
    "sectionIds": [
      "antipsychotics"
    ],
    "theoryIds": [
      "antipsychotics-theory"
    ]
  },
  {
    "id": "depression",
    "title": "Депрессивные расстройства",
    "systemId": "nervous",
    "sectionIds": [
      "antidepressants"
    ],
    "theoryIds": [
      "antidepressants-theory"
    ]
  },
  {
    "id": "insomnia-anxiety",
    "title": "Бессонница и тревога",
    "systemId": "nervous",
    "sectionIds": [
      "benzodiazepines"
    ],
    "theoryIds": [
      "benzodiazepines-theory"
    ]
  },
  {
    "id": "epilepsy",
    "title": "Эпилепсия",
    "systemId": "nervous",
    "sectionIds": [
      "epilepsy"
    ],
    "theoryIds": [
      "epilepsy-theory"
    ]
  },
  {
    "id": "migraine-neuropathic",
    "title": "Мигрень и нейропатическая боль",
    "systemId": "nervous",
    "sectionIds": [
      "migraine-neuropathic"
    ],
    "theoryIds": [
      "migraine-neuropathic-theory"
    ]
  },
  {
    "id": "diabetes",
    "title": "Сахарный диабет",
    "systemId": "endocrine",
    "sectionIds": [
      "diabetes"
    ],
    "theoryIds": [
      "diabetes-theory",
      "acarbose-theory"
    ]
  },
  {
    "id": "thrombosis",
    "title": "Тромбоз и антитромботическая терапия",
    "systemId": "blood",
    "sectionIds": [
      "hemostasis"
    ],
    "theoryIds": [
      "hemostasis-core"
    ]
  },
  {
    "id": "acid-disorders",
    "title": "Кислотозависимые заболевания ЖКТ",
    "systemId": "gastrointestinal",
    "sectionIds": [
      "gi-acid"
    ],
    "theoryIds": [
      "gastric-acid-theory",
      "ppi-theory"
    ]
  },
  {
    "id": "allergy",
    "title": "Аллергические заболевания",
    "systemId": "respiratory",
    "sectionIds": [
      "antihistamines"
    ],
    "theoryIds": [
      "antihistamine-theory"
    ]
  },
  {
    "id": "inflammatory-pain",
    "title": "Воспалительная боль",
    "systemId": "pain",
    "sectionIds": [
      "nsaids",
      "analgesics-local"
    ],
    "theoryIds": [
      "nsaid-theory",
      "paracetamol-theory"
    ]
  },
  {
    "id": "opioid-pain",
    "title": "Опиоидная анальгезия",
    "systemId": "pain",
    "sectionIds": [
      "opioids"
    ],
    "theoryIds": [
      "opioid-theory"
    ]
  },
  {
    "id": "steroid-inflammatory",
    "title": "Глюкокортикостероидная противовоспалительная терапия",
    "systemId": "immune",
    "sectionIds": [
      "steroids"
    ],
    "theoryIds": [
      "steroid-theory"
    ]
  }
];
