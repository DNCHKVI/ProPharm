export const VISUAL_SOURCES={
  servier:{name:'Servier Medical Art',url:'https://smart.servier.com/',license:'CC BY 4.0',use:'Анатомические и клеточные визуальные референсы; при прямом использовании изображения требуется атрибуция и отметка об адаптации.'},
  reactome:{name:'Reactome',url:'https://reactome.org/',license:'Pathway illustrations: CC BY 4.0; pathway data: CC0',use:'Научная основа сигнальных и биохимических путей; сложные pathways упрощаются до экзаменационно значимой цепочки.'},
  wikipathways:{name:'WikiPathways',url:'https://www.wikipathways.org/',license:'CC0',use:'Дополнительный открытый референс для metabolic/signaling pathways.'},
  openstax:{name:'OpenStax Anatomy & Physiology 2e',url:'https://openstax.org/details/books/anatomy-and-physiology-2e',license:'CC BY-NC-SA 4.0',use:'Учебный референс по анатомии и физиологии. В ProPharm не копировать напрямую без проверки условий конкретного изображения.'},
  wikimedia:{name:'Wikimedia Commons',url:'https://commons.wikimedia.org/',license:'Лицензия проверяется для каждого файла',use:'Дополнительные SVG/ЭКГ/анатомические схемы; прямое использование только после проверки лицензии конкретного файла.'}
};
export const VISUAL_SOURCE_GROUPS={
  physiology:['openstax','servier','wikimedia'],
  biochemistry:['reactome','wikipathways','wikimedia'],
  pathophysiology:['reactome','wikipathways','servier'],
  diagnostics:['openstax','wikimedia'],
  targets:['reactome','wikipathways']
};
