const DB_NAME = "propharm-personal-v1";
const DB_VERSION = 2;
const STORES = ["test_sessions","question_progress","favorites","review_queue","study_progress","user_settings","sync_queue","meta"];
let dbPromise;

function openDb(){
  if(dbPromise) return dbPromise;
  dbPromise = new Promise((resolve,reject)=>{
    const req=indexedDB.open(DB_NAME,DB_VERSION);
    req.onerror=()=>reject(req.error);
    req.onupgradeneeded=()=>{
      const db=req.result;
      for(const name of STORES){
        if(!db.objectStoreNames.contains(name)) db.createObjectStore(name,{keyPath:"key"});
      }
    };
    req.onsuccess=()=>resolve(req.result);
  });
  return dbPromise;
}

async function withStore(name,mode,fn){
  const db=await openDb();
  return new Promise((resolve,reject)=>{
    const tx=db.transaction(name,mode);const store=tx.objectStore(name);
    let result;
    try{result=fn(store,tx);}catch(err){reject(err);return;}
    tx.oncomplete=()=>resolve(result);
    tx.onerror=()=>reject(tx.error);
    tx.onabort=()=>reject(tx.error||new Error("IndexedDB transaction aborted"));
  });
}

export async function put(store,value){
  return withStore(store,"readwrite",s=>s.put(value));
}
export async function del(store,key){
  return withStore(store,"readwrite",s=>s.delete(key));
}
export async function get(store,key){
  const db=await openDb();
  return new Promise((resolve,reject)=>{const tx=db.transaction(store,"readonly"),req=tx.objectStore(store).get(key);req.onsuccess=()=>resolve(req.result||null);req.onerror=()=>reject(req.error);});
}
export async function all(store){
  const db=await openDb();
  return new Promise((resolve,reject)=>{const tx=db.transaction(store,"readonly"),req=tx.objectStore(store).getAll();req.onsuccess=()=>resolve(req.result||[]);req.onerror=()=>reject(req.error);});
}
export async function allForUser(store,userId){
  const rows=await all(store);return rows.filter(x=>x.user_id===userId);
}
export async function clearUser(store,userId){
  const rows=await allForUser(store,userId);for(const row of rows)await del(store,row.key);
}
export function makeKey(userId,...parts){return [userId,...parts].join("::")}
export function randomId(prefix="evt"){
  if(globalThis.crypto?.randomUUID)return `${prefix}-${crypto.randomUUID()}`;
  return `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2)}`;
}
