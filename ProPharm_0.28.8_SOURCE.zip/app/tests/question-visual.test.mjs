import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';import vm from 'node:vm';
test('question view hides explanation diagrams and captions but keeps required images',async()=>{
 const context=vm.createContext({});const source=fs.readFileSync('src/ui/visuals.js','utf8');
 const values={esc:s=>String(s),accordion:()=>'',renderAbbreviationLead:()=>'<abbr>DEFINITION</abbr>',SCIENTIFIC_VISUALS:{},WHITEBOARD_SOURCE_MAP:{}};
 const m=new vm.SourceTextModule(source,{context});await m.link(async spec=>{
 const names=[];for(const x of source.matchAll(/import\s*\{([^}]+)\}\s*from\s*['"]([^'"]+)['"]/g))if(x[2]===spec)names.push(...x[1].split(',').map(s=>s.trim()));
 return new vm.SyntheticModule(names,function(){for(const n of names)this.setExport(n,values[n])},{context});});await m.evaluate();
 const render=m.namespace.renderVisual,diagram={title:'Explanation',steps:['SPOILER']};
 assert.equal(render(diagram,{questionOnly:true}),'');assert(render(diagram).includes('SPOILER'));assert(render(diagram).includes('DEFINITION'));
 const image={imageUrl:'protected:test.png',title:'ANSWER',note:'SPOILER',alt:'ANSWER'};
 const prompt=render(image,{questionOnly:true});assert(prompt.includes('protected:test.png'));assert(!prompt.includes('ANSWER'));assert(!prompt.includes('SPOILER'));
 assert(render(image).includes('SPOILER'));
});
