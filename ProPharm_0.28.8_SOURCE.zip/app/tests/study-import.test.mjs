import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const c=JSON.parse(fs.readFileSync('content/catalog.json')).EXAM_MATERIALS;
const qs=JSON.parse(fs.readFileSync('content/questions.json'));
test('imported study cards are unique and all question links resolve',()=>{
 assert.equal(c.blocks.length,16);
 assert.equal(c.cards.length,560);
 assert.equal(new Set(c.cards.map(x=>x.id)).size,c.cards.length);
 const ids=new Set(c.blocks.map(x=>x.id));
 assert(c.cards.every(x=>ids.has(x.topic)&&x.front&&x.back[0]));
 assert(qs.every(q=>(q.studyBlockIds||[]).every(id=>ids.has(id))));
 assert.equal(qs.filter(q=>q.studyBlockIds?.length).length,228);
 assert.deepEqual(c.missingBlocks,Array.from({length:23},(_,i)=>i+17));
});
