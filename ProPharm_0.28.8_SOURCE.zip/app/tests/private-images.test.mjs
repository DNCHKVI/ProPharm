import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
test('protected bundle image works without Storage; access revocation and logout clear it',async()=>{
 const state={user:{id:'a'},profile:{status:'approved'}};
 const name='approved/test/assets/figure.png';let downloaded=0,revoked=0;
 const exports={authState:state,getSupabase:()=>({rpc:async()=>({data:{PRIVATE_ASSETS:{[name]:{mime:'image/png',base64:'AQID'}}}}),storage:{from:()=>({download:async()=>{downloaded++;throw Error('Object not found')}})}}),get:async()=>null,put:async()=>{},makeKey:(...x)=>x.join(':'),all:async()=>[],del:async()=>{},installContent:()=>{},resetContent:()=>{},bundlesForRoute:()=>['tests'],canAccessRoute:()=>true,hasFullAccess:()=>false,BUILD_ID:'test'};
 const context=vm.createContext({navigator:{onLine:true},URL:{createObjectURL:b=>{assert.equal(b.size,3);return 'blob:figure'},revokeObjectURL:()=>revoked++},Blob,Uint8Array,atob});
 const source=fs.readFileSync('src/core/content-service.js','utf8');const m=new vm.SourceTextModule(source,{context});
 await m.link(async spec=>{const names=[];for(const x of source.matchAll(/import\s*\{([^}]+)\}\s*from\s*['"]([^'"]+)['"]/g))if(x[2]===spec)names.push(...x[1].split(',').map(s=>s.trim()));return new vm.SyntheticModule(names,function(){for(const n of names)this.setExport(n,exports[n])},{context})});
 await m.evaluate();await m.namespace.ensureContent('tests');
 assert.equal(await m.namespace.resolveAsset('protected:'+name),'blob:figure');assert.equal(downloaded,0);
 await assert.rejects(m.namespace.resolveAsset('protected:full/test/assets/figure.png'));
 state.profile.status='blocked';await assert.rejects(m.namespace.resolveAsset('protected:'+name));
 m.namespace.clearContent();assert.equal(revoked,1);
 state.profile.status='approved';await assert.rejects(m.namespace.resolveAsset('protected:'+name),/Object not found/);assert.equal(downloaded,1);
});
