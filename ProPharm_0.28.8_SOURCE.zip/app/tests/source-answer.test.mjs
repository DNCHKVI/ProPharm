import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
import {sourceAnswerText} from '../src/questions/source-answer.js';
test('all imported law keys display full option text, including multiple source keys',()=>{
 const questions=JSON.parse(fs.readFileSync('content/questions.json')).filter(q=>q.id.startsWith('law-upload-3-'));
 assert.equal(questions.length,15);
 for(const q of questions){const ids=q.correct?[q.correct]:q.sourceCorrectIds;for(const id of ids)assert(sourceAnswerText(q).includes(q.options.find(o=>o.id===id).text));}
 assert.equal(sourceAnswerText({correct:null,options:[]}), 'В источнике однозначный ответ не установлен.');
});
