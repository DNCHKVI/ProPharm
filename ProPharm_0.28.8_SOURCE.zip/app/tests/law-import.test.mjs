import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
test('law document import preserves 15 source keys and excludes unverified law from exam',()=>{
const qs=JSON.parse(fs.readFileSync('content/questions.json')).filter(q=>q.sectionId==='law-upload-3');
assert.equal(qs.length,15);assert.deepEqual(qs.map(q=>q.correct),['4','5','3','4','5','4','4','2','2','4','1','2','2','5','5']);
assert(qs.every(q=>q.options.length===5&&!q.examEligible&&q.sourceNotes.length));
});
