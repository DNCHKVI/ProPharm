# ProPharm v0.27.0 — AUTH HARDENING

Цель релиза: устранить платформозависимые сбои регистрации/входа (в первую очередь Android) за счёт детерминированной связки Supabase Auth → server-verified user → profiles.

## Что изменено

1. Email confirmation больше не участвует в логике регистрации ProPharm. Ожидаемая настройка Supabase: Authentication → Sign In / Providers → Email → Confirm email = OFF.
2. `signUpWithPassword()` и `signInWithPassword()` сами завершают полный auth-flow и не зависят от случайного порядка `onAuthStateChange`.
3. Локальная session дополнительно подтверждается `supabase.auth.getUser()` через Auth server.
4. Добавлена RPC `public.ensure_my_profile()` (`supabase/migrations/003_auth_hardening.sql`):
   - UUID всегда берётся из `auth.uid()`;
   - браузер не может передать чужой UUID, role или status;
   - отсутствующий профиль создаётся только как `role=user`, `status=pending`;
   - существующий profile/approved/admin не перезаписывается.
5. Загрузка профиля получила retry + защиту от устаревших ответов при смене сессии.
6. `onAuthStateChange` теперь только сериализует синхронизацию после возврата callback; async Supabase-вызовы не выполняются непосредственно внутри callback.
7. Все импорты `authService.js` используют один URL `?v=0.27.0`, чтобы ES Modules не создавали несколько независимых экземпляров authState/Supabase client.
8. Pending-профиль автоматически перепроверяется каждые 30 секунд, при возврате PWA на экран и после восстановления интернета.
9. Service Worker v0.27.0 ищет fallback только в текущем release-cache; старые release-cache удаляются при activate. Для JS/JSON используется network-first с `cache: no-store`.

## Обязательное действие владельца Supabase

Перед тестом новых регистраций выполни в SQL Editor весь файл:

`SUPABASE_PATCH_003_AUTH_HARDENING.sql`

или эквивалентный файл:

`supabase/migrations/003_auth_hardening.sql`

Миграция не меняет существующие `role`/`status` и не трогает конкретных пользователей.

## Контрольный тест после деплоя

1. На Android полностью выйти из старого аккаунта.
2. Открыть новую v0.27.0 и создать НОВЫЙ тестовый email/password аккаунт.
3. Ожидаемо: без письма подтверждения сразу появляется экран `Аккаунт создан / pending`.
4. В Supabase `auth.users.id` и `public.profiles.user_id` должны совпадать.
5. Администратор меняет status → `approved`.
6. На pending-экране можно нажать `Обновить статус`; также приложение обновит статус автоматически ≤30 сек или при возврате на экран.
7. Проверить тот же логин на Android и iOS. Оба должны получать один и тот же profile UUID/status.

## Что НЕ нужно делать

- вручную подтверждать `email_confirmed_at` новым пользователям;
- вручную назначать общий пароль;
- создавать profiles вручную;
- отключать RLS;
- помещать service_role/secret key в браузерный код.
