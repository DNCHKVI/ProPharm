import { UI_DICTIONARY } from './locales/ui-dictionary.js?v=0.27.4';

const LANGS=Object.freeze({
  ru:{label:'RU',name:'Русский',dir:'ltr',remote:'ru'},
  en:{label:'EN',name:'English',dir:'ltr',remote:'en'},
  he:{label:'HE',name:'עברית',dir:'rtl',remote:'he'},
  ar:{label:'AR',name:'العربية',dir:'rtl',remote:'ar'},
});
const DEFAULT_LANGUAGE='ru';
const DB_NAME='propharm_i18n_cache_v3';
const STORE='translations';
const CYRILLIC=/[А-Яа-яЁё]/;
const SKIP_SELECTOR='script,style,code,pre,[data-no-translate],[data-propharm-admin-language-switcher],.force-ltr,.formula,.chemical-formula';
const STATUS_TEXT={
  ru:{ready:'Язык',working:'Перевод…',offline:'Нет сети · показан доступный перевод'},
  en:{ready:'Language',working:'Translating…',offline:'Offline · showing available translation'},
  he:{ready:'שפה',working:'מתרגם…',offline:'אין חיבור · מוצג תרגום זמין'},
  ar:{ready:'اللغة',working:'جارٍ الترجمة…',offline:'لا يوجد اتصال · يتم عرض الترجمة المتاحة'},
};

function normalizeLanguage(value){return Object.prototype.hasOwnProperty.call(LANGS,value)?value:DEFAULT_LANGUAGE}
function trimParts(value){const m=String(value??'').match(/^(\s*)([\s\S]*?)(\s*)$/);return {lead:m?.[1]||'',core:m?.[2]||'',tail:m?.[3]||''}}
function isTranslatable(value){const text=String(value??'').trim();return text.length>0&&CYRILLIC.test(text)}
function shouldSkipElement(el){return !!el?.closest?.(SKIP_SELECTOR)}
function exactMapFor(language){
  const ru=UI_DICTIONARY.ru||{},target=UI_DICTIONARY[language]||{};
  const map=new Map();
  for(const [key,source] of Object.entries(ru)){
    const translated=target[key];
    if(typeof source==='string'&&typeof translated==='string')map.set(source,translated);
  }
  return map;
}

function openDb(){
  return new Promise((resolve,reject)=>{
    if(!('indexedDB' in globalThis))return resolve(null);
    const req=indexedDB.open(DB_NAME,1);
    req.onupgradeneeded=()=>{const db=req.result;if(!db.objectStoreNames.contains(STORE))db.createObjectStore(STORE,{keyPath:'key'})};
    req.onsuccess=()=>resolve(req.result);
    req.onerror=()=>reject(req.error);
  });
}
async function cacheGet(key){
  try{const db=await openDb();if(!db)return null;return await new Promise((resolve,reject)=>{const tx=db.transaction(STORE,'readonly'),r=tx.objectStore(STORE).get(key);r.onsuccess=()=>resolve(r.result?.value??null);r.onerror=()=>reject(r.error)})}catch{return null}
}
async function cacheSet(key,value){
  try{const db=await openDb();if(!db)return;await new Promise((resolve,reject)=>{const tx=db.transaction(STORE,'readwrite');tx.objectStore(STORE).put({key,value,updated_at:Date.now()});tx.oncomplete=()=>resolve();tx.onerror=()=>reject(tx.error)})}catch{}
}

function sentenceChunks(text,max=320){
  const clean=String(text||'');if(clean.length<=max)return [clean];
  const out=[];let buf='';
  let parts=[];
  try{parts=[...new Intl.Segmenter('ru',{granularity:'sentence'}).segment(clean)].map(x=>x.segment)}catch{parts=clean.split(/(?<=[.!?])\s+/)}
  for(const part of parts){
    if(part.length>max){
      if(buf){out.push(buf);buf=''}
      for(let i=0;i<part.length;i+=max)out.push(part.slice(i,i+max));
    }else if((buf+part).length>max){out.push(buf);buf=part}else buf+=part;
  }
  if(buf)out.push(buf);return out.filter(Boolean);
}

async function createBrowserTranslator(target){
  try{
    const API=globalThis.Translator;
    if(!API?.create)return null;
    if(API.availability){const availability=await API.availability({sourceLanguage:'ru',targetLanguage:target});if(availability==='unavailable')return null}
    return await API.create({sourceLanguage:'ru',targetLanguage:target});
  }catch{return null}
}

async function remoteGoogleTranslate(text,target){
  const remote=LANGS[target]?.remote||target;
  const url=`https://translate.googleapis.com/translate_a/single?client=gtx&sl=ru&tl=${encodeURIComponent(remote)}&dt=t&q=${encodeURIComponent(text)}`;
  const controller=new AbortController();
  const timer=setTimeout(()=>controller.abort(),12000);
  try{
    const response=await fetch(url,{method:'GET',mode:'cors',credentials:'omit',cache:'no-store',signal:controller.signal});
    if(!response.ok)throw new Error(`translate HTTP ${response.status}`);
    const data=await response.json();
    const translated=Array.isArray(data?.[0])?data[0].map(row=>row?.[0]||'').join(''):'';
    if(!translated)throw new Error('empty translation');
    return translated;
  }finally{clearTimeout(timer)}
}

export function createAdminRuntimeI18n(options={}){
  const state={
    language:DEFAULT_LANGUAGE,
    generation:0,
    exact:new Map(),
    observer:null,
    browserTranslators:new Map(),
    pending:new Map(),
    failedNetwork:false,
    translating:0,
    textSources:new WeakMap(),
    attrSources:new WeakMap(),
  };
  const isAllowed=()=>Boolean(options.isAllowed?.());
  const getProfile=()=>options.getProfile?.()||null;
  const getStoredLanguage=()=>normalizeLanguage(options.getStoredLanguage?.()||DEFAULT_LANGUAGE);

  function setDirection(language){
    const lang=normalizeLanguage(language),meta=LANGS[lang];
    document.documentElement.lang=lang;
    document.documentElement.dir=meta.dir;
    document.body?.classList.toggle('propharm-rtl',meta.dir==='rtl');
  }
  function statusLabel(){return document.querySelector('[data-propharm-language-status]')}
  function updateStatus(){
    const el=statusLabel();if(!el)return;
    const t=STATUS_TEXT[state.language]||STATUS_TEXT.ru;
    el.textContent=state.translating>0?t.working:(state.failedNetwork&&!navigator.onLine?t.offline:t.ready);
  }

  async function translateCore(source,target){
    if(target==='ru'||!isTranslatable(source))return source;
    const exact=state.exact.get(source.trim());
    if(exact){const {lead,tail}=trimParts(source);return lead+exact+tail}
    const key=`${target}\u0000${source}`;
    const cached=await cacheGet(key);if(cached!=null)return cached;
    if(state.pending.has(key))return state.pending.get(key);
    const promise=(async()=>{
      const chunks=sentenceChunks(source);
      let browser=state.browserTranslators.get(target);
      if(browser===undefined){browser=await createBrowserTranslator(target);state.browserTranslators.set(target,browser||null)}
      const out=[];
      for(const chunk of chunks){
        let translated='';
        if(browser){try{translated=await browser.translate(chunk)}catch{translated=''}}
        if(!translated)translated=await remoteGoogleTranslate(chunk,target);
        out.push(translated);
      }
      const value=out.join('');await cacheSet(key,value);return value;
    })().catch(error=>{state.failedNetwork=true;console.warn('[ProPharm i18n] automatic translation unavailable',error);return source}).finally(()=>state.pending.delete(key));
    state.pending.set(key,promise);return promise;
  }

  function sourceForTextNode(node){
    if(!node||node.nodeType!==Node.TEXT_NODE)return '';
    const remembered=state.textSources.get(node);
    if(typeof remembered==='string')return remembered;
    const current=node.nodeValue||'';
    if(isTranslatable(current)){state.textSources.set(node,current);return current}
    return '';
  }

  function sourceForAttr(el,attr){
    if(!el?.getAttribute)return '';
    let map=state.attrSources.get(el);
    if(!map){map=new Map();state.attrSources.set(el,map)}
    if(map.has(attr))return map.get(attr)||'';
    const current=el.getAttribute(attr)||'';
    if(isTranslatable(current)){map.set(attr,current);return current}
    return '';
  }

  function restoreTrackedSources(root=document){
    if(!root)return;
    const restoreText=node=>{
      if(node?.nodeType!==Node.TEXT_NODE)return;
      const source=state.textSources.get(node);
      if(typeof source==='string'&&node.isConnected)node.nodeValue=source;
    };
    if(root.nodeType===Node.TEXT_NODE)restoreText(root);
    else{
      const walker=document.createTreeWalker(root,NodeFilter.SHOW_TEXT);
      while(walker.nextNode())restoreText(walker.currentNode);
      const elements=root.querySelectorAll?.('[placeholder],[title],[aria-label],[alt]')||[];
      for(const el of elements){
        const map=state.attrSources.get(el);if(!map)continue;
        for(const [attr,source] of map.entries())if(el.isConnected)el.setAttribute(attr,source);
      }
    }
  }

  async function translateTextNode(node,generation){
    if(!node?.isConnected||node.nodeType!==Node.TEXT_NODE||shouldSkipElement(node.parentElement))return;
    const source=sourceForTextNode(node);if(!source)return;
    const language=state.language;if(language==='ru'){node.nodeValue=source;return}
    state.translating++;updateStatus();
    const translated=await translateCore(source,language);
    state.translating=Math.max(0,state.translating-1);updateStatus();
    if(generation!==state.generation||state.language!==language||!node.isConnected)return;
    node.nodeValue=translated;
  }

  async function translateElementAttrs(el,generation){
    if(!el?.isConnected||shouldSkipElement(el))return;
    for(const attr of ['placeholder','title','aria-label','alt']){
      const source=sourceForAttr(el,attr);if(!source)continue;
      const language=state.language;
      if(language==='ru'){el.setAttribute(attr,source);continue}
      const translated=await translateCore(source,language);
      if(generation===state.generation&&state.language===language&&el.isConnected)el.setAttribute(attr,translated);
    }
  }

  async function runPool(tasks,limit=6){
    let index=0;const workers=Array.from({length:Math.min(limit,tasks.length)},async()=>{while(index<tasks.length){const task=tasks[index++];await task()}});await Promise.all(workers)
  }
  async function translateTree(root=document){
    if(!isAllowed()||state.language==='ru'||!root)return;
    const generation=state.generation,tasks=[];
    if(root.nodeType===Node.TEXT_NODE){tasks.push(()=>translateTextNode(root,generation))}
    else{
      const walker=document.createTreeWalker(root,NodeFilter.SHOW_TEXT);
      while(walker.nextNode()){
        const node=walker.currentNode;if(shouldSkipElement(node.parentElement))continue;
        const source=sourceForTextNode(node);if(!source)continue;
        tasks.push(()=>translateTextNode(node,generation));
      }
      const elements=root.querySelectorAll?.('[placeholder],[title],[aria-label],[alt]')||[];
      for(const el of elements)tasks.push(()=>translateElementAttrs(el,generation));
    }
    await runPool(tasks,6);
  }

  function mountSwitcher(){
    document.querySelectorAll('[data-propharm-admin-language-switcher]').forEach(el=>el.remove());
    if(!isAllowed())return;
    const home=document.querySelector('.homePage');if(!home)return;
    const wrap=document.createElement('section');
    wrap.dataset.propharmAdminLanguageSwitcher='true';wrap.dataset.noTranslate='true';wrap.className='propharm-admin-language-switcher';
    const title=document.createElement('div');title.className='propharm-admin-language-title';title.dataset.propharmLanguageStatus='true';wrap.appendChild(title);
    const row=document.createElement('div');row.className='propharm-admin-language-row';
    for(const [code,meta] of Object.entries(LANGS)){
      const button=document.createElement('button');button.type='button';button.className='propharm-admin-language-button';button.textContent=meta.label;button.title=meta.name;button.dataset.language=code;button.setAttribute('aria-pressed',code===state.language?'true':'false');if(code===state.language)button.classList.add('is-active');
      button.addEventListener('click',()=>setLanguage(code));row.appendChild(button);
    }
    wrap.appendChild(row);home.appendChild(wrap);updateStatus();
  }

  function ensureObserver(){
    if(state.observer)return;
    state.observer=new MutationObserver(records=>{
      if(!isAllowed()||state.language==='ru')return;
      for(const record of records){for(const node of record.addedNodes){if(node.nodeType===Node.ELEMENT_NODE||node.nodeType===Node.TEXT_NODE)translateTree(node).catch(()=>{})}}
    });
    state.observer.observe(document.body,{childList:true,subtree:true});
  }

  async function afterRender(){
    const root=options.getRoot?.()||document;
    if(!isAllowed()){
      state.generation++;restoreTrackedSources(root);state.language=DEFAULT_LANGUAGE;state.exact=exactMapFor(DEFAULT_LANGUAGE);setDirection(DEFAULT_LANGUAGE);document.querySelectorAll('[data-propharm-admin-language-switcher]').forEach(el=>el.remove());return;
    }
    const desired=getStoredLanguage();
    if(state.language!==desired){state.generation++;restoreTrackedSources(root);state.language=desired;state.exact=exactMapFor(state.language)}
    setDirection(state.language);mountSwitcher();ensureObserver();
    if(state.language==='ru')restoreTrackedSources(root);
    else await translateTree(root);
  }

  async function setLanguage(language){
    if(!isAllowed())return DEFAULT_LANGUAGE;
    const next=normalizeLanguage(language);
    // Invalidate every in-flight translation before changing the visible language.
    state.generation++;state.failedNetwork=false;
    restoreTrackedSources(options.getRoot?.()||document);
    state.language=next;state.exact=exactMapFor(next);setDirection(next);
    await options.persistLanguage?.(next,getProfile());
    if(typeof options.rerender==='function'){
      options.rerender();
      // router() renders synchronously; run an explicit pass as well so the click
      // is deterministic even if an older queued pass is still pending.
      await Promise.resolve();
      await afterRender();
    }else await afterRender();
    return next;
  }

  function getLanguage(){return state.language}
  return Object.freeze({afterRender,setLanguage,getLanguage,isAllowed,supported:LANGS,translateTree});
}
