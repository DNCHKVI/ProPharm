# Настройка Supabase для ProPharm v0.16

## 1. Создай проект Supabase

Создай новый проект в своём Supabase Dashboard. Все административные секреты остаются только в Supabase/панелях OAuth-провайдеров.

## 2. Выполни SQL migration

Открой SQL Editor и выполни:

`supabase/migrations/001_propharm_accounts.sql`

Migration создаёт:

- `profiles`;
- историю тестов;
- прогресс вопросов;
- favorites;
- review queue;
- study progress;
- user settings;
- admin actions;
- RLS policies;
- trigger создания профиля после `auth.users`.

Каждый новый профиль получает:

```text
role = user
status = pending
```

## 3. Получи публичные параметры

В Supabase найди Project URL и publishable/anon key.

Заполни `config/supabase-config.js`:

```js
export const SUPABASE_CONFIG = Object.freeze({
  enabled: true,
  url: "https://YOUR_PROJECT.supabase.co",
  publishableKey: "YOUR_PUBLIC_KEY",
  siteUrl: "https://dnchkvi.github.io/ProPharm/",
  auth: {
    requireApproval: true,
    allowLocalPreviewWhenDisabled: false,
    google: false,
    apple: false,
    manualIdentityLinking: false
  }
});
```

`publishableKey`/anon key является клиентским ключом. **Service role key сюда не вставлять.**

## 4. Redirect URL

В Supabase Auth URL Configuration укажи Site URL:

`https://dnchkvi.github.io/ProPharm/`

Добавь тот же адрес в разрешённые Redirect URLs.

## 5. Google

В Google Cloud Console создай OAuth web client и используй callback URL, который показывает Supabase для Google provider. Client secret хранится в настройках Supabase provider, не в GitHub Pages.

В Supabase: Authentication → Providers → Google → включить provider и заполнить его server-side credentials.

## 6. Apple

В Apple Developer настрой Sign in with Apple согласно callback/domain, которые требует Supabase. Private key/client secret не добавлять в ProPharm repository.

В Supabase: Authentication → Providers → Apple → заполнить требуемые server-side credentials.

Apple Hide My Email поддерживается: главным идентификатором ProPharm является `auth.users.id`, а не e-mail.

## 7. Создай первого администратора

После настройки зарегистрируй свой аккаунт любым способом: e-mail, Google или Apple.

В таблице `profiles` найди свой `user_id` и один раз выполни:

```sql
update public.profiles
set role = 'admin', status = 'approved'
where user_id = 'ТВОЙ-UUID';
```

После повторного входа/обновления статуса появится раздел **Администрирование**.

## 8. Одобрение пользователей

Новый пользователь после регистрации видит только Pending screen.

В админ-панели можно:

- Одобрить → `approved`;
- Отклонить → `rejected`;
- Заблокировать → `blocked`;
- вернуть в `pending`.

Обычный пользователь не может изменить себе `role` или `status` благодаря RLS и ограничениям SQL privileges.

## 9. Что происходит, пока Supabase не настроен

В v0.16 нет Local Preview и guest mode.

При `enabled: false`, пустом URL или пустом ключе пользователь видит экран:

**ProPharm ещё не подключён**

и не получает учебный UI.

## 10. Проверка

Проверь минимум:

- нет session → только Login;
- новый user → Pending;
- `blocked` → Blocked screen;
- `approved` → учебный интерфейс;
- `admin + approved` → учебный интерфейс + Admin panel;
- direct `#drugs` без session → Login;
- logout → Login;
- offline новый пользователь → нет доступа;
- offline ранее verified approved profile → только предусмотренный ограниченный offline-доступ.


## Текущая production-конфигурация v0.16

OAuth Google/Apple отключены. Вход и регистрация выполняются только через e-mail + пароль. Confirm email должен оставаться включённым в Supabase.

---

# ProPharm v0.16 — заявки администратора и уведомления

После обновления на v0.16 обязательно один раз выполни в **Supabase → SQL Editor → New query** файл:

`supabase/migrations/002_admin_applications_notifications.sql`

Этот патч:

- исправляет ситуацию, когда pending-пользователь виден в Supabase, но не виден внутри ProPharm;
- добавляет защищённую функцию `admin_list_users()` для списка заявок;
- добавляет счётчик `admin_pending_count()`;
- создаёт журнал `admin_notifications`;
- создаёт уведомление для каждой новой регистрации;
- добавляет Realtime для новых заявок;
- создаёт `push_subscriptions` для будущего Web Push;
- создаёт уведомления и для pending-заявок, которые уже существовали до установки v0.16.

После выполнения SQL:

1. Обнови ProPharm до v0.16.
2. Войди своим `admin + approved` аккаунтом.
3. Открой **Настройки → Администрирование**.
4. Текущие заявки должны появиться в блоке **Новые заявки**.
5. Нажми **Включить уведомления** и разреши уведомления в браузере/PWA.

## Какие уведомления работают сразу

После выполнения SQL-патча ProPharm подписывается на Supabase Realtime. Пока сайт/PWA запущен, новая регистрация:

`profiles INSERT → admin_notifications INSERT → Realtime → ProPharm → toast + системное уведомление + badge`

Для iPhone системные Web Push уведомления доступны у web app, добавленного на экран «Домой» (iOS/iPadOS 16.4+). Для уведомлений, когда PWA полностью закрыто, нужен дополнительный серверный Web Push шаг ниже.

## Настоящий Web Push, когда ProPharm полностью закрыт — опционально

В v0.16 уже подготовлены:

- таблица `push_subscriptions`;
- Push API подписка в клиенте;
- `push` handler в `sw.js`;
- Edge Function: `supabase/functions/admin-push/index.ts`.

Для включения полного Web Push нужны VAPID ключи.

1. Сгенерируй VAPID public/private key pair.
2. **Public** key вставь в:

`config/supabase-config.js`

```js
notifications: {
  vapidPublicKey: "ТВОЙ_PUBLIC_VAPID_KEY"
}
```

3. **Private** key никогда не помещай в GitHub. Добавь его только как Supabase Edge Function secret:

- `VAPID_PUBLIC_KEY`
- `VAPID_PRIVATE_KEY`
- `VAPID_SUBJECT` — например `mailto:твой-email`

4. Deploy Edge Function `admin-push`.
5. В **Supabase → Database → Webhooks** создай webhook:
   - Table: `admin_notifications`
   - Event: `INSERT`
   - Target: Supabase Edge Function `admin-push`
   - Method: POST
   - Add auth header with service key

После этого новая заявка сможет присылать push даже при закрытом установленном PWA.

**Важно:** private VAPID key, service_role и OAuth client secrets не должны попадать в frontend или ZIP, который публикуется на GitHub Pages.


---

## v0.27.0 AUTH HARDENING (обязательно для новых регистраций)

1. Убедись: Authentication → Sign In / Providers → Email → **Confirm email = OFF**.
2. Выполни `supabase/migrations/003_auth_hardening.sql` в SQL Editor.
3. После этого регистрация работает как `Auth user → profile pending → admin approved` без ссылки подтверждения почты.
4. Не добавляй secret/service_role key в PWA.
