-- ProPharm v0.27.0 — deterministic Auth/Profile hardening.
-- Safe for existing users: this migration does NOT change current role/status values.
-- Run once in Supabase SQL Editor before or immediately after deploying v0.27.0.

-- Harden the existing signup trigger. It still creates user + pending synchronously.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  insert into public.profiles(user_id,name,email,avatar_url,provider,role,status)
  values(
    new.id,
    coalesce(new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'name',''),
    new.email,
    coalesce(new.raw_user_meta_data->>'avatar_url',new.raw_user_meta_data->>'picture'),
    coalesce(new.raw_app_meta_data->>'provider','email'),
    'user'::public.propharm_role,
    'pending'::public.propharm_status
  )
  on conflict(user_id) do nothing;
  return new;
end;
$$;

-- Self-healing profile RPC.
-- No UUID, role or status is accepted from the browser: identity comes only from auth.uid().
create or replace function public.ensure_my_profile()
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_uid uuid;
  v_profile public.profiles%rowtype;
begin
  v_uid := auth.uid();
  if v_uid is null then
    raise exception 'not authenticated' using errcode = '28000';
  end if;

  insert into public.profiles(user_id,name,email,avatar_url,provider,role,status)
  select
    u.id,
    coalesce(u.raw_user_meta_data->>'full_name',u.raw_user_meta_data->>'name',''),
    u.email,
    coalesce(u.raw_user_meta_data->>'avatar_url',u.raw_user_meta_data->>'picture'),
    coalesce(u.raw_app_meta_data->>'provider','email'),
    'user'::public.propharm_role,
    'pending'::public.propharm_status
  from auth.users u
  where u.id = v_uid
  on conflict(user_id) do nothing;

  select p.* into v_profile
  from public.profiles p
  where p.user_id = v_uid;

  if v_profile.user_id is null then
    raise exception 'profile unavailable';
  end if;

  return to_jsonb(v_profile);
end;
$$;

revoke all on function public.ensure_my_profile() from public;
revoke all on function public.ensure_my_profile() from anon;
grant execute on function public.ensure_my_profile() to authenticated;

comment on function public.ensure_my_profile() is
'Returns or creates only the current auth.uid() profile. Missing profiles are created as role=user,status=pending.';
