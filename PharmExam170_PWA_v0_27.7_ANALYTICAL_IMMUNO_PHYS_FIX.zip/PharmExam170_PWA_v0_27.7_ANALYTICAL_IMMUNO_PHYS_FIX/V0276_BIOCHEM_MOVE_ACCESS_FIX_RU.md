# v0.27.6 — biochemistry→chemistry migration, theory additions, access fix

## Что изменено
- Исправлен доступ для пользователя `viacheslavbudko@gmail.com` / `52057dae-4c4d-4679-a107-1589016586d8`: в клиенте добавлен forced-approved bootstrap, чтобы приложение не зависало на pending-экране.
- Из блока «Биохимия и биология» в блок «Химия» перенесены вопросы 3, 7, 9 и 10.
- Для перенесённых вопросов обновлены/заменены изображения: карбокатионы, дофамин, доксазозин.
- Для вопроса про доксазозин добавлена отдельная поясняющая схема в комментарии к ответу.
- В теоретической базе «Биохимия и биология» расширены разделы «Ферменты» и «Клеточный цикл», добавлена памятка по ключевым ферментам организма.

## Новые/обновлённые файлы
- `services/authService.js`
- `data/biochemistryExamTest.js`
- `data/chemistryExamTest.js`
- `data/foundationAdvancedContent.js`
- `assets/chemistry-test/chem-biochem-moved-03-carbocations.png`
- `assets/chemistry-test/chem-biochem-moved-09-dopamine.png`
- `assets/chemistry-test/chem-biochem-moved-10-doxazosin-structure.png`
- `assets/chemistry-test/chem-biochem-moved-10-doxazosin-answer.png`
