import { TOPICS } from "./data/topics.js?v=0.9.0";
import { DRUGS } from "./data/drugs.js?v=0.9.0";
import { ABBREVIATIONS } from "./data/abbreviations.js?v=0.9.0";
import { THEORY } from "./data/theory.js?v=0.9.0";
import { MECHANISMS } from "./data/mechanisms.js?v=0.9.0";
import { HIGH_YIELD } from "./data/highYield.js?v=0.9.0";
import { TESTS } from "./data/tests.js?v=0.9.0";
import { TEST_ANALYSES } from "./data/testAnalyses.js?v=0.9.0";
import { SOURCE_SECTIONS } from "./data/sourceSections.js?v=0.9.0";
import { INTERACTIONS } from "./data/interactions.js?v=0.9.0";
import { DRUG_KNOWLEDGE } from "./data/drugKnowledge.js?v=0.9.0";
import { DRUG_PROFILES } from "./data/drugProfiles.js?v=0.9.0";
import { SECTION_VISUALS } from "./data/sectionVisuals.js?v=0.9.0";
import { CARDIO49 } from "./data/cardio49.js?v=0.9.0";
import { STUDY_TABLES } from "./data/studyTables.js?v=0.9.0";

const app = document.getElementById("app");
const topicMap = Object.fromEntries(TOPICS.map(t => [t.id,t]));
const drugMap = Object.fromEntries(DRUGS.map(d => [String(d.n),d]));
const esc = s => String(s ?? "").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));
const UI_SETTINGS_KEY="propharm_ui_settings_v1";
let uiSettings=Object.assign({largeText:false,reducedMotion:false},JSON.parse(localStorage.getItem(UI_SETTINGS_KEY)||"{}"));
function applyUiSettings(){document.documentElement.classList.toggle("largeText",!!uiSettings.largeText);document.documentElement.classList.toggle("reducedMotion",!!uiSettings.reducedMotion);}
applyUiSettings();


function doodleIcon(type){
 const common=`viewBox="0 0 64 64" aria-hidden="true" focusable="false"`;
 const svg=(body)=>`<svg ${common} class="chalkSvg"><g fill="none" stroke="currentColor" stroke-width="3.4" stroke-linecap="round" stroke-linejoin="round">${body}</g></svg>`;
 const map={
  tests:svg(`<path d="M19 12h28a5 5 0 0 1 5 5v36H14V17a5 5 0 0 1 5-5Z"/><path d="M24 9h18v9H24z"/><path d="m21 28 3 3 6-7M21 40l3 3 6-7M35 28h10M35 40h10"/>`),
  theory:svg(`<path d="M8 17c9-5 18-4 25 1v35c-7-5-16-6-25-1V17Z"/><path d="M56 17c-9-5-18-4-23 1v35c7-5 14-6 23-1V17Z"/><path d="M15 27h11M15 35h11M40 27h10M40 35h10"/>`),
  tables:svg(`<rect x="9" y="11" width="46" height="42" rx="6"/><path d="M9 25h46M9 39h46M24 11v42M40 11v42"/>`),
  schemes:svg(`<rect x="25" y="8" width="14" height="12" rx="3"/><rect x="8" y="43" width="18" height="13" rx="4"/><rect x="38" y="43" width="18" height="13" rx="4"/><path d="M32 20v11M17 43v-8h30v8"/>`),
  cards:svg(`<path d="m16 17 31-5 5 30-31 5-5-30Z"/><rect x="11" y="24" width="38" height="28" rx="5"/><circle cx="28" cy="37" r="4"/><path d="M36 34h8M36 41h7"/>`),
  drugs:svg(`<path d="M15 41 39 17a10 10 0 0 1 14 14L29 55a10 10 0 0 1-14-14Z"/><path d="m27 29 15 15"/><path d="M18 45h8M38 19h8"/>`),
  abbr:svg(`<rect x="9" y="10" width="46" height="44" rx="8"/><path d="M17 44 25 21l8 23M20 36h10M40 23h8M40 33h8M40 43h6"/>`),
  settings:svg(`<circle cx="32" cy="32" r="9"/><path d="M32 8v7M32 49v7M8 32h7M49 32h7M15 15l5 5M44 44l5 5M49 15l-5 5M20 44l-5 5"/>`),
  search:svg(`<circle cx="27" cy="27" r="15"/><path d="m38 38 14 14"/>`),
  home:svg(`<path d="m10 30 22-18 22 18v24H39V40H25v14H10V30Z"/>`),
  study:svg(`<path d="M8 17c9-5 18-4 25 1v35c-7-5-16-6-25-1V17ZM56 17c-9-5-18-4-23 1v35c7-5 14-6 23-1V17Z"/>`),
  profile:svg(`<circle cx="32" cy="22" r="9"/><path d="M15 54c2-13 10-19 17-19s15 6 17 19"/>`)
 };
 return map[type]||map.study;
}
function topicIcon(type){
 const common=`viewBox="0 0 64 64" aria-hidden="true" focusable="false"`;
 const wrap=(body)=>`<svg ${common} class="chalkSvg"><g fill="none" stroke="currentColor" stroke-width="3.2" stroke-linecap="round" stroke-linejoin="round">${body}</g></svg>`;
 const m={
  cardio:`<path d="M32 53S11 41 11 25c0-10 13-14 21-4 8-10 21-6 21 4 0 16-21 28-21 28Z"/>`,
  hemostasis:`<path d="M32 8s15 18 15 31a15 15 0 1 1-30 0C17 26 32 8 32 8Z"/>`,
  endocrine:`<circle cx="32" cy="32" r="6"/><path d="M32 9v12M32 43v12M9 32h12M43 32h12M16 16l8 8M40 40l8 8M48 16l-8 8M24 40l-8 8"/>`,
  psych:`<path d="M24 16c-8 2-11 12-6 18-5 5-2 14 6 15 3 6 13 5 15-1 8 1 13-8 8-14 5-7 0-17-8-17-3-6-12-6-15-1Z"/><path d="M32 17v31M24 27h8M32 37h8"/>`,
  neuro:`<path d="m35 7-17 29h13l-2 21 17-31H33l2-19Z"/>`,
  pain:`<path d="M32 8v16M32 40v16M8 32h16M40 32h16M15 15l11 11M38 38l11 11M49 15 38 26M26 38 15 49"/>`,
  infectious:`<circle cx="32" cy="32" r="12"/><path d="M32 8v12M32 44v12M8 32h12M44 32h12M15 15l9 9M40 40l9 9M49 15l-9 9M24 40l-9 9"/>`,
  resp:`<path d="M30 14v19c-8-14-17-10-18 5-1 13 8 17 18 11V33M34 14v19c8-14 17-10 18 5 1 13-8 17-18 11V33"/>`,
  gi:`<path d="M29 10c0 11 8 10 8 18 0 4-4 6-7 4-9-5-17 1-16 11 1 10 9 14 19 11 11-3 17-14 14-24-3-11-13-10-18-20Z"/>`,
  uro:`<path d="M25 13c-9 0-14 9-12 18 2 9 9 13 16 8V18c-1-3-2-5-4-5ZM39 13c9 0 14 9 12 18-2 9-9 13-16 8V18c1-3 2-5 4-5Z"/><path d="M29 39v14M35 39v14"/>`,
  repro:`<circle cx="32" cy="24" r="12"/><path d="M32 36v20M24 48h16"/>`,
  immune:`<path d="M32 8 50 15v14c0 13-8 21-18 27-10-6-18-14-18-27V15L32 8Z"/>`,
  oncology:`<path d="M22 11c17 6 23 18 20 42M42 11C25 17 19 29 22 53"/><path d="M22 26h20M23 40h18"/>`,
  bone:`<path d="M17 22c-7-7-13 2-7 7l20 20c7 7 16-2 9-9L20 21c-1-1-2-1-3 1ZM47 42c7 7 13-2 7-7L34 15c-7-7-16 2-9 9l19 19c1 1 2 1 3-1Z"/>`,
  ophth:`<path d="M7 32s10-15 25-15 25 15 25 15-10 15-25 15S7 32 7 32Z"/><circle cx="32" cy="32" r="7"/>`,
  local:`<path d="M16 46 42 20l8 8-26 26H16v-8Z"/><path d="m37 25 8 8"/>`,
  toxicology:`<path d="M32 8 56 52H8L32 8Z"/><path d="M32 23v14M32 45v1"/>`
 };
 return wrap(m[type]||m.study||`<circle cx="32" cy="32" r="20"/>`);
}

function capsuleLogo(cls="brandCapsuleLogo"){
 return `<svg class="${cls}" viewBox="0 0 120 82" aria-hidden="true" focusable="false">
   <g fill="none" stroke="currentColor" stroke-width="6.2" stroke-linecap="round" stroke-linejoin="round">
     <path d="M13 29c8-13 21-17 32-8l18 15-25 27-18-15c-9-7-10-13-7-19Z"/>
     <path d="M107 29c-8-13-21-17-32-8L57 36l25 27 18-15c9-7 10-13 7-19Z"/>
     <path d="M38 23c4 0 8 2 11 5M82 23c-4 0-8 2-11 5" stroke-width="4.4"/>
   </g>
   <g fill="currentColor">
     <circle cx="56" cy="48" r="3.8"/><circle cx="65" cy="53" r="4.7"/><circle cx="52" cy="58" r="3.3"/>
     <circle cx="62" cy="64" r="3.8"/><circle cx="54" cy="69" r="2.4"/><circle cx="67" cy="73" r="2.4"/>
   </g>
 </svg>`;
}
function header(){return `<div class="topbar innerTopbar chalkTop"><button class="backMini" onclick="history.length>1?history.back():location.hash='#home'">‹</button><div class="brandCompact brandWithLogo">${capsuleLogo("miniCapsuleLogo")}<span><b>ProPharm</b><small>экзаменационная база</small></span></div><div class="topDoodle">•••</div></div>`;}
function bottomNav(active){
 const items=[["home","#home","home","Главная"],["search","#search","search","Поиск"],["study","#topics","study","Учёба"],["profile","#profile","profile","Профиль"]];
 return `<nav class="bottomNav">${items.map(([id,route,ic,t])=>`<button class="navBtn ${active===id?"active":""}" data-route="${route}"><span class="navSketch">${doodleIcon(ic)}</span><span>${t}</span></button>`).join("")}</nav>`;
}
function bindNav(){
 document.querySelectorAll("[data-nav]").forEach(b=>b.addEventListener("click",()=>location.hash=b.dataset.nav==="home"?"#home":`#${b.dataset.nav}`));
 document.querySelectorAll("[data-route]").forEach(el=>el.addEventListener("click",()=>location.hash=el.dataset.route));
}
function countsForTopic(id){return {drugs:DRUGS.filter(d=>d.topics.includes(id)).length,abbr:(ABBREVIATIONS[id]||[]).length,theory:(THEORY[id]||[]).length,mechanisms:(MECHANISMS[id]||[]).length,tests:TESTS.filter(q=>q.topic===id).length,analyses:TEST_ANALYSES.filter(q=>q.topic===id).length,interactions:(INTERACTIONS[id]||[]).length};}

function renderHome(){
 const tiles=[
  ["tests","Тесты","Проверь знания","#tests","lavender"],
  ["theory","Теория","Изучай материал","#theory-hub","blue"],
  ["tables","Таблицы","Важное в системе","#tables","blue"],
  ["cards","Карточки","Запоминай быстрее","#cards","lavender"],
  ["schemes","Схемы","Наглядные механизмы","#schemes","paper"],
  ["drugs","170 препаратов","Единая база","#drugs","blue"],
  ["abbr","Аббревиатуры","По каждой теме","#abbr-hub","lavender"],
  ["settings","Настройки","Подстрой интерфейс","#settings","paper"]
 ];
 app.innerHTML=`<div class="homePage page chalkHome">
   <section class="chalkMasthead">
     <div class="chalkBrand">${capsuleLogo("homeBrandLogo")}<div><div class="chalkBrandName">ProPharm</div><div class="chalkBrandTag">знания лечат ♡</div></div></div>
     <button class="chalkMenu" aria-label="Меню" data-route="#profile">•••</button>
   </section>
   <section class="chalkIntro"><h1>Главная</h1><p>Выбери раздел</p><span class="handNote">маленькие шаги → большие цели ♡</span></section>
   <section class="dashboardGrid chalkGrid">${tiles.map(([ic,title,desc,route,tone])=>`<button class="dashTile chalkTile tone-${tone}" data-route="${route}"><span class="dashIcon">${doodleIcon(ic)}</span><span class="dashText"><b>${title}</b><small>${desc}</small></span></button>`).join("")}</section>
   <div class="chalkFooterNote">учись спокойно · повторяй регулярно · понимай механизмы ♡</div>
 </div>`+bottomNav("home");bindNav();
}
function renderTopics(){
 app.innerHTML=header()+`<div class="page"><div class="sectionTitle"><h2>Темы</h2><span class="muted">${TOPICS.length} разделов</span></div><div class="topicGrid">${TOPICS.map(t=>{const c=countsForTopic(t.id);return `<div class="card clickCard" data-route="#topic/${t.id}"><div class="cardHead"><div class="iconFrame topicLineIcon">${topicIcon(t.id)}</div><div><h3>${esc(t.title)}</h3><p>${esc(t.description)}</p><span class="badge">${c.drugs} препаратов</span>${c.abbr?`<span class="badge">${c.abbr} аббр.</span>`:""}${c.theory?`<span class="badge blue">${c.theory} теория</span>`:""}</div></div></div>`;}).join("")}</div></div>`+bottomNav("study");bindNav();
}
function topicSections(t){const c=countsForTopic(t.id);const defs=[["theory","📘","Теория",c.theory,"Конспекты и интерактивные учебные модули."],["mechanisms","🧬","Механизмы",c.mechanisms,"Сигнальные пути и причинно-следственные цепочки."],["drugs","💊","Препараты",c.drugs,"Препараты, связанные с этой темой."],["abbr","🔤","Аббревиатуры",c.abbr,"Только словарь этой темы — без смешивания."],["interactions","🔗","Взаимодействия",c.interactions,"Лекарственные взаимодействия с механизмом и клиническим следствием."],["tests","📝","Тесты",c.tests,"Вопросы только по выбранной теме."],["analysis","✅","Разбор тестов",c.analyses,"Почему правильный ответ верен и почему остальные неверны."],["high","⚡","High-yield",(HIGH_YIELD[t.id]||[]).length,"Короткий экзаменационный повтор."]];return defs.map(([id,ic,title,count,desc])=>`<div class="card clickCard" data-route="#topic/${t.id}/${id}"><div class="cardHead"><div class="iconFrame">${ic}</div><div><h3>${title}</h3><p>${desc}</p><span class="badge">${count}</span></div></div></div>`).join("");}
function renderTopic(id){const t=topicMap[id];if(!t){location.hash="#topics";return;}app.innerHTML=header()+`<div class="page"><div class="breadcrumb"><button data-route="#topics">Темы</button><span>›</span><span>${esc(t.short)}</span></div><div class="topicHeader"><div class="iconFrame topicLineIcon">${topicIcon(t.id)}</div><div><h2>${esc(t.title)}</h2><p>${esc(t.description)}</p></div></div><div class="sectionGrid">${topicSections(t)}</div></div>`+bottomNav("study");bindNav();}
function sectionShell(t,title,content){return header()+`<div class="page"><div class="breadcrumb"><button data-route="#topics">Темы</button><span>›</span><button data-route="#topic/${t.id}">${esc(t.short)}</button><span>›</span><span>${esc(title)}</span></div><div class="topicHeader"><div class="iconFrame topicLineIcon">${topicIcon(t.id)}</div><div><h2>${esc(title)}</h2><p>${esc(t.title)}</p></div></div>${content}</div>`+bottomNav("study");}

function renderVisual(v){
  if(!v||!v.steps?.length)return "";
  const title=v.title?`<div class="visualTitle">${esc(v.title)}</div>`:"";
  const steps=v.steps.map((x,i)=>`<div class="visualNode"><span class="visualIndex">${i+1}</span><span>${esc(x)}</span></div>${i<v.steps.length-1?'<div class="visualArrow">→</div>':''}`).join("");
  const special=v.kind?` visual-${esc(v.kind)}`:"";
  return `<div class="visualCard${special}">${title}<div class="visualFlow">${steps}</div></div>`;
}
function renderInteractions(t){
  const arr=INTERACTIONS[t.id]||[];
  if(!arr.length)return `<div class="emptyState"><div class="big">🔗</div><b>Взаимодействия пока не заполнены</b><p>Они будут добавляться из комментариев к тестам и теории.</p></div>`;
  return `<div class="list">${arr.map(x=>`<div class="theoryCard"><div class="resultType">${esc(x.type||"Взаимодействие")}</div><h3>${esc(x.title)}</h3><p>${esc(x.summary||"")}</p>${renderVisual({title:"Механизм взаимодействия",kind:"flow",steps:x.chain||[]})}${x.note?`<div class="sourceNote">${esc(x.note)}</div>`:""}</div>`).join("")}</div>`;
}
function renderTopicTheory(t){const items=THEORY[t.id]||[];if(!items.length)return `<div class="emptyState"><div class="big">📘</div><b>Теория пока не заполнена</b><p>Структура уже готова. Следующие конспекты добавим сюда по мере подготовки.</p></div>`;return `<div class="list">${items.map(x=>`<div class="theoryCard"><h3>${esc(x.title)}</h3><p>${esc(x.summary)}</p>${x.type==="interactive"?`<a class="moduleButton" href="${x.url}">📈 Открыть интерактивный модуль</a>`:""}${x.body?.length?`<div class="theoryBody">${x.body.map(v=>`<p>• ${esc(v)}</p>`).join("")}</div>`:""}${renderVisual(x.visual)}</div>`).join("")}</div>`;}
function renderMechanisms(t){const arr=MECHANISMS[t.id]||[];if(!arr.length)return `<div class="emptyState"><div class="big">🧬</div><b>Механизмы пока не заполнены</b><p>Здесь будут схемы receptor → messenger → effect → drug.</p></div>`;return `<div class="list">${arr.map(m=>`<div class="mechanismCard"><h3>${esc(m.title)}</h3><div class="chain">${m.chain.map((v,i)=>`${i?'<div class="chainArrow">→</div>':""}<div class="chainNode">${esc(v)}</div>`).join("")}</div><div class="chips">${m.examples.map(v=>`<span class="chip">${esc(v)}</span>`).join("")}</div></div>`).join("")}</div>`;}
function drugRows(list){return `<div class="list">${list.map(d=>`<div class="drugRow"><div class="drugNum">#${d.n}</div><div class="drugMain" style="flex:1"><b>${esc(d.name)}</b><span>${esc(d.group)}</span><div>${d.topics.map(x=>`<span class="badge">${esc(topicMap[x]?.short||x)}</span>`).join("")}</div></div><button class="drugLink" data-route="#drug/${d.n}">Открыть</button></div>`).join("")}</div>`;}
function renderTopicDrugs(t){const list=DRUGS.filter(d=>d.topics.includes(t.id));return `<div class="toolbar"><input id="topicDrugSearch" placeholder="Поиск в ${esc(t.short)}…"><span class="badge blue">${list.length} препаратов</span></div><div id="topicDrugList">${drugRows(list)}</div>`;}
function abbrRow(a){return `<div class="abbrRow"><b>${esc(a.abbr)}</b><div class="full">${esc(a.full)}</div><div class="ru">${esc(a.ru)}</div><div class="subtopic">${esc(a.subtopic)}</div></div>`;}
function renderAbbr(t){const arr=ABBREVIATIONS[t.id]||[];if(!arr.length)return `<div class="emptyState"><div class="big">🔤</div><b>Словарь этой темы пока не заполнен</b><p>Аббревиатуры будут добавляться внутри темы, а не в один смешанный список.</p></div>`;return `<div class="toolbar"><input id="abbrSearch" placeholder="Поиск по аббревиатурам ${esc(t.short)}…"><span class="badge">${arr.length}</span></div><div id="abbrList" class="list">${arr.map(abbrRow).join("")}</div>`;}
function renderTestsSection(t, analysis=false){
  const arr=(analysis?TEST_ANALYSES:TESTS).filter(x=>x.topic===t.id);
  if(!arr.length) return `<div class="emptyState"><div class="big">${analysis?"✅":"📝"}</div><b>${analysis?"Разборов":"Тестов"} пока нет</b></div>`;
  if(!analysis){
    const sections=SOURCE_SECTIONS.filter(s=>s.topic===t.id);
    return `<div class="card"><h3>Интерактивный тест</h3><p>${arr.length} вопросов из загруженного материала. Результаты сессии нигде не сохраняются.</p>
      <button class="moduleButton" data-start-test="topic:${t.id}">▶ Начать тест по теме (${arr.length})</button></div>
      <div class="sectionTitle"><h2>Блоки источника</h2></div>
      <div class="list">${sections.map(s=>`<div class="theoryCard"><h3>${esc(s.title)}</h3><p>${s.count} вопросов</p><button class="drugLink" data-start-test="section:${s.id}">Начать</button></div>`).join("")}</div>`;
  }
  const qmap=Object.fromEntries(TESTS.map(q=>[q.id,q]));
  return `<div class="list">${arr.map(a=>{
    const q=qmap[a.questionId]; if(!q)return "";
    return `<div class="theoryCard"><div class="resultType">${esc(q.sectionTitle)} · вопрос ${q.number}</div><h3>${esc(q.question)}</h3>
      <div class="answerReview"><b>Правильный ответ: ${esc(q.correct)}. ${esc(q.options.find(o=>o.id===q.correct)?.text||q.correctText||"")}</b></div>
      ${a.explanation?.length?`<div class="reviewText">${a.explanation.map(x=>`<p>${esc(x)}</p>`).join("")}</div>`:""}
      ${q.options.map(o=>`<div class="reviewOption ${o.id===q.correct?"isCorrect":""}"><b>${o.id}. ${esc(o.text)}</b><div>${o.id===q.correct?"Правильный вариант.":esc(a.optionExplanations?.[o.id]||"В исходном материале отдельный комментарий к этому варианту не сохранён.")}</div></div>`).join("")}
      ${renderVisual(q.visual||a.visual||SECTION_VISUALS[q.sectionId])}${a.sourceNotes?.length?`<div class="sourceNote">${a.sourceNotes.map(x=>`<div>⚠ ${esc(x)}</div>`).join("")}</div>`:""}
    </div>`;
  }).join("")}</div>`;
}
function renderHigh(t){const arr=HIGH_YIELD[t.id]||[];if(!arr.length)return `<div class="emptyState"><div class="big">⚡</div><b>High-yield пока не заполнен</b></div>`;return `<div class="list">${arr.map((x,i)=>`<div class="highYieldItem"><b>${i+1}.</b> ${esc(x)}</div>`).join("")}</div>`;}

function renderTopicSection(id,section){const t=topicMap[id];if(!t){location.hash="#topics";return;}const titles={theory:"Теория",mechanisms:"Механизмы",drugs:"Препараты",abbr:"Аббревиатуры",interactions:"Взаимодействия",tests:"Тесты",analysis:"Разбор тестов",high:"High-yield"};let content="";if(section==="theory")content=renderTopicTheory(t);if(section==="mechanisms")content=renderMechanisms(t);if(section==="drugs")content=renderTopicDrugs(t);if(section==="abbr")content=renderAbbr(t);if(section==="interactions")content=renderInteractions(t);if(section==="tests")content=renderTestsSection(t,false);if(section==="analysis")content=renderTestsSection(t,true);if(section==="high")content=renderHigh(t);app.innerHTML=sectionShell(t,titles[section]||section,content);bindNav();bindTestStarters();if(section==="drugs"){const input=document.getElementById("topicDrugSearch"),target=document.getElementById("topicDrugList"),base=DRUGS.filter(d=>d.topics.includes(t.id));input?.addEventListener("input",()=>{const q=input.value.toLowerCase();target.innerHTML=drugRows(base.filter(d=>drugSearchText(d).includes(q)));bindNav();});}if(section==="abbr"){const input=document.getElementById("abbrSearch"),target=document.getElementById("abbrList"),base=ABBREVIATIONS[t.id]||[];input?.addEventListener("input",()=>{const q=input.value.toLowerCase();target.innerHTML=base.filter(a=>(a.abbr+" "+a.full+" "+a.ru+" "+a.subtopic).toLowerCase().includes(q)).map(abbrRow).join("");});}}

function renderAllDrugs(){const options=TOPICS.map(t=>`<option value="${t.id}">${esc(t.short)}</option>`).join("");app.innerHTML=header()+`<div class="page"><div class="sectionTitle"><h2>170 препаратов</h2><span class="muted">единая база</span></div><div class="toolbar"><input id="drugSearch" placeholder="Название или фармгруппа…"><select id="drugTopic"><option value="">Все темы</option>${options}</select></div><div id="allDrugList">${drugRows(DRUGS)}</div></div>`+bottomNav("study");bindNav();const s=document.getElementById("drugSearch"),f=document.getElementById("drugTopic"),out=document.getElementById("allDrugList");const apply=()=>{const q=s.value.toLowerCase(),topic=f.value;const rows=DRUGS.filter(d=>(!q||drugSearchText(d).includes(q))&&(!topic||d.topics.includes(topic)));out.innerHTML=drugRows(rows);bindNav();};s.addEventListener("input",apply);f.addEventListener("change",apply);}

function testCommentForDrug(q,d){
  const a=TEST_ANALYSES.find(x=>x.questionId===q.id);
  const all=[];
  const generic=(a?.explanation||q.explanation||[]).filter(Boolean);
  if(generic.length) all.push(...generic);
  const name=(d.name||"").toLowerCase();
  const comments=Object.entries(a?.optionExplanations||q.optionExplanations||{}).filter(([key,text])=>{
    const opt=q.options?.find(o=>o.id===key)?.text||"";
    const hay=(opt+" "+text).toLowerCase();
    return hay.includes(name) || q.drugIds?.length===1;
  }).map(([key,text])=>`${key}: ${text}`);
  if(comments.length) all.push(...comments);
  return [...new Set(all)].slice(0,6);
}
function renderRelatedTestComments(d,relatedTests){
  if(!relatedTests.length)return `<p class="smallMuted">Пока комментариев из тестов по этому препарату нет.</p>`;
  return `<div class="testCommentList">${relatedTests.slice(0,40).map(q=>{
    const comments=testCommentForDrug(q,d);
    return `<div class="testCommentCard"><div class="resultType">${esc(q.sectionTitle)} · №${q.number}</div>${comments.length?comments.map(x=>`<p>Комментарий: ${esc(x)}</p>`).join(""):`<p>Комментарий: ${esc((q.explanation||[]).join(" ")||"Вопрос связан с препаратом, но отдельный текстовый комментарий в источнике не сохранён.")}</p>`}</div>`;
  }).join("")}</div>`;
}
function renderDrug(n){
  const d=drugMap[String(n)];if(!d){location.hash="#drugs";return;}
  const p=profileFor(d),cardio=CARDIO49[d.name],k=DRUG_KNOWLEDGE[String(d.n)],relatedTests=TESTS.filter(q=>q.drugIds?.includes(d.n));
  const relatedInteractions=Object.entries(INTERACTIONS).flatMap(([topic,arr])=>arr.map(x=>({...x,topic}))).filter(x=>x.drugIds?.includes(d.n));
  const sourceScheme=p?.schemeSteps?.length?renderVisual({title:"Схема механизма",kind:"flow",steps:p.schemeSteps}):"";
  app.innerHTML=header()+`<div class="page drugDetail">
    <div class="breadcrumb"><button data-route="#drugs">170 препаратов</button><span>›</span><span>#${d.n}</span></div>
    <div class="topicHeader"><div class="iconFrame">Rx</div><div><h2>${esc(p?.mnn||d.name)}</h2><p>${esc(p?.groupSource||d.group)}</p><div class="chips"><span class="badge blue">№ ${d.n}</span>${d.topics.map(x=>`<span class="badge">${esc(topicMap[x]?.short||x)}</span>`).join("")}</div></div></div>

    <div class="sourceNote profileSourceWarning"><b>Учебная карточка ProPharm v1.0.</b> Данные перенесены из загруженной базы. Точные регуляторные формулировки и PK-числа в исходнике отмечены как требующие второго прохода сверки по Israeli Drug Registry, FDA/Drugs@FDA и ГРЛС.</div>

    <div class="drugProfileAccordion">
      ${profileSection("Основная информация",p?.basic,"i")}
      ${profileSection("Показания к применению",p?.indications,"+")}
      ${profileSection("Противопоказания и ограничения",p?.contraindications,"!")}
      ${p?.mechanismText?`<details class="drugProfileSection" open><summary><span><span class="profileSectionIcon">→</span>Механизм действия</span><span class="schemePlus">＋</span></summary><div class="drugProfileBody"><p>${esc(p.mechanismText)}</p>${sourceScheme}</div></details>`:""}
      ${profileSection("Способы применения",p?.routes,"↗")}
      ${profileSection("Фармакодинамика",p?.pharmacodynamics,"PD")}
      ${profileSection("Фармакокинетика",p?.pharmacokinetics,"PK")}
      ${profileSection("Побочные эффекты",p?.adverseEffects,"⚠")}
      ${renderProfileInteractions(p)}
      ${profileSection("Особые ситуации",p?.specialSituations,"★")}
      ${profileSection("Источники для верификации",p?.sources,"≡")}
    </div>

    ${k?`<div class="detailBox"><h3>Дополнительные экзаменационные комментарии</h3>${k.pearls?.map(x=>`<p>• ${esc(x)}</p>`).join("")||""}${k.visual?renderVisual(k.visual):""}</div>`:""}
    ${cardio?`<div class="detailBox noteCardio"><h3>Связь с электрофизиологией ССС</h3><p>${esc(cardio.note)}</p><a class="moduleButton" href="modules/cardio/index.html">Открыть Cardio-модуль</a></div>`:""}
    ${relatedInteractions.length?`<div class="detailBox"><h3>Дополнительные взаимодействия из тестовой базы</h3>${relatedInteractions.map(x=>`<div class="interactionMini"><b>${esc(x.title)}</b><div>${esc(x.summary)}</div>${renderVisual({title:"Механизм",kind:"flow",steps:x.chain||[]})}</div>`).join("")}</div>`:""}
    <div class="detailBox"><h3>Комментарии из связанных тестов</h3><p class="smallMuted">Сам вопрос здесь не дублируется — показаны только учебные комментарии.</p>${renderRelatedTestComments(d,relatedTests)}</div>
  </div>`+bottomNav("study");bindNav();
}
function renderTests(){
  const topicCounts=TOPICS.map(t=>({...t,count:TESTS.filter(q=>q.topic===t.id).length})).filter(x=>x.count>0);
  app.innerHTML=header()+`<div class="page"><section class="hero"><h2>Экзаменационные тесты</h2><p>${TESTS.length} вопросов из двух загруженных блоков. Неправильный ответ → подсказка → повторная попытка; после правильного ответа — комментарии ко всем вариантам и схема.</p><div class="stats"><div class="stat"><b>${TESTS.length}</b><span>вопросов</span></div><div class="stat"><b>${SOURCE_SECTIONS.length}</b><span>блоков</span></div><div class="stat"><b>${topicCounts.length}</b><span>тем с тестами</span></div><div class="stat"><b>0</b><span>история не хранится</span></div></div><div class="warn">Результаты существуют только в текущей открытой сессии и не записываются в localStorage/cookies.</div></section>
  <div class="sectionTitle"><h2>Начать</h2></div><div class="sectionGrid"><div class="card clickCard"><div class="cardHead"><div class="iconFrame">🎯</div><div><h3>Все вопросы</h3><p>${TESTS.length} подряд.</p><button class="moduleButton" data-start-test="all">Начать</button></div></div></div>${topicCounts.map(t=>`<div class="card clickCard"><div class="cardHead"><div class="iconFrame topicLineIcon">${topicIcon(t.id)}</div><div><h3>${esc(t.short)}</h3><p>${t.count} вопросов.</p><button class="moduleButton" data-start-test="topic:${t.id}">Начать</button></div></div></div>`).join("")}</div>
  <div class="sectionTitle"><h2>По блокам источника</h2></div><div class="list">${SOURCE_SECTIONS.map(s=>`<div class="theoryCard"><div class="resultType">${esc(topicMap[s.topic]?.short||s.topic)}</div><h3>${esc(s.title)}</h3><p>${s.count} вопросов</p><button class="drugLink" data-start-test="section:${s.id}">Начать тест</button></div>`).join("")}</div></div>`+bottomNav("study");bindNav();bindTestStarters();
}
function renderSearch(){app.innerHTML=header()+`<div class="page"><div class="sectionTitle"><h2>Глобальный поиск</h2></div><input id="globalSearch" placeholder="Например: SERCA, metoprolol, QT, SGLT2…"><div id="globalResults" class="globalResults" style="margin-top:10px"><div class="emptyState"><div class="big">🔎</div><b>Начни вводить запрос</b><p>Поиск идёт по препаратам, аббревиатурам и теоретическим модулям.</p></div></div></div>`+bottomNav("search");bindNav();const input=document.getElementById("globalSearch"),out=document.getElementById("globalResults");input.addEventListener("input",()=>{const q=input.value.trim().toLowerCase();if(!q){out.innerHTML=`<div class="emptyState"><div class="big">🔎</div><b>Начни вводить запрос</b></div>`;return;}const dr=DRUGS.filter(d=>drugSearchText(d).includes(q)).slice(0,20);const ab=Object.entries(ABBREVIATIONS).flatMap(([topic,arr])=>arr.map(a=>({...a,topic}))).filter(a=>(a.abbr+" "+a.full+" "+a.ru+" "+a.subtopic).toLowerCase().includes(q)).slice(0,20);const th=Object.entries(THEORY).flatMap(([topic,arr])=>arr.map(x=>({...x,topic}))).filter(x=>(x.title+" "+x.summary).toLowerCase().includes(q)).slice(0,20);const html=[...dr.map(d=>`<div class="drugRow"><div><div class="resultType">Препарат</div><b>${esc(d.name)}</b><div class="smallMuted">${esc(d.group)}</div></div><button class="drugLink" data-route="#drug/${d.n}">Открыть</button></div>`),...ab.map(a=>`<div class="abbrRow"><div class="resultType">Аббревиатура · ${esc(topicMap[a.topic]?.short||a.topic)}</div><b>${esc(a.abbr)}</b><div class="ru">${esc(a.ru)}</div></div>`),...th.map(x=>`<div class="theoryCard"><div class="resultType">Теория · ${esc(topicMap[x.topic]?.short||x.topic)}</div><h3>${esc(x.title)}</h3><p>${esc(x.summary)}</p></div>`)].join("");out.innerHTML=html||`<div class="emptyState"><b>Ничего не найдено</b></div>`;bindNav();});}

function renderTheoryHub(){
 const groups=TOPICS.map(t=>({t,items:THEORY[t.id]||[]})).filter(x=>x.items.length);
 app.innerHTML=header()+`<div class="page"><div class="paperTitle"><span class="handMini">Учёба</span><h2>Теория</h2><p>Конспекты по темам, без смешивания разделов.</p></div><div class="topicGrid">${groups.map(({t,items})=>`<div class="card clickCard softPaper" data-route="#topic/${t.id}/theory"><div class="cardHead"><div class="iconFrame topicLineIcon">${topicIcon(t.id)}</div><div><h3>${esc(t.title)}</h3><p>${items.length} материалов</p><span class="badge blue">открыть теорию</span></div></div></div>`).join("")}</div></div>`+bottomNav("study");bindNav();
}
function renderTablesHub(){
 const topics=TOPICS.map(t=>({t,tables:STUDY_TABLES[t.id]||[]})).filter(x=>x.tables.length);
 const tableHtml=tbl=>`<div class="studyTableCard"><div class="resultType">${esc(tbl.type||"Теоретический материал")}</div><h3>${esc(tbl.title)}</h3><div class="tableScroll"><table><thead><tr>${tbl.columns.map(c=>`<th>${esc(c)}</th>`).join("")}</tr></thead><tbody>${tbl.rows.map(r=>`<tr>${r.map(c=>`<td>${esc(c)}</td>`).join("")}</tr>`).join("")}</tbody></table></div>${tbl.note?`<div class="tableNote">${esc(tbl.note)}</div>`:""}</div>`;
 app.innerHTML=header()+`<div class="page"><div class="paperTitle"><span class="handMini">Быстрый повтор</span><h2>Таблицы</h2><p>Только учебные таблицы: стандарты, классификации и теоретические сравнения. Статистика сайта сюда больше не выводится.</p></div>
 <div class="list">${topics.map(({t,tables})=>`<section class="tableTopicBlock"><div class="sectionTitle"><h2>${t.icon} ${esc(t.title)}</h2><span class="muted">${tables.length}</span></div>${tables.map(tableHtml).join("")}</section>`).join("")}</div></div>`+bottomNav("study");bindNav();
}
function schemeGroups(){
 const out={};
 const add=(topic,item)=>{if(!out[topic])out[topic]=[];const key=(item.title+"|"+(item.steps||[]).join("|")).toLowerCase();if(!out[topic].some(x=>x._key===key))out[topic].push({...item,_key:key});};
 TOPICS.forEach(t=>{
   (THEORY[t.id]||[]).forEach(x=>{if(x.visual?.steps?.length)add(t.id,{title:x.visual.title||x.title,kind:x.visual.kind||"flow",steps:x.visual.steps,explanation:x.summary,details:x.body||[],examples:[]});});
   (MECHANISMS[t.id]||[]).forEach(m=>add(t.id,{title:m.title,kind:"flow",steps:m.chain||[],explanation:`Механизм: ${(m.chain||[]).join(" → ")}.`,details:[],examples:m.examples||[]}));
   (INTERACTIONS[t.id]||[]).forEach(x=>add(t.id,{title:`Взаимодействие: ${x.title}`,kind:"flow",steps:x.chain||[],explanation:x.summary||"Лекарственное взаимодействие из тестовой/теоретической базы.",details:x.note?[x.note]:[],examples:[]}));
 });
 SOURCE_SECTIONS.forEach(sec=>{const v=SECTION_VISUALS[sec.id];if(v?.steps?.length)add(sec.topic,{title:`${sec.title}: ${v.title}`,kind:v.kind||"flow",steps:v.steps,explanation:`Схема к экзаменационному блоку «${sec.title}».`,details:[],examples:[]});});
 DRUGS.forEach(d=>{const p=profileFor(d);if(p?.schemeSteps?.length)add(d.primaryTopic||d.topics?.[0]||"",{title:`${d.name}: механизм действия`,kind:"flow",steps:p.schemeSteps,explanation:p.mechanismText||p.scheme,details:p.pharmacodynamics?[`Фармакодинамика: ${p.pharmacodynamics}`]:[],examples:[d.name]});});
 return out;
}
function renderSchemesHub(){
 const groups=schemeGroups();
 const topics=TOPICS.map(t=>({t,items:groups[t.id]||[]})).filter(x=>x.items.length);
 app.innerHTML=header()+`<div class="page"><div class="paperTitle"><span class="handMini">Наглядно</span><h2>Схемы</h2><p>Выбери тему → затем название схемы → раскрой блок. Внутри будет сама схема и текстовое пояснение.</p></div><div class="topicGrid">${topics.map(({t,items})=>`<div class="card clickCard softPaper" data-route="#schemes/${t.id}"><div class="cardHead"><div class="iconFrame topicLineIcon">${topicIcon(t.id)}</div><div><h3>${esc(t.title)}</h3><p>${items.length} схем</p><span class="badge blue">открыть схемы</span></div></div></div>`).join("")}</div></div>`+bottomNav("study");bindNav();
}
function renderSchemesTopic(topicId){
 const t=topicMap[topicId];if(!t){location.hash="#schemes";return;}
 const items=schemeGroups()[topicId]||[];
 app.innerHTML=header()+`<div class="page"><div class="breadcrumb"><button data-route="#schemes">Схемы</button><span>›</span><span>${esc(t.short)}</span></div><div class="topicHeader"><div class="iconFrame topicLineIcon">${topicIcon(t.id)}</div><div><h2>Схемы: ${esc(t.title)}</h2><p>Нажми на название, чтобы раскрыть схему и пояснение.</p></div></div><div class="schemeAccordionList">${items.map((x,i)=>`<details class="schemeAccordion" ${i===0?"open":""}><summary><span>${esc(x.title)}</span><span class="schemePlus">＋</span></summary><div class="schemeAccordionBody">${renderVisual({title:x.title,kind:x.kind,steps:x.steps})}<div class="schemeExplanation"><h4>Пояснение</h4><p>${esc(x.explanation||"")}</p>${x.details?.length?x.details.map(d=>`<p>• ${esc(d)}</p>`).join(""):""}${x.examples?.length?`<div class="chips"><span class="smallMuted">Примеры:</span>${x.examples.map(v=>`<span class="chip">${esc(v)}</span>`).join("")}</div>`:""}</div></div></details>`).join("")}</div></div>`+bottomNav("study");bindNav();
}
let flashIndex=0,flashRevealed=false,flashFilter="all",flashQuery="";
function buildFlashCards(){
 const cards=[];
 DRUGS.forEach(d=>{
   const p=profileFor(d);
   cards.push({type:"drug",topic:d.primaryTopic||d.topics?.[0]||"",drugId:d.n,title:d.name,front:`К какой фармакологической группе относится ${d.name}?`,back:[p?.groupSource||d.group,`Темы: ${d.topics.map(x=>topicMap[x]?.short||x).join(", ")}`]});
   if(p?.mechanismText)cards.push({type:"profileMechanism",topic:d.primaryTopic||d.topics?.[0]||"",drugId:d.n,title:d.name,front:`Механизм действия ${d.name}`,back:[p.mechanismText]});
   if(p?.indications)cards.push({type:"indications",topic:d.primaryTopic||d.topics?.[0]||"",drugId:d.n,title:d.name,front:`Основные показания ${d.name}`,back:[p.indications]});
   if(p?.pharmacokinetics)cards.push({type:"pk",topic:d.primaryTopic||d.topics?.[0]||"",drugId:d.n,title:d.name,front:`Что важно помнить о фармакокинетике ${d.name}?`,back:[p.pharmacokinetics]});
   if(p?.adverseEffects)cards.push({type:"adverse",topic:d.primaryTopic||d.topics?.[0]||"",drugId:d.n,title:d.name,front:`Основные побочные эффекты ${d.name}`,back:[p.adverseEffects]});
   if(p?.interactionsText)cards.push({type:"profileInteraction",topic:d.primaryTopic||d.topics?.[0]||"",drugId:d.n,title:d.name,front:`Ключевые взаимодействия ${d.name}`,back:[p.interactionsText]});
   const k=DRUG_KNOWLEDGE[String(d.n)];
   if(k?.mechanism?.length)cards.push({type:"mechanism",topic:d.primaryTopic||d.topics?.[0]||"",drugId:d.n,title:d.name,front:`Каков механизм действия ${d.name}?`,back:k.mechanism});
   if(k?.pearls?.length)k.pearls.forEach((p,i)=>cards.push({type:"pearl",topic:d.primaryTopic||d.topics?.[0]||"",drugId:d.n,title:d.name,front:`Что важно помнить о ${d.name}? · карточка ${i+1}`,back:[p]}));
 });
 TESTS.forEach(q=>{
   (q.drugIds||[]).forEach(drugId=>{
     const d=drugMap[String(drugId)];if(!d)return;
     const correct=q.options?.find(o=>o.id===q.correct);
     cards.push({type:"test",topic:q.topic||d.primaryTopic,drugId,title:d.name,front:q.question,back:[`Правильный ответ: ${q.correct}. ${correct?.text||q.correctText||""}`,...(q.explanation||[])]});
     Object.entries(q.optionExplanations||{}).forEach(([oid,comment])=>{
       const opt=q.options?.find(o=>o.id===oid);
       if(!comment||!opt)return;
       cards.push({type:"comment",topic:q.topic||d.primaryTopic,drugId,title:d.name,front:`Комментарий к варианту ${oid} в вопросе про ${d.name}: «${opt.text}»`,back:[comment]});
     });
   });
 });
 return cards;
}
function filteredFlashCards(){
 const all=buildFlashCards();
 return all.filter(c=>(flashFilter==="all"||c.type===flashFilter)&&(!flashQuery||(c.title+" "+c.front+" "+c.back.join(" ")).toLowerCase().includes(flashQuery.toLowerCase())));
}
function renderCardsHub(){
 const cards=filteredFlashCards();
 if(flashIndex>=cards.length)flashIndex=0;
 const d=cards[flashIndex];
 const typeNames={drug:"Фармгруппа",profileMechanism:"Механизм из базы 170",indications:"Показания",pk:"Фармакокинетика",adverse:"Побочные эффекты",profileInteraction:"Взаимодействия",mechanism:"Механизм из тестов",pearl:"Экзаменационный комментарий",test:"Вопрос из теста",comment:"Комментарий к варианту"};
 app.innerHTML=header()+`<div class="page"><div class="paperTitle"><span class="handMini">Повторение</span><h2>Карточки</h2><p>Карточки формируются из 170 препаратов, механизмов, тестовых вопросов и комментариев к вариантам.</p></div>
 <div class="flashToolbar"><input id="flashSearch" value="${esc(flashQuery)}" placeholder="Поиск препарата или текста…"><select id="flashType"><option value="all">Все типы</option>${Object.entries(typeNames).map(([k,v])=>`<option value="${k}" ${flashFilter===k?"selected":""}>${v}</option>`).join("")}</select></div>
 <div class="flashStats"><span class="badge blue">${cards.length} карточек</span><span class="badge">ничего не сохраняется</span></div>
 ${d?`<div class="flashWrap"><button class="flashCard ${flashRevealed?"revealed":""}" id="flashCard"><span class="flashNum">${esc(typeNames[d.type]||d.type)} · #${d.drugId||""}</span><h2>${esc(d.title)}</h2>${flashRevealed?`<div class="flashAnswer">${d.back.map(x=>`<p>${esc(x)}</p>`).join("")}</div>`:`<p>${esc(d.front)}</p><span class="handMini">нажми, чтобы перевернуть ↻</span>`}</button><div class="flashControls"><button id="prevCard">← Назад</button><span>${flashIndex+1} / ${cards.length}</span><button id="nextCard">Дальше →</button></div></div>`:`<div class="emptyState"><div class="big">🗂️</div><b>Нет карточек по выбранному фильтру</b></div>`}</div>`+bottomNav("study");bindNav();
 const search=document.getElementById("flashSearch"),type=document.getElementById("flashType");
 search.oninput=e=>{flashQuery=e.target.value;flashIndex=0;flashRevealed=false;clearTimeout(window.__flashTimer);window.__flashTimer=setTimeout(renderCardsHub,180)};
 type.onchange=e=>{flashFilter=e.target.value;flashIndex=0;flashRevealed=false;renderCardsHub()};
 if(d){document.getElementById("flashCard").onclick=()=>{flashRevealed=!flashRevealed;renderCardsHub()};document.getElementById("prevCard").onclick=()=>{flashIndex=(flashIndex-1+cards.length)%cards.length;flashRevealed=false;renderCardsHub()};document.getElementById("nextCard").onclick=()=>{flashIndex=(flashIndex+1)%cards.length;flashRevealed=false;renderCardsHub()};}
}
function renderSettingsHub(){
 app.innerHTML=header()+`<div class="page"><div class="paperTitle"><span class="handMini">Под себя</span><h2>Настройки</h2><p>Настройки интерфейса не затрагивают результаты тестов.</p></div><div class="settingsList"><label class="settingRow"><span><b>Крупный текст</b><small>Увеличить шрифт интерфейса</small></span><input type="checkbox" id="largeText" ${uiSettings.largeText?"checked":""}></label><label class="settingRow"><span><b>Меньше анимаций</b><small>Уменьшить движение элементов</small></span><input type="checkbox" id="reducedMotion" ${uiSettings.reducedMotion?"checked":""}></label></div></div>`+bottomNav("profile");bindNav();
 document.getElementById("largeText").onchange=e=>{uiSettings.largeText=e.target.checked;localStorage.setItem(UI_SETTINGS_KEY,JSON.stringify(uiSettings));applyUiSettings()};
 document.getElementById("reducedMotion").onchange=e=>{uiSettings.reducedMotion=e.target.checked;localStorage.setItem(UI_SETTINGS_KEY,JSON.stringify(uiSettings));applyUiSettings()};
}
function renderAbbrHub(){
 const groups=TOPICS.map(t=>({t,items:ABBREVIATIONS[t.id]||[]})).filter(x=>x.items.length);
 app.innerHTML=header()+`<div class="page"><div class="paperTitle"><span class="handMini">Словарь</span><h2>Аббревиатуры</h2><p>Каждый словарь хранится отдельно внутри своей темы.</p></div><div class="topicGrid">${groups.map(({t,items})=>`<div class="card clickCard softPaper" data-route="#topic/${t.id}/abbr"><div class="cardHead"><div class="iconFrame topicLineIcon">${topicIcon(t.id)}</div><div><h3>${esc(t.title)}</h3><p>${items.length} сокращений</p><span class="badge blue">открыть словарь</span></div></div></div>`).join("")}</div></div>`+bottomNav("study");bindNav();
}
function renderProfile(){
 app.innerHTML=header()+`<div class="page"><div class="paperTitle"><span class="handMini">Мой ProPharm</span><h2>Профиль</h2><p>Быстрый доступ к учебной базе и настройкам. История тестов и прогресс не сохраняются.</p></div><div class="sectionGrid profileGrid"><div class="card clickCard" data-route="#settings"><div class="cardHead"><div class="iconFrame">⚙</div><div><h3>Настройки</h3><p>Размер текста и анимации</p></div></div></div><div class="card clickCard" data-route="#drugs"><div class="cardHead"><div class="iconFrame">💊</div><div><h3>170 препаратов</h3><p>Полная экзаменационная база</p></div></div></div><div class="card clickCard" data-route="#abbr-hub"><div class="cardHead"><div class="iconFrame">🔤</div><div><h3>Аббревиатуры</h3><p>По темам, без смешивания</p></div></div></div><div class="card clickCard" data-route="#tests"><div class="cardHead"><div class="iconFrame">📝</div><div><h3>Тесты</h3><p>${TESTS.length} вопросов; результаты только в текущей сессии</p></div></div></div></div></div>`+bottomNav("profile");bindNav();
}

let testSession=null;

function bindTestStarters(){
  document.querySelectorAll("[data-start-test]").forEach(b=>b.addEventListener("click",()=>startTestSession(b.dataset.startTest)));
}

function startTestSession(spec){
  let questions=[...TESTS];
  if(spec?.startsWith("topic:")) {
    const topicId=spec.slice("topic:".length);
    questions=questions.filter(q=>q.topic===topicId);
  }
  if(spec?.startsWith("section:")) {
    const sectionId=spec.slice("section:".length);
    questions=questions.filter(q=>q.sectionId===sectionId);
  }
  if(!questions.length){
    const knownSections=[...new Set(TESTS.map(q=>q.sectionId))].filter(Boolean);
    console.error("ProPharm: test selection returned 0 questions", {spec,total:TESTS.length,knownSections});
    alert(`Не удалось загрузить вопросы для этого блока. Всего в базе сейчас: ${TESTS.length}. Обнови страницу — если ошибка повторится, это проблема кэша.`);
    return;
  }
  testSession={
    questions, index:0, firstTryCorrect:0, retriedQuestions:0, extraWrongAttempts:0,
    currentWrong:[], errors:[], answered:0
  };
  if(location.hash==="#quiz") renderQuiz();
  else location.hash="#quiz";
}

function currentQuestion(){return testSession?.questions?.[testSession.index]}

function renderQuiz(){
  if(!testSession){location.hash="#tests";return;}
  if(!testSession.questions?.length){
    console.error("ProPharm: attempted to render an empty test session");
    testSession=null;
    location.hash="#tests";
    return;
  }
  if(testSession.index>=testSession.questions.length){renderQuizResults();return;}
  const q=currentQuestion();
  const progress=Math.round((testSession.index/testSession.questions.length)*100);
  app.innerHTML=header()+`<div class="page quizPage">
    <div class="quizTop"><button class="quizExit" id="quizExit">✕ Закрыть</button><div class="quizCount">${testSession.index+1} / ${testSession.questions.length}</div></div>
    <div class="progressTrack"><div class="progressFill" style="width:${progress}%"></div></div>
    <div class="card quizCard">
      <div class="resultType">${esc(q.sectionTitle)} · вопрос ${q.number}</div>
      <h2>${esc(q.question)}</h2>
      ${q.disputed?`<div class="sourceNote">⚠ В исходном материале этот вопрос отмечен как спорный/исправленный. После ответа покажу примечание.</div>`:""}
      <div class="quizOptions">${q.options.map(o=>`<button class="quizOption" data-option="${o.id}"><span class="optionLetter">${o.id}</span><span>${esc(o.text)}</span></button>`).join("")}</div>
      <div class="smallMuted" style="margin-top:10px">Если ошибёшься, получишь подсказку и сможешь отвечать снова до правильного варианта.</div>
    </div>
  </div>`;
  document.getElementById("quizExit").addEventListener("click",()=>{testSession=null;location.hash="#tests";});
  document.querySelectorAll(".quizOption").forEach(b=>b.addEventListener("click",()=>handleQuizAnswer(b.dataset.option,b)));
}

function handleQuizAnswer(optionId,button){
  const q=currentQuestion();
  if(!q||button.disabled)return;
  if(optionId===q.correct){
    button.classList.add("correctAnswer");
    document.querySelectorAll(".quizOption").forEach(x=>x.disabled=true);
    if(testSession.currentWrong.length===0)testSession.firstTryCorrect++;
    else testSession.retriedQuestions++;
    testSession.answered++;
    showExplanationModal(q);
  }else{
    button.classList.add("wrongAnswer"); button.disabled=true;
    testSession.currentWrong.push(optionId);
    testSession.extraWrongAttempts++;
    let err=testSession.errors.find(e=>e.questionId===q.id);
    if(!err){err={questionId:q.id,sectionTitle:q.sectionTitle,number:q.number,question:q.question,wrong:[],correct:q.correct,correctText:q.options.find(o=>o.id===q.correct)?.text||q.correctText};testSession.errors.push(err);}
    err.wrong.push({id:optionId,text:q.options.find(o=>o.id===optionId)?.text||""});
    showHintModal(q,optionId);
  }
}

function modalShell(inner){
  const el=document.createElement("div"); el.className="modalBackdrop"; el.innerHTML=`<div class="modalSheet">${inner}</div>`; document.body.appendChild(el); return el;
}

function showHintModal(q,optionId){
  const wrong=q.options.find(o=>o.id===optionId);
  const modal=modalShell(`<div class="modalHandle"></div><div class="modalIcon bad">✕</div><h2>Пока неверно</h2><p class="modalWrong"><b>${esc(optionId)}. ${esc(wrong?.text||"")}</b></p><div class="hintBox"><b>Подсказка</b><p>${esc(q.hint)}</p></div><button class="modalPrimary" id="hintClose">Попробовать ещё раз</button>`);
  modal.querySelector("#hintClose").addEventListener("click",()=>modal.remove());
}

function showExplanationModal(q){
  const main=q.explanation?.length?q.explanation.map(x=>`<p>${esc(x)}</p>`).join(""):`<p>Правильный ответ указан в исходном материале.</p>`;
  const opts=q.options.map(o=>{
    const isCorrect=o.id===q.correct;
    const exp=isCorrect?esc(q.optionExplanations?.[o.id]||q.explanation?.join(" ")||"Правильный вариант."):esc(q.optionExplanations?.[o.id]||"В исходном материале отдельный комментарий к этому варианту не сохранён.");
    return `<div class="explainOption ${isCorrect?"good":"badLine"}"><b>${o.id}. ${esc(o.text)}</b><div>${exp}</div></div>`;
  }).join("");
  const notes=q.sourceNotes?.length?`<div class="sourceNote">${q.sourceNotes.map(x=>`<div>⚠ ${esc(x)}</div>`).join("")}</div>`:"";
  const modal=modalShell(`<div class="modalHandle"></div><div class="modalIcon good">✓</div><h2>Правильно</h2><div class="correctBanner"><b>${esc(q.correct)}. ${esc(q.options.find(o=>o.id===q.correct)?.text||q.correctText||"")}</b></div><div class="explanationText">${main}</div><h3>Разбор всех вариантов</h3>${opts}${renderVisual(q.visual||SECTION_VISUALS[q.sectionId])}${notes}<button class="modalPrimary" id="nextQuestion">${testSession.index+1>=testSession.questions.length?"Показать результат":"Следующий вопрос"}</button>`);
  modal.querySelector("#nextQuestion").addEventListener("click",()=>{
    modal.remove(); testSession.index++; testSession.currentWrong=[]; renderQuiz();
  });
}

function normText(s){return String(s||"").toLowerCase().replace(/[^a-zа-я0-9]+/g," ").trim()}

function renderQuizResults(){
  const s=testSession;if(!s){location.hash="#tests";return;}
  const total=s.questions.length;
  app.innerHTML=header()+`<div class="page">
    <section class="hero"><h2>Результат сессии</h2><p>Эта статистика не сохраняется. После закрытия страницы/сессии она исчезнет.</p>
      <div class="stats"><div class="stat"><b>${total}</b><span>вопросов</span></div><div class="stat"><b>${s.firstTryCorrect}</b><span>с 1-й попытки</span></div><div class="stat"><b>${s.retriedQuestions}</b><span>потребовалась ещё попытка</span></div><div class="stat"><b>${s.extraWrongAttempts}</b><span>лишних неверных выборов</span></div></div>
    </section>
    <div class="sectionTitle"><h2>Где были ошибки</h2><span class="muted">${s.errors.length} вопросов</span></div>
    ${s.errors.length?`<div class="list">${s.errors.map(e=>`<div class="theoryCard"><div class="resultType">${esc(e.sectionTitle)} · вопрос ${e.number}</div><h3>${esc(e.question)}</h3><div class="errorChoices"><b>Неверные попытки:</b>${e.wrong.map(w=>`<div class="wrongMini">✕ ${esc(w.id)}. ${esc(w.text)}</div>`).join("")}</div><div class="rightMini">✓ Правильно: ${esc(e.correct)}. ${esc(e.correctText)}</div></div>`).join("")}</div>`:`<div class="emptyState"><div class="big">🏆</div><b>Ни одной ошибки</b><p>Все вопросы были отвечены правильно с первой попытки.</p></div>`}
    <button class="moduleButton" id="closeResults">Закрыть результаты</button>
  </div>`;
  document.getElementById("closeResults").addEventListener("click",()=>{testSession=null;location.hash="#tests";});
}
function router(){const h=(location.hash||"#home").slice(1),parts=h.split("/");if(parts[0]==="home"||!parts[0])return renderHome();if(parts[0]==="topics")return renderTopics();if(parts[0]==="topic"&&parts.length===2)return renderTopic(parts[1]);if(parts[0]==="topic"&&parts.length>=3)return renderTopicSection(parts[1],parts[2]);if(parts[0]==="drugs")return renderAllDrugs();if(parts[0]==="drug")return renderDrug(parts[1]);if(parts[0]==="tests")return renderTests();if(parts[0]==="quiz")return renderQuiz();if(parts[0]==="search")return renderSearch();if(parts[0]==="theory-hub")return renderTheoryHub();if(parts[0]==="tables")return renderTablesHub();if(parts[0]==="schemes"&&parts.length===1)return renderSchemesHub();if(parts[0]==="schemes"&&parts.length>=2)return renderSchemesTopic(parts[1]);if(parts[0]==="cards")return renderCardsHub();if(parts[0]==="abbr-hub")return renderAbbrHub();if(parts[0]==="settings")return renderSettingsHub();if(parts[0]==="profile")return renderProfile();renderHome();}
window.addEventListener("hashchange",router);router();
