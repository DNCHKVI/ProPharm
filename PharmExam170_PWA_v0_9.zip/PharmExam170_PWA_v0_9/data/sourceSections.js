export const SOURCE_SECTIONS = [
  {
    "id": "heart-failure",
    "title": "I. СЕРДЕЧНАЯ НЕДОСТАТОЧНОСТЬ",
    "count": 7,
    "topic": "cardio"
  },
  {
    "id": "hypertension",
    "title": "II. АРТЕРИАЛЬНАЯ ГИПЕРТЕНЗИЯ, β-БЛОКАТОРЫ, ДИУРЕТИКИ И CCB",
    "count": 21,
    "topic": "cardio"
  },
  {
    "id": "ihd-acs",
    "title": "III. ИШЕМИЧЕСКАЯ БОЛЕЗНЬ СЕРДЦА, НИТРАТЫ И ОСТРЫЙ КОРОНАРНЫЙ СИНДРОМ",
    "count": 11,
    "topic": "cardio"
  },
  {
    "id": "antiarrhythmics",
    "title": "IV. АНТИАРИТМИЧЕСКИЕ ПРЕПАРАТЫ И ЭЛЕКТРОФИЗИОЛОГИЯ СЕРДЦА",
    "count": 11,
    "topic": "cardio"
  },
  {
    "id": "af",
    "title": "IV. АНТИАРИТМИЧЕСКИЕ ПРЕПАРАТЫ И ФИБРИЛЛЯЦИЯ ПРЕДСЕРДИЙ",
    "count": 9,
    "topic": "cardio"
  },
  {
    "id": "hemostasis",
    "title": "V. АНТИАГРЕГАНТЫ И АНТИКОАГУЛЯНТЫ",
    "count": 11,
    "topic": "hemostasis"
  },
  {
    "id": "cardiac-basics",
    "title": "VI. БАЗОВАЯ АНАТОМИЯ И ЭЛЕКТРОФИЗИОЛОГИЯ СЕРДЦА",
    "count": 6,
    "topic": "cardio"
  },
  {
    "id": "methylphenidate",
    "title": "Метилфенидат (Ritalin / Concerta)",
    "count": 3,
    "topic": "psych"
  },
  {
    "id": "parkinson",
    "title": "Болезнь Паркинсона",
    "count": 4,
    "topic": "neuro"
  },
  {
    "id": "antipsychotics",
    "title": "Антипсихотики, дофамин и экстрапирамидные эффекты",
    "count": 6,
    "topic": "psych"
  },
  {
    "id": "antidepressants",
    "title": "Антидепрессанты: TCA, SSRI и взаимодействия",
    "count": 5,
    "topic": "psych"
  },
  {
    "id": "benzodiazepines",
    "title": "Бензодиазепины и zolpidem",
    "count": 5,
    "topic": "psych"
  },
  {
    "id": "epilepsy",
    "title": "Противоэпилептические препараты",
    "count": 5,
    "topic": "neuro"
  },
  {
    "id": "nsaids",
    "title": "НПВС и aspirin",
    "count": 7,
    "topic": "pain"
  },
  {
    "id": "opioids",
    "title": "Опиоиды, tramadol и codeine",
    "count": 6,
    "topic": "pain"
  },
  {
    "id": "migraine-neuropathic",
    "title": "Мигрень и нейропатическая боль",
    "count": 3,
    "topic": "neuro"
  },
  {
    "id": "analgesics-local",
    "title": "Paracetamol и местная анестезия",
    "count": 3,
    "topic": "pain"
  },
  {
    "id": "gi-acid",
    "title": "Гистамин и кислотопродукция желудка",
    "count": 5,
    "topic": "gi"
  },
  {
    "id": "antihistamines",
    "title": "H1-антигистаминные препараты",
    "count": 2,
    "topic": "resp"
  },
  {
    "id": "steroids",
    "title": "Глюкокортикостероиды",
    "count": 2,
    "topic": "immune"
  },
  {
    "id": "diabetes",
    "title": "Сахарный диабет",
    "count": 4,
    "topic": "endocrine"
  }
];
