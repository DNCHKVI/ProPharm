export const DRUGS = [
  {
    "n": 1,
    "name": "Activated charcoal",
    "group": "Адсорбирующее средство (энтеросорбент)",
    "primaryTopic": "toxicology",
    "topics": [
      "toxicology"
    ]
  },
  {
    "n": 2,
    "name": "Acyclovir",
    "group": "Противовирусное средство",
    "primaryTopic": "infectious",
    "topics": [
      "infectious"
    ]
  },
  {
    "n": 3,
    "name": "Adalimumab",
    "group": "Иммунодепрессант (ингибитор ФНО-α)",
    "primaryTopic": "immune",
    "topics": [
      "immune"
    ]
  },
  {
    "n": 4,
    "name": "Alendronate",
    "group": "Ингибитор костной резорбции (бисфосфонат)",
    "primaryTopic": "bone",
    "topics": [
      "bone"
    ]
  },
  {
    "n": 5,
    "name": "Allopurinol",
    "group": "Противоподагрическое средство",
    "primaryTopic": "immune",
    "topics": [
      "immune"
    ]
  },
  {
    "n": 6,
    "name": "Amiodarone",
    "group": "Антиаритмическое средство (III класс)",
    "primaryTopic": "cardio",
    "topics": [
      "cardio"
    ]
  },
  {
    "n": 7,
    "name": "Amitriptyline",
    "group": "Антидепрессант (трициклический)",
    "primaryTopic": "psych",
    "topics": [
      "psych",
      "cardio"
    ]
  },
  {
    "n": 8,
    "name": "Amlodipine",
    "group": "Блокатор кальциевых каналов (гипотензивное)",
    "primaryTopic": "cardio",
    "topics": [
      "cardio"
    ]
  },
  {
    "n": 9,
    "name": "Amoxicillin/clavulanic acid",
    "group": "Антибиотик (пенициллин + ингибитор β-лактамаз)",
    "primaryTopic": "infectious",
    "topics": [
      "infectious"
    ]
  },
  {
    "n": 10,
    "name": "Anastrozole",
    "group": "Противоопухолевое средство (ингибитор ароматазы)",
    "primaryTopic": "oncology",
    "topics": [
      "oncology"
    ]
  },
  {
    "n": 11,
    "name": "Aspirin",
    "group": "НПВС (антиагрегант, анальгетик)",
    "primaryTopic": "hemostasis",
    "topics": [
      "hemostasis",
      "pain"
    ]
  },
  {
    "n": 12,
    "name": "Atenolol",
    "group": "Бета-адреноблокатор",
    "primaryTopic": "cardio",
    "topics": [
      "cardio"
    ]
  },
  {
    "n": 13,
    "name": "Atorvastatin",
    "group": "Гиполипидемическое средство (статин)",
    "primaryTopic": "cardio",
    "topics": [
      "cardio"
    ]
  },
  {
    "n": 14,
    "name": "Azithromycin",
    "group": "Антибиотик (макролид)",
    "primaryTopic": "infectious",
    "topics": [
      "infectious",
      "cardio"
    ]
  },
  {
    "n": 15,
    "name": "Betahistine hydrochloride",
    "group": "Препарат для лечения головокружения (гистаминергическое)",
    "primaryTopic": "neuro",
    "topics": [
      "neuro"
    ]
  },
  {
    "n": 16,
    "name": "Bezafibrate",
    "group": "Гиполипидемическое средство (фибрат)",
    "primaryTopic": "cardio",
    "topics": [
      "cardio"
    ]
  },
  {
    "n": 17,
    "name": "Biperiden",
    "group": "Противопаркинсоническое средство (холиноблокатор)",
    "primaryTopic": "neuro",
    "topics": [
      "neuro"
    ]
  },
  {
    "n": 18,
    "name": "Bisacodyl",
    "group": "Слабительное средство",
    "primaryTopic": "gi",
    "topics": [
      "gi"
    ]
  },
  {
    "n": 19,
    "name": "Bismuth subsalicylate",
    "group": "Противодиарейное, гастропротекторное средство",
    "primaryTopic": "gi",
    "topics": [
      "gi"
    ]
  },
  {
    "n": 20,
    "name": "Bromhexine",
    "group": "Муколитическое (отхаркивающее) средство",
    "primaryTopic": "resp",
    "topics": [
      "resp"
    ]
  },
  {
    "n": 21,
    "name": "Bromocriptine",
    "group": "Дофаминомиметик (противопаркинсоническое, гормональное)",
    "primaryTopic": "neuro",
    "topics": [
      "neuro",
      "repro"
    ]
  },
  {
    "n": 22,
    "name": "Brotizolam",
    "group": "Снотворное средство (бензодиазепин)",
    "primaryTopic": "psych",
    "topics": [
      "psych"
    ]
  },
  {
    "n": 23,
    "name": "Budesonide",
    "group": "Глюкокортикостероид (противовоспалительное)",
    "primaryTopic": "resp",
    "topics": [
      "resp",
      "immune"
    ]
  },
  {
    "n": 24,
    "name": "Bupropion",
    "group": "Антидепрессант (ингибитор обратного захвата ND)",
    "primaryTopic": "psych",
    "topics": [
      "psych"
    ]
  },
  {
    "n": 25,
    "name": "Cabergoline",
    "group": "Дофаминомиметик (ингибитор секреции пролактина)",
    "primaryTopic": "repro",
    "topics": [
      "repro"
    ]
  },
  {
    "n": 26,
    "name": "Calcium",
    "group": "Макроэлемент (препарат кальция)",
    "primaryTopic": "bone",
    "topics": [
      "bone",
      "cardio"
    ]
  },
  {
    "n": 27,
    "name": "Carbamazepine",
    "group": "Противоэпилептическое средство",
    "primaryTopic": "neuro",
    "topics": [
      "neuro",
      "cardio"
    ]
  },
  {
    "n": 28,
    "name": "Carbidopa",
    "group": "Ингибитор декарбоксилазы (применяется при паркинсонизме)",
    "primaryTopic": "neuro",
    "topics": [
      "neuro"
    ]
  },
  {
    "n": 29,
    "name": "Carbocysteine",
    "group": "Муколитическое средство",
    "primaryTopic": "resp",
    "topics": [
      "resp"
    ]
  },
  {
    "n": 30,
    "name": "Cefuroxime",
    "group": "Антибиотик (цефалоспорин II поколения)",
    "primaryTopic": "infectious",
    "topics": [
      "infectious"
    ]
  },
  {
    "n": 31,
    "name": "Celecoxib",
    "group": "НПВС (селективный ингибитор ЦОГ-2)",
    "primaryTopic": "pain",
    "topics": [
      "pain"
    ]
  },
  {
    "n": 32,
    "name": "Cephalexin",
    "group": "Антибиотик (цефалоспорин I поколения)",
    "primaryTopic": "infectious",
    "topics": [
      "infectious"
    ]
  },
  {
    "n": 33,
    "name": "Chloramphenicol",
    "group": "Антибиотик широкого спектра",
    "primaryTopic": "infectious",
    "topics": [
      "infectious"
    ]
  },
  {
    "n": 34,
    "name": "Cinnarizine",
    "group": "Блокатор кальциевых каналов (улучшает мозговое кровообращение)",
    "primaryTopic": "neuro",
    "topics": [
      "neuro"
    ]
  },
  {
    "n": 35,
    "name": "Ciprofloxacin",
    "group": "Антибиотик (фторхинолон)",
    "primaryTopic": "infectious",
    "topics": [
      "infectious",
      "cardio"
    ]
  },
  {
    "n": 36,
    "name": "Clindamycin",
    "group": "Антибиотик (линкозамид)",
    "primaryTopic": "infectious",
    "topics": [
      "infectious"
    ]
  },
  {
    "n": 37,
    "name": "Clomiphene citrate",
    "group": "Антиэстроген (стимулятор овуляции)",
    "primaryTopic": "repro",
    "topics": [
      "repro"
    ]
  },
  {
    "n": 38,
    "name": "Clonidine",
    "group": "Альфа-адреномиметик (гипотензивное средство)",
    "primaryTopic": "cardio",
    "topics": [
      "cardio"
    ]
  },
  {
    "n": 39,
    "name": "Clopidogrel",
    "group": "Антиагрегант",
    "primaryTopic": "hemostasis",
    "topics": [
      "hemostasis"
    ]
  },
  {
    "n": 40,
    "name": "Clozapine",
    "group": "Антипсихотическое средство (нейролептик)",
    "primaryTopic": "psych",
    "topics": [
      "psych",
      "cardio"
    ]
  },
  {
    "n": 41,
    "name": "Codeine",
    "group": "Опиоидный анальгетик (противокашлевое средство)",
    "primaryTopic": "pain",
    "topics": [
      "pain"
    ]
  },
  {
    "n": 42,
    "name": "Conjugated estrogens",
    "group": "Эстрогенные препараты",
    "primaryTopic": "repro",
    "topics": [
      "repro"
    ]
  },
  {
    "n": 43,
    "name": "Cyclosporine",
    "group": "Иммунодепрессант",
    "primaryTopic": "immune",
    "topics": [
      "immune"
    ]
  },
  {
    "n": 44,
    "name": "Dabigatran",
    "group": "Прямой антикоагулянт (ингибитор тромбина)",
    "primaryTopic": "hemostasis",
    "topics": [
      "hemostasis"
    ]
  },
  {
    "n": 45,
    "name": "Dapagliflozin",
    "group": "Гипогликемическое средство (ингибитор SGLT2)",
    "primaryTopic": "endocrine",
    "topics": [
      "endocrine"
    ]
  },
  {
    "n": 46,
    "name": "Dexchlorpheniramine",
    "group": "Антигистаминное средство",
    "primaryTopic": "resp",
    "topics": [
      "resp"
    ]
  },
  {
    "n": 47,
    "name": "Dextromethorphan",
    "group": "Противокашлевое средство",
    "primaryTopic": "resp",
    "topics": [
      "resp"
    ]
  },
  {
    "n": 48,
    "name": "Diazepam",
    "group": "Транквилизатор (бензодиазепин)",
    "primaryTopic": "psych",
    "topics": [
      "psych"
    ]
  },
  {
    "n": 49,
    "name": "Diclofenac",
    "group": "НПВС (обезболивающее, противовоспалительное)",
    "primaryTopic": "pain",
    "topics": [
      "pain"
    ]
  },
  {
    "n": 50,
    "name": "Digoxin",
    "group": "Сердечный гликозид",
    "primaryTopic": "cardio",
    "topics": [
      "cardio"
    ]
  },
  {
    "n": 51,
    "name": "Diltiazem",
    "group": "Блокатор кальциевых каналов (антиангинальное)",
    "primaryTopic": "cardio",
    "topics": [
      "cardio"
    ]
  },
  {
    "n": 52,
    "name": "Dimenhydrinate",
    "group": "Средство от тошноты / укачивания (антигистаминное)",
    "primaryTopic": "gi",
    "topics": [
      "gi"
    ]
  },
  {
    "n": 53,
    "name": "Dipyrone",
    "group": "Анальгетик-антипиретик (метамизол натрия)",
    "primaryTopic": "pain",
    "topics": [
      "pain"
    ]
  },
  {
    "n": 54,
    "name": "Domperidone",
    "group": "Противорвотное средство (стимулятор моторики ЖКТ)",
    "primaryTopic": "gi",
    "topics": [
      "gi",
      "cardio"
    ]
  },
  {
    "n": 55,
    "name": "Donepezil",
    "group": "Ингибитор холинэстеразы (от деменции)",
    "primaryTopic": "neuro",
    "topics": [
      "neuro",
      "cardio"
    ]
  },
  {
    "n": 56,
    "name": "Doxazosin",
    "group": "Альфа-адреноблокатор (от давления и гиперплазии простаты)",
    "primaryTopic": "uro",
    "topics": [
      "uro",
      "cardio"
    ]
  },
  {
    "n": 57,
    "name": "Doxycycline",
    "group": "Антибиотик (тетрациклин)",
    "primaryTopic": "infectious",
    "topics": [
      "infectious"
    ]
  },
  {
    "n": 58,
    "name": "Duloxetine",
    "group": "Антидепрессант (СИОЗСН)",
    "primaryTopic": "psych",
    "topics": [
      "psych"
    ]
  },
  {
    "n": 59,
    "name": "Dutasteride",
    "group": "Средство лечения гиперплазии простаты (ингибитор 5α-редуктазы)",
    "primaryTopic": "uro",
    "topics": [
      "uro"
    ]
  },
  {
    "n": 60,
    "name": "Enalapril",
    "group": "Ингибитор АПФ (гипотензивное)",
    "primaryTopic": "cardio",
    "topics": [
      "cardio"
    ]
  },
  {
    "n": 61,
    "name": "Enoxaparin",
    "group": "Антикоагулянт (низкомолекулярный гепарин)",
    "primaryTopic": "hemostasis",
    "topics": [
      "hemostasis"
    ]
  },
  {
    "n": 62,
    "name": "Entacapone",
    "group": "Противопаркинсоническое средство (ингибитор КОМТ)",
    "primaryTopic": "neuro",
    "topics": [
      "neuro"
    ]
  },
  {
    "n": 63,
    "name": "Escitalopram",
    "group": "Антидепрессант (СИОЗС)",
    "primaryTopic": "psych",
    "topics": [
      "psych",
      "cardio"
    ]
  },
  {
    "n": 64,
    "name": "Esomeprazole",
    "group": "Ингибитор протонной помпы (от изжоги/язвы)",
    "primaryTopic": "gi",
    "topics": [
      "gi"
    ]
  },
  {
    "n": 65,
    "name": "Exenatide",
    "group": "Гипогликемическое (агонист рецепторов ГПП-1)",
    "primaryTopic": "endocrine",
    "topics": [
      "endocrine"
    ]
  },
  {
    "n": 66,
    "name": "Ezetimibe",
    "group": "Гиполипидемическое средство (ингибитор абсорбции холестерина)",
    "primaryTopic": "cardio",
    "topics": [
      "cardio"
    ]
  },
  {
    "n": 67,
    "name": "Famotidine",
    "group": "H2-антигистаминное средство (противоязвенное)",
    "primaryTopic": "gi",
    "topics": [
      "gi"
    ]
  },
  {
    "n": 68,
    "name": "Fexofenadine",
    "group": "Антигистаминное средство",
    "primaryTopic": "resp",
    "topics": [
      "resp"
    ]
  },
  {
    "n": 69,
    "name": "Fluconazole",
    "group": "Противогрибковое средство",
    "primaryTopic": "infectious",
    "topics": [
      "infectious",
      "cardio"
    ]
  },
  {
    "n": 70,
    "name": "Fluoxetine",
    "group": "Антидепрессант (СИОЗС)",
    "primaryTopic": "psych",
    "topics": [
      "psych",
      "cardio"
    ]
  },
  {
    "n": 71,
    "name": "Folic Acid",
    "group": "Витамин B9",
    "primaryTopic": "bone",
    "topics": [
      "bone"
    ]
  },
  {
    "n": 72,
    "name": "Fluticasone",
    "group": "Глюкокортикостероид (ингаляционный или местный)",
    "primaryTopic": "resp",
    "topics": [
      "resp"
    ]
  },
  {
    "n": 73,
    "name": "Furosemide",
    "group": "Петлевой диуретик",
    "primaryTopic": "cardio",
    "topics": [
      "cardio"
    ]
  },
  {
    "n": 74,
    "name": "Gabapentin",
    "group": "Противоэпилептическое средство (при нейропатической боли)",
    "primaryTopic": "neuro",
    "topics": [
      "neuro"
    ]
  },
  {
    "n": 75,
    "name": "Gentamicin",
    "group": "Антибиотик (аминогликозид)",
    "primaryTopic": "infectious",
    "topics": [
      "infectious"
    ]
  },
  {
    "n": 76,
    "name": "Glibenclamide",
    "group": "Гипогликемическое (производное сульфонилмочевины)",
    "primaryTopic": "endocrine",
    "topics": [
      "endocrine"
    ]
  },
  {
    "n": 77,
    "name": "Guaiphenesin",
    "group": "Отхаркивающее средство",
    "primaryTopic": "resp",
    "topics": [
      "resp"
    ]
  },
  {
    "n": 78,
    "name": "Haloperidol",
    "group": "Антипсихотическое средство (нейролептик)",
    "primaryTopic": "psych",
    "topics": [
      "psych",
      "cardio"
    ]
  },
  {
    "n": 79,
    "name": "Hydrochlorothiazide",
    "group": "Тиазидный диуретик",
    "primaryTopic": "cardio",
    "topics": [
      "cardio"
    ]
  },
  {
    "n": 80,
    "name": "Ibuprofen",
    "group": "НПВС (анальгетик, антипиретик)",
    "primaryTopic": "pain",
    "topics": [
      "pain"
    ]
  },
  {
    "n": 81,
    "name": "Insulin",
    "group": "Гипогликемическое средство (гормон инсулин)",
    "primaryTopic": "endocrine",
    "topics": [
      "endocrine",
      "cardio"
    ]
  },
  {
    "n": 82,
    "name": "Isosorbide mono/dinitrate",
    "group": "Периферический вазодилататор (нитрат)",
    "primaryTopic": "cardio",
    "topics": [
      "cardio"
    ]
  },
  {
    "n": 83,
    "name": "Isotretinoin",
    "group": "Средство лечения угревой сыпи (ретиноид)",
    "primaryTopic": "local",
    "topics": [
      "local"
    ]
  },
  {
    "n": 84,
    "name": "Ketoconazole",
    "group": "Противогрибковое средство",
    "primaryTopic": "infectious",
    "topics": [
      "infectious",
      "cardio"
    ]
  },
  {
    "n": 85,
    "name": "Lactulose",
    "group": "Слабительное средство (пребиотик)",
    "primaryTopic": "gi",
    "topics": [
      "gi"
    ]
  },
  {
    "n": 86,
    "name": "Lamotrigine",
    "group": "Противоэпилептическое средство",
    "primaryTopic": "neuro",
    "topics": [
      "neuro",
      "cardio"
    ]
  },
  {
    "n": 87,
    "name": "Latanoprost",
    "group": "Противоглаукомное средство",
    "primaryTopic": "ophth",
    "topics": [
      "ophth"
    ]
  },
  {
    "n": 88,
    "name": "Letrozole",
    "group": "Противоопухолевое средство (ингибитор ароматазы)",
    "primaryTopic": "oncology",
    "topics": [
      "oncology"
    ]
  },
  {
    "n": 89,
    "name": "Levetiracetam",
    "group": "Противоэпилептическое средство",
    "primaryTopic": "neuro",
    "topics": [
      "neuro"
    ]
  },
  {
    "n": 90,
    "name": "Levodopa",
    "group": "Противопаркинсоническое средство",
    "primaryTopic": "neuro",
    "topics": [
      "neuro"
    ]
  },
  {
    "n": 91,
    "name": "Levothyroxine",
    "group": "Гормон щитовидной железы",
    "primaryTopic": "endocrine",
    "topics": [
      "endocrine",
      "cardio"
    ]
  },
  {
    "n": 92,
    "name": "Lithium",
    "group": "Соли лития (нормотимик)",
    "primaryTopic": "psych",
    "topics": [
      "psych",
      "cardio"
    ]
  },
  {
    "n": 93,
    "name": "Liraglutide",
    "group": "Гипогликемическое (агонист рецепторов ГПП-1)",
    "primaryTopic": "endocrine",
    "topics": [
      "endocrine"
    ]
  },
  {
    "n": 94,
    "name": "Loperamide",
    "group": "Противодиарейное средство",
    "primaryTopic": "gi",
    "topics": [
      "gi",
      "cardio"
    ]
  },
  {
    "n": 95,
    "name": "Loratadine",
    "group": "Антигистаминное средство",
    "primaryTopic": "resp",
    "topics": [
      "resp"
    ]
  },
  {
    "n": 96,
    "name": "Lorazepam",
    "group": "Транквилизатор (бензодиазепин)",
    "primaryTopic": "psych",
    "topics": [
      "psych"
    ]
  },
  {
    "n": 97,
    "name": "Losartan",
    "group": "Антагонист рецепторов ангиотензина II",
    "primaryTopic": "cardio",
    "topics": [
      "cardio"
    ]
  },
  {
    "n": 98,
    "name": "Mebendazole",
    "group": "Противогельминтное средство",
    "primaryTopic": "infectious",
    "topics": [
      "infectious"
    ]
  },
  {
    "n": 99,
    "name": "Mefloquine",
    "group": "Противомалярийное средство",
    "primaryTopic": "infectious",
    "topics": [
      "infectious"
    ]
  },
  {
    "n": 100,
    "name": "Melatonin",
    "group": "Адаптоген (гормон сна)",
    "primaryTopic": "psych",
    "topics": [
      "psych"
    ]
  },
  {
    "n": 101,
    "name": "Memantine",
    "group": "Средство для лечения деменции (NMDA-антагонист)",
    "primaryTopic": "neuro",
    "topics": [
      "neuro"
    ]
  },
  {
    "n": 102,
    "name": "Metformin",
    "group": "Гипогликемическое средство (бигуанид)",
    "primaryTopic": "endocrine",
    "topics": [
      "endocrine"
    ]
  },
  {
    "n": 103,
    "name": "Methimazole",
    "group": "Антитиреоидное средство",
    "primaryTopic": "endocrine",
    "topics": [
      "endocrine"
    ]
  },
  {
    "n": 104,
    "name": "Methotrexate",
    "group": "Иммунодепрессант, цитостатик",
    "primaryTopic": "immune",
    "topics": [
      "immune",
      "oncology"
    ]
  },
  {
    "n": 105,
    "name": "Methylphenidate",
    "group": "Психостимулятор",
    "primaryTopic": "psych",
    "topics": [
      "psych",
      "cardio"
    ]
  },
  {
    "n": 106,
    "name": "Metoclopramide",
    "group": "Противорвотное средство (центральное)",
    "primaryTopic": "gi",
    "topics": [
      "gi",
      "cardio"
    ]
  },
  {
    "n": 107,
    "name": "Metoprolol",
    "group": "Бета-адреноблокатор",
    "primaryTopic": "cardio",
    "topics": [
      "cardio"
    ]
  },
  {
    "n": 108,
    "name": "Metronidazole",
    "group": "Противомикробное и противопротозойное средство",
    "primaryTopic": "infectious",
    "topics": [
      "infectious"
    ]
  },
  {
    "n": 109,
    "name": "Montelukast",
    "group": "Антагонист лейкотриеновых рецепторов (от астмы)",
    "primaryTopic": "resp",
    "topics": [
      "resp"
    ]
  },
  {
    "n": 110,
    "name": "Naproxen",
    "group": "НПВС",
    "primaryTopic": "pain",
    "topics": [
      "pain"
    ]
  },
  {
    "n": 111,
    "name": "Nifedipine",
    "group": "Блокатор кальциевых каналов",
    "primaryTopic": "cardio",
    "topics": [
      "cardio"
    ]
  },
  {
    "n": 112,
    "name": "Nortriptyline",
    "group": "Антидепрессант (трициклический)",
    "primaryTopic": "psych",
    "topics": [
      "psych",
      "cardio"
    ]
  },
  {
    "n": 113,
    "name": "Olanzapine",
    "group": "Антипсихотическое средство (нейролептик)",
    "primaryTopic": "psych",
    "topics": [
      "psych"
    ]
  },
  {
    "n": 114,
    "name": "Omeprazole",
    "group": "Ингибитор протонной помпы (противоязвенное)",
    "primaryTopic": "gi",
    "topics": [
      "gi"
    ]
  },
  {
    "n": 115,
    "name": "Oral contraceptive",
    "group": "Пероральные контрацептивы (гормональные)",
    "primaryTopic": "repro",
    "topics": [
      "repro"
    ]
  },
  {
    "n": 116,
    "name": "Orlistat",
    "group": "Средство для лечения ожирения (ингибитор липаз)",
    "primaryTopic": "endocrine",
    "topics": [
      "endocrine"
    ]
  },
  {
    "n": 117,
    "name": "Oxazepam",
    "group": "Транквилизатор (бензодиазепин)",
    "primaryTopic": "psych",
    "topics": [
      "psych"
    ]
  },
  {
    "n": 118,
    "name": "Oxcarbazepine",
    "group": "Противоэпилептическое средство",
    "primaryTopic": "neuro",
    "topics": [
      "neuro",
      "cardio"
    ]
  },
  {
    "n": 119,
    "name": "Oxycodone",
    "group": "Опиоидный анальгетик",
    "primaryTopic": "pain",
    "topics": [
      "pain"
    ]
  },
  {
    "n": 120,
    "name": "Papaverine",
    "group": "Спазмолитик",
    "primaryTopic": "cardio",
    "topics": [
      "cardio"
    ]
  },
  {
    "n": 121,
    "name": "Paracetamol",
    "group": "Анальгетик-антипиретик",
    "primaryTopic": "pain",
    "topics": [
      "pain"
    ]
  },
  {
    "n": 122,
    "name": "Paroxetine",
    "group": "Антидепрессант (СИОЗС)",
    "primaryTopic": "psych",
    "topics": [
      "psych"
    ]
  },
  {
    "n": 123,
    "name": "Penicillin V",
    "group": "Антибиотик (пенициллин)",
    "primaryTopic": "infectious",
    "topics": [
      "infectious"
    ]
  },
  {
    "n": 124,
    "name": "Perphenazine",
    "group": "Антипсихотическое средство (нейролептик)",
    "primaryTopic": "psych",
    "topics": [
      "psych",
      "cardio"
    ]
  },
  {
    "n": 125,
    "name": "Phenazopyridine",
    "group": "Анальгетик для мочевыводящих путей",
    "primaryTopic": "uro",
    "topics": [
      "uro"
    ]
  },
  {
    "n": 126,
    "name": "Phenytoin",
    "group": "Противоэпилептическое средство",
    "primaryTopic": "neuro",
    "topics": [
      "neuro",
      "cardio"
    ]
  },
  {
    "n": 127,
    "name": "Pioglitazone",
    "group": "Гипогликемическое средство (тиазолидиндион)",
    "primaryTopic": "endocrine",
    "topics": [
      "endocrine"
    ]
  },
  {
    "n": 128,
    "name": "Potassium chloride",
    "group": "Препарат калия",
    "primaryTopic": "cardio",
    "topics": [
      "cardio"
    ]
  },
  {
    "n": 129,
    "name": "Prednisone",
    "group": "Глюкокортикостероид",
    "primaryTopic": "immune",
    "topics": [
      "immune"
    ]
  },
  {
    "n": 130,
    "name": "Pregabalin",
    "group": "Противоэпилептическое / анальгезирующее средство",
    "primaryTopic": "neuro",
    "topics": [
      "neuro"
    ]
  },
  {
    "n": 131,
    "name": "Promethazine",
    "group": "Антигистаминное / седативное средство",
    "primaryTopic": "resp",
    "topics": [
      "resp",
      "cardio"
    ]
  },
  {
    "n": 132,
    "name": "Propafenone",
    "group": "Антиаритмическое средство (IC класс)",
    "primaryTopic": "cardio",
    "topics": [
      "cardio"
    ]
  },
  {
    "n": 133,
    "name": "Propranolol",
    "group": "Бета-адреноблокатор (неселективный)",
    "primaryTopic": "cardio",
    "topics": [
      "cardio"
    ]
  },
  {
    "n": 134,
    "name": "Pseudoephedrine",
    "group": "Сосудосуживающее (деконгестант)",
    "primaryTopic": "local",
    "topics": [
      "local",
      "cardio"
    ]
  },
  {
    "n": 135,
    "name": "Psyllium",
    "group": "Слабительное средство (растительного происхождения)",
    "primaryTopic": "gi",
    "topics": [
      "gi"
    ]
  },
  {
    "n": 136,
    "name": "Quetiapine",
    "group": "Антипсихотическое средство (нейролептик)",
    "primaryTopic": "psych",
    "topics": [
      "psych",
      "cardio"
    ]
  },
  {
    "n": 137,
    "name": "Ranitidine",
    "group": "H2-антигистаминное средство (противоязвенное)",
    "primaryTopic": "gi",
    "topics": [
      "gi"
    ]
  },
  {
    "n": 138,
    "name": "Rasagiline",
    "group": "Противопаркинсоническое (ингибитор МАО-Б)",
    "primaryTopic": "neuro",
    "topics": [
      "neuro"
    ]
  },
  {
    "n": 139,
    "name": "Repaglinide",
    "group": "Гипогликемическое средство (глинид)",
    "primaryTopic": "endocrine",
    "topics": [
      "endocrine"
    ]
  },
  {
    "n": 140,
    "name": "Risperidone",
    "group": "Антипсихотическое средство (нейролептик)",
    "primaryTopic": "psych",
    "topics": [
      "psych",
      "cardio"
    ]
  },
  {
    "n": 141,
    "name": "Rivaroxaban",
    "group": "Прямой антикоагулянт (ингибитор Xa фактора)",
    "primaryTopic": "hemostasis",
    "topics": [
      "hemostasis"
    ]
  },
  {
    "n": 142,
    "name": "Rizatriptan",
    "group": "Противомигренозное средство (триптан)",
    "primaryTopic": "neuro",
    "topics": [
      "neuro"
    ]
  },
  {
    "n": 143,
    "name": "Roxithromycin",
    "group": "Антибиотик (макролид)",
    "primaryTopic": "infectious",
    "topics": [
      "infectious",
      "cardio"
    ]
  },
  {
    "n": 144,
    "name": "Salbutamol",
    "group": "Бронходилататор (β2-адреномиметик)",
    "primaryTopic": "resp",
    "topics": [
      "resp",
      "cardio"
    ]
  },
  {
    "n": 145,
    "name": "Sertraline",
    "group": "Антидепрессант (СИОЗС)",
    "primaryTopic": "psych",
    "topics": [
      "psych"
    ]
  },
  {
    "n": 146,
    "name": "Sildenafil",
    "group": "Ингибитор ФДЭ-5",
    "primaryTopic": "cardio",
    "topics": [
      "cardio"
    ]
  },
  {
    "n": 147,
    "name": "Simvastatin",
    "group": "Гиполипидемическое средство (статин)",
    "primaryTopic": "cardio",
    "topics": [
      "cardio"
    ]
  },
  {
    "n": 148,
    "name": "Sitagliptin",
    "group": "Гипогликемическое (ингибитор ДПП-4)",
    "primaryTopic": "endocrine",
    "topics": [
      "endocrine"
    ]
  },
  {
    "n": 149,
    "name": "Solifenacin",
    "group": "М-холиноблокатор (при недержании мочи)",
    "primaryTopic": "uro",
    "topics": [
      "uro"
    ]
  },
  {
    "n": 150,
    "name": "Spironolactone",
    "group": "Калийсберегающий диуретик",
    "primaryTopic": "cardio",
    "topics": [
      "cardio"
    ]
  },
  {
    "n": 151,
    "name": "Sumatriptan",
    "group": "Противомигренозное средство (триптан)",
    "primaryTopic": "neuro",
    "topics": [
      "neuro"
    ]
  },
  {
    "n": 152,
    "name": "Tacrolimus",
    "group": "Иммунодепрессант (ингибитор кальциневрина)",
    "primaryTopic": "immune",
    "topics": [
      "immune"
    ]
  },
  {
    "n": 153,
    "name": "Tamoxifen",
    "group": "Противоопухолевое (антагонист эстрогенов)",
    "primaryTopic": "oncology",
    "topics": [
      "oncology"
    ]
  },
  {
    "n": 154,
    "name": "Tamsulosin",
    "group": "Альфа-адреноблокатор (при заболеваниях простаты)",
    "primaryTopic": "uro",
    "topics": [
      "uro"
    ]
  },
  {
    "n": 155,
    "name": "Terbinafine",
    "group": "Противогрибковое средство",
    "primaryTopic": "infectious",
    "topics": [
      "infectious"
    ]
  },
  {
    "n": 156,
    "name": "Tetrahydrozoline",
    "group": "Альфа-адреномиметик (сосудосуживающее местное)",
    "primaryTopic": "local",
    "topics": [
      "local"
    ]
  },
  {
    "n": 157,
    "name": "Thyrothricin+benzocaine",
    "group": "Местное противомикробное + обезболивающее средство",
    "primaryTopic": "local",
    "topics": [
      "local"
    ]
  },
  {
    "n": 158,
    "name": "Timolol",
    "group": "Бета-адреноблокатор (в т.ч. офтальмология)",
    "primaryTopic": "ophth",
    "topics": [
      "ophth",
      "cardio"
    ]
  },
  {
    "n": 159,
    "name": "Tiotropium bromide",
    "group": "Холиноблокатор (бронхолитическое средство)",
    "primaryTopic": "resp",
    "topics": [
      "resp"
    ]
  },
  {
    "n": 160,
    "name": "Topiramate",
    "group": "Противоэпилептическое средство",
    "primaryTopic": "neuro",
    "topics": [
      "neuro",
      "cardio"
    ]
  },
  {
    "n": 161,
    "name": "Tramadol",
    "group": "Опиоидный анальгетик",
    "primaryTopic": "pain",
    "topics": [
      "pain"
    ]
  },
  {
    "n": 162,
    "name": "Trazodone",
    "group": "Антидепрессант",
    "primaryTopic": "psych",
    "topics": [
      "psych",
      "cardio"
    ]
  },
  {
    "n": 163,
    "name": "Trospium Chloride",
    "group": "М-холиноблокатор (при недержании мочи)",
    "primaryTopic": "uro",
    "topics": [
      "uro"
    ]
  },
  {
    "n": 164,
    "name": "Valproic acid",
    "group": "Противоэпилептическое средство (нормотимик)",
    "primaryTopic": "neuro",
    "topics": [
      "neuro"
    ]
  },
  {
    "n": 165,
    "name": "Venlafaxine",
    "group": "Антидепрессант (СИОЗСН)",
    "primaryTopic": "psych",
    "topics": [
      "psych",
      "cardio"
    ]
  },
  {
    "n": 166,
    "name": "Verapamil",
    "group": "Блокатор кальциевых каналов (антиаритмик, гипотензивное)",
    "primaryTopic": "cardio",
    "topics": [
      "cardio"
    ]
  },
  {
    "n": 167,
    "name": "Vit D",
    "group": "Витамин (холекальциферол)",
    "primaryTopic": "bone",
    "topics": [
      "bone"
    ]
  },
  {
    "n": 168,
    "name": "Warfarin",
    "group": "Непрямой антикоагулянт",
    "primaryTopic": "hemostasis",
    "topics": [
      "hemostasis"
    ]
  },
  {
    "n": 169,
    "name": "Xylometazoline",
    "group": "Сосудосуживающее (деконгестант)",
    "primaryTopic": "local",
    "topics": [
      "local"
    ]
  },
  {
    "n": 170,
    "name": "Zolpidem",
    "group": "Снотворное средство",
    "primaryTopic": "psych",
    "topics": [
      "psych"
    ]
  }
];
