export const SECTION_VISUALS = {
  "heart-failure": {
    "title": "Frank–Starling",
    "kind": "flow",
    "steps": [
      "venous return",
      "EDV/preload",
      "stretch",
      "contraction",
      "SV"
    ]
  },
  "hypertension": {
    "title": "BP control",
    "kind": "flow",
    "steps": [
      "CO × SVR",
      "β-blocker → CO ↓",
      "CCB → SVR ↓",
      "diuretic → volume ↓"
    ]
  },
  "ihd-acs": {
    "title": "Nitrate mechanism",
    "kind": "flow",
    "steps": [
      "nitrate",
      "NO",
      "cGMP",
      "venodilation",
      "preload/O₂ demand ↓"
    ]
  },
  "antiarrhythmics": {
    "title": "AP and ECG",
    "kind": "flow",
    "steps": [
      "Na⁺ → phase 0/QRS",
      "Ca²⁺ → nodal conduction",
      "K⁺ → phase 3/QT"
    ]
  },
  "af": {
    "title": "AF management",
    "kind": "flow",
    "steps": [
      "atrial fibrillation",
      "rate/rhythm strategy",
      "stroke risk",
      "anticoagulation when indicated"
    ]
  },
  "hemostasis": {
    "title": "Clot pathway",
    "kind": "flow",
    "steps": [
      "platelet activation",
      "P2Y12/TXA₂",
      "Xa",
      "thrombin",
      "fibrin"
    ]
  },
  "cardiac-basics": {
    "title": "Conduction",
    "kind": "flow",
    "steps": [
      "SA node",
      "atria/P",
      "AV node/PR",
      "His–Purkinje",
      "ventricles/QRS",
      "repolarization/T"
    ]
  },
  "methylphenidate": {
    "title": "DAT/NET synapse",
    "kind": "synapse",
    "steps": [
      "DAT ⊣",
      "NET ⊣",
      "DA ↑",
      "NE ↑"
    ]
  },
  "parkinson": {
    "title": "Dopamine strategy",
    "kind": "bbb",
    "steps": [
      "levodopa",
      "carbidopa",
      "BBB",
      "dopamine CNS",
      "entacapone/rasagiline"
    ]
  },
  "antipsychotics": {
    "title": "D₂ pathways",
    "kind": "flow",
    "steps": [
      "D₂ blockade",
      "mesolimbic → psychosis ↓",
      "nigrostriatal → EPS ↑"
    ]
  },
  "antidepressants": {
    "title": "Monoamines and interactions",
    "kind": "flow",
    "steps": [
      "SERT/NET",
      "monoamines ↑",
      "therapeutic effects",
      "interaction/toxicity patterns"
    ]
  },
  "benzodiazepines": {
    "title": "GABA-A",
    "kind": "gaba",
    "steps": [
      "GABA",
      "benzodiazepine",
      "Cl⁻ opening frequency ↑",
      "hyperpolarization"
    ]
  },
  "epilepsy": {
    "title": "Antiseizure mechanisms",
    "kind": "flow",
    "steps": [
      "Na⁺ firing ↓",
      "GABA inhibition ↑",
      "Ca²⁺ transmitter release ↓",
      "seizure probability ↓"
    ]
  },
  "nsaids": {
    "title": "COX pathways",
    "kind": "cox",
    "steps": [
      "COX-1",
      "COX-2",
      "PG/TXA₂",
      "GI/renal/CV effects"
    ]
  },
  "opioids": {
    "title": "μ receptor",
    "kind": "flow",
    "steps": [
      "μ Gi/o",
      "Ca²⁺ ↓",
      "K⁺ ↑",
      "release ↓",
      "analgesia"
    ]
  },
  "migraine-neuropathic": {
    "title": "Pain modulation",
    "kind": "flow",
    "steps": [
      "5-HT1B/1D or SNRI/α₂δ",
      "transmitter/vascular effect",
      "pain signal ↓"
    ]
  },
  "analgesics-local": {
    "title": "Analgesic biochemistry",
    "kind": "paracetamol",
    "steps": [
      "paracetamol",
      "CYP2E1",
      "NAPQI",
      "glutathione"
    ]
  },
  "gi-acid": {
    "title": "Gastric acid",
    "kind": "stomach",
    "steps": [
      "gastrin",
      "histamine",
      "H₂",
      "proton pump",
      "HCl"
    ]
  },
  "antihistamines": {
    "title": "H₁ generation",
    "kind": "flow",
    "steps": [
      "1st gen → BBB",
      "sedation ↑",
      "2nd gen → BBB ↓",
      "sedation ↓"
    ]
  },
  "steroids": {
    "title": "Steroid genomic action",
    "kind": "steroid",
    "steps": [
      "membrane",
      "GR/Hsp90",
      "nucleus",
      "DNA",
      "transcription"
    ]
  },
  "diabetes": {
    "title": "Glucose control",
    "kind": "thresholds",
    "steps": [
      "diagnosis",
      "insulin resistance",
      "hyperglycemia",
      "drug mechanism"
    ]
  }
};
