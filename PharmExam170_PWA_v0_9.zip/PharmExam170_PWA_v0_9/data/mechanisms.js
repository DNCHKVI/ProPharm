export const MECHANISMS = {
  "cardio": [
    {
      "title": "β₁ → Gs → cAMP → PKA",
      "chain": [
        "β₁",
        "Gs",
        "Adenylyl cyclase ↑",
        "cAMP ↑",
        "PKA ↑",
        "If/ICaL ↑",
        "ЧСС/проводимость/Ca²⁺-цикл ↑"
      ],
      "examples": [
        "Atenolol",
        "Metoprolol",
        "Propranolol",
        "Timolol"
      ]
    },
    {
      "title": "M₂ → Gi + GIRK",
      "chain": [
        "M₂",
        "Gi",
        "cAMP ↓",
        "If/ICaL ↓",
        "GIRK K⁺ ↑",
        "гиперполяризация",
        "ЧСС и АВ-проведение ↓"
      ],
      "examples": [
        "Donepezil — косвенно через ACh ↑"
      ]
    },
    {
      "title": "L-type Ca²⁺ → RyR2 → CICR",
      "chain": [
        "Cav1.2",
        "Ca²⁺ входит",
        "RyR2",
        "Ca²⁺ из СПР",
        "TnC",
        "actin–myosin",
        "сокращение"
      ],
      "examples": [
        "Verapamil",
        "Diltiazem",
        "Amlodipine",
        "Nifedipine"
      ]
    },
    {
      "title": "Na⁺/K⁺-АТФаза → NCX → Ca²⁺",
      "chain": [
        "Na⁺/K⁺-АТФаза",
        "Na⁺-градиент",
        "NCX",
        "Ca²⁺-выведение",
        "Ca²⁺ в СПР",
        "инотропия"
      ],
      "examples": [
        "Digoxin"
      ]
    },
    {
      "title": "Fast Na⁺ → фаза 0 → QRS",
      "chain": [
        "Nav1.5",
        "INa",
        "крутизна фазы 0",
        "скорость проведения",
        "QRS"
      ],
      "examples": [
        "Propafenone",
        "Amitriptyline",
        "Nortriptyline",
        "Phenytoin"
      ]
    },
    {
      "title": "IKr/hERG → QT → TdP",
      "chain": [
        "IKr ↓",
        "фаза 3 дольше",
        "APD ↑",
        "QT/QTc ↑",
        "EAD",
        "TdP"
      ],
      "examples": [
        "Amiodarone",
        "Haloperidol",
        "Domperidone",
        "Azithromycin",
        "Escitalopram"
      ]
    },
    {
      "title": "NO → sGC → cGMP",
      "chain": [
        "NO",
        "sGC",
        "cGMP ↑",
        "Ca²⁺ гладкой мышцы ↓",
        "вазодилатация"
      ],
      "examples": [
        "Isosorbide mono/dinitrate",
        "Sildenafil — downstream PDE5"
      ]
    },
    {
      "title": "RAAS",
      "chain": [
        "Renin",
        "Angiotensin I",
        "ACE",
        "Angiotensin II",
        "AT₁",
        "вазоконстрикция/aldosterone"
      ],
      "examples": [
        "Enalapril",
        "Losartan",
        "Spironolactone"
      ]
    }
  ],
  "psych": [
    {
      "title": "DAT/NET inhibition → DA/NE ↑",
      "chain": [
        "Methylphenidate",
        "DAT + NET blockade",
        "reuptake ↓",
        "dopamine + norepinephrine ↑"
      ],
      "examples": [
        "Methylphenidate"
      ]
    },
    {
      "title": "D₂ blockade → EPS",
      "chain": [
        "D₂ blockade",
        "nigrostriatal DA signaling ↓",
        "EPS / tardive dyskinesia risk ↑"
      ],
      "examples": [
        "Haloperidol",
        "Perphenazine",
        "Risperidone"
      ]
    },
    {
      "title": "GABA-A + benzodiazepine",
      "chain": [
        "GABA-A",
        "benzodiazepine allosteric site",
        "opening frequency of Cl⁻ channel ↑",
        "hyperpolarization",
        "excitability ↓"
      ],
      "examples": [
        "Diazepam",
        "Lorazepam",
        "Oxazepam",
        "Brotizolam"
      ]
    }
  ],
  "neuro": [
    {
      "title": "Levodopa + carbidopa",
      "chain": [
        "Carbidopa ⊣ peripheral DOPA-decarboxylase",
        "peripheral dopamine ↓",
        "levodopa in plasma ↑",
        "BBB passage ↑",
        "dopamine in CNS ↑"
      ],
      "examples": [
        "Levodopa",
        "Carbidopa"
      ]
    },
    {
      "title": "COMT и MAO-B при Parkinson",
      "chain": [
        "Entacapone ⊣ COMT",
        "Rasagiline ⊣ MAO-B",
        "dopamine availability ↑"
      ],
      "examples": [
        "Entacapone",
        "Rasagiline"
      ]
    },
    {
      "title": "α₂δ VGCC → transmitter release ↓",
      "chain": [
        "Pregabalin",
        "α₂δ subunit",
        "presynaptic Ca²⁺ influx ↓",
        "glutamate/Substance P release ↓"
      ],
      "examples": [
        "Pregabalin"
      ]
    }
  ],
  "pain": [
    {
      "title": "COX → prostaglandins",
      "chain": [
        "NSAID",
        "COX inhibition",
        "prostaglandins ↓",
        "pain/fever/inflammation ↓",
        "renal/GI consequences"
      ],
      "examples": [
        "Ibuprofen",
        "Naproxen",
        "Diclofenac",
        "Celecoxib",
        "Aspirin"
      ]
    },
    {
      "title": "Codeine → CYP2D6 → morphine",
      "chain": [
        "Codeine",
        "CYP2D6",
        "morphine",
        "μ-receptor",
        "analgesia"
      ],
      "examples": [
        "Codeine"
      ]
    },
    {
      "title": "Paracetamol → NAPQI",
      "chain": [
        "Paracetamol",
        "CYP2E1 minor pathway",
        "NAPQI",
        "glutathione detoxification",
        "overdose → glutathione ↓ → liver injury"
      ],
      "examples": [
        "Paracetamol"
      ]
    }
  ],
  "gi": [
    {
      "title": "H₂ → cAMP → proton pump",
      "chain": [
        "Histamine",
        "H₂ receptor",
        "Gs/cAMP ↑",
        "H⁺/K⁺-ATPase ↑",
        "HCl ↑"
      ],
      "examples": [
        "Famotidine",
        "Omeprazole"
      ]
    }
  ],
  "immune": [
    {
      "title": "Glucocorticoid genomic action",
      "chain": [
        "Steroid",
        "cytoplasmic GR + Hsp90",
        "nuclear translocation",
        "DNA response element",
        "transcription change"
      ],
      "examples": [
        "Prednisone",
        "Budesonide",
        "Fluticasone"
      ]
    }
  ],
  "endocrine": [
    {
      "title": "Acarbose",
      "chain": [
        "Acarbose",
        "intestinal α-glucosidase inhibition",
        "carbohydrate digestion slower",
        "postprandial glucose ↓"
      ],
      "examples": [
        "Acarbose — вне списка 170, но встречается в тесте"
      ]
    }
  ]
};
