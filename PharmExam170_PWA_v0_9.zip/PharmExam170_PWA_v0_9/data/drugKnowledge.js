export const DRUG_KNOWLEDGE = {
  "105": {
    "mechanism": [
      "DAT и NET inhibition → DA/NE ↑"
    ],
    "pearls": [
      "Concerta — наиболее длительная форма среди вариантов источника.",
      "Контролировать ЧСС/АД; у детей также рост, массу и аппетит."
    ],
    "interactions": [],
    "visual": {
      "kind": "synapse",
      "title": "Methylphenidate at synapse",
      "steps": [
        "DAT ⊣",
        "NET ⊣",
        "DA ↑",
        "NE ↑"
      ]
    }
  },
  "90": {
    "mechanism": [
      "Levodopa crosses BBB → dopamine in CNS"
    ],
    "pearls": [
      "Длительная терапия может сопровождаться wearing-off, on-off fluctuations и dyskinesias."
    ],
    "interactions": [],
    "visual": null
  },
  "28": {
    "mechanism": [
      "Peripheral DOPA-decarboxylase inhibitor"
    ],
    "pearls": [
      "Повышает доступность levodopa для мозга и уменьшает peripheral dopamine-related adverse effects."
    ],
    "interactions": [],
    "visual": null
  },
  "62": {
    "mechanism": [
      "COMT inhibitor"
    ],
    "pearls": [
      "Уменьшает peripheral metabolism levodopa; используется при wearing-off."
    ],
    "interactions": [],
    "visual": null
  },
  "138": {
    "mechanism": [
      "Selective MAO-B inhibitor"
    ],
    "pearls": [
      "Dopamine breakdown in CNS ↓; может сочетаться с levodopa/carbidopa."
    ],
    "interactions": [],
    "visual": null
  },
  "17": {
    "mechanism": [
      "Central muscarinic receptor blockade"
    ],
    "pearls": [
      "Уменьшает cholinergic overactivity in striatum; anticholinergic adverse effects."
    ],
    "interactions": [],
    "visual": null
  },
  "140": {
    "mechanism": [
      "D₂ + 5-HT₂A antagonism"
    ],
    "pearls": [
      "EPS risk ниже, чем у высокопотентных типичных antipsychotics, но дозозависимо не равен нулю."
    ],
    "interactions": [],
    "visual": null
  },
  "78": {
    "mechanism": [
      "Potent D₂ antagonism"
    ],
    "pearls": [
      "Высокий риск EPS; используется при psychosis, некоторых тиках и как antiemetic in selected settings."
    ],
    "interactions": [],
    "visual": null
  },
  "92": {
    "mechanism": [
      "Ионные/внутриклеточные механизмы mood stabilization; узкое therapeutic window"
    ],
    "pearls": [
      "Требует serum level monitoring; toxicity включает neurologic и cardiac manifestations."
    ],
    "interactions": [],
    "visual": null
  },
  "122": {
    "mechanism": [
      "SSRI: SERT inhibition"
    ],
    "pearls": [
      "Используется при depression, panic disorder, social anxiety, OCD."
    ],
    "interactions": [
      "Clopidogrel: bleeding risk ↑",
      "Codeine: CYP2D6 inhibition → analgesia may ↓"
    ],
    "visual": null
  },
  "48": {
    "mechanism": [
      "GABA-A positive allosteric modulation"
    ],
    "pearls": [
      "CYP metabolism → выше interaction potential; sedation/respiratory depression risk."
    ],
    "interactions": [],
    "visual": null
  },
  "96": {
    "mechanism": [
      "GABA-A positive allosteric modulation"
    ],
    "pearls": [
      "Преимущественно glucuronidation → меньше CYP-interactions."
    ],
    "interactions": [],
    "visual": null
  },
  "117": {
    "mechanism": [
      "GABA-A positive allosteric modulation"
    ],
    "pearls": [
      "Преимущественно glucuronidation."
    ],
    "interactions": [],
    "visual": null
  },
  "170": {
    "mechanism": [
      "GABA-A benzodiazepine-site agonist with relative α1/BZ1 preference"
    ],
    "pearls": [
      "Преимущественно hypnotic effect; shorter half-life."
    ],
    "interactions": [],
    "visual": null
  },
  "86": {
    "mechanism": [
      "Voltage-gated Na⁺ channel modulation"
    ],
    "pearls": [
      "В source block предпочитается в pregnancy among listed options."
    ],
    "interactions": [
      "Valproate ↓ metabolism lamotrigine → exposure/rash risk ↑"
    ],
    "visual": null
  },
  "164": {
    "mechanism": [
      "Multiple: GABA ↑, Na⁺ channel effects, etc."
    ],
    "pearls": [
      "Высокий teratogenic risk; по возможности избегать при pregnancy."
    ],
    "interactions": [
      "Lamotrigine metabolism ↓"
    ],
    "visual": null
  },
  "27": {
    "mechanism": [
      "Na⁺ channel inactivation stabilization"
    ],
    "pearls": [
      "CYP3A4 inducer."
    ],
    "interactions": [
      "Oral contraceptives efficacy ↓"
    ],
    "visual": null
  },
  "130": {
    "mechanism": [
      "α₂δ subunit of voltage-gated Ca²⁺ channels"
    ],
    "pearls": [
      "Neuropathic pain + selected epilepsy indications; does not directly activate GABA receptors."
    ],
    "interactions": [],
    "visual": null
  },
  "80": {
    "mechanism": [
      "Reversible COX inhibition"
    ],
    "pearls": [
      "Renal PG ↓ → sodium/water retention and GFR risk."
    ],
    "interactions": [
      "Aspirin antiplatelet effect may be reduced depending on timing",
      "ACE inhibitor → renal hemodynamic risk",
      "Methotrexate clearance may ↓"
    ],
    "visual": null
  },
  "11": {
    "mechanism": [
      "Irreversible platelet COX-1 acetylation → TXA₂ ↓"
    ],
    "pearls": [
      "Antiplatelet effect persists for platelet lifespan."
    ],
    "interactions": [
      "Ibuprofen can interfere with platelet COX-1 access"
    ],
    "visual": null
  },
  "161": {
    "mechanism": [
      "Weak μ-agonism + 5-HT/NA reuptake inhibition; CYP2D6 active metabolite"
    ],
    "pearls": [
      "Respiratory depression generally less than potent pure μ-agonists but not absent."
    ],
    "interactions": [
      "SSRI → serotonin syndrome/seizure risk ↑"
    ],
    "visual": null
  },
  "41": {
    "mechanism": [
      "Prodrug-like partial CYP2D6 conversion to morphine for analgesia"
    ],
    "pearls": [
      "CYP2D6 phenotype changes analgesic response."
    ],
    "interactions": [
      "Paroxetine ⊣ CYP2D6 → morphine formation ↓"
    ],
    "visual": null
  },
  "58": {
    "mechanism": [
      "SNRI"
    ],
    "pearls": [
      "First-line option for several neuropathic pain syndromes."
    ],
    "interactions": [],
    "visual": null
  },
  "114": {
    "mechanism": [
      "Irreversible H⁺/K⁺-ATPase inhibitor after acid activation"
    ],
    "pearls": [
      "Take before meal; effect outlasts plasma half-life."
    ],
    "interactions": [
      "Phenytoin exposure may ↑",
      "Clopidogrel activation may ↓"
    ],
    "visual": null
  },
  "67": {
    "mechanism": [
      "H₂ receptor antagonist"
    ],
    "pearls": [
      "Can be used when antacids are insufficient in step-up therapy for heartburn."
    ],
    "interactions": [],
    "visual": null
  },
  "68": {
    "mechanism": [
      "Peripheral H₁ receptor antagonist, 2nd generation"
    ],
    "pearls": [
      "Minimal BBB penetration → low sedation."
    ],
    "interactions": [],
    "visual": null
  },
  "52": {
    "mechanism": [
      "H₁ antagonist with anticholinergic effects"
    ],
    "pearls": [
      "Motion sickness/antiemetic use; sedation common."
    ],
    "interactions": [],
    "visual": null
  },
  "129": {
    "mechanism": [
      "Glucocorticoid receptor agonist"
    ],
    "pearls": [
      "Genomic action via intracellular receptor → nucleus; chronic adverse effects include hyperglycemia, HTN, osteoporosis, glaucoma."
    ],
    "interactions": [],
    "visual": null
  },
  "121": {
    "mechanism": [
      "Central analgesic/antipyretic; weak peripheral anti-inflammatory effect"
    ],
    "pearls": [
      "Overdose: glutathione depletion → NAPQI hepatotoxicity; NAC antidote."
    ],
    "interactions": [],
    "visual": null
  }
};
