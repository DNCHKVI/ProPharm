export const HIGH_YIELD = {
  "cardio": [
    "L-type Ca²⁺-канал ≠ RyR2: первый пропускает Ca²⁺ из внеклеточного пространства, второй — из СПР.",
    "SERCA2a ≠ NCX: SERCA возвращает Ca²⁺ в СПР с затратой ATP; NCX использует Na⁺-градиент.",
    "СА/АВ-узел: фаза 0 зависит от Ca²⁺; рабочий желудочковый миокард: фаза 0 зависит от Na⁺.",
    "P = деполяризация предсердий; QRS = деполяризация желудочков; T = реполяризация желудочков.",
    "PR interval ≠ PR segment.",
    "QT зависит от ЧСС, поэтому используют QTc; QTc >500 мс — важный маркер высокого риска TdP.",
    "Дигидропиридины (amlodipine/nifedipine) преимущественно сосудистые; verapamil/diltiazem значительно сильнее влияют на АВ-узел.",
    "Гипокалиемия: T уплощается, U появляется; гиперкалиемия: высокий заострённый T, затем PR/QRS могут увеличиваться."
  ],
  "psych": [
    "Methylphenidate: DAT + NET blockade → DA + NE ↑.",
    "Benzodiazepines require endogenous GABA and increase frequency of GABA-A Cl⁻ channel opening.",
    "TCA antimuscarinic effects include xerostomia, constipation, urinary retention, mydriasis and tachycardia.",
    "SSRI + antiplatelet therapy can increase bleeding risk."
  ],
  "neuro": [
    "Carbidopa = peripheral DOPA-decarboxylase inhibitor; entacapone = COMT inhibitor; rasagiline = MAO-B inhibitor.",
    "Valproate can increase lamotrigine exposure and rash/SJS risk.",
    "Pregabalin binds α₂δ VGCC; it does not directly activate GABA receptors.",
    "Triptans are 5-HT1B/1D agonists for acute migraine."
  ],
  "pain": [
    "COX-1 supports gastric mucosa and platelet TXA₂; COX-2 is more inflammation-associated.",
    "NSAID + ACE inhibitor can reduce glomerular filtration by opposing arteriolar effects.",
    "Tramadol + SSRI → serotonin syndrome/seizure risk ↑.",
    "Codeine analgesia depends partly on CYP2D6 conversion to morphine.",
    "Paracetamol overdose: glutathione depletion → NAPQI hepatotoxicity; NAC is antidote."
  ],
  "gi": [
    "ECL histamine → H₂ → cAMP → H⁺/K⁺-ATPase → HCl.",
    "Omeprazole irreversibly inhibits H⁺/K⁺-ATPase after acid activation.",
    "Omeprazole ⊣ CYP2C19 → phenytoin exposure may ↑ and clopidogrel activation may ↓."
  ],
  "resp": [
    "First-generation H₁ blockers cross BBB more readily and are more sedating; fexofenadine is minimally sedating."
  ],
  "immune": [
    "Glucocorticoid receptor is intracellular; hormone–receptor complex translocates to nucleus and changes transcription.",
    "Chronic systemic glucocorticoids cause hyperglycemia rather than hypoglycemia."
  ],
  "endocrine": [
    "Diabetes: FPG ≥126 mg/dL, 2-h OGTT ≥200 mg/dL, HbA1c ≥6.5% are key diagnostic thresholds.",
    "Type 2 diabetes begins with insulin resistance and compensatory hyperinsulinemia before β-cell failure.",
    "Sweating is more typical of hypoglycemia than hyperglycemia."
  ]
};
