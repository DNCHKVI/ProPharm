export const INTERACTIONS = {
  "psych": [
    {
      "id": "paroxetine-clopidogrel",
      "title": "Paroxetine + Clopidogrel",
      "type": "Фармакодинамическое",
      "drugIds": [
        122,
        39
      ],
      "summary": "SSRI-associated platelet dysfunction + antiplatelet therapy → bleeding risk ↑.",
      "chain": [
        "SSRI → platelet serotonin uptake ↓",
        "platelet function ↓",
        "clopidogrel → P2Y12 block",
        "combined bleeding risk ↑"
      ],
      "note": "Это взаимодействие источник разбирает как фармакодинамическое."
    },
    {
      "id": "tramadol-ssri",
      "title": "Tramadol + SSRI",
      "type": "Фармакодинамическое",
      "drugIds": [
        161,
        63,
        70,
        122,
        145
      ],
      "summary": "Суммирование serotonergic activity → serotonin syndrome/seizure risk ↑.",
      "chain": [
        "tramadol → 5-HT/NA reuptake ↓",
        "SSRI → 5-HT reuptake ↓",
        "serotonergic activity ↑↑",
        "serotonin syndrome / seizures"
      ]
    },
    {
      "id": "codeine-paroxetine",
      "title": "Codeine + Paroxetine",
      "type": "Фармакокинетическое",
      "drugIds": [
        41,
        122
      ],
      "summary": "CYP2D6 inhibition → conversion codeine→morphine ↓ → analgesia may decrease.",
      "chain": [
        "codeine",
        "CYP2D6",
        "morphine",
        "analgesia",
        "paroxetine ⊣ CYP2D6 → effect ↓"
      ]
    }
  ],
  "neuro": [
    {
      "id": "valproate-lamotrigine",
      "title": "Valproate + Lamotrigine",
      "type": "Фармакокинетическое",
      "drugIds": [
        164,
        86
      ],
      "summary": "Valproate slows lamotrigine metabolism → lamotrigine exposure ↑ → rash/SJS risk ↑.",
      "chain": [
        "valproate",
        "lamotrigine metabolism ↓",
        "lamotrigine concentration ↑",
        "rash/SJS risk ↑",
        "lower/slower lamotrigine titration"
      ]
    },
    {
      "id": "carbamazepine-oc",
      "title": "Carbamazepine + Oral contraceptive",
      "type": "Фармакокинетическое",
      "drugIds": [
        27,
        115
      ],
      "summary": "CYP3A4 induction → hormone metabolism ↑ → contraceptive efficacy ↓.",
      "chain": [
        "carbamazepine",
        "CYP3A4 induction",
        "estrogen/progestin metabolism ↑",
        "exposure ↓",
        "contraceptive efficacy ↓"
      ]
    }
  ],
  "pain": [
    {
      "id": "ibuprofen-aspirin",
      "title": "Ibuprofen + Aspirin",
      "type": "Фармакодинамическое на уровне COX-1",
      "drugIds": [
        80,
        11
      ],
      "summary": "Reversible ibuprofen occupancy of platelet COX-1 can interfere with aspirin access and reduce aspirin antiplatelet effect depending on timing.",
      "chain": [
        "ibuprofen ↔ COX-1",
        "aspirin needs COX-1 access",
        "aspirin irreversible acetylation ↓",
        "antiplatelet effect may ↓"
      ]
    },
    {
      "id": "nsaid-acei",
      "title": "NSAID + ACE inhibitor",
      "type": "Гемодинамическое",
      "drugIds": [
        80,
        110,
        49,
        31,
        60
      ],
      "summary": "Afferent constriction + efferent dilation → intraglomerular pressure/GFR ↓.",
      "chain": [
        "NSAID → renal PG ↓",
        "afferent dilation ↓",
        "ACEi → efferent dilation",
        "glomerular pressure ↓",
        "AKI risk ↑"
      ]
    },
    {
      "id": "nsaid-mtx",
      "title": "NSAID + Methotrexate",
      "type": "Фармакокинетическое",
      "drugIds": [
        80,
        104
      ],
      "summary": "Renal methotrexate clearance may decrease → exposure/toxicity ↑.",
      "chain": [
        "NSAID",
        "renal clearance of methotrexate ↓",
        "methotrexate concentration ↑",
        "toxicity ↑"
      ]
    }
  ],
  "gi": [
    {
      "id": "omeprazole-phenytoin",
      "title": "Omeprazole + Phenytoin",
      "type": "Фармакокинетическое",
      "drugIds": [
        114,
        126
      ],
      "summary": "CYP2C19 inhibition by omeprazole can reduce phenytoin metabolism and increase exposure.",
      "chain": [
        "omeprazole ⊣ CYP2C19",
        "phenytoin metabolism ↓",
        "phenytoin concentration ↑",
        "toxicity monitoring"
      ]
    },
    {
      "id": "omeprazole-clopidogrel",
      "title": "Omeprazole + Clopidogrel",
      "type": "Фармакокинетическое",
      "drugIds": [
        114,
        39
      ],
      "summary": "CYP2C19 inhibition → clopidogrel activation ↓ → antiplatelet effect may decrease.",
      "chain": [
        "clopidogrel prodrug",
        "CYP2C19",
        "active metabolite",
        "P2Y12 block",
        "omeprazole ⊣ CYP2C19 → activation ↓"
      ]
    }
  ],
  "hemostasis": [
    {
      "id": "clopidogrel-ssri",
      "title": "Clopidogrel + SSRI",
      "type": "Фармакодинамическое",
      "drugIds": [
        39,
        122,
        63,
        70,
        145
      ],
      "summary": "Antiplatelet effect + SSRI-associated impairment of platelet serotonin handling → bleeding risk ↑.",
      "chain": [
        "clopidogrel → P2Y12 block",
        "SSRI → platelet serotonin uptake ↓",
        "hemostatic reserve ↓",
        "bleeding risk ↑"
      ]
    },
    {
      "id": "clopidogrel-omeprazole",
      "title": "Clopidogrel + Omeprazole",
      "type": "Фармакокинетическое",
      "drugIds": [
        39,
        114
      ],
      "summary": "CYP2C19 inhibition may reduce clopidogrel bioactivation.",
      "chain": [
        "clopidogrel prodrug",
        "CYP2C19",
        "active metabolite",
        "omeprazole ⊣ CYP2C19",
        "antiplatelet effect ↓"
      ]
    }
  ]
};
