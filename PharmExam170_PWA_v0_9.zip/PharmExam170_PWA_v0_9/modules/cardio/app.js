// Интерактивный конспект: электрофизиология сердца, ЭКГ и 49 препаратов.
// Учебная модель, не клинический симулятор.

const root=document.getElementById("app");
const uid="cardio_app";
root.id=uid;

const DRUGS=[{"n":6,"name":"Amiodarone","g":"Антиаритмики III класса","note":"IKr ↓; дополнительно Na⁺/Ca²⁺/β-эффекты → реполяризация и рефрактерность ↑; QT ↑, ЧСС/проводимость могут ↓."},{"n":7,"name":"Amitriptyline","g":"Трициклические антидепрессанты","note":"При кардиотоксичности блокирует быстрые Na⁺-каналы → QRS ↑; антихолинергический эффект → ЧСС ↑; возможен QT ↑."},{"n":8,"name":"Amlodipine","g":"Дигидропиридиновые БКК","note":"Блокирует L-type Ca²⁺-каналы сосудов → вазодилатация; прямое торможение АВ-узла минимально; возможна рефлекторная тахикардия."},{"n":12,"name":"Atenolol","g":"β-адреноблокаторы","note":"β1 ↓ → Gs/cAMP/PKA ↓ → If и ICaL ↓ → ЧСС ↓, АВ-проведение ↓, сократимость ↓."},{"n":14,"name":"Azithromycin","g":"Антиинфекционные препараты с риском QT","note":"Снижает реполяризационный резерв → фаза 3 дольше → QT/QTc ↑; риск TdP выше при гипокалиемии и сочетаниях."},{"n":26,"name":"Calcium","g":"Электролит-модифицирующие средства","note":"Ca²⁺ влияет на фазу 2 и ECC; гипокальциемия удлиняет ST/QT, гиперкальциемия укорачивает QT."},{"n":27,"name":"Carbamazepine","g":"Na⁺-канальные противоэпилептические","note":"Модулирует voltage-gated Na⁺-каналы; при токсичности/предрасположенности возможно замедление проводимости."},{"n":35,"name":"Ciprofloxacin","g":"Антиинфекционные препараты с риском QT","note":"У восприимчивых пациентов может замедлять реполяризацию → QT ↑; риск усиливается электролитными нарушениями."},{"n":38,"name":"Clonidine","g":"Центральное/холинергическое замедление ритма","note":"Центральные α2 → симпатический outflow ↓ → β1-сигнал ↓ → ЧСС ↓ и АВ-проведение ↓."},{"n":40,"name":"Clozapine","g":"Антипсихотики/фенотиазины с риском ЭКГ","note":"Автономные эффекты часто дают тахикардию; возможен QT ↑. Отдельно помнить риск myocarditis/cardiomyopathy."},{"n":50,"name":"Digoxin","g":"Сердечные гликозиды","note":"Na⁺/K⁺-АТФаза ↓ → Na⁺i ↑ → NCX хуже выводит Ca²⁺ → Ca²⁺i/SR ↑ → инотропия ↑; вагус ↑ → PR ↑."},{"n":51,"name":"Diltiazem","g":"Недигидропиридиновые БКК","note":"L-type Ca²⁺ ↓ в СА/АВ-узле → Ca²⁺-зависимая фаза 0 медленнее → ЧСС ↓, PR ↑; сократимость ↓."},{"n":54,"name":"Domperidone","g":"D₂-антагонисты: противорвотные/прокинетики","note":"Кардиальный риск связан не с D₂-блокадой, а с уменьшением реполяризационного резерва → QT ↑."},{"n":55,"name":"Donepezil","g":"Центральное/холинергическое замедление ритма","note":"AChE ↓ → ACh ↑ → M2/Gi и GIRK ↑ → cAMP/If/ICaL ↓ → брадикардия, PR ↑; возможен QT-риск."},{"n":63,"name":"Escitalopram","g":"Антидепрессанты с влиянием на QT/автономику","note":"Дозозависимый потенциал удлинения реполяризации → QT ↑; риск выше при других QT-факторах."},{"n":69,"name":"Fluconazole","g":"Антиинфекционные препараты с риском QT","note":"Реполяризация замедляется; дополнительно CYP-взаимодействия могут повышать экспозицию других QT-препаратов."},{"n":70,"name":"Fluoxetine","g":"Антидепрессанты с влиянием на QT/автономику","note":"QT-эффект обычно контекстный; важны сочетания и CYP2D6-взаимодействия."},{"n":73,"name":"Furosemide","g":"Диуретики и калиевый баланс","note":"NKCC2 ↓ → потери K⁺/Mg²⁺ ↑ → гипокалиемия: T ↓, U ↑; риск QT/TdP косвенно ↑."},{"n":78,"name":"Haloperidol","g":"Антипсихотики/фенотиазины с риском ЭКГ","note":"IKr/hERG ↓ → реполяризация дольше → QT ↑; риск TdP особенно при высокой экспозиции и сочетаниях."},{"n":79,"name":"Hydrochlorothiazide","g":"Диуретики и калиевый баланс","note":"NCC ↓ → дистальная доставка Na⁺ ↑ → потери K⁺ ↑ → T уплощается, U появляется; TdP-риск косвенно ↑."},{"n":81,"name":"Insulin","g":"Электролит-модифицирующие средства","note":"Insulin receptor → PI3K/Akt → Na⁺/K⁺-АТФаза ↑ → K⁺ внутрь клеток → serum K⁺ ↓; используется для временной коррекции гиперкалиемии."},{"n":84,"name":"Ketoconazole","g":"Антиинфекционные препараты с риском QT","note":"Может снижать реполяризационный резерв; CYP3A4 inhibition усиливает риск взаимодействий."},{"n":86,"name":"Lamotrigine","g":"Na⁺-канальные противоэпилептические","note":"Na⁺-канальный механизм; у пациентов с клинически значимой сердечной патологией возможен риск нарушений проводимости/аритмий."},{"n":91,"name":"Levothyroxine","g":"Симпатическая/эндокринная стимуляция","note":"T4→T3 → β-адренергическая чувствительность ↑ → автоматизм СА-узла ↑ → тахикардия/риск предсердных аритмий при избытке."},{"n":92,"name":"Lithium","g":"Особые токсикологические примеры","note":"При токсичности возможны дисфункция СА-узла, брадикардия, изменения T и проводимости/QT."},{"n":94,"name":"Loperamide","g":"Особые токсикологические примеры","note":"При передозировке блокирует cardiac Na⁺ и hERG/K⁺ → QRS ↑ + QT ↑ → риск VT/TdP."},{"n":105,"name":"Methylphenidate","g":"Симпатическая/эндокринная стимуляция","note":"DAT/NET ↓ → catecholamines ↑ → β1/cAMP/PKA ↑ → ЧСС/АД ↑; у предрасположенных возможна эктопия."},{"n":106,"name":"Metoclopramide","g":"D₂-антагонисты: противорвотные/прокинетики","note":"QT-риск контекстный; важны сочетания и электролитные нарушения."},{"n":107,"name":"Metoprolol","g":"β-адреноблокаторы","note":"β1 ↓ → If/ICaL/cAMP ↓ → ЧСС ↓, PR ↑, сократимость ↓."},{"n":111,"name":"Nifedipine","g":"Дигидропиридиновые БКК","note":"Сосудистый L-type Ca²⁺ ↓ → вазодилатация; возможна рефлекторная тахикардия; АВ-узел подавляет существенно слабее non-DHP."},{"n":112,"name":"Nortriptyline","g":"Трициклические антидепрессанты","note":"При токсичности INa ↓ → QRS ↑; антихолинергический компонент → ЧСС ↑; возможен QT ↑."},{"n":118,"name":"Oxcarbazepine","g":"Na⁺-канальные противоэпилептические","note":"Na⁺-канальный механизм; потенциальное влияние на проводимость клинически значимее у уязвимых пациентов/при токсичности."},{"n":124,"name":"Perphenazine","g":"Антипсихотики/фенотиазины с риском ЭКГ","note":"Фенотиазиновый антипсихотик; возможное уменьшение реполяризационного резерва → QT ↑."},{"n":126,"name":"Phenytoin","g":"Na⁺-канальные противоэпилептические","note":"Блокирует быстрые Na⁺-каналы; при в/в введении/токсичности может замедлять проведение → PR/QRS ↑."},{"n":128,"name":"Potassium chloride","g":"Электролит-модифицирующие средства","note":"Корректирует гипокалиемию и нормализует K⁺-зависимые токи; избыток K⁺ → peaked T → PR/QRS ↑."},{"n":131,"name":"Promethazine","g":"Антипсихотики/фенотиазины с риском ЭКГ","note":"Фенотиазиновое H1-средство; возможен QT-риск у предрасположенных."},{"n":132,"name":"Propafenone","g":"Антиаритмики IC класса","note":"Сильная блокада Nav1.5 → фаза 0 медленнее → проведение ↓ → PR и особенно QRS ↑."},{"n":133,"name":"Propranolol","g":"β-адреноблокаторы","note":"β1/β2 ↓; в сердце β1-сигнал ↓ → автоматизм и АВ-проведение ↓ → ЧСС ↓, PR ↑."},{"n":134,"name":"Pseudoephedrine","g":"Симпатическая/эндокринная стимуляция","note":"Sympathomimetic drive ↑ → сосудистый тонус/АД ↑; ЧСС и эктопия могут ↑."},{"n":136,"name":"Quetiapine","g":"Антипсихотики/фенотиазины с риском ЭКГ","note":"Возможен QT-риск, особенно при передозировке, сочетаниях и электролитных нарушениях."},{"n":140,"name":"Risperidone","g":"Антипсихотики/фенотиазины с риском ЭКГ","note":"Может удлинять QT у восприимчивых пациентов; риск зависит от дозы и факторов пациента."},{"n":143,"name":"Roxithromycin","g":"Антиинфекционные препараты с риском QT","note":"Макролид-ассоциированный риск замедления реполяризации → QT ↑ у предрасположенных."},{"n":144,"name":"Salbutamol","g":"Электролит-модифицирующие средства","note":"β2→Gs/cAMP ↑ + Na⁺/K⁺-АТФаза ↑ в мышце → K⁺ внутрь → serum K⁺ ↓; ЧСС ↑; при гипокалиемии T ↓/U ↑."},{"n":150,"name":"Spironolactone","g":"Диуретики и калиевый баланс","note":"Mineralocorticoid receptor ↓ → K⁺-секреция почками ↓ → риск гиперкалиемии: peaked T → PR/QRS ↑."},{"n":158,"name":"Timolol","g":"β-адреноблокаторы","note":"Даже офтальмологический timolol может давать системную β-блокаду → брадикардия, PR ↑/АВ-блокада."},{"n":160,"name":"Topiramate","g":"Na⁺-канальные противоэпилептические","note":"Мультимодальный противоэпилептик; Na⁺-канальный компонент рассматривается как условная cardiac-safety связь, а не типичный ЭКГ-эффект."},{"n":162,"name":"Trazodone","g":"Антидепрессанты с влиянием на QT/автономику","note":"Может удлинять QT, особенно при передозировке и сочетании факторов риска."},{"n":165,"name":"Venlafaxine","g":"Антидепрессанты с влиянием на QT/автономику","note":"NA/5-HT ↑ → ЧСС/АД могут ↑; при токсичности возможны QT/QRS-изменения."},{"n":166,"name":"Verapamil","g":"Недигидропиридиновые БКК","note":"L-type Ca²⁺ ↓ в СА/АВ-узле и миокарде → ЧСС ↓, PR ↑, сократимость ↓; избыток → АВ-блокада."}];
const GROUPS={"Антиаритмики III класса":{"ecg":{"hr":58,"pr":190,"qrs":105,"qt":480,"t":0.9},"bio":["IKr ↓","выход K⁺ в фазу 3 ↓","реполяризация и ERP ↑","QT ↑; автоматизм/проводимость могут ↓"]},"Антиаритмики IC класса":{"ecg":{"hr":64,"pr":220,"qrs":150,"qt":430,"t":1},"bio":["Nav1.5 блокирован","INa ↓","фаза 0 становится медленнее","проведение ↓","QRS ↑, PR ↑"]},"β-адреноблокаторы":{"ecg":{"hr":52,"pr":200,"qrs":90,"qt":430,"t":1},"bio":["β1 блокирован","Gs → AC → cAMP ↓","PKA ↓","If + ICaL ↓","ЧСС ↓, PR ↑, сократимость ↓"]},"Недигидропиридиновые БКК":{"ecg":{"hr":54,"pr":220,"qrs":90,"qt":420,"t":1},"bio":["Cav1.2/L-type Ca²⁺ блокирован","ICaL ↓","фаза 0 СА/АВ-узла медленнее","АВ-проведение ↓","PR ↑; инотропия ↓"]},"Дигидропиридиновые БКК":{"ecg":{"hr":88,"pr":160,"qrs":90,"qt":410,"t":1},"bio":["L-type Ca²⁺ сосудов ↓","Ca²⁺–calmodulin/MLCK ↓","вазодилатация","барорефлекс ↑","возможна рефлекторная тахикардия"]},"Сердечные гликозиды":{"ecg":{"hr":55,"pr":220,"qrs":90,"qt":360,"t":0.55,"st":-0.45},"bio":["Na⁺/K⁺-АТФаза ↓","Na⁺i ↑","градиент Na⁺ ↓","выведение Ca²⁺ через NCX ↓","Ca²⁺i/SR ↑ → инотропия ↑","вагус ↑ → PR ↑"]},"Трициклические антидепрессанты":{"ecg":{"hr":105,"pr":180,"qrs":145,"qt":475,"t":0.75},"bio":["быстрые Na⁺-каналы ↓","INa ↓","проведение ↓ → QRS ↑","антихолинергический эффект → ЧСС ↑","реполяризация может замедляться → QT ↑"]},"Антиинфекционные препараты с риском QT":{"ecg":{"hr":70,"pr":160,"qrs":90,"qt":470,"t":0.9},"bio":["реполяризующий K⁺-резерв ↓","фаза 3 дольше","APD ↑","QT/QTc ↑","EAD/TdP-риск ↑ при дополнительных факторах"]},"Антипсихотики/фенотиазины с риском ЭКГ":{"ecg":{"hr":84,"pr":165,"qrs":92,"qt":465,"t":0.9},"bio":["IKr/реполяризационный резерв ↓","фаза 3 дольше","QT ↑","автономные рецепторные эффекты могут менять ЧСС"]},"Антидепрессанты с влиянием на QT/автономику":{"ecg":{"hr":82,"pr":160,"qrs":92,"qt":455,"t":0.9},"bio":["моноаминергическая передача изменяется","у части препаратов IKr-резерв ↓","QT может ↑","при NA-компоненте симпатический тонус и ЧСС ↑"]},"D₂-антагонисты: противорвотные/прокинетики":{"ecg":{"hr":72,"pr":160,"qrs":90,"qt":470,"t":0.9},"bio":["терапевтическая D₂-блокада","отдельно: реполяризационный K⁺-резерв ↓","фаза 3 дольше","QT ↑","риск усиливают гипокалиемия/сочетания"]},"Диуретики и калиевый баланс":{"ecg":{"hr":78,"pr":165,"qrs":95,"qt":450,"t":0.55,"u":0.4,"st":-0.2},"bio":["почечный Na⁺-транспорт изменяется","дистальная секреция K⁺ меняется","[K⁺]o меняется","IK1/IKr и реполяризация меняются","форма T/U зависит от направления K⁺"]},"Электролит-модифицирующие средства":{"ecg":{"hr":75,"pr":160,"qrs":92,"qt":430,"t":0.8,"u":0.15},"bio":["меняется доступность/распределение K⁺ или Ca²⁺","трансмембранные градиенты меняются","потенциал покоя/реполяризация/ECC меняются","для точного направления выбери конкретный препарат"]},"Симпатическая/эндокринная стимуляция":{"ecg":{"hr":108,"pr":145,"qrs":90,"qt":390,"t":1},"bio":["catecholamine/β-чувствительность ↑","β1→Gs→cAMP/PKA ↑","If + ICaL ↑","фаза 4 СА-узла круче","ЧСС ↑, АВ-проведение ускоряется"]},"Центральное/холинергическое замедление ритма":{"ecg":{"hr":50,"pr":205,"qrs":90,"qt":430,"t":1},"bio":["симпатический драйв ↓ или вагус ↑","cAMP в пейсмекере ↓","If + ICaL ↓","СА-автоматизм ↓","ЧСС ↓, PR ↑"]},"Na⁺-канальные противоэпилептические":{"ecg":{"hr":66,"pr":180,"qrs":105,"qt":410,"t":1},"bio":["voltage-gated Na⁺-каналы модулируются","в ЦНС высокочастотная импульсация ↓","при cardiac exposure INa может ↓","фаза 0/проведение могут замедляться"]},"Особые токсикологические примеры":{"ecg":{"hr":68,"pr":180,"qrs":120,"qt":460,"t":0.75},"bio":["при токсической концентрации ионные системы нарушаются","автоматизм/INa/реполяризация страдают в разной степени","возможны брадикардия, QRS ↑, QT ↑","для точного механизма выбери препарат"]}};
const OVERRIDE={"Amiodarone":{"hr":56,"pr":195,"qrs":108,"qt":485,"t":0.85},"Amitriptyline":{"hr":106,"pr":180,"qrs":148,"qt":480,"t":0.72},"Amlodipine":{"hr":80,"pr":160,"qrs":90,"qt":410,"t":1},"Atenolol":{"hr":52,"pr":195,"qrs":90,"qt":430,"t":1},"Calcium":{"hr":70,"pr":155,"qrs":90,"qt":350,"t":1},"Carbamazepine":{"hr":64,"pr":190,"qrs":108,"qt":410,"t":1},"Clonidine":{"hr":50,"pr":195,"qrs":90,"qt":430,"t":1},"Clozapine":{"hr":105,"pr":155,"qrs":92,"qt":450,"t":0.9},"Digoxin":{"hr":54,"pr":220,"qrs":90,"qt":355,"t":0.45,"st":-0.5},"Diltiazem":{"hr":56,"pr":210,"qrs":90,"qt":420,"t":1},"Domperidone":{"hr":72,"pr":160,"qrs":90,"qt":480,"t":0.9},"Donepezil":{"hr":52,"pr":205,"qrs":90,"qt":450,"t":0.9},"Escitalopram":{"hr":72,"pr":160,"qrs":90,"qt":465,"t":0.9},"Furosemide":{"hr":78,"pr":165,"qrs":95,"qt":455,"t":0.4,"u":0.55,"st":-0.3},"Haloperidol":{"hr":78,"pr":160,"qrs":92,"qt":490,"t":0.9},"Hydrochlorothiazide":{"hr":76,"pr":165,"qrs":95,"qt":450,"t":0.45,"u":0.5,"st":-0.25},"Insulin":{"hr":78,"pr":160,"qrs":92,"qt":445,"t":0.5,"u":0.4,"st":-0.2},"Lamotrigine":{"hr":66,"pr":175,"qrs":102,"qt":410,"t":1},"Levothyroxine":{"hr":112,"pr":140,"qrs":90,"qt":380,"t":1},"Lithium":{"hr":52,"pr":185,"qrs":95,"qt":445,"t":0.4},"Loperamide":{"hr":72,"pr":190,"qrs":150,"qt":510,"t":0.75},"Methylphenidate":{"hr":106,"pr":145,"qrs":90,"qt":390,"t":1},"Metoprolol":{"hr":50,"pr":200,"qrs":90,"qt":430,"t":1},"Nifedipine":{"hr":90,"pr":155,"qrs":90,"qt":405,"t":1},"Nortriptyline":{"hr":102,"pr":180,"qrs":138,"qt":465,"t":0.78},"Phenytoin":{"hr":64,"pr":190,"qrs":112,"qt":405,"t":1},"Potassium chloride":{"hr":70,"pr":160,"qrs":90,"qt":400,"t":1.15},"Propafenone":{"hr":64,"pr":220,"qrs":152,"qt":430,"t":1},"Propranolol":{"hr":50,"pr":200,"qrs":90,"qt":430,"t":1},"Pseudoephedrine":{"hr":105,"pr":145,"qrs":90,"qt":390,"t":1},"Salbutamol":{"hr":106,"pr":145,"qrs":92,"qt":430,"t":0.55,"u":0.3,"st":-0.15},"Spironolactone":{"hr":64,"pr":180,"qrs":108,"qt":390,"t":1.55},"Timolol":{"hr":52,"pr":195,"qrs":90,"qt":430,"t":1},"Venlafaxine":{"hr":96,"pr":150,"qrs":95,"qt":445,"t":0.9},"Verapamil":{"hr":50,"pr":225,"qrs":90,"qt":420,"t":1}};
const SPECIAL={"Digoxin":["Na⁺/K⁺-АТФаза ↓","Na⁺ внутри ↑","Na⁺-градиент ↓","NCX выводит меньше Ca²⁺","Ca²⁺ цитозоля/СПР ↑ → инотропия ↑","вагус ↑ → АВ-проведение ↓ → PR ↑"],"Insulin":["insulin receptor → PI3K/Akt","Na⁺/K⁺-АТФаза ↑","K⁺ перемещается внутрь клеток","[K⁺]o ↓","при избытке: T ↓, U ↑; при гиперкалиемии — терапевтическая коррекция"],"Potassium chloride":["K⁺ доступность ↑","при гипокалиемии градиент K⁺ нормализуется","IK1/IKr и Na⁺/K⁺-АТФаза работают ближе к норме","T/U нормализуются","избыток → гиперкалиемический профиль"],"Calcium":["[Ca²⁺]o ↑","Ca²⁺-зависимая кинетика фазы 2 меняется","ST/QT укорачиваются при гиперкальциемии","при коррекции гипокальциемии QT нормализуется"],"Salbutamol":["β2→Gs→cAMP ↑","Na⁺/K⁺-АТФаза в скелетной мышце ↑","K⁺ внутрь клеток","serum K⁺ ↓","ЧСС ↑; при гипокалиемии T ↓ и U ↑"],"Spironolactone":["минералокортикоидный рецептор блокирован","ENaC-зависимая дистальная Na⁺-реабсорбция ↓","K⁺-секреция ↓","[K⁺]o может ↑","peaked T → PR/QRS ↑ при нарастании гиперкалиемии"],"Furosemide":["NKCC2 блокирован","доставка Na⁺ дистально ↑","потери K⁺/Mg²⁺ ↑","[K⁺]o ↓","T ↓, U ↑; QT/TdP-риск ↑ косвенно"],"Hydrochlorothiazide":["NCC блокирован","дистальная доставка Na⁺ ↑","потери K⁺ ↑","гипокалиемия","T ↓, U ↑; сочетание с QT-препаратами опаснее"],"Clonidine":["центральные α2/Gi активированы","norepinephrine outflow ↓","β1/cAMP/PKA ↓","If/ICaL ↓","ЧСС ↓, PR ↑"],"Donepezil":["AChE ингибирована","ACh ↑","M2/Gi + GIRK ↑","cAMP/If/ICaL ↓","брадикардия, PR ↑"],"Levothyroxine":["T4→T3","β-адренергическая чувствительность ↑","ответ на catecholamines ↑","фаза 4 СА-узла круче","тахикардия/риск предсердных аритмий"],"Methylphenidate":["DAT/NET ингибированы","dopamine/norepinephrine ↑","симпатический β1-сигнал ↑","cAMP/PKA/If ↑","ЧСС/АД ↑"],"Pseudoephedrine":["симпатомиметический сигнал ↑","α1-вазоконстрикция ↑","адренергический драйв сердца ↑","ЧСС/АД могут ↑","эктопия у чувствительных"],"Loperamide":["при высоких концентрациях cardiac Na⁺ и hERG/K⁺ блокируются","INa ↓ → QRS ↑","IKr ↓ → QT ↑","substrate для VT/TdP ↑","это профиль передозировки/злоупотребления"],"Propafenone":["Nav1.5 сильно блокирован","INa ↓","фаза 0 рабочего миокарда медленнее","проведение ↓","PR ↑ и особенно QRS ↑"]};
const ELECTRO={"Норма":{"ecg":{"hr":70,"pr":160,"qrs":90,"qt":410,"t":1},"bio":["нормальный K⁺-градиент","стабильный потенциал покоя","нормальные Na⁺/Ca²⁺/K⁺ токи","нормальная проводимость и реполяризация"]},"Гипокалиемия":{"ecg":{"hr":78,"pr":165,"qrs":95,"qt":460,"t":0.3,"u":0.75,"st":-0.4},"bio":["[K⁺]o ↓","IKr/реполяризационный резерв ↓","фаза 3 нестабильнее","T уплощается, ST ↓, U появляется","EAD/TdP-риск ↑ при QT-препаратах"]},"Гиперкалиемия":{"ecg":{"hr":55,"pr":230,"qrs":155,"qt":340,"t":2.2,"p":0.25},"bio":["[K⁺]o ↑","потенциал покоя менее отрицательный","часть fast Na⁺-каналов инактивирована","проведение ↓","peaked T → P ↓/PR ↑ → QRS ↑"]},"Гипокальциемия":{"ecg":{"hr":70,"pr":160,"qrs":90,"qt":510,"t":1},"bio":["[Ca²⁺]o ↓","плато/сегмент ST удлиняется","QT ↑","QRS обычно существенно не меняется"]},"Гиперкальциемия":{"ecg":{"hr":70,"pr":155,"qrs":90,"qt":330,"t":1},"bio":["[Ca²⁺]o ↑","плато завершается быстрее","ST укорачивается","QT ↓"]},"Гипомагниемия":{"ecg":{"hr":78,"pr":160,"qrs":92,"qt":470,"t":0.8,"u":0.2},"bio":["Mg²⁺ ↓","регуляция K⁺/Ca²⁺-токов менее стабильна","реполяризационный резерв ↓","EAD/TdP-риск ↑"]}};

const BASE={hr:70,p:1,pr:160,qrs:90,st:0,t:1,qt:410,u:0};
const merge=(...x)=>Object.assign({},BASE,...x);
const esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));
const $=s=>root.querySelector(s);

const style=document.createElement("style");
style.textContent=`
#${uid}{
  --b:#f4f7fb;
  --b2:#ffffff;
  --f:#18212f;
  --m:#667085;
  --bd:#d8e1ec;
  --a:#2563eb;
  --a2:#eaf2ff;
  --ecg:#0f766e;
  --red:#dc5a67;
  --amber:#b7791f;
  --violet:#7c5ce5;
  --shadow:0 7px 24px rgba(31,41,55,.08);
  color:var(--f);
  background:var(--b);
  font-family:-apple-system,BlinkMacSystemFont,"SF Pro Text","Segoe UI",system-ui,sans-serif;
  font-size:16px;
  line-height:1.45;
  width:100%;
  min-width:0;
  -webkit-text-size-adjust:100%;
  text-size-adjust:100%;
}
#${uid} *{box-sizing:border-box}
#${uid} h1,#${uid} h2,#${uid} h3{color:var(--f);word-break:normal;overflow-wrap:anywhere}
#${uid} h1{font-size:clamp(1.45rem,6vw,2rem);line-height:1.12;margin:0 0 8px}
#${uid} h2{font-size:clamp(1.12rem,4.5vw,1.38rem);line-height:1.22;margin:0 0 10px}
#${uid} p{margin:.55rem 0}
#${uid} .hero,#${uid} .card{
  border:1.5px solid var(--bd);
  border-radius:18px;
  background:var(--b2);
  padding:14px;
  margin-bottom:11px;
  box-shadow:var(--shadow);
  min-width:0;
}
#${uid} .hero{
  background:linear-gradient(145deg,#ffffff 0%,#eef5ff 100%);
  border-color:#cbdcf6;
}
#${uid} .sub,#${uid} .small{color:var(--m)}
#${uid} .small{font-size:.86rem}
#${uid} .tabs{
  position:sticky;
  top:6px;
  z-index:30;
  display:flex;
  gap:6px;
  overflow-x:auto;
  flex-wrap:nowrap;
  margin:8px 0 12px;
  padding:6px;
  border:1.5px solid var(--bd);
  border-radius:16px;
  background:rgba(255,255,255,.96);
  box-shadow:0 5px 18px rgba(31,41,55,.08);
  -webkit-overflow-scrolling:touch;
  scrollbar-width:none;
}
#${uid} .tabs::-webkit-scrollbar{display:none}
#${uid} .tabs button{
  flex:0 0 auto;
  display:flex;
  align-items:center;
  gap:6px;
  min-height:46px;
  padding:6px 9px;
  background:#fff;
  border:1.5px solid var(--bd);
  border-radius:13px;
  color:var(--f);
  font-weight:650;
  white-space:nowrap;
}
#${uid} .tabs button.active{
  background:var(--a2);
  border-color:#91b7f7;
  color:#1549a0;
}
#${uid} .navicon,#${uid} .modeicon{
  display:inline-grid;
  place-items:center;
  width:31px;
  height:31px;
  flex:0 0 31px;
  border:1.5px solid #b9c8dc;
  border-radius:9px;
  background:#fff;
  box-shadow:0 2px 7px rgba(31,41,55,.07);
  font-size:17px;
  line-height:1;
}
#${uid} .panel{display:none}
#${uid} .panel.active{display:block}
#${uid} .grid{
  display:grid;
  grid-template-columns:minmax(0,1fr) minmax(0,1fr);
  gap:10px;
  min-width:0;
}
#${uid} .selects{
  display:grid;
  grid-template-columns:minmax(0,1fr) minmax(0,1fr);
  gap:9px;
}
#${uid} .modes,#${uid} .chips{
  display:flex;
  gap:7px;
  flex-wrap:wrap;
  margin:9px 0;
}
#${uid} button,#${uid} select,#${uid} input{
  font:inherit;
  color:var(--f);
  background:#fff;
  border:1.5px solid var(--bd);
  border-radius:12px;
  padding:9px 10px;
  min-height:44px;
  max-width:100%;
}
#${uid} select,#${uid} input{width:100%}
#${uid} button{cursor:pointer;-webkit-tap-highlight-color:transparent}
#${uid} button.active{
  background:var(--a2);
  border-color:#91b7f7;
  color:#1549a0;
}
#${uid} .mode{
  display:flex;
  align-items:center;
  gap:6px;
  font-weight:600;
}
#${uid} .chip{
  border:1.5px solid #c9d5e5;
  background:#f8fbff;
  border-radius:12px;
}
#${uid} .svg{
  width:100%;
  min-width:0;
  overflow:hidden;
  border:1.5px solid #cbd8e8;
  border-radius:15px;
  background:#fbfdff;
  padding:8px;
}
#${uid} svg{
  width:100%;
  max-width:100%;
  min-width:0;
  height:auto;
  display:block;
  overflow:visible;
}
#${uid} .flow{
  display:flex;
  gap:7px;
  overflow-x:auto;
  align-items:stretch;
  padding:5px 1px 8px;
  -webkit-overflow-scrolling:touch;
}
#${uid} .node{
  min-width:160px;
  border:1.5px solid #cbd8e8;
  border-radius:13px;
  padding:10px;
  background:#f9fbfe;
  color:var(--f);
}
#${uid} .arr{align-self:center;color:#7b8ba1;font-size:1.2rem}
#${uid} .params{
  display:grid;
  grid-template-columns:repeat(3,minmax(0,1fr));
  gap:6px;
  margin-top:9px;
}
#${uid} .p{
  border:1.5px solid #cbd8e8;
  border-radius:11px;
  padding:7px;
  font-size:.82rem;
  background:#fff;
  text-align:center;
}
#${uid} .table{
  max-height:520px;
  overflow:auto;
  border:1.5px solid var(--bd);
  border-radius:12px;
  background:#fff;
}
#${uid} table{width:100%;border-collapse:collapse;font-size:.84rem}
#${uid} th,#${uid} td{
  padding:8px;
  border-bottom:1px solid #e5eaf1;
  text-align:left;
  vertical-align:top;
  color:var(--f);
}
#${uid} th{position:sticky;top:0;background:#eef4fb;z-index:2}
#${uid} .warn{
  border:1.5px solid #f1d18a;
  border-left:5px solid #d39b2c;
  padding:10px;
  background:#fff9e9;
  border-radius:12px;
  margin-top:9px;
  color:#59451d;
}
#${uid} .graph-title{
  display:flex;align-items:center;gap:8px;margin:12px 0 7px;font-weight:750;color:var(--f)
}
#${uid} .graph-title .navicon{width:29px;height:29px;flex-basis:29px}
#${uid} .mobile-note{
  padding:9px 10px;border-radius:11px;background:#f2f7ff;border:1px solid #cfe0f8;color:#36516f;font-size:.86rem
}
@media(max-width:760px){
  #${uid}{font-size:15.5px}
  #${uid} .grid,#${uid} .selects{grid-template-columns:1fr}
  #${uid} .hero,#${uid} .card{padding:12px;border-radius:16px}
  #${uid} .params{grid-template-columns:repeat(2,minmax(0,1fr))}
  #${uid} .flow{
    display:grid;
    grid-template-columns:1fr;
    overflow:visible;
    gap:5px;
  }
  #${uid} .node{min-width:0;width:100%}
  #${uid} .arr{justify-self:center;transform:rotate(90deg);height:22px}
  #${uid} .modes{display:grid;grid-template-columns:1fr 1fr}
  #${uid} .mode{justify-content:flex-start;text-align:left}
  #${uid} table{min-width:660px}
}
@media(max-width:390px){
  #${uid} .tabs button{padding:5px 7px}
  #${uid} .navicon{width:29px;height:29px;flex-basis:29px}
  #${uid} .modes{grid-template-columns:1fr}
}
`;
root.appendChild(style);

root.insertAdjacentHTML("beforeend",`
<div class="hero"><h1>🫀 Электрофизиология сердца и интерактивная фармакология</h1>
<div class="sub">49 экзаменационных препаратов. Выбери группу, препарат или электролит — ЭКГ и биохимическая цепочка изменятся одновременно.</div>
<div class="warn"><b>Важно:</b> ЭКГ — схематическая учебная модель направления изменений, а не прогноз для конкретного пациента.</div><div class="mobile-note" style="margin-top:9px">📱 Версия 2 адаптирована для iPhone: графики масштабируются по ширине экрана, блоки располагаются вертикально, а навигационные иконки имеют отдельные рамки.</div></div>

<div class="tabs" aria-label="Навигация">
<button class="tab active" data-t="sim"><span class="navicon">💊</span><span>Фармакология</span></button>
<button class="tab" data-t="ap"><span class="navicon">⚡</span><span>Потенциал</span></button>
<button class="tab" data-t="ecc"><span class="navicon">🧬</span><span>Ca²⁺</span></button>
<button class="tab" data-t="ref"><span class="navicon">📚</span><span>49 препаратов</span></button>
<button class="tab" data-t="install"><span class="navicon">📲</span><span>Установка</span></button>
</div>

<section class="panel active" data-p="sim">
<div class="card">
<h2>Что моделируем?</h2>
<div class="modes">
<button class="mode active" data-m="group"><span class="modeicon">🗂️</span>Фармгруппа</button>
<button class="mode" data-m="drug"><span class="modeicon">💊</span>Один препарат</button>
<button class="mode" data-m="electro"><span class="modeicon">⚗️</span>Электролиты</button>
<button class="mode" data-m="normal"><span class="modeicon">♥︎</span>Норма</button>
</div>
<div class="selects"><label>Выбор<select id="${uid}_sel"></select></label><div id="${uid}_hint" class="small"></div></div>
</div>
<div class="grid">
<div class="card"><h2 id="${uid}_title"></h2><div id="${uid}_desc"></div><div class="chips" id="${uid}_members"></div><h2 style="margin-top:12px">ЭКГ</h2><div class="svg" id="${uid}_ecg"></div><div class="params" id="${uid}_params"></div></div>
<div class="card"><h2>Биохимическая и клеточная цепочка</h2><div class="flow" id="${uid}_bio"></div></div>
</div>
</section>

<section class="panel" data-p="ap">
<div class="card">
  <h2>Потенциал действия рабочего кардиомиоцита</h2>
  <div class="graph-title"><span class="navicon">📈</span>График фаз 0–4</div>
  <div class="svg">
    <svg viewBox="0 0 720 330" aria-label="Потенциал действия желудочкового кардиомиоцита">
      <rect x="0" y="0" width="720" height="330" rx="12" fill="#fbfdff"/>
      <g stroke="#dbe5f0" stroke-width="1">
        <line x1="65" y1="40" x2="65" y2="285"/><line x1="65" y1="285" x2="690" y2="285"/>
        <line x1="65" y1="80" x2="690" y2="80"/><line x1="65" y1="150" x2="690" y2="150"/><line x1="65" y1="220" x2="690" y2="220"/>
      </g>
      <path d="M72 262 L120 262 L150 55 Q158 36 172 48 L205 88 Q300 72 398 83 Q470 92 520 150 Q560 205 602 260 L680 262"
            fill="none" stroke="#2563eb" stroke-width="6" stroke-linecap="round"/>
      <g fill="#18212f" font-size="15" font-family="system-ui,sans-serif">
        <text x="125" y="235">4</text><text x="148" y="42">0</text><text x="194" y="118">1</text>
        <text x="315" y="65">2 — плато Ca²⁺</text><text x="500" y="135">3 — K⁺</text>
        <text x="8" y="55">+20 mV</text><text x="8" y="268">−90 mV</text>
        <text x="335" y="315">время →</text>
      </g>
    </svg>
  </div>
  <div class="flow" style="margin-top:9px">
    <div class="node"><b>Фаза 0</b><br>Na⁺ внутрь через Nav1.5<br><span class="small">Propafenone, TCA, Phenytoin</span></div><div class="arr">→</div>
    <div class="node"><b>Фаза 1</b><br>Краткий K⁺ наружу</div><div class="arr">→</div>
    <div class="node"><b>Фаза 2</b><br>L-type Ca²⁺ внутрь ↔ K⁺ наружу<br><span class="small">Verapamil/Diltiazem; CICR</span></div><div class="arr">→</div>
    <div class="node"><b>Фаза 3</b><br>K⁺-реполяризация<br><span class="small">Amiodarone и препараты с QT-риском</span></div><div class="arr">→</div>
    <div class="node"><b>Фаза 4</b><br>IK1 + Na⁺/K⁺-градиенты</div>
  </div>
</div>

<div class="card">
  <h2>Пейсмекерный потенциал СА/АВ-узлов</h2>
  <div class="graph-title"><span class="navicon">〽️</span>Фазы 4 → 0 → 3</div>
  <div class="svg">
    <svg viewBox="0 0 720 320" aria-label="Пейсмекерный потенциал">
      <rect x="0" y="0" width="720" height="320" rx="12" fill="#fbfdff"/>
      <g stroke="#dbe5f0" stroke-width="1">
        <line x1="65" y1="35" x2="65" y2="275"/><line x1="65" y1="275" x2="690" y2="275"/>
        <line x1="65" y1="145" x2="690" y2="145" stroke="#d39b2c" stroke-dasharray="7 6"/>
      </g>
      <path d="M72 250 Q150 236 225 158 Q245 137 270 65 Q282 40 298 62 Q325 145 352 246 Q430 232 505 157 Q525 136 550 65"
            fill="none" stroke="#0f766e" stroke-width="6" stroke-linecap="round"/>
      <g fill="#18212f" font-size="15" font-family="system-ui,sans-serif">
        <text x="130" y="220">Фаза 4 — If/HCN</text><text x="270" y="105">0 — Ca²⁺</text><text x="320" y="185">3 — K⁺</text>
        <text x="545" y="137" fill="#9a6a13">порог</text><text x="300" y="305">время →</text>
      </g>
    </svg>
  </div>
  <p><b>β-блокаторы, clonidine, donepezil</b> уменьшают автоматизм/проведение. <b>Verapamil и diltiazem</b> уменьшают Ca²⁺-зависимую фазу 0 АВ-узла.</p>
</div>
</section>

<section class="panel" data-p="ecc">
<div class="card">
  <h2>Сопряжение возбуждения и сокращения</h2>
  <div class="flow">
    <div class="node"><b>L-type Ca²⁺</b><br>Триггерный Ca²⁺ входит</div><div class="arr">→</div>
    <div class="node"><b>RyR2</b><br>Ca²⁺ из СПР → CICR</div><div class="arr">→</div>
    <div class="node"><b>Troponin C</b><br>Tropomyosin смещается</div><div class="arr">→</div>
    <div class="node"><b>Actin–myosin</b><br>ATP → рабочий ход</div><div class="arr">→</div>
    <div class="node"><b>SERCA2a + NCX</b><br>Ca²⁺ из цитозоля → расслабление</div>
  </div>

  <div class="graph-title"><span class="navicon">🧪</span>Ca²⁺-транзиент и механическое напряжение</div>
  <div class="svg">
    <svg viewBox="0 0 720 330" aria-label="Кальциевый транзиент и сокращение">
      <rect x="0" y="0" width="720" height="330" rx="12" fill="#fbfdff"/>
      <g stroke="#dbe5f0" stroke-width="1">
        <line x1="55" y1="280" x2="690" y2="280"/>
        <line x1="55" y1="55" x2="55" y2="280"/>
      </g>
      <path d="M60 260 Q115 258 145 220 Q178 100 225 75 Q275 100 325 178 Q375 235 455 252 Q545 260 680 260"
            fill="none" stroke="#2563eb" stroke-width="6" stroke-linecap="round"/>
      <path d="M60 270 Q135 270 180 245 Q230 160 295 135 Q355 145 425 205 Q505 260 680 270"
            fill="none" stroke="#dc5a67" stroke-width="6" stroke-linecap="round"/>
      <g fill="#18212f" font-size="15" font-family="system-ui,sans-serif">
        <text x="230" y="68" fill="#2563eb">Ca²⁺ в цитозоле</text>
        <text x="332" y="128" fill="#b43e4d">механическое напряжение</text>
        <text x="315" y="312">время →</text>
      </g>
    </svg>
  </div>
  <div class="small" style="margin-top:7px">Синий Ca²⁺-транзиент начинается раньше; механическое сокращение следует за ним с задержкой.</div>
</div>

<div class="card">
  <h2>Digoxin как интеграционный пример</h2>
  <p>Na⁺/K⁺-АТФаза ↓ → Na⁺i ↑ → движущая сила NCX ↓ → выведение Ca²⁺ ↓ → Ca²⁺i/СПР ↑ → сократимость ↑. Параллельно вагус ↑ → АВ-проведение ↓ → PR ↑.</p>
</div>
</section>

<section class="panel" data-p="install">
<div class="card"><h2>Установка на iPhone</h2>
<p>1. Открой приложение в Safari по HTTPS-ссылке.</p>
<p>2. Нажми <b>Поделиться</b>.</p>
<p>3. Выбери <b>На экран «Домой»</b>.</p>
<p>4. Включи <b>Открыть как веб-приложение</b>, если iOS показывает этот переключатель.</p>
<p>5. После первого открытия приложение кэшируется и основные разделы работают офлайн.</p>
<div class="warn"><b>Важно:</b> для установки PWA файл должен быть размещён на бесплатном HTTPS-хостинге. Подойдёт GitHub Pages или Cloudflare Pages.</div>
</div>
<div class="card"><h2>О приложении</h2><p><b>CardioPharm Study</b> — учебный симулятор электрофизиологии сердца и фармакологии. Включает 49 препаратов, электролитные нарушения, динамическую ЭКГ и биохимические цепочки.</p><p class="small">Версия 2.0 · Светлая мобильная тема · Исправлены SVG-графики · Все учебные данные хранятся локально.</p></div>
</section>

<section class="panel" data-p="ref">
<div class="card"><h2>Справочник 49 препаратов</h2><input id="${uid}_q" placeholder="Поиск по препарату или группе…"><div class="table"><table id="${uid}_tbl"></table></div></div>
</section>
`);

root.querySelectorAll(".tab").forEach(b=>b.onclick=()=>{
root.querySelectorAll(".tab").forEach(x=>x.classList.toggle("active",x===b));
root.querySelectorAll(".panel").forEach(p=>p.classList.toggle("active",p.dataset.p===b.dataset.t));
});

let mode="group";
const sel=$(`#${uid}_sel`);
function groups(){return Object.keys(GROUPS)}
function fill(){
 if(mode==="group")sel.innerHTML=groups().map(x=>`<option>${esc(x)}</option>`).join("");
 if(mode==="drug")sel.innerHTML=DRUGS.map(d=>`<option value="${esc(d.name)}">#${d.n} ${esc(d.name)}</option>`).join("");
 if(mode==="electro")sel.innerHTML=Object.keys(ELECTRO).map(x=>`<option>${esc(x)}</option>`).join("");
 if(mode==="normal")sel.innerHTML="<option>Норма</option>";
 render();
}
root.querySelectorAll(".mode").forEach(b=>b.onclick=()=>{
 mode=b.dataset.m; root.querySelectorAll(".mode").forEach(x=>x.classList.toggle("active",x===b)); fill();
});
sel.onchange=render;

function profileDrug(d){return merge(GROUPS[d.g].ecg,OVERRIDE[d.name]||{})}
function bioDrug(d){return SPECIAL[d.name]||[d.note,...GROUPS[d.g].bio.slice(1)]}

function selected(){
 if(mode==="group"){let g=sel.value||groups()[0];return {title:g,desc:GROUPS[g].bio.join(" → "),ecg:merge(GROUPS[g].ecg),bio:GROUPS[g].bio,members:DRUGS.filter(d=>d.g===g)}}
 if(mode==="drug"){let d=DRUGS.find(x=>x.name===sel.value)||DRUGS[0];return {title:`#${d.n} ${d.name}`,desc:`<b>Группа:</b> ${esc(d.g)}<br>${esc(d.note)}`,ecg:profileDrug(d),bio:bioDrug(d),members:[]}}
 if(mode==="electro"){let k=sel.value||"Норма";let e=ELECTRO[k];return {title:k,desc:"Электролитное состояние",ecg:merge(e.ecg),bio:e.bio,members:[]}}
 let e=ELECTRO["Норма"];return {title:"Норма",desc:"Исходная учебная ЭКГ",ecg:merge(e.ecg),bio:e.bio,members:[]};
}

function wave(p){
 const y=165, p0=40, pAmp=30*(p.p??1), pr=(p.pr??160)*.72, qs=p0+pr, qw=(p.qrs??90)*.72, qe=qs+qw, qt=(p.qt??410)*.72, te=qs+qt, ts=Math.max(qe+20,te-120), tp=(ts+te)/2;
 const ta=52*(p.t??1), st=y-(p.st??0)*35, u=p.u??0, up=(te+38), ue=te+76;
 const path=`M15 ${y} L${p0} ${y} Q${p0+18} ${y-pAmp} ${p0+36} ${y} L${qs-7} ${y} L${qs} ${y+16} L${qs+qw*.28} ${y-78} L${qs+qw*.55} ${y+38} L${qe} ${st} L${ts} ${st} Q${tp} ${st-ta} ${te} ${y} ${u?`L${up} ${y} Q${(up+ue)/2} ${y-25*u} ${ue} ${y}`:""} L735 ${y}`;
 return `<svg viewBox="0 0 760 290" aria-label="Динамическая ЭКГ">
 <defs><pattern id="ecgGrid" width="20" height="20" patternUnits="userSpaceOnUse"><path d="M20 0H0V20" fill="none" stroke="#e3ebf4" stroke-width="1"/></pattern></defs>
 <rect x="0" y="0" width="760" height="290" rx="12" fill="#ffffff"/>
 <rect x="0" y="0" width="760" height="290" rx="12" fill="url(#ecgGrid)"/>
 <line x1="10" y1="${y}" x2="745" y2="${y}" stroke="#aebdce" stroke-dasharray="4 4"/>
 <path d="${path}" fill="none" stroke="#0f766e" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/>
 <g fill="#18212f" font-family="system-ui,sans-serif">
   <text x="15" y="25" font-size="15" font-weight="700">ЧСС ≈ ${p.hr}/мин</text>
   <text x="620" y="25" fill="#667085" font-size="12">учебная модель</text>
   <text x="${p0+13}" y="${Math.max(38,y-pAmp-8)}" font-size="14">P</text>
   <text x="${qs+qw*.28-4}" y="${Math.max(30,y-90)}" font-size="14">R</text>
   <text x="${tp-3}" y="${Math.max(32,st-ta-8)}" font-size="14">T</text>
   ${u?`<text x="${up+12}" y="${Math.max(34,y-25*u-8)}" font-size="13">U</text>`:""}
 </g>
 </svg>`;
}
function render(){
 let s=selected();
 $(`#${uid}_title`).textContent=s.title;
 $(`#${uid}_desc`).innerHTML=s.desc;
 $(`#${uid}_ecg`).innerHTML=wave(s.ecg);
 $(`#${uid}_params`).innerHTML=[["ЧСС",s.ecg.hr,"/мин"],["PR",s.ecg.pr,"мс"],["QRS",s.ecg.qrs,"мс"],["QT",s.ecg.qt,"мс"],["T",Math.round((s.ecg.t??1)*100),"%"],["U",Math.round((s.ecg.u??0)*100),"%"]].map(x=>`<span class="p"><b>${x[0]}</b> ${x[1]} ${x[2]}</span>`).join("");
 $(`#${uid}_bio`).innerHTML=s.bio.map((x,i)=>`${i?'<div class="arr">→</div>':''}<div class="node"><b>${i+1}</b><br>${esc(x)}</div>`).join("");
 $(`#${uid}_members`).innerHTML=s.members.length?`<span class="small">Нажми препарат для индивидуального профиля:</span>`+s.members.map(d=>`<button class="chip" data-n="${d.name}">#${d.n} ${d.name}</button>`).join(""):"";
 root.querySelectorAll(".chip").forEach(b=>b.onclick=()=>{mode="drug";root.querySelectorAll(".mode").forEach(x=>x.classList.toggle("active",x.dataset.m==="drug"));fill();sel.value=b.dataset.n;render();});
 $(`#${uid}_hint`).innerHTML=mode==="group"?"Групповой профиль показывает типичное направление. Для точности выбери один препарат.":mode==="drug"?"Показан индивидуальный учебный профиль выбранного препарата.":mode==="electro"?"Показано влияние изменения ионной среды.":"Исходная учебная модель.";
}

const q=$(`#${uid}_q`);
function table(){
 const s=(q.value||"").toLowerCase();
 const rows=DRUGS.filter(d=>(d.name+" "+d.g+" "+d.note).toLowerCase().includes(s));
 $(`#${uid}_tbl`).innerHTML="<thead><tr><th>№</th><th>Препарат</th><th>Группа</th><th>Механизм / ЭКГ</th></tr></thead><tbody>"+rows.map(d=>`<tr><td>${d.n}</td><td><b>${esc(d.name)}</b></td><td>${esc(d.g)}</td><td>${esc(d.note)}</td></tr>`).join("")+"</tbody>";
}
q.oninput=table; table(); fill();