const CACHE="propharm-v0.13.0";
const CORE=["./","./index.html","./styles.css","./app.js","./manifest.webmanifest","./config/supabase-config.js","./services/authService.js","./services/localDb.js","./services/userData.js","./data/topics.js","./data/drugs.js","./data/abbreviations.js","./data/theory.js","./data/mechanisms.js","./data/highYield.js","./data/tests.js","./data/testAnalyses.js","./data/cardio49.js","./data/sourceSections.js","./data/interactions.js","./data/drugKnowledge.js","./data/drugProfiles.js","./data/sectionVisuals.js","./data/studyTables.js","./data/systems.js","./data/diseases.js","./data/glossaryExtras.js","./data/cardioIntegrated.js","./data/visualSources.js","./modules/cardio/index.html","./modules/cardio/app.js","./icons/icon-180.png","./icons/icon-192.png","./icons/icon-512.png"];
self.addEventListener("install",e=>{self.skipWaiting();e.waitUntil(caches.open(CACHE).then(c=>c.addAll(CORE)))});
self.addEventListener("activate",e=>{e.waitUntil((async()=>{const keys=await caches.keys();await Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)));await self.clients.claim()})())});
async function cached(req){return (await caches.match(req))||(await caches.match(req,{ignoreSearch:true}))}
async function remember(req,response){if(response&&response.ok){const copy=response.clone();caches.open(CACHE).then(c=>c.put(req,copy)).catch(()=>{})}return response}
self.addEventListener("fetch",e=>{
  if(e.request.method!=="GET")return;
  const u=new URL(e.request.url);
  const isSdk=u.hostname==="cdn.jsdelivr.net"&&u.pathname.includes("@supabase/supabase-js");
  if(isSdk){e.respondWith((async()=>{const hit=await cached(e.request);if(hit)return hit;return remember(e.request,await fetch(e.request))})());return}
  const code=/\.(?:js|json)$/.test(u.pathname)||u.pathname.endsWith("/index.html")||u.pathname.endsWith("/");
  if(code){e.respondWith((async()=>{try{return remember(e.request,await fetch(e.request))}catch{const hit=await cached(e.request);return hit||(await caches.match("./index.html"))}})());return}
  e.respondWith((async()=>{const hit=await cached(e.request);if(hit)return hit;try{return remember(e.request,await fetch(e.request))}catch{return Response.error()}})());
});
