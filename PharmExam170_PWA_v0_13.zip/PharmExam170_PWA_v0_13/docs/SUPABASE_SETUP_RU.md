# ProPharm v0.13 — настройка Supabase

## 1. Создать проект Supabase
Создай новый проект и открой SQL Editor.

## 2. Выполнить миграцию
Запусти файл `supabase/migrations/001_propharm_accounts.sql`.

## 3. Настроить публичный frontend
Открой `config/supabase-config.js` и укажи:
- `enabled: true`
- `url`: Project URL
- `publishableKey`: public/publishable (anon) key
- `siteUrl`: `https://dnchkvi.github.io/ProPharm/`

Никогда не вставляй сюда `service_role`.

## 4. Первый администратор
1. Зарегистрируй собственный аккаунт любым способом: email, Google или Apple.
2. Найди UUID в Authentication → Users.
3. В SQL Editor выполни:

```sql
update public.profiles
set role='admin', status='approved'
where user_id='ТВОЙ-UUID';
```

В интерфейсе нет функции «Сделать администратором». Это намеренно.

## 5. Google OAuth
В Supabase Authentication → Providers включи Google и настрой Google OAuth credentials. В Allowed Redirect URLs добавь URL callback, который показывает Supabase Dashboard для проекта, а Site URL/Additional Redirect URLs должны разрешать `https://dnchkvi.github.io/ProPharm/`.

## 6. Apple OAuth
Включи Apple provider. Потребуются Apple Developer настройки (Services ID / secret). Секреты Apple хранятся только в Supabase provider configuration, не в GitHub Pages.

Apple может использовать Hide My Email, поэтому ProPharm связывает данные по `auth.users.id`, а не по email.

## 7. Approval gate
Любой новый пользователь получает `role=user`, `status=pending`. Только bootstrap-admin может перевести его в `approved`, `blocked`, `rejected` через панель ProPharm.

## 8. Офлайн
IndexedDB хранит локальную историю, избранное, очередь повторения и операции синхронизации. При восстановлении сети данные отправляются в Supabase. Локальные записи разделены по `user_id`.

## 9. Секреты, которые нельзя коммитить
- service_role key
- Google client secret
- Apple private key
- Apple client secret
- любые административные токены

## 10. Важное ограничение GitHub Pages
GitHub Pages — публичный статический хостинг. Auth-gate ProPharm защищает интерфейс аккаунта и персональные данные Supabase, но не превращает статические JS/JSON-файлы учебной базы в приватные серверные ресурсы: человек, знающий точный URL asset-файла, технически может запросить его напрямую.

Если позднее потребуется скрыть сам учебный контент от неавторизованных пользователей, перенеси чувствительные учебные данные за аутентифицированный backend/API или в приватное хранилище с проверкой сессии. Для текущей архитектуры GitHub Pages + Supabase авторизация предназначена прежде всего для управления доступом в UI, профилей, прогресса, истории, избранного и синхронизации.

## 11. Что происходит без Supabase credentials
В репозитории `enabled` оставлен `false`, а `url` и `publishableKey` пустые. Это намеренно: ZIP можно безопасно публиковать без секретов. В таком режиме ProPharm работает как локальный preview, а персональная история сохраняется только в IndexedDB текущего устройства.
