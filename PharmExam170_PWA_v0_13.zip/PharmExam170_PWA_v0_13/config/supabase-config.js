// ProPharm v0.13 — public Supabase configuration.
// This file is safe to commit ONLY with a public/publishable key.
// NEVER put service_role, Apple private keys, Google client secrets or other secrets here.
export const SUPABASE_CONFIG = Object.freeze({
  enabled: false,
  url: "",
  publishableKey: "",
  siteUrl: "https://dnchkvi.github.io/ProPharm/",
  auth: {
    requireApproval: true,
    allowLocalPreviewWhenDisabled: true,
    google: true,
    apple: true,
    manualIdentityLinking: true
  }
});
