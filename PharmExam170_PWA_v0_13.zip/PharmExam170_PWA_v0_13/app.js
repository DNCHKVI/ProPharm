import { TOPICS } from "./data/topics.js?v=0.13.0";
import { DRUGS } from "./data/drugs.js?v=0.13.0";
import { ABBREVIATIONS } from "./data/abbreviations.js?v=0.13.0";
import { THEORY } from "./data/theory.js?v=0.13.0";
import { MECHANISMS } from "./data/mechanisms.js?v=0.13.0";
import { HIGH_YIELD } from "./data/highYield.js?v=0.13.0";
import { TESTS as BASE_TESTS } from "./data/tests.js?v=0.13.0";
import { TEST_ANALYSES as BASE_TEST_ANALYSES } from "./data/testAnalyses.js?v=0.13.0";
import { SOURCE_SECTIONS } from "./data/sourceSections.js?v=0.13.0";
import { INTERACTIONS } from "./data/interactions.js?v=0.13.0";
import { DRUG_KNOWLEDGE } from "./data/drugKnowledge.js?v=0.13.0";
import { DRUG_PROFILES } from "./data/drugProfiles.js?v=0.13.0";
import { SECTION_VISUALS } from "./data/sectionVisuals.js?v=0.13.0";
import { CARDIO49 } from "./data/cardio49.js?v=0.13.0";
import { STUDY_TABLES } from "./data/studyTables.js?v=0.13.0";
import { SYSTEMS, SYSTEM_SECTION_ORDER } from "./data/systems.js?v=0.13.0";
import { DISEASES } from "./data/diseases.js?v=0.13.0";
import { GLOSSARY_EXTRAS } from "./data/glossaryExtras.js?v=0.13.0";
import { CARDIO_GLOSSARY, CARDIO_PHYSIOLOGY, CARDIO_BIOCHEMISTRY, CARDIO_PATHOLOGIES, CARDIO_TARGETS, CARDIO_DIAGNOSTICS, CARDIO_FLASHCARDS, CARDIO_EXTRA_TESTS, CARDIO_EXTRA_ANALYSES } from "./data/cardioIntegrated.js?v=0.13.0";
import { VISUAL_SOURCES, VISUAL_SOURCE_GROUPS } from "./data/visualSources.js?v=0.13.0";
import { authState, initAuth, onAuthState, isAuthConfigured, isAdmin, signInWithPassword, signUpWithPassword, signInWithOAuth, signOut, resetPassword, updatePassword, updateOwnProfile, listUsersForAdmin, adminSetStatus, refreshProfile, linkIdentity } from "./services/authService.js?v=0.13.0";
import { saveTestSession, recordQuestionResult, toggleFavorite, isFavorite, listFavorites, setReview, removeReview, listReview, getLearningStats, lastStudyRoute, recordStudyPosition, saveUserSettings, loadUserSettings, hydrateFromCloud, syncPending } from "./services/userData.js?v=0.13.0";

const TESTS=[...BASE_TESTS,...CARDIO_EXTRA_TESTS];
const TEST_ANALYSES=[...BASE_TEST_ANALYSES,...CARDIO_EXTRA_ANALYSES];

const app = document.getElementById("app");
const topicMap = Object.fromEntries(TOPICS.map(t => [t.id,t]));
const drugMap = Object.fromEntries(DRUGS.map(d => [String(d.n),d]));
const systemMap = Object.fromEntries(SYSTEMS.map(s=>[s.id,s]));
const diseaseMap = Object.fromEntries(DISEASES.map(d=>[d.id,d]));
const esc = s => String(s ?? "").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));
const UI_SETTINGS_KEY="propharm_ui_settings_v1";
let uiSettings=Object.assign({largeText:false,reducedMotion:false},JSON.parse(localStorage.getItem(UI_SETTINGS_KEY)||"{}"));
function applyUiSettings(){document.documentElement.classList.toggle("largeText",!!uiSettings.largeText);document.documentElement.classList.toggle("reducedMotion",!!uiSettings.reducedMotion);}
applyUiSettings();



function authBadge(){
  if(!isAuthConfigured())return `<span class="modeBadge local">Локальный режим</span>`;
  const p=authState.profile;if(!p)return "";
  return `<span class="modeBadge ${p.role==='admin'?'admin':'user'}">${p.role==='admin'?'Администратор':'Профиль'}</span>`;
}
function toast(message,type="ok"){
  const old=document.querySelector('.toastMessage');if(old)old.remove();
  const el=document.createElement('div');el.className=`toastMessage ${type}`;el.textContent=message;document.body.appendChild(el);setTimeout(()=>el.classList.add('show'),20);setTimeout(()=>{el.classList.remove('show');setTimeout(()=>el.remove(),250)},2200);
}
function favoriteButton(type,id,label="Избранное"){
  return `<button class="miniAction favoriteAction" data-favorite-type="${esc(type)}" data-favorite-id="${esc(id)}" aria-label="${esc(label)}"><span>♡</span><small>${esc(label)}</small></button>`;
}
function reviewButton(type,id,label="Повторить"){
  return `<button class="miniAction reviewAction" data-review-type="${esc(type)}" data-review-id="${esc(id)}" aria-label="${esc(label)}"><span>↻</span><small>${esc(label)}</small></button>`;
}
async function bindPersonalActions(){
  document.querySelectorAll('[data-favorite-type]').forEach(async b=>{
    const type=b.dataset.favoriteType,id=b.dataset.favoriteId;
    try{if(await isFavorite(type,id)){b.classList.add('active');const s=b.querySelector('span');if(s)s.textContent='♥'}}catch{}
    b.onclick=async e=>{e.preventDefault();e.stopPropagation();try{const on=await toggleFavorite(type,id);b.classList.toggle('active',on);const sp=b.querySelector('span');if(sp)sp.textContent=on?'♥':'♡';toast(on?'Добавлено в избранное':'Удалено из избранного')}catch(err){toast(err.message||String(err),'bad')}};
  });
  document.querySelectorAll('[data-review-type]').forEach(b=>{
    b.onclick=async e=>{e.preventDefault();e.stopPropagation();try{await setReview(b.dataset.reviewType,b.dataset.reviewId,{reason:'manual',priority:2});b.classList.add('active');toast('Добавлено в «Повторить»')}catch(err){toast(err.message||String(err),'bad')}};
  });
}
function inferProgressFromRoute(parts){
  if(parts[0]==='system')return {system_id:parts[1]||null,section_id:parts[2]||'overview',entity_id:null,route:location.hash};
  if(parts[0]==='drug')return {system_id:null,section_id:'drug',entity_id:parts[1],route:location.hash};
  if(parts[0]==='disease'||parts[0]==='cardio-pathology')return {system_id:parts[0]==='cardio-pathology'?'cardiovascular':null,section_id:'disease',entity_id:parts[1],route:location.hash};
  if(parts[0]==='mechanism')return {system_id:null,section_id:'mechanism',entity_id:parts[1],route:location.hash};
  return {system_id:null,section_id:parts[0]||'home',entity_id:null,route:location.hash};
}
function resolvePersonalEntity(type,id){
  if(type==='drug'){const d=drugMap[String(id)];return d?{title:d.name,subtitle:d.group,route:`#drug/${d.n}`}:null}
  if(type==='disease'){const d=diseaseMap[id];return d?{title:d.title,subtitle:systemMap[d.systemId]?.title||'Заболевание',route:`#disease/${id}`}:null}
  if(type==='cardio-pathology'){const d=CARDIO_PATHOLOGIES.find(x=>x.id===id);return d?{title:d.title,subtitle:'Сердечно-сосудистая система',route:`#cardio-pathology/${id}`}:null}
  if(type==='mechanism'){const m=allCanonicalMechanisms().find(x=>x.id===id);return m?{title:m.title,subtitle:systemMap[m.systemId]?.title||'Механизм',route:`#mechanism/${id}`}:null}
  if(type==='question'){const q=TESTS.find(x=>x.id===id);return q?{title:q.question,subtitle:q.sectionTitle||'Тестовый вопрос',route:'#tests'}:null}
  if(type==='system'){const x=systemMap[id];return x?{title:x.title,subtitle:'Система',route:`#system/${id}`}:null}
  if(type==='card'){const c=buildFlashCards().find(x=>x.id===id);return c?{title:c.title,subtitle:c.front,route:'#cards'}:null}
  return {title:`${type}: ${id}`,subtitle:'Сохранённый материал',route:'#study'};
}

function doodleIcon(type){
 const common=`viewBox="0 0 64 64" aria-hidden="true" focusable="false"`;
 const svg=(body)=>`<svg ${common} class="chalkSvg"><g fill="none" stroke="currentColor" stroke-width="3.4" stroke-linecap="round" stroke-linejoin="round">${body}</g></svg>`;
 const map={
  tests:svg(`<path d="M19 12h28a5 5 0 0 1 5 5v36H14V17a5 5 0 0 1 5-5Z"/><path d="M24 9h18v9H24z"/><path d="m21 28 3 3 6-7M21 40l3 3 6-7M35 28h10M35 40h10"/>`),
  theory:svg(`<path d="M8 17c9-5 18-4 25 1v35c-7-5-16-6-25-1V17Z"/><path d="M56 17c-9-5-18-4-23 1v35c7-5 14-6 23-1V17Z"/><path d="M15 27h11M15 35h11M40 27h10M40 35h10"/>`),
  tables:svg(`<rect x="9" y="11" width="46" height="42" rx="6"/><path d="M9 25h46M9 39h46M24 11v42M40 11v42"/>`),
  schemes:svg(`<rect x="25" y="8" width="14" height="12" rx="3"/><rect x="8" y="43" width="18" height="13" rx="4"/><rect x="38" y="43" width="18" height="13" rx="4"/><path d="M32 20v11M17 43v-8h30v8"/>`),
  cards:svg(`<path d="m16 17 31-5 5 30-31 5-5-30Z"/><rect x="11" y="24" width="38" height="28" rx="5"/><circle cx="28" cy="37" r="4"/><path d="M36 34h8M36 41h7"/>`),
  drugs:svg(`<path d="M15 41 39 17a10 10 0 0 1 14 14L29 55a10 10 0 0 1-14-14Z"/><path d="m27 29 15 15"/><path d="M18 45h8M38 19h8"/>`),
  abbr:svg(`<rect x="9" y="10" width="46" height="44" rx="8"/><path d="M17 44 25 21l8 23M20 36h10M40 23h8M40 33h8M40 43h6"/>`),
  settings:svg(`<circle cx="32" cy="32" r="9"/><path d="M32 8v7M32 49v7M8 32h7M49 32h7M15 15l5 5M44 44l5 5M49 15l-5 5M20 44l-5 5"/>`),
  search:svg(`<circle cx="27" cy="27" r="15"/><path d="m38 38 14 14"/>`),
  home:svg(`<path d="m10 30 22-18 22 18v24H39V40H25v14H10V30Z"/>`),
  study:svg(`<path d="M8 17c9-5 18-4 25 1v35c-7-5-16-6-25-1V17ZM56 17c-9-5-18-4-23 1v35c7-5 14-6 23-1V17Z"/>`),
  profile:svg(`<circle cx="32" cy="22" r="9"/><path d="M15 54c2-13 10-19 17-19s15 6 17 19"/>`)
 };
 return map[type]||map.study;
}
function topicIcon(type){
 const common=`viewBox="0 0 64 64" aria-hidden="true" focusable="false"`;
 const wrap=(body)=>`<svg ${common} class="chalkSvg"><g fill="none" stroke="currentColor" stroke-width="3.2" stroke-linecap="round" stroke-linejoin="round">${body}</g></svg>`;
 const m={
  cardio:`<path d="M32 53S11 41 11 25c0-10 13-14 21-4 8-10 21-6 21 4 0 16-21 28-21 28Z"/>`,
  hemostasis:`<path d="M32 8s15 18 15 31a15 15 0 1 1-30 0C17 26 32 8 32 8Z"/>`,
  endocrine:`<circle cx="32" cy="32" r="6"/><path d="M32 9v12M32 43v12M9 32h12M43 32h12M16 16l8 8M40 40l8 8M48 16l-8 8M24 40l-8 8"/>`,
  psych:`<path d="M24 16c-8 2-11 12-6 18-5 5-2 14 6 15 3 6 13 5 15-1 8 1 13-8 8-14 5-7 0-17-8-17-3-6-12-6-15-1Z"/><path d="M32 17v31M24 27h8M32 37h8"/>`,
  neuro:`<path d="m35 7-17 29h13l-2 21 17-31H33l2-19Z"/>`,
  pain:`<path d="M32 8v16M32 40v16M8 32h16M40 32h16M15 15l11 11M38 38l11 11M49 15 38 26M26 38 15 49"/>`,
  infectious:`<circle cx="32" cy="32" r="12"/><path d="M32 8v12M32 44v12M8 32h12M44 32h12M15 15l9 9M40 40l9 9M49 15l-9 9M24 40l-9 9"/>`,
  resp:`<path d="M30 14v19c-8-14-17-10-18 5-1 13 8 17 18 11V33M34 14v19c8-14 17-10 18 5 1 13-8 17-18 11V33"/>`,
  gi:`<path d="M29 10c0 11 8 10 8 18 0 4-4 6-7 4-9-5-17 1-16 11 1 10 9 14 19 11 11-3 17-14 14-24-3-11-13-10-18-20Z"/>`,
  uro:`<path d="M25 13c-9 0-14 9-12 18 2 9 9 13 16 8V18c-1-3-2-5-4-5ZM39 13c9 0 14 9 12 18-2 9-9 13-16 8V18c1-3 2-5 4-5Z"/><path d="M29 39v14M35 39v14"/>`,
  repro:`<circle cx="32" cy="24" r="12"/><path d="M32 36v20M24 48h16"/>`,
  immune:`<path d="M32 8 50 15v14c0 13-8 21-18 27-10-6-18-14-18-27V15L32 8Z"/>`,
  oncology:`<path d="M22 11c17 6 23 18 20 42M42 11C25 17 19 29 22 53"/><path d="M22 26h20M23 40h18"/>`,
  bone:`<path d="M17 22c-7-7-13 2-7 7l20 20c7 7 16-2 9-9L20 21c-1-1-2-1-3 1ZM47 42c7 7 13-2 7-7L34 15c-7-7-16 2-9 9l19 19c1 1 2 1 3-1Z"/>`,
  ophth:`<path d="M7 32s10-15 25-15 25 15 25 15-10 15-25 15S7 32 7 32Z"/><circle cx="32" cy="32" r="7"/>`,
  local:`<path d="M16 46 42 20l8 8-26 26H16v-8Z"/><path d="m37 25 8 8"/>`,
  toxicology:`<path d="M32 8 56 52H8L32 8Z"/><path d="M32 23v14M32 45v1"/>`
 };
 return wrap(m[type]||m.study||`<circle cx="32" cy="32" r="20"/>`);
}

function capsuleLogo(cls="brandCapsuleLogo"){
 return `<svg class="${cls}" viewBox="0 0 120 82" aria-hidden="true" focusable="false">
   <g fill="none" stroke="currentColor" stroke-width="6.2" stroke-linecap="round" stroke-linejoin="round">
     <path d="M13 29c8-13 21-17 32-8l18 15-25 27-18-15c-9-7-10-13-7-19Z"/>
     <path d="M107 29c-8-13-21-17-32-8L57 36l25 27 18-15c9-7 10-13 7-19Z"/>
     <path d="M38 23c4 0 8 2 11 5M82 23c-4 0-8 2-11 5" stroke-width="4.4"/>
   </g>
   <g fill="currentColor">
     <circle cx="56" cy="48" r="3.8"/><circle cx="65" cy="53" r="4.7"/><circle cx="52" cy="58" r="3.3"/>
     <circle cx="62" cy="64" r="3.8"/><circle cx="54" cy="69" r="2.4"/><circle cx="67" cy="73" r="2.4"/>
   </g>
 </svg>`;
}
function header(){return `<div class="topbar innerTopbar chalkTop"><button class="backMini" onclick="history.length>1?history.back():location.hash='#home'">‹</button><div class="brandCompact brandWithLogo">${capsuleLogo("miniCapsuleLogo")}<span><b>ProPharm</b><small>экзаменационная база</small></span></div><div class="topDoodle">•••</div></div>`;}
function bottomNav(active){
 const items=[["home","#home","home","Главная"],["search","#search","search","Поиск"],["study","#study","study","Учёба"],["settings","#settings","settings","Настройки"]];
 return `<nav class="bottomNav">${items.map(([id,route,ic,t])=>`<button class="navBtn ${active===id?"active":""}" data-route="${route}"><span class="navSketch">${doodleIcon(ic)}</span><span>${t}</span></button>`).join("")}</nav>`;
}
function bindNav(){
 document.querySelectorAll("[data-nav]").forEach(b=>b.addEventListener("click",()=>location.hash=b.dataset.nav==="home"?"#home":`#${b.dataset.nav}`));
 document.querySelectorAll("[data-route]").forEach(el=>el.addEventListener("click",()=>location.hash=el.dataset.route));
 bindPersonalActions();
}
function countsForTopic(id){return {drugs:DRUGS.filter(d=>d.topics.includes(id)).length,abbr:(ABBREVIATIONS[id]||[]).length,theory:(THEORY[id]||[]).length,mechanisms:(MECHANISMS[id]||[]).length,tests:TESTS.filter(q=>q.topic===id).length,analyses:TEST_ANALYSES.filter(q=>q.topic===id).length,interactions:(INTERACTIONS[id]||[]).length};}



const ALL_ABBREVIATIONS=(()=>{
 const seen=new Set(),out=[];
 const push=(x)=>{
   if(!x?.abbr)return;
   const key=(x.abbr+"|"+(x.full||"")).toLowerCase();
   if(seen.has(key))return;seen.add(key);out.push(x);
 };
 Object.values(ABBREVIATIONS).flat().forEach(push);
 GLOSSARY_EXTRAS.forEach(push);
 CARDIO_GLOSSARY.forEach(push);
 return out;
})();
function abbreviationAliases(abbr){
 return String(abbr||"").split(/\s*\/\s*/).map(x=>x.trim()).filter(Boolean);
}
function textHasAbbreviation(text,abbr){
 const hay=String(text||"");
 return abbreviationAliases(abbr).some(alias=>{
   const escaped=alias.replace(/[.*+?^${}()|[\]\\]/g,"\\$&");
   return new RegExp(`(^|[^A-Za-zА-Яа-я0-9])${escaped}([^A-Za-zА-Яа-я0-9]|$)`,"i").test(hay);
 });
}
function abbreviationsInText(text){
 if(!text)return [];
 return ALL_ABBREVIATIONS.filter(a=>textHasAbbreviation(text,a.abbr));
}
function renderAbbreviationLead(text){
 const found=abbreviationsInText(text);
 if(!found.length)return "";
 return `<div class="abbrLead"><div class="abbrLeadTitle">Используемые термины и сокращения</div>${found.map(a=>`<div class="abbrLeadRow"><b>${esc(a.abbr)}</b><span>${esc(a.full||"")}${a.ru?` — ${esc(a.ru)}`:""}</span></div>`).join("")}</div>`;
}
function renderTextWithAbbreviations(text){
 if(!text)return "";
 return `${renderAbbreviationLead(text)}${String(text).split("\\n").filter(Boolean).map(x=>`<p>${esc(x)}</p>`).join("")}`;
}

// Helpers for the full 170-drug profile database.
// These are deliberately kept close to the router/UI helpers because the
// drug page, schemes hub, flashcards and full-text search all depend on them.
function profileFor(drugOrNumber){
  const n=typeof drugOrNumber==="object" ? drugOrNumber?.n : drugOrNumber;
  return n==null ? null : (DRUG_PROFILES[String(n)] || null);
}
function profileSection(title,text,icon="•"){
  if(!text)return "";
  return `<details class="drugProfileSection"><summary><span><span class="profileSectionIcon">${esc(icon)}</span>${esc(title)}</span><span class="schemePlus">＋</span></summary><div class="drugProfileBody">${renderAbbreviationLead(text)}${String(text).split("\\n").filter(Boolean).map(x=>`<p>${esc(x)}</p>`).join("")}</div></details>`;
}
function interactionRiskClass(level=""){
  const l=String(level).toUpperCase();
  if(l.includes("КРАСН"))return "riskRed";
  if(l.includes("ОРАНЖ"))return "riskOrange";
  if(l.includes("ЖЁЛТ")||l.includes("ЖЕЛТ"))return "riskYellow";
  if(l.includes("ЗЕЛЁН")||l.includes("ЗЕЛЕН"))return "riskGreen";
  return "riskGray";
}
function renderProfileInteractions(profile){
  if(!profile)return "";
  const arr=Array.isArray(profile.interactions)?profile.interactions:[];
  if(arr.length){
    return `<details class="drugProfileSection"><summary><span><span class="profileSectionIcon">↔</span>Лекарственные взаимодействия</span><span class="schemePlus">＋</span></summary><div class="drugProfileBody"><div class="interactionProfileList">${arr.map(x=>`<div class="profileInteraction">${renderAbbreviationLead(x.text||"")}<span class="riskBadge ${interactionRiskClass(x.level)}">${esc(x.level||"СЕРЫЙ")}</span><p>${esc(x.text||"")}</p></div>`).join("")}</div></div></details>`;
  }
  return profileSection("Лекарственные взаимодействия",profile.interactionsText,"↔");
}
function drugSearchText(d){
  const p=profileFor(d);
  return [
    d?.name,d?.group,
    ...(d?.topics||[]).map(x=>topicMap[x]?.title||x),
    p?.sourceTitle,p?.mnn,p?.groupSource,p?.basic,p?.indications,p?.contraindications,
    p?.mechanismText,p?.scheme,p?.routes,p?.pharmacodynamics,p?.pharmacokinetics,
    p?.adverseEffects,p?.interactionsText,p?.specialSituations,
    ...(p?.interactions||[]).flatMap(x=>[x.level,x.text])
  ].filter(Boolean).join(" ").toLowerCase();
}

function renderHome(){
 const tiles=[
  ["study","Системы","Главный путь: норма → механизм → патология → лечение","#systems","lavender"],
  ["drugs","170 препаратов","Полная экзаменационная база","#drugs","blue"],
  ["tests","Тесты","Интерактивные вопросы и повторные попытки","#tests","lavender"],
  ["cards","Карточки","Повторение по препаратам и тестам","#cards","blue"],
  ["schemes","Схемы","Механизмы и процессы","#schemes","paper"],
  ["tables","Таблицы","Сравнения и диагностические ориентиры","#tables","blue"],
  ["abbr","Аббревиатуры","Расшифровки по системам","#abbr-hub","lavender"],
  ["schemes","Взаимодействия","Механизм → риск → клиническое следствие","#interactions-hub","paper"]
 ];
 app.innerHTML=`<div class="homePage page chalkHome">
   <section class="chalkMasthead"><div class="chalkBrand">${capsuleLogo("homeBrandLogo")}<div><div class="chalkBrandName">ProPharm</div><div class="chalkBrandTag">знания лечат ♡</div></div></div><button class="chalkMenu" aria-label="Настройки" data-route="#settings">•••</button></section>
   <section class="chalkIntro"><h1>Главная</h1><p>Начни с системного изучения</p><span class="handNote">норма → механизм → патология → препарат ♡</span></section>
   <section class="dashboardGrid chalkGrid">${tiles.map(([ic,title,desc,route,tone])=>`<button class="dashTile chalkTile tone-${tone}" data-route="${route}"><span class="dashIcon">${doodleIcon(ic)}</span><span class="dashText"><b>${title}</b><small>${desc}</small></span></button>`).join("")}</section>
   <div class="chalkFooterNote">понимай связи · не учи изолированные факты</div>
 </div>`+bottomNav("home");bindNav();
}
function renderTopics(){
 app.innerHTML=header()+`<div class="page"><div class="sectionTitle"><h2>Темы</h2><span class="muted">${TOPICS.length} разделов</span></div><div class="topicGrid">${TOPICS.map(t=>{const c=countsForTopic(t.id);return `<div class="card clickCard" data-route="#topic/${t.id}"><div class="cardHead"><div class="iconFrame topicLineIcon">${topicIcon(t.id)}</div><div><h3>${esc(t.title)}</h3><p>${esc(t.description)}</p><span class="badge">${c.drugs} препаратов</span>${c.abbr?`<span class="badge">${c.abbr} аббр.</span>`:""}${c.theory?`<span class="badge blue">${c.theory} теория</span>`:""}</div></div></div>`;}).join("")}</div></div>`+bottomNav("study");bindNav();
}
function topicSections(t){const c=countsForTopic(t.id);const defs=[["theory","📘","Теория",c.theory,"Конспекты и интерактивные учебные модули."],["mechanisms","🧬","Механизмы",c.mechanisms,"Сигнальные пути и причинно-следственные цепочки."],["drugs","💊","Препараты",c.drugs,"Препараты, связанные с этой темой."],["abbr","🔤","Аббревиатуры",c.abbr,"Только словарь этой темы — без смешивания."],["interactions","🔗","Взаимодействия",c.interactions,"Лекарственные взаимодействия с механизмом и клиническим следствием."],["tests","📝","Тесты",c.tests,"Вопросы только по выбранной теме."],["analysis","✅","Разбор тестов",c.analyses,"Почему правильный ответ верен и почему остальные неверны."],["high","⚡","High-yield",(HIGH_YIELD[t.id]||[]).length,"Короткий экзаменационный повтор."]];return defs.map(([id,ic,title,count,desc])=>`<div class="card clickCard" data-route="#topic/${t.id}/${id}"><div class="cardHead"><div class="iconFrame">${ic}</div><div><h3>${title}</h3><p>${desc}</p><span class="badge">${count}</span></div></div></div>`).join("");}
function renderTopic(id){const t=topicMap[id];if(!t){location.hash="#topics";return;}app.innerHTML=header()+`<div class="page"><div class="breadcrumb"><button data-route="#topics">Темы</button><span>›</span><span>${esc(t.short)}</span></div><div class="topicHeader"><div class="iconFrame topicLineIcon">${topicIcon(t.id)}</div><div><h2>${esc(t.title)}</h2><p>${esc(t.description)}</p></div></div><div class="sectionGrid">${topicSections(t)}</div></div>`+bottomNav("study");bindNav();}
function sectionShell(t,title,content){return header()+`<div class="page"><div class="breadcrumb"><button data-route="#topics">Темы</button><span>›</span><button data-route="#topic/${t.id}">${esc(t.short)}</button><span>›</span><span>${esc(title)}</span></div><div class="topicHeader"><div class="iconFrame topicLineIcon">${topicIcon(t.id)}</div><div><h2>${esc(title)}</h2><p>${esc(t.title)}</p></div></div>${content}</div>`+bottomNav("study");}

function renderVisual(v){
  if(!v||!v.steps?.length)return "";
  const raw=[v.title||"",...(v.steps||[])].join(" ");
  const title=v.title?`<div class="visualTitle">${esc(v.title)}</div>`:"";
  const steps=v.steps.map((x,i)=>`<div class="visualNode"><span class="visualIndex">${i+1}</span><span>${esc(x)}</span></div>${i<v.steps.length-1?'<div class="visualArrow">→</div>':''}`).join("");
  const special=v.kind?` visual-${esc(v.kind)}`:"";
  return `${v.skipAbbr?"":renderAbbreviationLead(raw)}<div class="visualCard${special}">${title}<div class="visualFlow">${steps}</div></div>`;
}
function renderInteractions(t){
  const arr=INTERACTIONS[t.id]||[];
  if(!arr.length)return `<div class="emptyState"><div class="big">🔗</div><b>Взаимодействия пока не заполнены</b><p>Они будут добавляться из комментариев к тестам и теории.</p></div>`;
  return `<div class="list">${arr.map(x=>`<div class="theoryCard"><div class="resultType">${esc(x.type||"Взаимодействие")}</div><h3>${esc(x.title)}</h3><p>${esc(x.summary||"")}</p>${renderVisual({title:"Механизм взаимодействия",kind:"flow",steps:x.chain||[],skipAbbr:true})}${x.note?`<div class="sourceNote">${esc(x.note)}</div>`:""}</div>`).join("")}</div>`;
}
function renderTopicTheory(t){const items=THEORY[t.id]||[];if(!items.length)return `<div class="emptyState"><div class="big">📘</div><b>Теория пока не заполнена</b><p>Структура уже готова. Следующие конспекты добавим сюда по мере подготовки.</p></div>`;return `<div class="list">${items.map(x=>`<div class="theoryCard"><h3>${esc(x.title)}</h3><p>${esc(x.summary)}</p>${x.type==="interactive"?`<a class="moduleButton" href="${x.url}">📈 Открыть интерактивный модуль</a>`:""}${x.body?.length?`<div class="theoryBody">${x.body.map(v=>`<p>• ${esc(v)}</p>`).join("")}</div>`:""}${renderVisual(x.visual?{...x.visual,skipAbbr:true}:x.visual)}</div>`).join("")}</div>`;}
function renderMechanisms(t){const arr=MECHANISMS[t.id]||[];if(!arr.length)return `<div class="emptyState"><div class="big">🧬</div><b>Механизмы пока не заполнены</b><p>Здесь будут схемы receptor → messenger → effect → drug.</p></div>`;return `<div class="list">${arr.map(m=>`<div class="mechanismCard"><h3>${esc(m.title)}</h3><div class="chain">${m.chain.map((v,i)=>`${i?'<div class="chainArrow">→</div>':""}<div class="chainNode">${esc(v)}</div>`).join("")}</div><div class="chips">${m.examples.map(v=>`<span class="chip">${esc(v)}</span>`).join("")}</div></div>`).join("")}</div>`;}
function drugRows(list){return `<div class="list">${list.map(d=>`<div class="drugRow"><div class="drugNum">#${d.n}</div><div class="drugMain" style="flex:1"><b>${esc(d.name)}</b><span>${esc(d.group)}</span><div>${d.topics.map(x=>`<span class="badge">${esc(topicMap[x]?.short||x)}</span>`).join("")}</div></div><div class="rowActions">${favoriteButton("drug",d.n,"Сохранить")}<button class="drugLink" data-route="#drug/${d.n}">Открыть</button></div></div>`).join("")}</div>`;}
function renderTopicDrugs(t){const list=DRUGS.filter(d=>d.topics.includes(t.id));return `<div class="toolbar"><input id="topicDrugSearch" placeholder="Поиск в ${esc(t.short)}…"><span class="badge blue">${list.length} препаратов</span></div><div id="topicDrugList">${drugRows(list)}</div>`;}
function abbrRow(a){return `<div class="abbrRow"><b>${esc(a.abbr)}</b><div class="full">${esc(a.full)}</div><div class="ru">${esc(a.ru)}</div><div class="subtopic">${esc(a.subtopic)}</div></div>`;}
function renderAbbr(t){const arr=ABBREVIATIONS[t.id]||[];if(!arr.length)return `<div class="emptyState"><div class="big">🔤</div><b>Словарь этой темы пока не заполнен</b><p>Аббревиатуры будут добавляться внутри темы, а не в один смешанный список.</p></div>`;return `<div class="toolbar"><input id="abbrSearch" placeholder="Поиск по аббревиатурам ${esc(t.short)}…"><span class="badge">${arr.length}</span></div><div id="abbrList" class="list">${arr.map(abbrRow).join("")}</div>`;}
function renderTestsSection(t, analysis=false){
  const arr=(analysis?TEST_ANALYSES:TESTS).filter(x=>x.topic===t.id);
  if(!arr.length) return `<div class="emptyState"><div class="big">${analysis?"✅":"📝"}</div><b>${analysis?"Разборов":"Тестов"} пока нет</b></div>`;
  if(!analysis){
    const sections=SOURCE_SECTIONS.filter(s=>s.topic===t.id);
    return `<div class="card"><h3>Интерактивный тест</h3><p>${arr.length} вопросов из загруженного материала. Результаты сохраняются в личной истории обучения и синхронизируются при подключённом аккаунте.</p>
      <button class="moduleButton" data-start-test="topic:${t.id}">▶ Начать тест по теме (${arr.length})</button></div>
      <div class="sectionTitle"><h2>Блоки источника</h2></div>
      <div class="list">${sections.map(s=>`<div class="theoryCard"><h3>${esc(s.title)}</h3><p>${s.count} вопросов</p><button class="drugLink" data-start-test="section:${s.id}">Начать</button></div>`).join("")}</div>`;
  }
  const qmap=Object.fromEntries(TESTS.map(q=>[q.id,q]));
  return `<div class="list">${arr.map(a=>{
    const q=qmap[a.questionId]; if(!q)return "";
    return `<div class="theoryCard"><div class="resultType">${esc(q.sectionTitle)} · вопрос ${q.number}</div><h3>${esc(q.question)}</h3>
      <div class="answerReview"><b>Правильный ответ: ${esc(q.correct)}. ${esc(q.options.find(o=>o.id===q.correct)?.text||q.correctText||"")}</b></div>
      ${a.explanation?.length?`<div class="reviewText">${a.explanation.map(x=>`<p>${esc(x)}</p>`).join("")}</div>`:""}
      ${q.options.map(o=>`<div class="reviewOption ${o.id===q.correct?"isCorrect":""}"><b>${o.id}. ${esc(o.text)}</b><div>${o.id===q.correct?"Правильный вариант.":esc(a.optionExplanations?.[o.id]||"В исходном материале отдельный комментарий к этому варианту не сохранён.")}</div></div>`).join("")}
      ${renderVisual(q.visual||a.visual||SECTION_VISUALS[q.sectionId])}${a.sourceNotes?.length?`<div class="sourceNote">${a.sourceNotes.map(x=>`<div>⚠ ${esc(x)}</div>`).join("")}</div>`:""}
    </div>`;
  }).join("")}</div>`;
}
function renderHigh(t){const arr=HIGH_YIELD[t.id]||[];if(!arr.length)return `<div class="emptyState"><div class="big">⚡</div><b>High-yield пока не заполнен</b></div>`;return `<div class="list">${arr.map((x,i)=>`<div class="highYieldItem"><b>${i+1}.</b> ${esc(x)}</div>`).join("")}</div>`;}

function renderTopicSection(id,section){const t=topicMap[id];if(!t){location.hash="#topics";return;}const titles={theory:"Теория",mechanisms:"Механизмы",drugs:"Препараты",abbr:"Аббревиатуры",interactions:"Взаимодействия",tests:"Тесты",analysis:"Разбор тестов",high:"High-yield"};let content="";if(section==="theory")content=renderTopicTheory(t);if(section==="mechanisms")content=renderMechanisms(t);if(section==="drugs")content=renderTopicDrugs(t);if(section==="abbr")content=renderAbbr(t);if(section==="interactions")content=renderInteractions(t);if(section==="tests")content=renderTestsSection(t,false);if(section==="analysis")content=renderTestsSection(t,true);if(section==="high")content=renderHigh(t);app.innerHTML=sectionShell(t,titles[section]||section,content);bindNav();bindTestStarters();if(section==="drugs"){const input=document.getElementById("topicDrugSearch"),target=document.getElementById("topicDrugList"),base=DRUGS.filter(d=>d.topics.includes(t.id));input?.addEventListener("input",()=>{const q=input.value.toLowerCase();target.innerHTML=drugRows(base.filter(d=>drugSearchText(d).includes(q)));bindNav();});}if(section==="abbr"){const input=document.getElementById("abbrSearch"),target=document.getElementById("abbrList"),base=ABBREVIATIONS[t.id]||[];input?.addEventListener("input",()=>{const q=input.value.toLowerCase();target.innerHTML=base.filter(a=>(a.abbr+" "+a.full+" "+a.ru+" "+a.subtopic).toLowerCase().includes(q)).map(abbrRow).join("");});}}

function renderAllDrugs(){const options=TOPICS.map(t=>`<option value="${t.id}">${esc(t.short)}</option>`).join("");app.innerHTML=header()+`<div class="page"><div class="sectionTitle"><h2>170 препаратов</h2><span class="muted">единая база</span></div><div class="toolbar"><input id="drugSearch" placeholder="Название или фармгруппа…"><select id="drugTopic"><option value="">Все темы</option>${options}</select></div><div id="allDrugList">${drugRows(DRUGS)}</div></div>`+bottomNav("study");bindNav();const s=document.getElementById("drugSearch"),f=document.getElementById("drugTopic"),out=document.getElementById("allDrugList");const apply=()=>{const q=s.value.toLowerCase(),topic=f.value;const rows=DRUGS.filter(d=>(!q||drugSearchText(d).includes(q))&&(!topic||d.topics.includes(topic)));out.innerHTML=drugRows(rows);bindNav();};s.addEventListener("input",apply);f.addEventListener("change",apply);}

function testCommentForDrug(q,d){
  const a=TEST_ANALYSES.find(x=>x.questionId===q.id);
  const all=[];
  const generic=(a?.explanation||q.explanation||[]).filter(Boolean);
  if(generic.length) all.push(...generic);
  const name=(d.name||"").toLowerCase();
  const comments=Object.entries(a?.optionExplanations||q.optionExplanations||{}).filter(([key,text])=>{
    const opt=q.options?.find(o=>o.id===key)?.text||"";
    const hay=(opt+" "+text).toLowerCase();
    return hay.includes(name) || q.drugIds?.length===1;
  }).map(([key,text])=>`${key}: ${text}`);
  if(comments.length) all.push(...comments);
  return [...new Set(all)].slice(0,6);
}
function renderRelatedTestComments(d,relatedTests){
  if(!relatedTests.length)return `<p class="smallMuted">Пока комментариев из тестов по этому препарату нет.</p>`;
  return `<div class="testCommentList">${relatedTests.slice(0,40).map(q=>{
    const comments=testCommentForDrug(q,d);
    return `<div class="testCommentCard"><div class="resultType">${esc(q.sectionTitle)} · №${q.number}</div>${comments.length?comments.map(x=>`<p>Комментарий: ${esc(x)}</p>`).join(""):`<p>Комментарий: ${esc((q.explanation||[]).join(" ")||"Вопрос связан с препаратом, но отдельный текстовый комментарий в источнике не сохранён.")}</p>`}</div>`;
  }).join("")}</div>`;
}
function renderDrug(n){
  const d=drugMap[String(n)];if(!d){location.hash="#drugs";return;}
  const p=profileFor(d),cardio=CARDIO49[d.name],k=DRUG_KNOWLEDGE[String(d.n)],relatedTests=TESTS.filter(q=>q.drugIds?.includes(d.n));
  const relatedInteractions=Object.entries(INTERACTIONS).flatMap(([topic,arr])=>arr.map(x=>({...x,topic}))).filter(x=>x.drugIds?.includes(d.n));
  const sourceScheme=p?.schemeSteps?.length?`${renderVisual({title:"Схема механизма",kind:"flow",steps:p.schemeSteps,skipAbbr:true})}${renderProcessCommentary({commentary:p.schemeSteps.map((step,i)=>`${i+1}. ${step}`)})}`:"";
  app.innerHTML=header()+`<div class="page drugDetail">
    <div class="breadcrumb"><button data-route="#drugs">170 препаратов</button><span>›</span><span>#${d.n}</span></div>
    <div class="topicHeader"><div class="iconFrame">Rx</div><div><h2>${esc(p?.mnn||d.name)}</h2><p>${esc(p?.groupSource||d.group)}</p><div class="chips"><span class="badge blue">№ ${d.n}</span>${d.topics.map(x=>`<span class="badge">${esc(topicMap[x]?.short||x)}</span>`).join("")}</div><div class="entityActions">${favoriteButton("drug",d.n,"Избранное")}${reviewButton("drug",d.n,"Повторить")}</div></div></div>

    <div class="sourceNote profileSourceWarning"><b>Учебная карточка ProPharm v1.0.</b> Данные перенесены из загруженной базы. Точные регуляторные формулировки и PK-числа в исходнике отмечены как требующие второго прохода сверки по Israeli Drug Registry, FDA/Drugs@FDA и ГРЛС.</div>

    <div class="drugProfileAccordion">
      ${profileSection("Основная информация",p?.basic,"i")}
      ${profileSection("Показания к применению",p?.indications,"+")}
      ${profileSection("Противопоказания и ограничения",p?.contraindications,"!")}
      ${p?.mechanismText?`<details class="drugProfileSection" open><summary><span><span class="profileSectionIcon">→</span>Механизм действия</span><span class="schemePlus">＋</span></summary><div class="drugProfileBody">${renderAbbreviationLead((p.mechanismText||"")+" "+(p.scheme||""))}<p>${esc(p.mechanismText)}</p>${sourceScheme}</div></details>`:""}
      ${profileSection("Способы применения",p?.routes,"↗")}
      ${profileSection("Фармакодинамика",p?.pharmacodynamics,"PD")}
      ${profileSection("Фармакокинетика",p?.pharmacokinetics,"PK")}
      ${profileSection("Побочные эффекты",p?.adverseEffects,"⚠")}
      ${renderProfileInteractions(p)}
      ${profileSection("Особые ситуации",p?.specialSituations,"★")}
      ${profileSection("Источники для верификации",p?.sources,"≡")}
    </div>

    ${k?`<div class="detailBox"><h3>Дополнительные экзаменационные комментарии</h3>${k.pearls?.map(x=>`<p>• ${esc(x)}</p>`).join("")||""}${k.visual?renderVisual(k.visual):""}</div>`:""}
    ${cardio?`<div class="detailBox noteCardio"><h3>Связь с электрофизиологией ССС</h3><p>${esc(cardio.note)}</p><a class="moduleButton" href="modules/cardio/index.html">Открыть Cardio-модуль</a></div>`:""}
    ${relatedInteractions.length?`<div class="detailBox"><h3>Дополнительные взаимодействия из тестовой базы</h3>${relatedInteractions.map(x=>`<div class="interactionMini"><b>${esc(x.title)}</b><div>${esc(x.summary)}</div>${renderVisual({title:"Механизм",kind:"flow",steps:x.chain||[]})}</div>`).join("")}</div>`:""}
    <div class="detailBox"><h3>Комментарии из связанных тестов</h3><p class="smallMuted">Сам вопрос здесь не дублируется — показаны только учебные комментарии.</p>${renderRelatedTestComments(d,relatedTests)}</div>
  </div>`+bottomNav("study");bindNav();
}
function renderTests(){
  const topicCounts=TOPICS.map(t=>({...t,count:TESTS.filter(q=>q.topic===t.id).length})).filter(x=>x.count>0);
  app.innerHTML=header()+`<div class="page"><section class="hero"><h2>Экзаменационные тесты</h2><p>${TESTS.length} вопросов: исходная загруженная экзаменационная база + ${CARDIO_EXTRA_TESTS.length} новых учебных вопросов ССС. Неправильный ответ → подсказка → повторная попытка; после правильного ответа — комментарии ко всем вариантам и схема.</p><div class="stats"><div class="stat"><b>${TESTS.length}</b><span>вопросов</span></div><div class="stat"><b>${SOURCE_SECTIONS.length}</b><span>блоков</span></div><div class="stat"><b>${topicCounts.length}</b><span>тем с тестами</span></div><div class="stat"><b>∞</b><span>история в профиле</span></div></div><div class="warn">Результаты сохраняются в IndexedDB. При подключённом аккаунте они синхронизируются с Supabase; подробный прогресс разделён по user_id.</div></section>
  <div class="sectionTitle"><h2>Начать</h2></div><div class="sectionGrid"><div class="card clickCard"><div class="cardHead"><div class="iconFrame">🎯</div><div><h3>Все вопросы</h3><p>${TESTS.length} подряд.</p><button class="moduleButton" data-start-test="all">Начать</button></div></div></div>${topicCounts.map(t=>`<div class="card clickCard"><div class="cardHead"><div class="iconFrame topicLineIcon">${topicIcon(t.id)}</div><div><h3>${esc(t.short)}</h3><p>${t.count} вопросов.</p><button class="moduleButton" data-start-test="topic:${t.id}">Начать</button></div></div></div>`).join("")}</div>
  <div class="sectionTitle"><h2>По блокам источника</h2></div><div class="list">${SOURCE_SECTIONS.map(s=>`<div class="theoryCard"><div class="resultType">${esc(topicMap[s.topic]?.short||s.topic)}</div><h3>${esc(s.title)}</h3><p>${s.count} вопросов</p><button class="drugLink" data-start-test="section:${s.id}">Начать тест</button></div>`).join("")}</div></div>`+bottomNav("study");bindNav();bindTestStarters();
}
function renderSearch(){app.innerHTML=header()+`<div class="page"><div class="sectionTitle"><h2>Глобальный поиск</h2></div><input id="globalSearch" placeholder="Например: SERCA, metoprolol, QT, SGLT2…"><div id="globalResults" class="globalResults" style="margin-top:10px"><div class="emptyState"><div class="big">🔎</div><b>Начни вводить запрос</b><p>Поиск идёт по препаратам, аббревиатурам и теоретическим модулям.</p></div></div></div>`+bottomNav("search");bindNav();const input=document.getElementById("globalSearch"),out=document.getElementById("globalResults");input.addEventListener("input",()=>{const q=input.value.trim().toLowerCase();if(!q){out.innerHTML=`<div class="emptyState"><div class="big">🔎</div><b>Начни вводить запрос</b></div>`;return;}const dr=DRUGS.filter(d=>drugSearchText(d).includes(q)).slice(0,20);const ab=ALL_ABBREVIATIONS.map(a=>({...a,topic:a.subtopic?.startsWith("ССС")?"cardio":""})).filter(a=>(a.abbr+" "+a.full+" "+a.ru+" "+a.subtopic).toLowerCase().includes(q)).slice(0,30);const integrated=[...CARDIO_PHYSIOLOGY.map(x=>({...x,kind:"Анатомия / физиология"})),...CARDIO_BIOCHEMISTRY.map(x=>({...x,kind:"Биохимия"})),...CARDIO_PATHOLOGIES.map(x=>({...x,summary:x.definition,kind:"Патофизиология"})),...CARDIO_DIAGNOSTICS.map(x=>({...x,kind:"Диагностика"}))].filter(x=>cardioBlockText(x).toLowerCase().includes(q)).slice(0,20);const th=Object.entries(THEORY).flatMap(([topic,arr])=>arr.map(x=>({...x,topic}))).filter(x=>(x.title+" "+x.summary).toLowerCase().includes(q)).slice(0,20);const html=[...dr.map(d=>`<div class="drugRow"><div><div class="resultType">Препарат</div><b>${esc(d.name)}</b><div class="smallMuted">${esc(d.group)}</div></div><button class="drugLink" data-route="#drug/${d.n}">Открыть</button></div>`),...ab.map(a=>`<div class="abbrRow"><div class="resultType">Термин / сокращение ${a.topic?`· ${esc(topicMap[a.topic]?.short||a.topic)}`:""}</div><b>${esc(a.abbr)}</b><div class="full">${esc(a.full||"")}</div><div class="ru">${esc(a.ru)}</div></div>`),...integrated.map(x=>`<div class="theoryCard"><div class="resultType">ССС · ${esc(x.kind)}</div><h3>${esc(x.title)}</h3><p>${esc(x.summary||"")}</p><button class="drugLink" data-route="#system/cardiovascular/${x.kind==="Биохимия"?"biochemistry":x.kind==="Патофизиология"?"pathophysiology":x.kind==="Диагностика"?"diagnostics":"physiology"}">Открыть раздел</button></div>`),...th.map(x=>`<div class="theoryCard"><div class="resultType">Теория · ${esc(topicMap[x.topic]?.short||x.topic)}</div><h3>${esc(x.title)}</h3><p>${esc(x.summary)}</p></div>`)].join("");out.innerHTML=html||`<div class="emptyState"><b>Ничего не найдено</b></div>`;bindNav();});}

function renderTheoryHub(){
 const groups=TOPICS.map(t=>({t,items:THEORY[t.id]||[]})).filter(x=>x.items.length);
 app.innerHTML=header()+`<div class="page"><div class="paperTitle"><span class="handMini">Учёба</span><h2>Теория</h2><p>Конспекты по темам, без смешивания разделов.</p></div><div class="topicGrid">${groups.map(({t,items})=>`<div class="card clickCard softPaper" data-route="#topic/${t.id}/theory"><div class="cardHead"><div class="iconFrame topicLineIcon">${topicIcon(t.id)}</div><div><h3>${esc(t.title)}</h3><p>${items.length} материалов</p><span class="badge blue">открыть теорию</span></div></div></div>`).join("")}</div></div>`+bottomNav("study");bindNav();
}
function renderTablesHub(){
 const topics=TOPICS.map(t=>({t,tables:STUDY_TABLES[t.id]||[]})).filter(x=>x.tables.length);
 const tableHtml=tbl=>`<div class="studyTableCard"><div class="resultType">${esc(tbl.type||"Теоретический материал")}</div><h3>${esc(tbl.title)}</h3>${renderAbbreviationLead([tbl.title,...tbl.columns,...tbl.rows.flat(),tbl.note||""].join(" "))}<div class="tableScroll"><table><thead><tr>${tbl.columns.map(c=>`<th>${esc(c)}</th>`).join("")}</tr></thead><tbody>${tbl.rows.map(r=>`<tr>${r.map(c=>`<td>${esc(c)}</td>`).join("")}</tr>`).join("")}</tbody></table></div>${tbl.note?`<div class="tableNote">${esc(tbl.note)}</div>`:""}</div>`;
 app.innerHTML=header()+`<div class="page"><div class="paperTitle"><span class="handMini">Быстрый повтор</span><h2>Таблицы</h2><p>Только учебные таблицы: стандарты, классификации и теоретические сравнения. Статистика сайта сюда больше не выводится.</p></div>
 <div class="list">${topics.map(({t,tables})=>`<section class="tableTopicBlock"><div class="sectionTitle"><h2>${t.icon} ${esc(t.title)}</h2><span class="muted">${tables.length}</span></div>${tables.map(tableHtml).join("")}</section>`).join("")}</div></div>`+bottomNav("study");bindNav();
}
function schemeGroups(){
 const out={};
 const add=(topic,item)=>{if(!out[topic])out[topic]=[];const key=(item.title+"|"+(item.steps||[]).join("|")).toLowerCase();if(!out[topic].some(x=>x._key===key))out[topic].push({...item,_key:key});};
 TOPICS.forEach(t=>{
   (THEORY[t.id]||[]).forEach(x=>{if(x.visual?.steps?.length)add(t.id,{title:x.visual.title||x.title,kind:x.visual.kind||"flow",steps:x.visual.steps,explanation:x.summary,details:x.body||[],examples:[]});});
   (MECHANISMS[t.id]||[]).forEach(m=>add(t.id,{title:m.title,kind:"flow",steps:m.chain||[],explanation:`Механизм: ${(m.chain||[]).join(" → ")}.`,details:[],examples:m.examples||[]}));
   (INTERACTIONS[t.id]||[]).forEach(x=>add(t.id,{title:`Взаимодействие: ${x.title}`,kind:"flow",steps:x.chain||[],explanation:x.summary||"Лекарственное взаимодействие из тестовой/теоретической базы.",details:x.note?[x.note]:[],examples:[]}));
 });
 SOURCE_SECTIONS.forEach(sec=>{const v=SECTION_VISUALS[sec.id];if(v?.steps?.length)add(sec.topic,{title:`${sec.title}: ${v.title}`,kind:v.kind||"flow",steps:v.steps,explanation:`Схема к экзаменационному блоку «${sec.title}».`,details:[],examples:[]});});
 DRUGS.forEach(d=>{const p=profileFor(d);if(p?.schemeSteps?.length)add(d.primaryTopic||d.topics?.[0]||"",{title:`${d.name}: механизм действия`,kind:"flow",steps:p.schemeSteps,explanation:p.mechanismText||p.scheme,details:p.pharmacodynamics?[`Фармакодинамика: ${p.pharmacodynamics}`]:[],examples:[d.name]});});
 CARDIO_BIOCHEMISTRY.forEach(x=>add("cardio",{title:`ССС · ${x.title}`,kind:"integrated-cardio",steps:x.steps||[],explanation:x.summary,details:x.commentary||[],examples:(x.drugIds||[]).map(id=>drugMap[String(id)]?.name).filter(Boolean),integrated:x}));
 CARDIO_PHYSIOLOGY.forEach(x=>add("cardio",{title:`ССС · ${x.title}`,kind:"integrated-cardio",steps:x.points||[],explanation:x.summary,details:x.commentary||[],examples:[],integrated:x}));
 return out;
}
function renderSchemesHub(){
 const groups=schemeGroups();
 const topics=TOPICS.map(t=>({t,items:groups[t.id]||[]})).filter(x=>x.items.length);
 app.innerHTML=header()+`<div class="page"><div class="paperTitle"><span class="handMini">Наглядно</span><h2>Схемы</h2><p>Выбери тему → затем название схемы → раскрой блок. Внутри будет сама схема и текстовое пояснение.</p></div><div class="topicGrid">${topics.map(({t,items})=>`<div class="card clickCard softPaper" data-route="#schemes/${t.id}"><div class="cardHead"><div class="iconFrame topicLineIcon">${topicIcon(t.id)}</div><div><h3>${esc(t.title)}</h3><p>${items.length} схем</p><span class="badge blue">открыть схемы</span></div></div></div>`).join("")}</div></div>`+bottomNav("study");bindNav();
}
function renderSchemesTopic(topicId){
 const t=topicMap[topicId];if(!t){location.hash="#schemes";return;}
 const items=schemeGroups()[topicId]||[];
 app.innerHTML=header()+`<div class="page"><div class="breadcrumb"><button data-route="#schemes">Схемы</button><span>›</span><span>${esc(t.short)}</span></div><div class="topicHeader"><div class="iconFrame topicLineIcon">${topicIcon(t.id)}</div><div><h2>Схемы: ${esc(t.title)}</h2><p>Нажми на название, чтобы раскрыть схему и пояснение.</p></div></div><div class="schemeAccordionList">${items.map((x,i)=>`<details class="schemeAccordion" ${i===0?"open":""}><summary><span>${esc(x.title)}</span><span class="schemePlus">＋</span></summary><div class="schemeAccordionBody">${x.integrated?`${renderAbbreviationLead(cardioBlockText(x.integrated))}${cardioSvg(x.integrated.illustration,x.integrated)}${renderProcessCommentary(x.integrated)}`:renderVisual({title:x.title,kind:x.kind,steps:x.steps})}<div class="schemeExplanation"><h4>Пояснение</h4><p>${esc(x.explanation||"")}</p>${x.details?.length?x.details.map(d=>`<p>• ${esc(d)}</p>`).join(""):""}${x.examples?.length?`<div class="chips"><span class="smallMuted">Примеры:</span>${x.examples.map(v=>`<span class="chip">${esc(v)}</span>`).join("")}</div>`:""}</div></div></details>`).join("")}</div></div>`+bottomNav("study");bindNav();
}
let flashIndex=0,flashRevealed=false,flashFilter="all",flashQuery="";
function stableFlashId(card){
 let h=2166136261,s=[card.type,card.drugId||'',card.topic||'',card.front||''].join('|');
 for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619)}
 return `fc-${card.type}-${(h>>>0).toString(36)}`;
}
function buildFlashCards(){
 const cards=[];
 DRUGS.forEach(d=>{
   const p=profileFor(d);
   cards.push({type:"drug",topic:d.primaryTopic||d.topics?.[0]||"",drugId:d.n,title:d.name,front:`К какой фармакологической группе относится ${d.name}?`,back:[p?.groupSource||d.group,`Темы: ${d.topics.map(x=>topicMap[x]?.short||x).join(", ")}`]});
   if(p?.mechanismText)cards.push({type:"profileMechanism",topic:d.primaryTopic||d.topics?.[0]||"",drugId:d.n,title:d.name,front:`Механизм действия ${d.name}`,back:[p.mechanismText]});
   if(p?.indications)cards.push({type:"indications",topic:d.primaryTopic||d.topics?.[0]||"",drugId:d.n,title:d.name,front:`Основные показания ${d.name}`,back:[p.indications]});
   if(p?.pharmacokinetics)cards.push({type:"pk",topic:d.primaryTopic||d.topics?.[0]||"",drugId:d.n,title:d.name,front:`Что важно помнить о фармакокинетике ${d.name}?`,back:[p.pharmacokinetics]});
   if(p?.adverseEffects)cards.push({type:"adverse",topic:d.primaryTopic||d.topics?.[0]||"",drugId:d.n,title:d.name,front:`Основные побочные эффекты ${d.name}`,back:[p.adverseEffects]});
   if(p?.interactionsText)cards.push({type:"profileInteraction",topic:d.primaryTopic||d.topics?.[0]||"",drugId:d.n,title:d.name,front:`Ключевые взаимодействия ${d.name}`,back:[p.interactionsText]});
   const k=DRUG_KNOWLEDGE[String(d.n)];
   if(k?.mechanism?.length)cards.push({type:"mechanism",topic:d.primaryTopic||d.topics?.[0]||"",drugId:d.n,title:d.name,front:`Каков механизм действия ${d.name}?`,back:k.mechanism});
   if(k?.pearls?.length)k.pearls.forEach((p,i)=>cards.push({type:"pearl",topic:d.primaryTopic||d.topics?.[0]||"",drugId:d.n,title:d.name,front:`Что важно помнить о ${d.name}? · карточка ${i+1}`,back:[p]}));
 });
 TESTS.forEach(q=>{
   (q.drugIds||[]).forEach(drugId=>{
     const d=drugMap[String(drugId)];if(!d)return;
     const correct=q.options?.find(o=>o.id===q.correct);
     cards.push({type:"test",topic:q.topic||d.primaryTopic,drugId,title:d.name,front:q.question,back:[`Правильный ответ: ${q.correct}. ${correct?.text||q.correctText||""}`,...(q.explanation||[])]});
     Object.entries(q.optionExplanations||{}).forEach(([oid,comment])=>{
       const opt=q.options?.find(o=>o.id===oid);
       if(!comment||!opt)return;
       cards.push({type:"comment",topic:q.topic||d.primaryTopic,drugId,title:d.name,front:`Комментарий к варианту ${oid} в вопросе про ${d.name}: «${opt.text}»`,back:[comment]});
     });
   });
 });
 CARDIO_FLASHCARDS.forEach(c=>cards.push({type:"cardioIntegrated",topic:"cardio",drugId:"",title:c.title,front:c.front,back:[c.back],cardioArea:c.area}));
 return cards.map(c=>({...c,id:stableFlashId(c)}));
}
function filteredFlashCards(){
 const all=buildFlashCards();
 return all.filter(c=>(flashFilter==="all"||c.type===flashFilter)&&(!flashQuery||(c.title+" "+c.front+" "+c.back.join(" ")).toLowerCase().includes(flashQuery.toLowerCase())));
}
function renderCardsHub(){
 const cards=filteredFlashCards();
 if(flashIndex>=cards.length)flashIndex=0;
 const d=cards[flashIndex];
 const typeNames={drug:"Фармгруппа",profileMechanism:"Механизм из базы 170",indications:"Показания",pk:"Фармакокинетика",adverse:"Побочные эффекты",profileInteraction:"Взаимодействия",mechanism:"Механизм из тестов",pearl:"Экзаменационный комментарий",test:"Вопрос из теста",comment:"Комментарий к варианту",cardioIntegrated:"ССС · интегрированная карточка"};
 app.innerHTML=header()+`<div class="page"><div class="paperTitle"><span class="handMini">Повторение</span><h2>Карточки</h2><p>Карточки формируются из 170 препаратов, механизмов, тестовых вопросов и комментариев к вариантам.</p></div>
 <div class="flashToolbar"><input id="flashSearch" value="${esc(flashQuery)}" placeholder="Поиск препарата или текста…"><select id="flashType"><option value="all">Все типы</option>${Object.entries(typeNames).map(([k,v])=>`<option value="${k}" ${flashFilter===k?"selected":""}>${v}</option>`).join("")}</select></div>
 <div class="flashStats"><span class="badge blue">${cards.length} карточек</span><span class="badge">прогресс сохраняется</span></div>
 ${d?`<div class="flashWrap"><button class="flashCard ${flashRevealed?"revealed":""}" id="flashCard"><span class="flashNum">${esc(typeNames[d.type]||d.type)} · #${d.drugId||""}</span><h2>${esc(d.title)}</h2>${renderAbbreviationLead([d.front,...d.back].join(" "))}${flashRevealed?`<div class="flashAnswer">${d.back.map(x=>`<p>${esc(x)}</p>`).join("")}</div>`:`<p>${esc(d.front)}</p><span class="handMini">нажми, чтобы перевернуть ↻</span>`}</button><div class="flashPersonal">${favoriteButton("card",d.id,"Избранное")}${reviewButton("card",d.id,"Повторить")}<button class="miniAction" id="knowCard">✓ Знаю</button></div><div class="flashControls"><button id="prevCard">← Назад</button><span>${flashIndex+1} / ${cards.length}</span><button id="nextCard">Дальше →</button></div></div>`:`<div class="emptyState"><div class="big">🗂️</div><b>Нет карточек по выбранному фильтру</b></div>`}</div>`+bottomNav("study");bindNav();
 const search=document.getElementById("flashSearch"),type=document.getElementById("flashType");
 search.oninput=e=>{flashQuery=e.target.value;flashIndex=0;flashRevealed=false;clearTimeout(window.__flashTimer);window.__flashTimer=setTimeout(renderCardsHub,180)};
 type.onchange=e=>{flashFilter=e.target.value;flashIndex=0;flashRevealed=false;renderCardsHub()};
 if(d){document.getElementById("flashCard").onclick=()=>{flashRevealed=!flashRevealed;renderCardsHub()};document.getElementById("prevCard").onclick=()=>{flashIndex=(flashIndex-1+cards.length)%cards.length;flashRevealed=false;renderCardsHub()};document.getElementById("nextCard").onclick=()=>{flashIndex=(flashIndex+1)%cards.length;flashRevealed=false;renderCardsHub()};document.getElementById("knowCard")?.addEventListener("click",async()=>{await recordStudyPosition({system_id:d.topic||"global",section_id:"cards",entity_id:d.id,route:"#cards",completed:true});toast("Карточка отмечена как изученная");flashIndex=(flashIndex+1)%cards.length;flashRevealed=false;renderCardsHub()});}
}
function renderSettingsHub(){
 const profile=authState.profile;
 app.innerHTML=header()+`<div class="page"><div class="paperTitle"><span class="handMini">Под себя</span><h2>Настройки</h2><p>Интерфейс, аккаунт и синхронизация.</p>${authBadge()}</div>
 <div class="settingsList"><label class="settingRow"><span><b>Крупный текст</b><small>Увеличить шрифт интерфейса</small></span><input type="checkbox" id="largeText" ${uiSettings.largeText?"checked":""}></label><label class="settingRow"><span><b>Меньше анимаций</b><small>Уменьшить движение элементов</small></span><input type="checkbox" id="reducedMotion" ${uiSettings.reducedMotion?"checked":""}></label></div>
 <div class="sectionTitle"><h2>Аккаунт и учёба</h2></div><div class="sectionGrid profileGrid">
 <div class="card clickCard" data-route="#profile"><h3>Профиль</h3><p>${esc(profile?.name||profile?.email||'Локальный профиль')}</p></div>
 <div class="card clickCard" data-route="#my-study"><h3>Моя учёба</h3><p>История тестов и успешность</p></div>
 <div class="card clickCard" data-route="#favorites"><h3>Избранное</h3><p>Сохранённые материалы</p></div>
 <div class="card clickCard" data-route="#review"><h3>Повторить</h3><p>Очередь слабых тем</p></div>
 ${isAdmin()?`<div class="card clickCard adminCard" data-route="#admin"><h3>Администрирование</h3><p>Одобрение и блокировка пользователей</p></div>`:""}
 </div>${!isAuthConfigured()?`<div class="sourceNote"><b>Supabase пока не подключён.</b> Приложение работает в локальном preview-режиме, а история и избранное сохраняются в IndexedDB этого устройства. Для аккаунтов открой <code>docs/SUPABASE_SETUP_RU.md</code>.</div>`:`<button class="moduleButton secondary" id="syncNow">Синхронизировать сейчас</button><button class="moduleButton dangerSoft" id="logoutBtn">Выйти из аккаунта</button>`}</div>`+bottomNav("settings");bindNav();
 document.getElementById("largeText").onchange=e=>{uiSettings.largeText=e.target.checked;localStorage.setItem(UI_SETTINGS_KEY,JSON.stringify(uiSettings));saveUserSettings(uiSettings).catch(()=>{});applyUiSettings()};
 document.getElementById("reducedMotion").onchange=e=>{uiSettings.reducedMotion=e.target.checked;localStorage.setItem(UI_SETTINGS_KEY,JSON.stringify(uiSettings));saveUserSettings(uiSettings).catch(()=>{});applyUiSettings()};
 document.getElementById('syncNow')?.addEventListener('click',async()=>{try{await syncPending();await hydrateFromCloud();toast('Синхронизация завершена')}catch(e){toast(e.message||String(e),'bad')}});
 document.getElementById('logoutBtn')?.addEventListener('click',async()=>{await signOut();location.hash='#home';router()});
}
function renderAbbrHub(){return renderSystemAbbrHub();}
async function renderProfile(){
 const p=authState.profile||{};
 app.innerHTML=header()+`<div class="page"><div class="paperTitle"><span class="handMini">Мой ProPharm</span><h2>Профиль</h2><p>${isAuthConfigured()?'Данные аккаунта и способы входа.':'Локальный preview-профиль до подключения Supabase.'}</p>${authBadge()}</div>
 <div class="profileHero"><div class="profileAvatar">${esc((p.name||p.email||'P').slice(0,1).toUpperCase())}</div><div><h3>${esc(p.name||'Пользователь')}</h3><p>${esc(p.email||'')}</p><div class="chips"><span class="chip">${esc(p.provider||'local')}</span><span class="chip">${esc(p.status||'approved')}</span><span class="chip">${esc(p.role||'user')}</span></div></div></div>
 ${isAuthConfigured()?`<div class="card"><h3>Имя профиля</h3><div class="inlineForm"><input id="profileName" value="${esc(p.name||'')}" placeholder="Имя"><button class="drugLink" id="saveProfile">Сохранить</button></div></div><div class="card"><h3>Связать способ входа</h3><p>Дополнительная identity будет связана с текущим UUID через Supabase, а не по догадке по email.</p><div class="oauthRow"><button class="oauthButton" data-link-provider="google">Google</button><button class="oauthButton" data-link-provider="apple">Apple</button></div></div>`:''}
 <div class="sectionGrid"><div class="card clickCard" data-route="#my-study"><h3>Моя учёба</h3><p>Статистика и история тестов</p></div><div class="card clickCard" data-route="#favorites"><h3>Избранное</h3><p>Сохранённые сущности</p></div><div class="card clickCard" data-route="#review"><h3>Повторить</h3><p>Материал для повторения</p></div><div class="card clickCard" data-route="${esc(lastStudyRoute())}"><h3>Продолжить обучение</h3><p>${esc(lastStudyRoute())}</p></div></div></div>`+bottomNav('settings');bindNav();
 document.getElementById('saveProfile')?.addEventListener('click',async()=>{try{await updateOwnProfile({name:document.getElementById('profileName').value});toast('Профиль сохранён');renderProfile()}catch(e){toast(e.message||String(e),'bad')}});
 document.querySelectorAll('[data-link-provider]').forEach(b=>b.addEventListener('click',async()=>{try{await linkIdentity(b.dataset.linkProvider)}catch(e){toast(e.message||String(e),'bad')}}));
}
async function renderMyStudy(){
 app.innerHTML=header()+`<div class="page"><div class="paperTitle"><span class="handMini">Персональная статистика</span><h2>Моя учёба</h2><p>Загружаю локальную историю…</p></div></div>`+bottomNav('settings');bindNav();
 const st=await getLearningStats();
 const recent=[...st.sessions].sort((a,b)=>String(b.completed_at||b.created_at).localeCompare(String(a.completed_at||a.created_at))).slice(0,12);
 const weak=[...st.questions].filter(x=>(x.wrong_count||0)>0).sort((a,b)=>(b.wrong_count||0)-(a.wrong_count||0)).slice(0,10);
 const systemStats=SYSTEMS.map(system=>{
   const source=new Set(systemSourceTopics(system));
   const rows=st.questions.filter(r=>{const q=TESTS.find(x=>x.id===r.question_id);return q&&source.has(q.topic)});
   const correct=rows.reduce((n,r)=>n+(r.correct_count||0),0),wrong=rows.reduce((n,r)=>n+(r.wrong_count||0),0),attempts=rows.reduce((n,r)=>n+(r.attempts||0),0),first=rows.reduce((n,r)=>n+(r.first_try_correct_count||0),0);
   return {system,rows:rows.length,attempts,wrong,accuracy:(correct+wrong)?Math.round(correct/(correct+wrong)*100):0,firstTry:attempts?Math.round(first/attempts*100):0};
 }).filter(x=>x.attempts>0);
 app.innerHTML=header()+`<div class="page"><div class="paperTitle"><span class="handMini">Персональная статистика</span><h2>Моя учёба</h2><p>История хранится локально и при настроенном аккаунте синхронизируется между устройствами.</p></div>
 <div class="stats learningStats"><div class="stat"><b>${st.sessions.length}</b><span>тестовых сессий</span></div><div class="stat"><b>${st.accuracy}%</b><span>точность выборов</span></div><div class="stat"><b>${st.firstTryRate}%</b><span>с 1-й попытки</span></div><div class="stat"><b>${st.wrong}</b><span>ошибочных выборов</span></div></div>
 <div class="quickStudy"><button class="moduleButton" data-route="${esc(lastStudyRoute())}">Продолжить обучение</button><button class="moduleButton secondary" data-route="#review">Повторить слабые темы (${st.review.length})</button></div>
 <div class="sectionTitle"><h2>По системам</h2><span class="muted">${systemStats.length}</span></div>${systemStats.length?`<div class="list systemProgressList">${systemStats.map(x=>`<div class="theoryCard"><div class="resultType">${esc(x.system.short||x.system.title)}</div><h3>${x.accuracy}% точность</h3><p>С первой попытки: ${x.firstTry}% · прохождений вопросов: ${x.attempts} · ошибочных выборов: ${x.wrong}</p><button class="drugLink" data-route="#system/${x.system.id}">Открыть систему</button></div>`).join('')}</div>`:`<div class="emptyState"><b>Статистики по системам пока нет</b><p>Она появится после прохождения тематических тестов.</p></div>`}
 <div class="sectionTitle"><h2>Последние тесты</h2><span class="muted">${recent.length}</span></div>${recent.length?`<div class="list">${recent.map(x=>`<div class="theoryCard"><div class="resultType">${esc(x.test_id||'Тест')}</div><h3>${Number(x.score||0).toFixed(0)}% с первой попытки</h3><p>${x.first_try_correct||0}/${x.questions_total||0} с первой попытки · ошибок выбора: ${x.wrong_selections||0}</p><div class="smallMuted">${esc((x.completed_at||x.created_at||'').replace('T',' ').slice(0,16))}</div></div>`).join('')}</div>`:`<div class="emptyState"><b>Истории пока нет</b><p>Пройди первый тест — результат появится здесь.</p></div>`}
 <div class="sectionTitle"><h2>Слабые вопросы</h2></div>${weak.length?`<div class="list">${weak.map(x=>{const q=TESTS.find(q=>q.id===x.question_id);return `<div class="theoryCard"><h3>${esc(q?.question||x.question_id)}</h3><p>Ошибочных выборов: ${x.wrong_count||0} · прохождений: ${x.attempts||0}</p>${reviewButton('question',x.question_id,'Повторить')}</div>`}).join('')}</div>`:`<div class="emptyState"><b>Слабых вопросов пока не выявлено</b></div>`}</div>`+bottomNav('settings');bindNav();
}
async function renderFavorites(){
 const rows=await listFavorites();const resolved=rows.map(x=>({...x,info:resolvePersonalEntity(x.entity_type,x.entity_id)})).filter(x=>x.info);
 app.innerHTML=header()+`<div class="page"><div class="paperTitle"><span class="handMini">Сохранённое</span><h2>Избранное</h2><p>Препараты, заболевания, механизмы, карточки и вопросы привязаны к твоему профилю.</p></div>${resolved.length?`<div class="list">${resolved.map(x=>`<div class="card personalRow"><div><div class="resultType">${esc(x.entity_type)}</div><h3>${esc(x.info.title)}</h3><p>${esc(x.info.subtitle||'')}</p></div><div class="rowActions">${favoriteButton(x.entity_type,x.entity_id,'Удалить')}<button class="drugLink" data-route="${esc(x.info.route)}">Открыть</button></div></div>`).join('')}</div>`:`<div class="emptyState"><div class="big">♡</div><b>Избранное пока пусто</b><p>Нажимай ♡ возле препаратов и других учебных сущностей.</p></div>`}</div>`+bottomNav('settings');bindNav();
}
async function renderReview(){
 const rows=await listReview();const resolved=rows.map(x=>({...x,info:resolvePersonalEntity(x.entity_type,x.entity_id)}));
 app.innerHTML=header()+`<div class="page"><div class="paperTitle"><span class="handMini">Активное повторение</span><h2>Повторить</h2><p>Отдельно от избранного: сюда попадает материал, который нужно закрепить.</p></div>${resolved.length?`<div class="list">${resolved.map(x=>`<div class="card personalRow"><div><div class="resultType">${esc(x.reason||'manual')}</div><h3>${esc(x.info?.title||x.entity_id)}</h3><p>${esc(x.info?.subtitle||'')}</p></div><div class="rowActions"><button class="miniAction" data-remove-review="${esc(x.entity_type)}|${esc(x.entity_id)}">✓ Готово</button>${x.info?.route?`<button class="drugLink" data-route="${esc(x.info.route)}">Открыть</button>`:''}</div></div>`).join('')}</div>`:`<div class="emptyState"><div class="big">↻</div><b>Очередь повторения пуста</b></div>`}</div>`+bottomNav('settings');bindNav();
 document.querySelectorAll('[data-remove-review]').forEach(b=>b.addEventListener('click',async()=>{const [t,id]=b.dataset.removeReview.split('|');await removeReview(t,id);renderReview()}));
}
function renderAuthLoading(){app.innerHTML=`<div class="authPage"><div class="authCard"><div class="authLogo">${capsuleLogo('authCapsuleLogo')}</div><h1>ProPharm</h1><p>Проверяем аккаунт…</p><div class="authSpinner"></div></div></div>`}
function renderLogin(){
 const oauthGoogle=`<button class="oauthButton google" data-oauth="google">Продолжить с Google</button>`;
 const oauthApple=`<button class="oauthButton apple" data-oauth="apple">Продолжить с Apple</button>`;
 app.innerHTML=`<div class="authPage"><div class="authCard"><div class="authLogo">${capsuleLogo('authCapsuleLogo')}</div><h1>ProPharm</h1><p>Войди в учебный профиль</p>${oauthGoogle}${oauthApple}<div class="authDivider"><span>или</span></div><form id="loginForm"><label>E-mail<input type="email" id="loginEmail" autocomplete="email" required></label><label>Пароль<input type="password" id="loginPassword" autocomplete="current-password" required></label><button class="moduleButton" type="submit">Войти</button></form><div class="authLinks"><button data-route="#register">Создать аккаунт</button><button id="forgotPassword">Забыли пароль?</button></div><div id="authMessage" class="authMessage"></div></div></div>`;bindNav();
 document.querySelectorAll('[data-oauth]').forEach(b=>b.addEventListener('click',async()=>{try{await signInWithOAuth(b.dataset.oauth)}catch(e){showAuthError(e)}}));
 document.getElementById('loginForm').onsubmit=async e=>{e.preventDefault();try{await signInWithPassword(document.getElementById('loginEmail').value,document.getElementById('loginPassword').value);await refreshProfile();router()}catch(err){showAuthError(err)}};
 document.getElementById('forgotPassword').onclick=async()=>{const email=document.getElementById('loginEmail').value;if(!email)return showAuthError(new Error('Сначала введи e-mail'));try{await resetPassword(email);document.getElementById('authMessage').textContent='Ссылка для восстановления отправлена.'}catch(e){showAuthError(e)}};
}
function renderRegister(){app.innerHTML=`<div class="authPage"><div class="authCard"><div class="authLogo">${capsuleLogo('authCapsuleLogo')}</div><h1>Создать аккаунт</h1><p>После подтверждения e-mail новый профиль получит статус pending и будет ждать одобрения администратора.</p><form id="registerForm"><label>Имя<input id="registerName" required></label><label>E-mail<input type="email" id="registerEmail" required></label><label>Пароль<input type="password" id="registerPassword" minlength="8" required></label><button class="moduleButton" type="submit">Зарегистрироваться</button></form><div class="authLinks"><button data-route="#login">Уже есть аккаунт</button></div><div id="authMessage" class="authMessage"></div></div></div>`;bindNav();document.getElementById('registerForm').onsubmit=async e=>{e.preventDefault();try{await signUpWithPassword(document.getElementById('registerName').value,document.getElementById('registerEmail').value,document.getElementById('registerPassword').value);document.getElementById('authMessage').textContent='Проверь e-mail и подтверди регистрацию. После этого потребуется одобрение администратора.'}catch(err){showAuthError(err)}}}
function showAuthError(err){const x=document.getElementById('authMessage');if(x){x.textContent=err?.message||String(err);x.classList.add('error')}else toast(err?.message||String(err),'bad')}
function renderResetPassword(){app.innerHTML=`<div class="authPage"><div class="authCard"><div class="authLogo">${capsuleLogo('authCapsuleLogo')}</div><h1>Новый пароль</h1><p>Установи новый пароль для текущей recovery-сессии.</p><form id="resetPasswordForm"><label>Новый пароль<input type="password" id="newPassword" minlength="8" required autocomplete="new-password"></label><label>Повтори пароль<input type="password" id="newPassword2" minlength="8" required autocomplete="new-password"></label><button class="moduleButton" type="submit">Сохранить пароль</button></form><div id="authMessage" class="authMessage"></div></div></div>`;document.getElementById('resetPasswordForm').onsubmit=async e=>{e.preventDefault();const a=document.getElementById('newPassword').value,b=document.getElementById('newPassword2').value;if(a!==b)return showAuthError(new Error('Пароли не совпадают'));try{await updatePassword(a);document.getElementById('authMessage').textContent='Пароль обновлён.';setTimeout(()=>{location.hash='#settings'},700)}catch(err){showAuthError(err)}}}
function renderAccessState(status){const map={pending:['Ожидается подтверждение','Аккаунт создан. Доступ к ProPharm ожидает одобрения администратора.'],blocked:['Доступ ограничен','Аккаунт заблокирован администратором.'],rejected:['Заявка отклонена','Администратор отклонил запрос на доступ.']},[title,text]=map[status]||['Доступ недоступен','Проверь статус аккаунта.'];app.innerHTML=`<div class="authPage"><div class="authCard"><div class="authLogo">${capsuleLogo('authCapsuleLogo')}</div><h1>${title}</h1><p>${text}</p><button class="moduleButton" id="refreshAccess">Обновить статус</button><button class="moduleButton secondary" id="accessLogout">Выйти</button></div></div>`;document.getElementById('refreshAccess').onclick=async()=>{await refreshProfile();router()};document.getElementById('accessLogout').onclick=async()=>{await signOut();router()}}
async function renderAdmin(){
 if(!isAdmin()){location.hash='#settings';return}
 app.innerHTML=header()+`<div class="page"><div class="paperTitle"><span class="handMini">Только владелец</span><h2>Администрирование</h2><p>Загружаю пользователей…</p></div></div>`+bottomNav('settings');bindNav();
 try{const users=await listUsersForAdmin();app.innerHTML=header()+`<div class="page"><div class="paperTitle"><span class="handMini">Только владелец</span><h2>Администрирование</h2><p>Новые аккаунты по умолчанию user + pending. Назначение второго admin через UI отсутствует.</p></div><div class="adminSummary"><span class="badge blue">${users.length} пользователей</span><span class="badge">${users.filter(u=>u.status==='pending').length} ожидают</span></div><div class="list">${users.map(u=>`<div class="card adminUser"><div><div class="resultType">${esc(u.provider||'email')} · ${esc(u.role)}</div><h3>${esc(u.name||u.email||u.user_id)}</h3><p>${esc(u.email||'')}</p><div class="chips"><span class="chip">${esc(u.status)}</span><span class="smallMuted">${esc((u.created_at||'').slice(0,10))}</span></div></div>${u.role==='admin'?`<span class="badge">bootstrap admin</span>`:`<div class="adminActions"><button data-admin-status="approved" data-user-id="${esc(u.user_id)}">Одобрить</button><button data-admin-status="rejected" data-user-id="${esc(u.user_id)}">Отклонить</button><button data-admin-status="blocked" data-user-id="${esc(u.user_id)}">Блокировать</button><button data-admin-status="pending" data-user-id="${esc(u.user_id)}">В pending</button></div>`}</div>`).join('')}</div></div>`+bottomNav('settings');bindNav();document.querySelectorAll('[data-admin-status]').forEach(b=>b.addEventListener('click',async()=>{try{await adminSetStatus(b.dataset.userId,b.dataset.adminStatus);toast('Статус обновлён');renderAdmin()}catch(e){toast(e.message||String(e),'bad')}}))}catch(e){app.innerHTML=header()+`<div class="page"><div class="emptyState"><b>Не удалось загрузить пользователей</b><p>${esc(e.message||String(e))}</p></div></div>`+bottomNav('settings');bindNav()}
}


const CARDIO_SECTION_ORDER=[
 ['abbr','Аббревиатуры и обозначения','Словарь сокращений, белков, ферментов, каналов, транспортёров и соединений.'],
 ['physiology','Анатомия и физиология','Анатомия сердца, кровоток, проводящая система, сердечный цикл и гемодинамика.'],
 ['biochemistry','Биохимия и клеточные процессы','Рецепторы, вторичные посредники, ионные токи, Ca²⁺-handling и нейрогуморальные каскады.'],
 ['pathophysiology','Патофизиология','Перечень патологий: формирование → изменения → диагностика → фармакотерапия.'],
 ['diseases','Заболевания','Клиническая навигация по тем же патофизиологическим сущностям.'],
 ['targets','Фармакологические мишени','Мишень → процесс → связанные препараты → ожидаемый эффект.'],
 ['drugs','Препараты','Препараты ССС из глобальной базы 170. Взаимодействия — внутри карточки каждого препарата.'],
 ['diagnostics','Диагностика / ЭКГ / лаборатория','ЭКГ, объёмы и EF, электролиты, troponin, BNP/NT-proBNP.'],
 ['cards','Карточки','Карточки из анатомии, физиологии, биохимии, патофизиологии, мишеней и диагностики.'],
 ['tests','Тесты','Существующие экзаменационные вопросы + созданные учебные вопросы по материалу ССС.'],
 ['analysis','Разбор тестов','Почему правильный вариант верен, почему остальные неверны и с каким механизмом это связано.']
];
function systemSectionOrder(system){return system?.id==='cardiovascular'?CARDIO_SECTION_ORDER:SYSTEM_SECTION_ORDER;}
function cardioSectionMeta(key){return CARDIO_SECTION_ORDER.find(x=>x[0]===key)||systemSectionMeta(key);}
function cardioArrow(x1,y1,x2,y2){return `<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" marker-end="url(#cvArrow)"/>`;}
function cardioSvg(type,item={}){
 const defs=`<defs><marker id="cvArrow" markerWidth="8" markerHeight="8" refX="7" refY="3" orient="auto"><path d="M0,0 L0,6 L7,3 z" fill="currentColor" stroke="none"/></marker></defs>`;
 const wrap=(body,view='0 0 620 310')=>`<div class="cardioIllustration"><svg viewBox="${view}" role="img" aria-label="${esc(item.title||'Учебная схема')}">${defs}<g fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round">${body}</g></svg></div>`;
 const box=(x,y,w,h,t,sub='')=>`<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="16"/><text x="${x+w/2}" y="${y+h/2-(sub?7:0)}" text-anchor="middle" class="cvLabel">${esc(t)}</text>${sub?`<text x="${x+w/2}" y="${y+h/2+15}" text-anchor="middle" class="cvSub">${esc(sub)}</text>`:''}`;
 if(type==='heart-anatomy')return wrap(`<path d="M306 76c-47-54-130-18-130 57 0 89 130 139 130 139s130-50 130-139c0-75-83-111-130-57Z"/><path d="M306 79v180M180 143h252"/><text x="240" y="122" class="cvLabel">Правое предсердие</text><text x="370" y="122" class="cvLabel">Левое предсердие</text><text x="235" y="202" class="cvLabel">Правый желудочек</text><text x="372" y="202" class="cvLabel">Левый желудочек</text><path d="M108 80c35 5 49 22 68 50"/>${cardioArrow(110,80,170,126)}<text x="72" y="65" class="cvSub">полые вены</text><path d="M435 195c53-7 63-43 65-77"/>${cardioArrow(430,196,500,118)}<text x="510" y="102" class="cvSub">аорта</text><path d="M177 198c-38 8-55-10-69-39"/>${cardioArrow(176,198,108,159)}<text x="68" y="152" class="cvSub">лёгочная артерия</text><path d="M504 59c-43 0-51 25-69 59"/>${cardioArrow(505,59,436,116)}<text x="520" y="48" class="cvSub">лёгочные вены</text>`);
 if(type==='coronary')return wrap(`<path d="M308 64c-48-48-128-10-128 65 0 86 128 135 128 135s128-49 128-135c0-75-80-113-128-65Z"/><path d="M310 65c-4 45-7 92-8 177"/><path d="M312 87c-45 10-71 35-91 70"/><path d="M311 100c40 8 73 31 98 66"/><path d="M302 146c-40 14-56 44-62 76"/><path d="M305 154c36 12 59 36 70 70"/><text x="184" y="152" class="cvLabel">LAD</text><text x="414" y="158" class="cvLabel">RCA</text><text x="205" y="228" class="cvSub">субэндокард</text><path d="M70 77h92" marker-end="url(#cvArrow)"/><text x="53" y="59" class="cvSub">аорта</text><text x="80" y="290" class="cvLabel">Левая коронарная перфузия преимущественно в диастолу</text>`);
 if(type==='conduction')return wrap(`<path d="M305 63c-44-47-119-13-119 59 0 83 119 132 119 132s119-49 119-132c0-72-75-106-119-59Z"/><circle cx="245" cy="93" r="13"/><text x="213" y="73" class="cvLabel">SA</text><circle cx="292" cy="137" r="11"/><text x="258" y="135" class="cvLabel">AV</text>${cardioArrow(252,101,286,130)}<path d="M298 147v38M298 185l-39 51M298 185l39 51"/><path d="M258 236c-20 4-35 12-47 25M338 236c20 4 35 12 47 25"/><text x="319" y="173" class="cvSub">His</text><text x="187" y="279" class="cvSub">Purkinje</text><text x="386" y="279" class="cvSub">Purkinje</text>`);
 if(type==='cardiac-cycle')return wrap(`${box(18,105,105,68,'Наполнение','AV open')}${cardioArrow(123,139,150,139)}${box(150,105,105,68,'Atrial systole','EDV ↑')}${cardioArrow(255,139,282,139)}${box(282,105,105,68,'Iso contraction','all closed')}${cardioArrow(387,139,414,139)}${box(414,105,90,68,'Ejection','SV')}${cardioArrow(504,139,530,139)}${box(530,105,78,68,'Iso relax','all closed')}<path d="M568 184c-25 66-480 66-506 0" marker-end="url(#cvArrow)"/>`);
 if(type==='hemodynamics')return wrap(`${box(38,55,125,60,'Venous return','→ preload')}${cardioArrow(163,85,240,85)}${box(240,55,135,60,'EDV / contractility','→ SV')}${cardioArrow(375,85,455,85)}${box(455,55,125,60,'SV','EDV−ESV')}<text x="310" y="174" text-anchor="middle" class="cvFormula">CO = HR × SV</text><text x="310" y="218" text-anchor="middle" class="cvFormula">EF = SV / EDV × 100%</text><path d="M488 246h-356" marker-end="url(#cvArrow)"/><text x="310" y="275" text-anchor="middle" class="cvSub">SVR / afterload ↑  ← сосудистое сопротивление</text>`);
 if(type==='frank-starling')return wrap(`<path d="M80 250C160 238 211 201 266 154S390 72 545 62"/><path d="M82 250V42M82 250H560"/><text x="24" y="55" class="cvSub" transform="rotate(-90 24 55)">SV / сила</text><text x="438" y="284" class="cvSub">EDV / preload</text><circle cx="300" cy="130" r="8"/><text x="318" y="128" class="cvLabel">рабочая зона</text><path d="M338 188c72-5 131 12 190 46" stroke-dasharray="8 7"/><text x="407" y="218" class="cvSub">HF: кривая уплощена</text>`);
 if(type==='autonomic')return wrap(`${box(52,52,145,70,'β₁ receptor','Gs → cAMP ↑')}${cardioArrow(197,87,280,87)}${box(280,52,145,70,'SA / AV / muscle','HR, conduction, force ↑')}${box(52,194,145,70,'M₂ receptor','Gi → cAMP ↓')}${cardioArrow(197,229,280,229)}${box(280,194,145,70,'SA / AV','HR, conduction ↓')}<path d="M461 185v-55" marker-end="url(#cvArrow)"/><text x="480" y="158" class="cvSub">GIRK: K⁺ out</text>`);
 if(type==='ventricular-ap')return wrap(`<path d="M55 246L105 246L145 65L184 112L210 105L380 112L500 220L555 246"/><text x="130" y="48" class="cvLabel">0 · Na⁺</text><text x="181" y="91" class="cvLabel">1</text><text x="292" y="92" class="cvLabel">2 · Ca²⁺ plateau</text><text x="460" y="186" class="cvLabel">3 · K⁺</text><text x="60" y="272" class="cvLabel">4 · IK1</text><path d="M50 246V35M50 246H575"/>`);
 if(type==='nodal-ap')return wrap(`<path d="M55 245C113 235 150 201 184 154S236 64 275 54C325 66 348 128 375 182S439 241 560 244"/><path d="M55 245V35M55 245H575"/><text x="118" y="218" class="cvLabel">If / HCN</text><text x="213" y="108" class="cvLabel">Ca²⁺ upstroke</text><text x="410" y="218" class="cvLabel">K⁺ repolarization</text>`);
 if(type==='ecg')return wrap(`<path d="M32 168h63l20-28 19 28h46l12-8 16-96 20 176 18-72h58l23-42 25 42h66c14 0 18-12 28-23s18 23 30 23h88"/><text x="112" y="126" class="cvLabel">P</text><text x="209" y="47" class="cvLabel">QRS</text><text x="348" y="111" class="cvLabel">T</text><path d="M94 252h136M94 242v20M230 242v20"/><text x="146" y="286" class="cvSub">PR</text><path d="M178 215h230M178 205v20M408 205v20"/><text x="274" y="247" class="cvSub">QT</text>`);
 // v0.12: biochemical drawings use membrane/cell structures, not only flow boxes.
 if(type==='beta1')return wrap(`<path d="M28 80h564" stroke-dasharray="8 7"/><text x="34" y="58" class="cvSub">мембрана кардиомиоцита</text><path d="M92 55c-18 19-18 44 0 63 18-19 18-44 0-63Z"/><text x="92" y="138" text-anchor="middle" class="cvLabel">β₁</text><circle cx="166" cy="126" r="25"/><text x="166" y="131" text-anchor="middle" class="cvLabel">Gs</text>${cardioArrow(115,105,142,118)}<ellipse cx="246" cy="126" rx="38" ry="25"/><text x="246" y="131" text-anchor="middle" class="cvLabel">AC</text>${cardioArrow(191,126,207,126)}${cardioArrow(284,126,327,126)}<circle cx="358" cy="126" r="28"/><text x="358" y="131" text-anchor="middle" class="cvLabel">cAMP ↑</text>${cardioArrow(386,126,424,126)}<circle cx="463" cy="126" r="30"/><text x="463" y="131" text-anchor="middle" class="cvLabel">PKA</text><path d="M500 80v76M530 80v76"/><path d="M500 100h30M500 124h30M500 148h30"/><text x="515" y="176" text-anchor="middle" class="cvSub">Cav1.2</text>${cardioArrow(492,126,500,126)}<path d="M510 196v62" marker-end="url(#cvArrow)"/><text x="530" y="226" class="cvLabel">Ca²⁺ ↑</text><path d="M82 218h250" stroke-width="7"/><text x="84" y="205" class="cvSub">SR</text><circle cx="330" cy="218" r="15"/><text x="330" y="249" text-anchor="middle" class="cvSub">RyR2</text>${cardioArrow(495,232,347,220)}<text x="190" y="282" class="cvLabel">Ca²⁺ → TnC → сокращение ↑</text>`);
 if(type==='gq')return wrap(`<path d="M28 78h564" stroke-dasharray="8 7"/><text x="34" y="56" class="cvSub">мембрана гладкомышечной клетки</text><path d="M88 52c-18 18-18 44 0 62 18-18 18-44 0-62Z"/><text x="88" y="136" text-anchor="middle" class="cvLabel">α₁</text><circle cx="160" cy="126" r="24"/><text x="160" y="131" text-anchor="middle" class="cvLabel">Gq</text>${cardioArrow(113,104,138,118)}<ellipse cx="235" cy="126" rx="34" ry="24"/><text x="235" y="131" text-anchor="middle" class="cvLabel">PLC</text>${cardioArrow(184,126,201,126)}${cardioArrow(269,126,310,126)}<rect x="312" y="101" width="80" height="50" rx="15"/><text x="352" y="131" text-anchor="middle" class="cvLabel">PIP₂</text><path d="M392 126c34-33 59-41 91-45" marker-end="url(#cvArrow)"/><path d="M392 126c34 33 59 41 91 45" marker-end="url(#cvArrow)"/><text x="506" y="82" class="cvLabel">IP₃</text><text x="506" y="178" class="cvLabel">DAG → PKC</text><path d="M70 223h310" stroke-width="7"/><text x="72" y="209" class="cvSub">внутриклеточное депо Ca²⁺</text>${cardioArrow(500,94,371,214)}<text x="402" y="246" class="cvLabel">Ca²⁺ ↑</text>${cardioArrow(457,245,533,245)}<text x="545" y="250" class="cvLabel">сокращение ↑</text>`);
 if(type==='gi')return wrap(`<path d="M28 78h564" stroke-dasharray="8 7"/><text x="34" y="56" class="cvSub">мембрана SA/AV-клетки</text><path d="M88 52c-18 18-18 44 0 62 18-18 18-44 0-62Z"/><text x="88" y="136" text-anchor="middle" class="cvLabel">M₂</text><circle cx="163" cy="126" r="25"/><text x="163" y="131" text-anchor="middle" class="cvLabel">Gi</text>${cardioArrow(113,104,139,118)}<ellipse cx="250" cy="126" rx="39" ry="25"/><text x="250" y="131" text-anchor="middle" class="cvLabel">AC ↓</text>${cardioArrow(189,126,211,126)}${cardioArrow(289,126,335,126)}<circle cx="370" cy="126" r="31"/><text x="370" y="131" text-anchor="middle" class="cvLabel">cAMP ↓</text><path d="M450 80v80M480 80v80M450 106h30M450 134h30"/><text x="465" y="180" text-anchor="middle" class="cvSub">HCN / Ca²⁺</text>${cardioArrow(401,126,446,126)}<path d="M506 82c22 18 22 58 0 76M534 82c-22 18-22 58 0 76"/><text x="520" y="180" text-anchor="middle" class="cvSub">GIRK ↑</text><path d="M520 194v43" marker-end="url(#cvArrow)"/><text x="452" y="259" class="cvLabel">K⁺ out → гиперполяризация</text><text x="150" y="276" class="cvLabel">ЧСС / AV-проведение ↓</text>`);
 if(type==='ecc')return wrap(`<path d="M28 70h564" stroke-dasharray="8 7"/><text x="35" y="48" class="cvSub">сарколемма / T-трубочка</text><path d="M118 70v78M151 70v78M118 95h33M118 122h33"/><text x="135" y="168" text-anchor="middle" class="cvLabel">Cav1.2</text><path d="M135 18v42" marker-end="url(#cvArrow)"/><text x="153" y="42" class="cvLabel">AP</text><path d="M135 178v35" marker-end="url(#cvArrow)"/><text x="153" y="203" class="cvLabel">Ca²⁺ trigger</text><path d="M228 205h175" stroke-width="8"/><text x="230" y="190" class="cvSub">SR</text><circle cx="248" cy="205" r="16"/><text x="248" y="239" text-anchor="middle" class="cvLabel">RyR2</text>${cardioArrow(160,214,228,207)}<path d="M270 206c48 22 76 33 112 36" marker-end="url(#cvArrow)"/><text x="307" y="273" class="cvLabel">CICR · Ca²⁺ ↑</text><path d="M430 215h125M430 245h125"/><path d="M449 211l22 38M482 211l22 38M515 211l22 38"/><text x="493" y="287" text-anchor="middle" class="cvLabel">TnC → actin/myosin → contraction</text><path d="M345 202v-58" marker-end="url(#cvArrow)"/><text x="365" y="151" class="cvSub">SERCA2a → relaxation</text>`);
 if(type==='raas')return wrap(`${box(24,44,115,58,'Kidney','perfusion/NaCl ↓')}${cardioArrow(139,73,176,73)}${box(176,44,90,58,'Renin')}${cardioArrow(266,73,304,73)}${box(304,44,110,58,'Angiotensinogen','→ Ang I')}${cardioArrow(414,73,452,73)}${box(452,44,90,58,'ACE','→ Ang II')}<circle cx="510" cy="172" r="33"/><text x="510" y="177" text-anchor="middle" class="cvLabel">AT1</text>${cardioArrow(510,103,510,136)}<path d="M510 205c-50 25-99 39-148 45" marker-end="url(#cvArrow)"/><path d="M510 205c0 29 0 45 0 67" marker-end="url(#cvArrow)"/><path d="M510 205c45 25 70 38 92 54" marker-end="url(#cvArrow)"/><text x="255" y="266" class="cvLabel">вазоконстрикция</text><text x="465" y="296" class="cvLabel">aldosterone</text><text x="548" y="280" class="cvLabel">remodeling</text><text x="48" y="145" class="cvSub">Enalapril ⊣ ACE</text><text x="48" y="172" class="cvSub">Losartan ⊣ AT1</text><text x="48" y="199" class="cvSub">Spironolactone ⊣ MR</text>`);
 if(type==='no-cgmp')return wrap(`<path d="M42 70h536" stroke-dasharray="8 7"/><text x="46" y="48" class="cvSub">гладкомышечная клетка сосуда</text><circle cx="88" cy="124" r="29"/><text x="88" y="130" text-anchor="middle" class="cvLabel">NO</text>${cardioArrow(117,124,165,124)}<ellipse cx="215" cy="124" rx="45" ry="27"/><text x="215" y="130" text-anchor="middle" class="cvLabel">sGC</text>${cardioArrow(260,124,305,124)}<circle cx="345" cy="124" r="32"/><text x="345" y="130" text-anchor="middle" class="cvLabel">cGMP ↑</text>${cardioArrow(377,124,420,124)}<circle cx="458" cy="124" r="30"/><text x="458" y="130" text-anchor="middle" class="cvLabel">PKG</text>${cardioArrow(488,124,535,124)}<text x="538" y="115" class="cvLabel">Ca²⁺ ↓</text><text x="528" y="143" class="cvSub">relaxation</text><path d="M345 162v65" marker-end="url(#cvArrow)"/><text x="364" y="207" class="cvLabel">PDE5</text><text x="364" y="234" class="cvSub">cGMP breakdown</text><path d="M300 253h135"/><path d="M362 240l18 26M380 240l-18 26"/><text x="443" y="260" class="cvSub">Sildenafil ⊣ PDE5</text>`);
 if(type==='nak-ncx')return wrap(`<path d="M36 82h548" stroke-dasharray="8 7"/><text x="42" y="57" class="cvSub">мембрана кардиомиоцита</text><rect x="100" y="60" width="54" height="86" rx="18"/><text x="127" y="169" text-anchor="middle" class="cvLabel">Na⁺/K⁺ ATPase</text><path d="M127 38v21" marker-end="url(#cvArrow)"/><text x="144" y="43" class="cvSub">Na⁺ out</text><path d="M202 60h150"/><path d="M270 47l18 26M288 47l-18 26"/><text x="217" y="40" class="cvLabel">Digoxin ⊣</text><rect x="405" y="60" width="58" height="86" rx="18"/><text x="434" y="170" text-anchor="middle" class="cvLabel">NCX</text><path d="M434 38v21" marker-end="url(#cvArrow)"/><text x="453" y="43" class="cvSub">Ca²⁺ out ↓</text><text x="74" y="225" class="cvLabel">Na⁺ inside ↑ → Na⁺ gradient ↓</text>${cardioArrow(322,218,405,218)}<text x="425" y="224" class="cvLabel">Ca²⁺ inside/SR ↑</text><text x="248" y="276" class="cvFormula">сократимость ↑</text>`);
 if(type==='qt')return wrap(`<path d="M48 234L100 234L137 70L175 111L205 108L365 112L488 214L552 234"/><text x="404" y="144" class="cvLabel">Phase 3</text><path d="M420 77v80"/><text x="438" y="96" class="cvSub">IKr / hERG</text><path d="M466 72h78"/><path d="M500 59l18 26M518 59l-18 26"/><text x="465" y="48" class="cvSub">drug block</text><path d="M365 112C430 105 507 142 554 213" stroke-dasharray="9 7"/><text x="430" y="248" class="cvLabel">APD / QT ↑ → EAD → TdP</text>`);
 if(type==='qrs')return wrap(`<path d="M35 180h110l18-11 16-108 22 190 22-71h102"/><text x="160" y="42" class="cvLabel">QRS normal</text><path d="M335 180h55l18-8 24-104 55 182 36-70h62"/><text x="423" y="42" class="cvLabel">QRS widened</text><path d="M292 83h54"/><path d="M310 70l18 26M328 70l-18 26"/><text x="271" y="61" class="cvSub">Nav1.5 / INa block</text><text x="195" y="282" class="cvLabel">phase 0 slope ↓ → conduction velocity ↓</text>`);
 if(type==='electrolytes')return wrap(`${box(36,52,150,58,'K⁺','repolarization')}${box(235,52,150,58,'Ca²⁺','plateau / contraction')}${box(434,52,150,58,'Mg²⁺','electrical stability')}<path d="M110 133v60" marker-end="url(#cvArrow)"/><path d="M310 133v60" marker-end="url(#cvArrow)"/><path d="M510 133v60" marker-end="url(#cvArrow)"/><text x="55" y="218" class="cvSub">hypoK⁺ → U / TdP risk ↑</text><text x="252" y="218" class="cvSub">Ca²⁺ ↔ QT duration</text><text x="442" y="218" class="cvSub">hypoMg²⁺ → TdP risk ↑</text><path d="M55 258h510"/><text x="310" y="286" text-anchor="middle" class="cvLabel">электролиты меняют возбудимость и реполяризацию</text>`);
 if(type==='troponin')return wrap(`<path d="M72 205c0-70 40-126 94-126s94 56 94 126"/><path d="M100 178h132M110 199h112"/><text x="166" y="59" text-anchor="middle" class="cvLabel">кардиомиоцит</text><path d="M260 143c58-31 85-24 117 0" marker-end="url(#cvArrow)"/><text x="317" y="110" class="cvSub">injury</text><circle cx="420" cy="143" r="34"/><text x="420" y="149" text-anchor="middle" class="cvLabel">cTnI/T</text>${cardioArrow(454,143,528,143)}<path d="M525 104c34 0 48 20 48 39s-14 39-48 39"/><text x="520" y="205" class="cvSub">кровь</text><text x="310" y="267" text-anchor="middle" class="cvLabel">повышение = myocardial injury; причину определяет контекст</text>`);
 const processTypes=new Set(['beta1','gq','gi','ecc','raas','no-cgmp','nak-ncx','qt','qrs']);
 if(processTypes.has(type)){
   const steps=(item.steps||[]).slice(0,7);const w=Math.max(116,Math.floor(560/Math.min(steps.length,4)));let body='<path d="M22 72h576" stroke-dasharray="8 8"/><text x="30" y="52" class="cvSub">клеточная мембрана / сигнальный процесс</text>';steps.forEach((st,i)=>{const row=i<4?0:1,idx=row?i-4:i,count=row?Math.max(1,steps.length-4):Math.min(4,steps.length),gap=540/count,x=40+idx*gap,y=row?200:100;body+=box(x,y,Math.min(125,gap-18),60,String(i+1),String(st).replace(/→/g,'→').slice(0,27)+(String(st).length>27?'…':''));if(idx<count-1)body+=cardioArrow(x+Math.min(125,gap-18),y+30,x+gap-5,y+30)});return wrap(body);}
 if(type==='atherosclerosis')return wrap(`${box(34,100,95,60,'LDL','intima')}${cardioArrow(129,130,165,130)}${box(165,100,95,60,'oxidized LDL')}${cardioArrow(260,130,296,130)}${box(296,100,95,60,'macrophage')}${cardioArrow(391,130,427,130)}${box(427,100,82,60,'foam cell')}${cardioArrow(509,130,540,130)}${box(540,100,68,60,'plaque')}<text x="310" y="225" text-anchor="middle" class="cvSub">rupture → platelet/coagulation → thrombosis</text>`);
 if(type==='valve-stenosis'||type==='valve-regurg')return wrap(`${box(66,105,130,70,'Atrium / vessel')}${type==='valve-stenosis'?cardioArrow(196,140,276,140):cardioArrow(276,160,196,160)}${box(276,105,90,70,type==='valve-stenosis'?'narrow valve':'leaky valve')}${cardioArrow(366,140,446,140)}${box(446,105,130,70,'Ventricle / artery')}<text x="310" y="232" text-anchor="middle" class="cvSub">pressure / volume overload → remodeling</text>`);
 if(type==='shock')return wrap(`${box(40,90,140,70,'Primary defect')}${cardioArrow(180,125,245,125)}${box(245,90,130,70,'CO / SVR / preload')}${cardioArrow(375,125,440,125)}${box(440,90,140,70,'Tissue perfusion ↓')}<text x="310" y="220" text-anchor="middle" class="cvSub">compare pump failure · volume loss · vasodilation</text>`);
 if(type==='hf')return wrap(`${box(48,90,110,66,'CO ↓')}${cardioArrow(158,123,210,123)}${box(210,90,110,66,'SNS + RAAS')}${cardioArrow(320,123,372,123)}${box(372,90,110,66,'preload / afterload ↑')}${cardioArrow(482,123,520,123)}${box(520,90,80,66,'remodeling')}<path d="M558 166c-75 92-395 92-448 4" marker-end="url(#cvArrow)"/>`);
 const fallbackSteps=(item.formation||item.steps||item.points||[]).slice(0,6);
 if(fallbackSteps.length){let body='<text x="28" y="38" class="cvSub">механизм процесса</text>';fallbackSteps.forEach((st,i)=>{const row=i<3?0:1,idx=row?i-3:i,count=row?Math.max(1,fallbackSteps.length-3):Math.min(3,fallbackSteps.length),gap=560/count,x=30+idx*gap,y=row?190:70,w=Math.min(160,gap-20);body+=box(x,y,w,66,String(i+1),String(st).slice(0,31)+(String(st).length>31?'…':''));if(idx<count-1)body+=cardioArrow(x+w,y+33,x+gap-7,y+33);if(i===2&&fallbackSteps.length>3)body+=`<path d="M${x+w/2} ${y+66}v42" marker-end="url(#cvArrow)"/>`;});return wrap(body);}
 return wrap(`${box(45,110,145,70,'Норма')}${cardioArrow(190,145,260,145)}${box(260,110,145,70,'Нарушение')}${cardioArrow(405,145,475,145)}${box(475,110,105,70,'Следствие')}`);
}
function cardioBlockText(item){return [item.title,item.summary,...(item.points||[]),...(item.steps||[]),item.physiology,item.pathology,...(item.commentary||[])].filter(Boolean).join(' ');}
function renderVisualSources(area){const ids=VISUAL_SOURCE_GROUPS[area]||[];if(!ids.length)return '';return `<details class="sourceAccordion"><summary>Источники и научные референсы схемы</summary><div class="sourceAccordionBody">${ids.map(id=>{const x=VISUAL_SOURCES[id];return `<div class="visualSourceRow"><b>${esc(x.name)}</b><span>${esc(x.license)}</span><p>${esc(x.use)}</p><a href="${esc(x.url)}" target="_blank" rel="noopener noreferrer">Открыть источник ↗</a></div>`}).join('')}<p class="smallMuted">Текущие SVG ProPharm нарисованы внутри приложения как учебная адаптация; этот блок фиксирует научные/визуальные референсы и лицензионную политику для дальнейших схем.</p></div></details>`;}
function renderProcessCommentary(item){const rows=item.commentary||item.steps||[];return rows.length?`<div class="processComment"><h4>Что происходит на этой схеме</h4><ol>${rows.map(x=>`<li>${esc(x)}</li>`).join('')}</ol></div>`:'';}
function cardioDrugChips(ids=[],label='Связанные препараты'){return ids.length?`<div class="linkedDrugs"><b>${esc(label)}</b><div class="chips">${ids.map(id=>{const d=drugMap[String(id)];return d?`<button class="chip drugChip" data-route="#drug/${d.n}">${esc(d.name)}</button>`:''}).join('')}</div></div>`:'';}
function renderPathologyTherapy(p){const linked=cardioDrugChips(p.drugIds||[],'11. Фармакотерапия · препараты из базы ProPharm');return `<div class="therapyMap"><b>11. Фармакотерапия / лечебная стратегия</b>${linked||`<p>В экзаменационном списке 170 нет специфического препарата, который устраняет первичный дефект этой патологии. Основная стратегия: ${esc((p.targets||[]).join('; '))}.</p>`}<p><b>Логика:</b> ${esc(p.why||'')}</p></div>`;}
function renderCardioKnowledge(items,area){return `<div class="cardioKnowledge">${items.map(item=>`<article class="theoryCard cardioKnowledgeCard" id="cv-${esc(item.id)}"><h3>${esc(item.title)}</h3>${renderAbbreviationLead(cardioBlockText(item))}<p class="leadText">${esc(item.summary||item.definition||'')}</p>${item.points?.length?`<div class="theoryBody">${item.points.map(x=>`<p>• ${esc(x)}</p>`).join('')}</div>`:''}${cardioSvg(item.illustration,item)}${renderProcessCommentary(item)}${item.physiology?`<div class="dualExplain"><div><b>Связь с физиологией</b><p>${esc(item.physiology)}</p></div><div><b>Связь с патологией</b><p>${esc(item.pathology||'')}</p></div></div>`:''}${cardioDrugChips(item.drugIds||[])}${renderContextCards(item.cards||[],item.title)}${renderVisualSources(area)}</article>`).join('')}</div>${renderContextTests(area)}`;}
function renderContextCards(cards,title=''){if(!cards.length)return '';return `<div class="contextCards"><h4>Карточки по этому блоку</h4><div class="miniFlashGrid">${cards.map(c=>`<div class="miniFlash"><b>${esc(c[0])}</b><p>${esc(c[1])}</p></div>`).join('')}</div></div>`;}
function cardioTestSections(area){const map={physiology:['cardiac-basics','cardio-v012-physiology'],biochemistry:['cardio-v012-biochemistry'],pathophysiology:['heart-failure','hypertension','ihd-acs','antiarrhythmics','af','cardio-v012-pathophysiology'],diseases:['heart-failure','hypertension','ihd-acs','antiarrhythmics','af','cardio-v012-pathophysiology'],targets:['heart-failure','hypertension','antiarrhythmics','cardio-v012-targets'],diagnostics:['cardiac-basics','antiarrhythmics','af','cardio-v012-diagnostics']};return map[area]||[];}
function cardioTests(area){const set=new Set(cardioTestSections(area));return TESTS.filter(q=>set.has(q.sectionId));}
function renderContextTests(area){const qs=cardioTests(area);if(!qs.length)return '';return `<div class="contextStudy"><div><span class="handMini">Проверить себя</span><h3>Тесты по этому разделу</h3><p>${qs.length} вопросов: существующая экзаменационная база + новые учебные вопросы v0.12.</p></div><button class="moduleButton" data-start-test="cardio-section:${area}">Начать</button></div>`;}
function renderCardioPhysiology(){return renderCardioKnowledge(CARDIO_PHYSIOLOGY,'physiology');}
function renderCardioBiochemistry(){return `<div class="integratedIntro">Каждый биохимический процесс показан как рисунок + причинно-следственная схема + текстовый комментарий. Перед блоком автоматически раскрываются используемые белки, ферменты, каналы и сокращения.</div>${renderCardioKnowledge(CARDIO_BIOCHEMISTRY,'biochemistry')}`;}
function renderCardioPathologyCard(p,detail=false){const allText=[p.title,p.definition,p.normal,p.abnormal,...p.formation,p.biochem,...p.consequences,...p.clinical,...p.diagnostics,...p.targets,p.why].join(' ');return `<article class="theoryCard pathologyCard"><h3>${esc(p.title)}</h3>${renderAbbreviationLead(allText)}<div class="pathologyGrid"><div><b>1. Определение</b><p>${esc(p.definition)}</p></div><div><b>2. Что происходит в норме</b><p>${esc(p.normal)}</p></div><div><b>3. Что нарушается</b><p>${esc(p.abnormal)}</p></div><div class="wide"><b>4. Механизм формирования</b>${cardioSvg(p.illustration,p)}${renderProcessCommentary({...p,commentary:p.formation})}</div><div><b>5. Биохимические изменения</b><p>${esc(p.biochem)}</p></div><div><b>6. Физиологические последствия</b>${p.consequences.map(x=>`<p>• ${esc(x)}</p>`).join('')}</div><div><b>7. Клинические проявления</b>${p.clinical.map(x=>`<p>• ${esc(x)}</p>`).join('')}</div><div><b>8. Диагностика</b>${p.diagnostics.map(x=>`<p>• ${esc(x)}</p>`).join('')}</div><div><b>9. Фармакологические мишени</b>${p.targets.map(x=>`<span class="chip">${esc(x)}</span>`).join(' ')}</div><div><b>10. Почему работает фармакотерапия</b><p>${esc(p.why)}</p></div></div>${renderPathologyTherapy(p)}${renderContextCards(p.cards,p.title)}${renderVisualSources('pathophysiology')}${detail?renderContextTests('pathophysiology'):''}</article>`;}
function renderCardioPathophysiology(){return `<div class="integratedIntro">Патологии перечислены отдельными сущностями. Каждая: норма → нарушение → формирование → биохимические/физиологические изменения → симптомы → диагностика → мишени → фармакотерапия.</div><div class="pathologyIndex">${CARDIO_PATHOLOGIES.map(p=>`<button class="chip" data-route="#cardio-pathology/${p.id}">${esc(p.title)}</button>`).join('')}</div>${CARDIO_PATHOLOGIES.map(p=>renderCardioPathologyCard(p,false)).join('')}${renderContextTests('pathophysiology')}`;}
function renderCardioDiseases(){const cards=CARDIO_PATHOLOGIES.flatMap(p=>(p.cards||[]).slice(0,1));return `<div class="list">${CARDIO_PATHOLOGIES.map(p=>`<div class="card clickCard" data-route="#cardio-pathology/${p.id}"><h3>${esc(p.title)}</h3><p>${esc(p.definition)}</p><span class="badge blue">механизм + диагностика + фармакотерапия</span></div>`).join('')}</div><div class="sectionTitle"><h2>Карточки по заболеваниям</h2></div>${renderContextCards(cards,'Заболевания ССС')}${renderContextTests('diseases')}`;}
function renderCardioPathologyDetail(id){const p=CARDIO_PATHOLOGIES.find(x=>x.id===id);if(!p){location.hash='#system/cardiovascular/pathophysiology';return;}app.innerHTML=header()+`<div class="page"><div class="breadcrumb"><button data-route="#system/cardiovascular">ССС</button><span>›</span><button data-route="#system/cardiovascular/pathophysiology">Патофизиология</button><span>›</span><span>${esc(p.title)}</span></div>${renderCardioPathologyCard(p,true)}</div>`+bottomNav('study');bindNav();bindTestStarters();}
function renderCardioTargets(){return `<div class="list">${CARDIO_TARGETS.map(t=>`<div class="theoryCard"><h3>${esc(t.title)}</h3>${renderAbbreviationLead([t.title,t.mechanism,t.effect].join(' '))}${cardioSvg(['nav15'].includes(t.id)?'qrs':t.id==='ikr'?'qt':t.id==='beta1'?'beta1':t.id==='nocgmp'?'no-cgmp':'process',{title:t.title,steps:t.mechanism.split('→')})}${renderProcessCommentary({commentary:t.mechanism.split('→').map(x=>x.trim())})}<p><b>Фармакологический эффект:</b> ${esc(t.effect)}</p>${cardioDrugChips(t.drugIds)}${renderContextCards([[`Назови ключевой эффект воздействия на ${t.title}`,t.effect]],t.title)}${renderVisualSources('targets')}</div>`).join('')}</div>${renderContextTests('targets')}`;}
function renderCardioDiagnostics(){return renderCardioKnowledge(CARDIO_DIAGNOSTICS,'diagnostics');}
function renderCardioCards(){const groups=['physiology','biochemistry','pathophysiology','diagnostics','targets'];return `<div class="flashStats"><span class="badge blue">${CARDIO_FLASHCARDS.length} карточек ССС</span></div>${groups.map(area=>{const arr=CARDIO_FLASHCARDS.filter(c=>c.area===area);return `<div class="sectionTitle"><h2>${esc({physiology:'Анатомия и физиология',biochemistry:'Биохимия',pathophysiology:'Патофизиология',diagnostics:'Диагностика',targets:'Фармакологические мишени'}[area])}</h2></div><div class="miniFlashGrid">${arr.map(c=>`<details class="miniFlash"><summary>${esc(c.front)}</summary>${renderAbbreviationLead(c.front+' '+c.back)}<p>${esc(c.back)}</p></details>`).join('')}</div>`}).join('')}`;}

function systemIcon(s){return topicIcon(s?.iconSource||"cardio");}
function systemSourceTopics(system){return system?.sourceTopics||[];}
function systemDrugs(system){
 const topics=systemSourceTopics(system),extra=new Set(system?.extraDrugIds||[]);
 return DRUGS.filter(d=>d.topics?.some(t=>topics.includes(t))||extra.has(d.n));
}
function systemAbbreviations(system){
 const seen=new Set(),arr=[];
 const add=a=>{if(!a?.abbr)return;const k=a.abbr.toLowerCase();if(!seen.has(k)){seen.add(k);arr.push(a)}};
 systemSourceTopics(system).forEach(t=>(ABBREVIATIONS[t]||[]).forEach(add));
 if(system?.id==="cardiovascular")CARDIO_GLOSSARY.forEach(add);
 return arr;
}
function systemTheory(system){return systemSourceTopics(system).flatMap(t=>(THEORY[t]||[]).map(x=>({...x,topic:t})));}
function systemMechanisms(system){
 const out=[];systemSourceTopics(system).forEach(t=>(MECHANISMS[t]||[]).forEach((m,i)=>out.push({...m,topic:t,id:`${t}-m${i+1}`})));return out;
}
function systemDiseases(system){return DISEASES.filter(d=>d.systemId===system.id);}
function systemTests(system){const topics=systemSourceTopics(system);return TESTS.filter(q=>topics.includes(q.topic));}
function systemAnalyses(system){const qids=new Set(systemTests(system).map(q=>q.id));return TEST_ANALYSES.filter(a=>qids.has(a.questionId));}
function systemInteractions(system){
 const topics=systemSourceTopics(system),out=[];
 topics.forEach(t=>(INTERACTIONS[t]||[]).forEach(x=>out.push({...x,topic:t})));
 return out;
}
function systemTables(system){return systemSourceTopics(system).flatMap(t=>(STUDY_TABLES[t]||[]).map(x=>({...x,topic:t})));}
function systemHighYield(system){return systemSourceTopics(system).flatMap(t=>(HIGH_YIELD[t]||[]));}
function countSystemData(system){return {drugs:systemDrugs(system).length,abbr:systemAbbreviations(system).length,tests:systemTests(system).length,mechanisms:systemMechanisms(system).length,diseases:systemDiseases(system).length};}
function systemSectionMeta(key){return SYSTEM_SECTION_ORDER.find(x=>x[0]===key)||[key,key,""];}
function renderSystemsHub(){
 app.innerHTML=header()+`<div class="page"><div class="paperTitle"><span class="handMini">Интегрированное обучение</span><h2>Системы</h2><p>В каждой системе физиология, биохимия, патофизиология и фармакология связаны одной причинно-следственной цепочкой.</p></div><div class="topicGrid">${SYSTEMS.map(s=>{const c=countSystemData(s);return `<div class="card clickCard softPaper" data-route="#system/${s.id}"><div class="cardTopActions">${favoriteButton("system",s.id,"Сохранить")}</div><div class="cardHead"><div class="iconFrame topicLineIcon">${systemIcon(s)}</div><div><h3>${esc(s.title)}</h3><p>${esc(s.description)}</p><span class="badge">${c.drugs} препаратов</span><span class="badge blue">${c.tests} тестов</span></div></div></div>`}).join("")}</div></div>`+bottomNav("study");bindNav();
}
function renderSystem(systemId){
 const s=systemMap[systemId];if(!s){location.hash="#systems";return;}const c=countSystemData(s),order=systemSectionOrder(s);
 app.innerHTML=header()+`<div class="page"><div class="breadcrumb"><button data-route="#systems">Системы</button><span>›</span><span>${esc(s.short)}</span></div><div class="topicHeader"><div class="iconFrame topicLineIcon">${systemIcon(s)}</div><div><h2>${esc(s.title)}</h2><p>${esc(s.description)}</p></div></div><div class="causalRibbon"><span>Норма</span><b>→</b><span>Биохимия</span><b>→</b><span>Нарушение</span><b>→</b><span>Заболевание</span><b>→</b><span>Мишень</span><b>→</b><span>Препарат</span></div>${s.id==="cardiovascular"?`<div class="sourceNote">В ССС взаимодействия не вынесены в отдельный учебный раздел: они остаются внутри карточек препаратов. Отдельный High-yield раздел также удалён.</div>`:""}<div class="sectionGrid">${order.map(([key,title,desc])=>{let n="";if(key==="abbr")n=systemAbbreviations(s).length;if(key==="diseases"&&s.id==="cardiovascular")n=CARDIO_PATHOLOGIES.length;else if(key==="diseases")n=c.diseases;if(key==="targets"&&s.id==="cardiovascular")n=CARDIO_TARGETS.length;else if(key==="targets"||key==="biochemistry")n=c.mechanisms;if(key==="biochemistry"&&s.id==="cardiovascular")n=CARDIO_BIOCHEMISTRY.length;if(key==="physiology"&&s.id==="cardiovascular")n=CARDIO_PHYSIOLOGY.length;if(key==="drugs")n=c.drugs;if(key==="diagnostics"&&s.id==="cardiovascular")n=CARDIO_DIAGNOSTICS.length;if(key==="cards"&&s.id==="cardiovascular")n=CARDIO_FLASHCARDS.length;if(key==="tests"||key==="analysis")n=systemTests(s).length;return `<div class="card clickCard" data-route="#system/${s.id}/${key}"><div class="cardHead"><div class="iconFrame">${key==="abbr"?"Aa":key==="biochemistry"?"⇄":key==="drugs"?"Rx":key==="tests"?"?":key==="analysis"?"✓":key==="cards"?"▤":"→"}</div><div><h3>${esc(title)}</h3><p>${esc(desc)}</p>${n!==""?`<span class="badge blue">${n}</span>`:""}</div></div></div>`}).join("")}</div></div>`+bottomNav("study");bindNav();
}
function renderSystemTheoryCards(items){
 if(!items.length)return `<div class="emptyState"><b>В текущей базе отдельный материал для этого блока ещё не выделен.</b><p>Структура готова; данные будут появляться здесь без дублирования по мере расширения источников.</p></div>`;
 return `<div class="list">${items.map(x=>`<div class="theoryCard"><h3>${esc(x.title)}</h3>${renderAbbreviationLead([x.title,x.summary,...(x.body||[]),...(x.visual?.steps||[])].join(" "))}<p>${esc(x.summary||"")}</p>${x.body?.length?`<div class="theoryBody">${x.body.map(v=>`<p>• ${esc(v)}</p>`).join("")}</div>`:""}${x.type==="interactive"?`<a class="moduleButton" href="${x.url}">Открыть интерактивный модуль</a>`:""}${renderVisual(x.visual?{...x.visual,skipAbbr:true}:x.visual)}</div>`).join("")}</div>`;
}
function renderBiochemistry(system){
 const ms=systemMechanisms(system);if(!ms.length)return renderSystemTheoryCards([]);
 return `<div class="integratedIntro">Каждый механизм хранится как единая сущность и повторно используется в теории, препаратах, взаимодействиях и тестах.</div><div class="list">${ms.map(m=>`<div class="mechanismCard clickCard" data-route="#mechanism/${m.id}"><h3>${esc(m.title)}</h3>${renderAbbreviationLead([m.title,...(m.chain||[])].join(" "))}${renderVisual({title:m.title,kind:"process",steps:m.chain||[],skipAbbr:true})}<div class="chips">${(m.examples||[]).map(x=>`<span class="chip">${esc(x)}</span>`).join("")}</div></div>`).join("")}</div>`;
}
function renderPathophysiology(system){
 const ds=systemDiseases(system),theory=systemTheory(system).filter(x=>ds.some(d=>(d.theoryIds||[]).includes(x.id)));
 return `<div class="integratedIntro">Патофизиология здесь строится из уже имеющихся разборов заболеваний: нормальный механизм → его нарушение → клинический блок → точка приложения терапии.</div>${renderSystemTheoryCards(theory)}`;
}
function renderDiseaseCards(system){const ds=systemDiseases(system);if(!ds.length)return renderSystemTheoryCards([]);return `<div class="list">${ds.map(d=>{const cnt=TESTS.filter(q=>(d.sectionIds||[]).includes(q.sectionId)).length;return `<div class="card clickCard" data-route="#disease/${d.id}"><div class="cardTopActions">${favoriteButton("disease",d.id,"Сохранить")}</div><h3>${esc(d.title)}</h3><p>Связанные теоретические разборы, препараты, механизмы и тесты.</p><span class="badge blue">${cnt} вопросов</span></div>`}).join("")}</div>`;}
function renderSystemDiagnostics(system){
 const tables=systemTables(system);return `${system.diagnostics?.length?`<div class="list">${system.diagnostics.map(x=>`<div class="highYieldItem">${renderAbbreviationLead(x)}${esc(x)}</div>`).join("")}</div>`:""}${tables.length?`<div class="sectionTitle"><h2>Связанные таблицы</h2></div>${tables.map(tbl=>`<div class="studyTableCard"><h3>${esc(tbl.title)}</h3>${renderAbbreviationLead([tbl.title,...tbl.columns,...tbl.rows.flat(),tbl.note||""].join(" "))}<div class="tableScroll"><table><thead><tr>${tbl.columns.map(c=>`<th>${esc(c)}</th>`).join("")}</tr></thead><tbody>${tbl.rows.map(r=>`<tr>${r.map(c=>`<td>${esc(c)}</td>`).join("")}</tr>`).join("")}</tbody></table></div>${tbl.note?`<div class="tableNote">${esc(tbl.note)}</div>`:""}</div>`).join("")}`:""}${(!system.diagnostics?.length&&!tables.length)?renderSystemTheoryCards([]):""}`;
}
function renderSystemInteractions(system){const arr=systemInteractions(system);if(!arr.length)return renderSystemTheoryCards([]);return `<div class="list">${arr.map(x=>`<div class="interactionCard"><div class="resultType">${esc(x.type||"Взаимодействие")}</div><h3>${esc(x.title)}</h3>${renderAbbreviationLead([x.title,x.summary,...(x.chain||[])].join(" "))}<p>${esc(x.summary||"")}</p>${renderVisual({title:"Механизм взаимодействия",kind:"flow",steps:x.chain||[],skipAbbr:true})}</div>`).join("")}</div>`;}
function renderSystemTests(system,analysis=false){
 const q=systemTests(system);if(!q.length)return renderSystemTheoryCards([]);
 if(!analysis)return `<div class="card"><h3>Тест по системе</h3><p>${q.length} вопросов. История сохраняется в личном профиле.</p><button class="moduleButton" data-start-test="system:${system.id}">Начать тест</button></div><div class="sectionTitle"><h2>Клинические блоки</h2></div>${renderDiseaseCards(system)}`;
 const qids=new Set(q.map(x=>x.id));const arr=TEST_ANALYSES.filter(a=>qids.has(a.questionId));const qmap=Object.fromEntries(TESTS.map(x=>[x.id,x]));return `<div class="list">${arr.map(a=>{const x=qmap[a.questionId];if(!x)return "";const raw=[x.question,...(x.options||[]).map(o=>o.text),...(a.explanation||[]),...Object.values(a.optionExplanations||{})].join(" ");return `<div class="theoryCard">${renderAbbreviationLead(raw)}<div class="resultType">${esc(x.sectionTitle)} · вопрос ${x.number}</div><h3>${esc(x.question)}</h3><div class="answerReview"><b>Правильный ответ: ${esc(x.correct)}. ${esc(x.options.find(o=>o.id===x.correct)?.text||"")}</b></div>${(a.explanation||[]).map(z=>`<p>${esc(z)}</p>`).join("")}${x.options.map(o=>`<div class="reviewOption ${o.id===x.correct?"isCorrect":""}"><b>${o.id}. ${esc(o.text)}</b><div>${esc(a.optionExplanations?.[o.id]|| (o.id===x.correct?"Правильный вариант.":"Отдельный комментарий в источнике не сохранён."))}</div></div>`).join("")}${renderVisual(x.visual||a.visual||SECTION_VISUALS[x.sectionId])}</div>`}).join("")}</div>`;
}
function renderSystemSection(systemId,key){
 const s=systemMap[systemId];if(!s){location.hash="#systems";return;}const [,title]=(s.id==="cardiovascular"?cardioSectionMeta(key):systemSectionMeta(key));let content="";
 if(s.id==="cardiovascular"){
   if(key==="abbr"){const a=systemAbbreviations(s);content=`<div class="integratedIntro">Словарь ССС включает не только аббревиатуры, но и белки, ферменты, рецепторы, каналы, транспортёры, ионные токи и биохимические соединения.</div><div class="list">${a.map(abbrRow).join("")}</div>`}
   if(key==="physiology")content=renderCardioPhysiology();
   if(key==="biochemistry")content=renderCardioBiochemistry();
   if(key==="pathophysiology")content=renderCardioPathophysiology();
   if(key==="diseases")content=renderCardioDiseases();
   if(key==="targets")content=renderCardioTargets();
   if(key==="drugs"){const list=systemDrugs(s);content=`<div class="sourceNote">Лекарственные взаимодействия находятся внутри полной карточки каждого препарата, а не отдельным разделом ССС.</div><div class="toolbar"><input id="systemDrugSearch" placeholder="Поиск препарата…"><span class="badge blue">${list.length}</span></div><div id="systemDrugList">${drugRows(list)}</div>`}
   if(key==="diagnostics")content=renderCardioDiagnostics();
   if(key==="cards")content=renderCardioCards();
   if(key==="tests")content=`${renderContextTests("physiology")}${renderContextTests("biochemistry")}${renderContextTests("pathophysiology")}${renderContextTests("targets")}${renderContextTests("diagnostics")}<div class="sectionTitle"><h2>Весь тест по ССС</h2></div>${renderSystemTests(s,false)}`;
   if(key==="analysis")content=renderSystemTests(s,true);
   if(key==="interactions"||key==="high"){location.hash="#system/cardiovascular";return;}
 }else{
   if(key==="abbr"){const a=systemAbbreviations(s);content=a.length?`<div class="list">${a.map(abbrRow).join("")}</div>`:renderSystemTheoryCards([])}
   if(key==="physiology"){const items=systemTheory(s).filter(x=>/electrophysi|электрофизи|базов|кислотност|диабет/i.test((x.id||"")+" "+(x.title||"")+" "+(x.summary||"")));content=renderSystemTheoryCards(items)}
   if(key==="biochemistry")content=renderBiochemistry(s);
   if(key==="pathophysiology")content=renderPathophysiology(s);
   if(key==="diseases")content=renderDiseaseCards(s);
   if(key==="targets")content=renderBiochemistry(s);
   if(key==="drugs"){const list=systemDrugs(s);content=`<div class="toolbar"><input id="systemDrugSearch" placeholder="Поиск препарата…"><span class="badge blue">${list.length}</span></div><div id="systemDrugList">${drugRows(list)}</div>`}
   if(key==="interactions")content=renderSystemInteractions(s);
   if(key==="diagnostics")content=renderSystemDiagnostics(s);
   if(key==="high"){const arr=systemHighYield(s);content=arr.length?`<div class="list">${arr.map((x,i)=>`<div class="highYieldItem">${renderAbbreviationLead(x)}<b>${i+1}.</b> ${esc(x)}</div>`).join("")}</div>`:renderSystemTheoryCards([])}
   if(key==="tests")content=renderSystemTests(s,false);
   if(key==="analysis")content=renderSystemTests(s,true);
 }
 app.innerHTML=header()+`<div class="page"><div class="breadcrumb"><button data-route="#systems">Системы</button><span>›</span><button data-route="#system/${s.id}">${esc(s.short)}</button><span>›</span><span>${esc(title)}</span></div><div class="topicHeader"><div class="iconFrame topicLineIcon">${systemIcon(s)}</div><div><h2>${esc(title)}</h2><p>${esc(s.title)}</p></div></div>${content}</div>`+bottomNav("study");bindNav();bindTestStarters();
 if(key==="drugs"){const base=systemDrugs(s),inp=document.getElementById("systemDrugSearch"),out=document.getElementById("systemDrugList");inp?.addEventListener("input",()=>{const q=inp.value.toLowerCase();out.innerHTML=drugRows(base.filter(d=>drugSearchText(d).includes(q)));bindNav();})}
}
function allCanonicalMechanisms(){
 const base=SYSTEMS.flatMap(s=>systemMechanisms(s).map(m=>({...m,systemId:s.id})));
 const cv=CARDIO_BIOCHEMISTRY.map(m=>({id:`cv12-${m.id}`,title:m.title,chain:m.steps||[],examples:(m.drugIds||[]).map(id=>drugMap[String(id)]?.name).filter(Boolean),systemId:"cardiovascular",integrated:true,illustration:m.illustration,commentary:m.commentary}));
 return [...cv,...base.filter(m=>!cv.some(x=>x.title===m.title))];
}
function renderMechanismsHub(){const arr=allCanonicalMechanisms();app.innerHTML=header()+`<div class="page"><div class="paperTitle"><span class="handMini">Единые сущности</span><h2>Механизмы</h2><p>Один механизм используется повторно в физиологии, патологии, препаратах и тестах.</p></div><div class="list">${arr.map(m=>`<div class="mechanismCard clickCard" data-route="#mechanism/${m.id}"><div class="cardTopActions">${favoriteButton("mechanism",m.id,"Сохранить")}</div><div class="resultType">${esc(systemMap[m.systemId]?.short||"")}</div><h3>${esc(m.title)}</h3>${renderAbbreviationLead([m.title,...(m.chain||[])].join(" "))}<p>${esc((m.chain||[]).join(" → "))}</p></div>`).join("")}</div></div>`+bottomNav("study");bindNav();}
function renderMechanismDetail(id){const m=allCanonicalMechanisms().find(x=>x.id===id);if(!m){location.hash="#mechanisms";return;}const names=new Set((m.examples||[]).map(x=>String(x).split(" — ")[0].trim().toLowerCase()));const ds=DRUGS.filter(d=>names.has(d.name.toLowerCase()));const tests=TESTS.filter(q=>(q.drugIds||[]).some(n=>ds.some(d=>d.n===n))||systemMap[m.systemId]?.sourceTopics?.includes(q.topic));app.innerHTML=header()+`<div class="page"><div class="breadcrumb"><button data-route="#mechanisms">Механизмы</button><span>›</span><span>${esc(m.title)}</span></div><div class="paperTitle"><h2>${esc(m.title)}</h2><p>${esc(systemMap[m.systemId]?.title||"")}</p></div>${renderAbbreviationLead([m.title,...(m.chain||[])].join(" "))}${renderVisual({title:"Процесс",kind:"process",steps:m.chain||[],skipAbbr:true})}<div class="detailBox"><h3>Связанные препараты</h3>${ds.length?drugRows(ds):`<div class="chips">${(m.examples||[]).map(x=>`<span class="chip">${esc(x)}</span>`).join("")}</div>`}</div><div class="detailBox"><h3>Связанные тесты</h3><p>${tests.length} вопросов связаны через систему/препараты. Вопросы физически не копируются.</p><button class="moduleButton" data-route="#system/${m.systemId}/tests">Открыть тесты системы</button></div></div>`+bottomNav("study");bindNav();}
function renderDiseasesHub(){const legacy=DISEASES.filter(d=>d.systemId!=="cardiovascular");app.innerHTML=header()+`<div class="page"><div class="paperTitle"><span class="handMini">Клиническая навигация</span><h2>По заболеваниям</h2><p>Это альтернативный вход в те же связанные данные. Патологии ССС используют тот же интегрированный слой, что и раздел системы.</p></div><div class="list">${CARDIO_PATHOLOGIES.map(p=>`<div class="card clickCard" data-route="#cardio-pathology/${p.id}"><div class="cardTopActions">${favoriteButton("cardio-pathology",p.id,"Сохранить")}</div><div class="cardHead"><div class="iconFrame topicLineIcon">${systemIcon(systemMap.cardiovascular)}</div><div><h3>${esc(p.title)}</h3><p>Сердечно-сосудистая система</p><span class="badge blue">механизм + терапия + диагностика</span></div></div></div>`).join("")}${legacy.map(d=>{const s=systemMap[d.systemId],cnt=TESTS.filter(q=>(d.sectionIds||[]).includes(q.sectionId)).length;return `<div class="card clickCard" data-route="#disease/${d.id}"><div class="cardTopActions">${favoriteButton("disease",d.id,"Сохранить")}</div><div class="cardHead"><div class="iconFrame topicLineIcon">${systemIcon(s)}</div><div><h3>${esc(d.title)}</h3><p>${esc(s?.title||"")}</p><span class="badge blue">${cnt} тестов</span></div></div></div>`}).join("")}</div></div>`+bottomNav("study");bindNav();}
function renderDisease(id){const d=diseaseMap[id];if(!d){location.hash="#diseases";return;}const s=systemMap[d.systemId],theory=systemTheory(s).filter(x=>(d.theoryIds||[]).includes(x.id)),qs=TESTS.filter(q=>(d.sectionIds||[]).includes(q.sectionId)),drugIds=new Set(qs.flatMap(q=>q.drugIds||[])),drugs=DRUGS.filter(x=>drugIds.has(x.n));app.innerHTML=header()+`<div class="page"><div class="breadcrumb"><button data-route="#diseases">Заболевания</button><span>›</span><span>${esc(d.title)}</span></div><div class="topicHeader"><div class="iconFrame topicLineIcon">${systemIcon(s)}</div><div><h2>${esc(d.title)}</h2><p>${esc(s.title)}</p></div></div><div class="causalRibbon"><span>Норма</span><b>→</b><span>Нарушение</span><b>→</b><span>${esc(d.title)}</span><b>→</b><span>Мишени</span><b>→</b><span>Препараты</span></div><div class="sectionTitle"><h2>Теория и патофизиология</h2></div>${renderSystemTheoryCards(theory)}<div class="sectionTitle"><h2>Связанные препараты</h2></div>${drugs.length?drugRows(drugs):renderSystemTheoryCards([])}<div class="sectionTitle"><h2>Тесты</h2></div><div class="card"><p>${qs.length} вопросов из существующей базы.</p>${qs.length?`<button class="moduleButton" data-start-test="disease:${d.id}">Начать тест</button>`:""}</div></div>`+bottomNav("study");bindNav();bindTestStarters();}
function renderStudyHub(){const items=[["Системы","Главный интегрированный путь","#systems"],["Заболевания","Клинический вход в связанные материалы","#diseases"],["Механизмы","Рецепторы, каналы, ферменты и сигнальные пути","#mechanisms"],["Препараты","170 полных карточек","#drugs"],["Тесты","Интерактивная экзаменационная база","#tests"],["Схемы","Все визуальные процессы","#schemes"],["Таблицы","Сравнения и диагностические ориентиры","#tables"]];app.innerHTML=header()+`<div class="page"><div class="paperTitle"><span class="handMini">Навигация по знаниям</span><h2>Учёба</h2><p>Разные входы открывают одну и ту же связанную базу — без дублирования сущностей.</p></div><div class="sectionGrid">${items.map(([a,b,c])=>`<div class="card clickCard" data-route="${c}"><h3>${a}</h3><p>${b}</p></div>`).join("")}</div></div>`+bottomNav("study");bindNav();}
function renderInteractionsHub(){const systems=SYSTEMS.filter(s=>s.id!=="cardiovascular");app.innerHTML=header()+`<div class="page"><div class="paperTitle"><span class="handMini">Связи препаратов</span><h2>Взаимодействия</h2><p>В модуле ССС отдельного раздела взаимодействий больше нет: они показываются внутри карточек конкретных препаратов.</p></div><div class="sourceNote"><b>ССС:</b> открой «Препараты» → нужный препарат → «Лекарственные взаимодействия».</div><div class="topicGrid">${systems.map(s=>{const n=systemInteractions(s).length;return `<div class="card clickCard" data-route="#system/${s.id}/interactions"><div class="cardHead"><div class="iconFrame topicLineIcon">${systemIcon(s)}</div><div><h3>${esc(s.title)}</h3><p>${n} структурированных взаимодействий из текущей тестовой/теоретической базы</p></div></div></div>`}).join("")}</div></div>`+bottomNav("study");bindNav();}
function renderSystemAbbrHub(){app.innerHTML=header()+`<div class="page"><div class="paperTitle"><span class="handMini">Сначала расшифровка</span><h2>Аббревиатуры</h2><p>Словарь организован по новым системам.</p></div><div class="topicGrid">${SYSTEMS.map(s=>{const n=systemAbbreviations(s).length;return `<div class="card clickCard" data-route="#system/${s.id}/abbr"><div class="cardHead"><div class="iconFrame topicLineIcon">${systemIcon(s)}</div><div><h3>${esc(s.title)}</h3><p>${n} сокращений из текущего словаря</p></div></div></div>`}).join("")}</div></div>`+bottomNav("study");bindNav();}


let testSession=null;

function bindTestStarters(){
  document.querySelectorAll("[data-start-test]").forEach(b=>b.addEventListener("click",()=>startTestSession(b.dataset.startTest)));
}

function startTestSession(spec){
  let questions=[...TESTS];
  if(spec?.startsWith("topic:")) {
    const topicId=spec.slice("topic:".length);
    questions=questions.filter(q=>q.topic===topicId);
  }
  if(spec?.startsWith("section:")) {
    const sectionId=spec.slice("section:".length);
    questions=questions.filter(q=>q.sectionId===sectionId);
  }
  if(spec?.startsWith("system:")) {
    const systemId=spec.slice("system:".length),s=systemMap[systemId];
    questions=questions.filter(q=>s?.sourceTopics?.includes(q.topic));
  }
  if(spec?.startsWith("cardio-section:")) {
    const area=spec.slice("cardio-section:".length),sections=new Set(cardioTestSections(area));
    questions=questions.filter(q=>sections.has(q.sectionId));
  }
  if(spec?.startsWith("disease:")) {
    const diseaseId=spec.slice("disease:".length),d=diseaseMap[diseaseId];
    questions=questions.filter(q=>(d?.sectionIds||[]).includes(q.sectionId));
  }
  if(!questions.length){
    const knownSections=[...new Set(TESTS.map(q=>q.sectionId))].filter(Boolean);
    console.error("ProPharm: test selection returned 0 questions", {spec,total:TESTS.length,knownSections});
    alert(`Не удалось загрузить вопросы для этого блока. Всего в базе сейчас: ${TESTS.length}. Обнови страницу — если ошибка повторится, это проблема кэша.`);
    return;
  }
  testSession={
    id:`session-${Date.now()}-${Math.random().toString(36).slice(2)}`,spec:spec||"all",startedAt:new Date().toISOString(),
    questions, index:0, firstTryCorrect:0, retriedQuestions:0, extraWrongAttempts:0,
    currentWrong:[], errors:[], answered:0
  };
  if(location.hash==="#quiz") renderQuiz();
  else location.hash="#quiz";
}

function currentQuestion(){return testSession?.questions?.[testSession.index]}

function renderQuiz(){
  if(!testSession){location.hash="#tests";return;}
  if(!testSession.questions?.length){
    console.error("ProPharm: attempted to render an empty test session");
    testSession=null;
    location.hash="#tests";
    return;
  }
  if(testSession.index>=testSession.questions.length){renderQuizResults();return;}
  const q=currentQuestion();
  const progress=Math.round((testSession.index/testSession.questions.length)*100);
  app.innerHTML=header()+`<div class="page quizPage">
    <div class="quizTop"><button class="quizExit" id="quizExit">✕ Закрыть</button><div class="quizCount">${testSession.index+1} / ${testSession.questions.length}</div></div>
    <div class="progressTrack"><div class="progressFill" style="width:${progress}%"></div></div>
    <div class="card quizCard">
      <div class="resultType">${esc(q.sectionTitle)} · вопрос ${q.number}</div>
      ${renderAbbreviationLead([q.question,...q.options.map(o=>o.text)].join(" "))}
      <h2>${esc(q.question)}</h2>
      ${q.disputed?`<div class="sourceNote">⚠ В исходном материале этот вопрос отмечен как спорный/исправленный. После ответа покажу примечание.</div>`:""}
      <div class="quizOptions">${q.options.map(o=>`<button class="quizOption" data-option="${o.id}"><span class="optionLetter">${o.id}</span><span>${esc(o.text)}</span></button>`).join("")}</div>
      <div class="smallMuted" style="margin-top:10px">Если ошибёшься, получишь подсказку и сможешь отвечать снова до правильного варианта.</div>
    </div>
  </div>`;
  document.getElementById("quizExit").addEventListener("click",()=>{testSession=null;location.hash="#tests";});
  document.querySelectorAll(".quizOption").forEach(b=>b.addEventListener("click",()=>handleQuizAnswer(b.dataset.option,b)));
}

function handleQuizAnswer(optionId,button){
  const q=currentQuestion();
  if(!q||button.disabled)return;
  if(optionId===q.correct){
    button.classList.add("correctAnswer");
    document.querySelectorAll(".quizOption").forEach(x=>x.disabled=true);
    if(testSession.currentWrong.length===0)testSession.firstTryCorrect++;
    else testSession.retriedQuestions++;
    testSession.answered++;
    recordQuestionResult({question_id:q.id,system_id:q.topic||null,section_id:q.sectionId||null,correct:true,first_try:testSession.currentWrong.length===0,wrong_count:testSession.currentWrong.length}).catch(console.warn);
    if(testSession.currentWrong.length>=2)setReview("question",q.id,{reason:"repeated_wrong_answer",priority:3}).catch(console.warn);
    showExplanationModal(q);
  }else{
    button.classList.add("wrongAnswer"); button.disabled=true;
    testSession.currentWrong.push(optionId);
    testSession.extraWrongAttempts++;
    let err=testSession.errors.find(e=>e.questionId===q.id);
    if(!err){err={questionId:q.id,sectionTitle:q.sectionTitle,number:q.number,question:q.question,wrong:[],correct:q.correct,correctText:q.options.find(o=>o.id===q.correct)?.text||q.correctText};testSession.errors.push(err);}
    err.wrong.push({id:optionId,text:q.options.find(o=>o.id===optionId)?.text||""});
    showHintModal(q,optionId);
  }
}

function modalShell(inner){
  const el=document.createElement("div"); el.className="modalBackdrop"; el.innerHTML=`<div class="modalSheet">${inner}</div>`; document.body.appendChild(el); return el;
}

function showHintModal(q,optionId){
  const wrong=q.options.find(o=>o.id===optionId);
  const modal=modalShell(`<div class="modalHandle"></div><div class="modalIcon bad">✕</div><h2>Пока неверно</h2><p class="modalWrong"><b>${esc(optionId)}. ${esc(wrong?.text||"")}</b></p><div class="hintBox"><b>Подсказка</b><p>${esc(q.hint)}</p></div><button class="modalPrimary" id="hintClose">Попробовать ещё раз</button>`);
  modal.querySelector("#hintClose").addEventListener("click",()=>modal.remove());
}

function showExplanationModal(q){
  const main=q.explanation?.length?q.explanation.map(x=>`<p>${esc(x)}</p>`).join(""):`<p>Правильный ответ указан в исходном материале.</p>`;
  const opts=q.options.map(o=>{
    const isCorrect=o.id===q.correct;
    const exp=isCorrect?esc(q.optionExplanations?.[o.id]||q.explanation?.join(" ")||"Правильный вариант."):esc(q.optionExplanations?.[o.id]||"В исходном материале отдельный комментарий к этому варианту не сохранён.");
    return `<div class="explainOption ${isCorrect?"good":"badLine"}"><b>${o.id}. ${esc(o.text)}</b><div>${exp}</div></div>`;
  }).join("");
  const notes=q.sourceNotes?.length?`<div class="sourceNote">${q.sourceNotes.map(x=>`<div>⚠ ${esc(x)}</div>`).join("")}</div>`:"";
  const abbreviationBlock=renderAbbreviationLead([q.question,...q.options.map(o=>o.text),...(q.explanation||[]),...Object.values(q.optionExplanations||{})].join(" "));
  const modal=modalShell(`<div class="modalHandle"></div><div class="modalIcon good">✓</div><h2>Правильно</h2>${abbreviationBlock}<div class="correctBanner"><b>${esc(q.correct)}. ${esc(q.options.find(o=>o.id===q.correct)?.text||q.correctText||"")}</b></div><div class="explanationText">${main}</div><h3>Разбор всех вариантов</h3>${opts}${renderVisual(q.visual||SECTION_VISUALS[q.sectionId])}${notes}<div class="modalPersonalActions">${favoriteButton("question",q.id,"Избранное")}${reviewButton("question",q.id,"Повторить")}</div><button class="modalPrimary" id="nextQuestion">${testSession.index+1>=testSession.questions.length?"Показать результат":"Следующий вопрос"}</button>`);
  bindPersonalActions();
  modal.querySelector("#nextQuestion").addEventListener("click",()=>{
    modal.remove(); testSession.index++; testSession.currentWrong=[]; renderQuiz();
  });
}

function normText(s){return String(s||"").toLowerCase().replace(/[^a-zа-я0-9]+/g," ").trim()}

async function renderQuizResults(){
  const s=testSession;if(!s){location.hash="#tests";return;}
  const total=s.questions.length,score=total?Math.round(s.firstTryCorrect/total*100):0,completedAt=new Date().toISOString();
  const firstQ=s.questions[0]||{};
  const payload={id:s.id,test_id:s.spec,system_id:firstQ.topic||null,section_id:s.spec?.startsWith('section:')?s.spec.slice(8):(firstQ.sectionId||null),started_at:s.startedAt,completed_at:completedAt,questions_total:total,first_try_correct:s.firstTryCorrect,questions_with_retries:s.retriedQuestions,wrong_selections:s.extraWrongAttempts,score,duration_seconds:Math.max(0,Math.round((Date.parse(completedAt)-Date.parse(s.startedAt))/1000))};
  if(!s.saved){s.saved=true;saveTestSession(payload).then(()=>syncPending()).catch(console.warn)}
  app.innerHTML=header()+`<div class="page">
    <section class="hero"><h2>Результат сессии</h2><p>Результат сохранён в личной истории. При подключённом Supabase он синхронизируется между устройствами.</p>
      <div class="stats"><div class="stat"><b>${total}</b><span>вопросов</span></div><div class="stat"><b>${s.firstTryCorrect}</b><span>с 1-й попытки</span></div><div class="stat"><b>${s.retriedQuestions}</b><span>потребовалась ещё попытка</span></div><div class="stat"><b>${s.extraWrongAttempts}</b><span>неверных выборов</span></div></div>
    </section>
    <div class="sectionTitle"><h2>Где были ошибки</h2><span class="muted">${s.errors.length} вопросов</span></div>
    ${s.errors.length?`<div class="list">${s.errors.map(e=>`<div class="theoryCard"><div class="resultType">${esc(e.sectionTitle)} · вопрос ${e.number}</div><h3>${esc(e.question)}</h3><div class="errorChoices"><b>Неверные попытки:</b>${e.wrong.map(w=>`<div class="wrongMini">✕ ${esc(w.id)}. ${esc(w.text)}</div>`).join("")}</div><div class="rightMini">✓ Правильно: ${esc(e.correct)}. ${esc(e.correctText)}</div>${reviewButton('question',e.questionId,'Повторить')}</div>`).join("")}</div>`:`<div class="emptyState"><div class="big">🏆</div><b>Ни одной ошибки</b><p>Все вопросы были отвечены правильно с первой попытки.</p></div>`}
    <div class="quickStudy"><button class="moduleButton secondary" data-route="#my-study">Моя статистика</button><button class="moduleButton secondary" data-route="#review">Повторить слабое</button></div>
    <button class="moduleButton" id="closeResults">Закрыть результаты</button>
  </div>`;
  bindNav();
  document.getElementById("closeResults").addEventListener("click",()=>{testSession=null;location.hash="#tests";});
}

function routeNeedsGate(parts){return !['login','register'].includes(parts[0]);}
function router(){
  try{
    const h=(location.hash||"#home").slice(1),parts=h.split("/");
    if(isAuthConfigured()){
      if(authState.loading||!authState.initialized)return renderAuthLoading();
      if(!authState.session){if(parts[0]==='register')return renderRegister();return renderLogin();}
      if(parts[0]==='reset-password')return renderResetPassword();
      const status=authState.profile?.status;
      if(status&&status!=='approved')return renderAccessState(status);
      if(!authState.profile)return renderAuthLoading();
    }
    if(parts[0]==='login')return renderLogin();
    if(parts[0]==='register')return renderRegister();
    if(parts[0]==='reset-password')return renderResetPassword();
    if(parts[0]==="home"||!parts[0])renderHome();
    else if(parts[0]==="study")renderStudyHub();
    else if(parts[0]==="systems")renderSystemsHub();
    else if(parts[0]==="system"&&parts.length===2)renderSystem(parts[1]);
    else if(parts[0]==="system"&&parts.length>=3)renderSystemSection(parts[1],parts[2]);
    else if(parts[0]==="diseases")renderDiseasesHub();
    else if(parts[0]==="cardio-pathology")renderCardioPathologyDetail(parts[1]);
    else if(parts[0]==="disease")renderDisease(parts[1]);
    else if(parts[0]==="mechanisms")renderMechanismsHub();
    else if(parts[0]==="mechanism")renderMechanismDetail(parts[1]);
    else if(parts[0]==="interactions-hub")renderInteractionsHub();
    else if(parts[0]==="topics")renderSystemsHub();
    else if(parts[0]==="topic"&&parts.length===2)renderTopic(parts[1]);
    else if(parts[0]==="topic"&&parts.length>=3)renderTopicSection(parts[1],parts[2]);
    else if(parts[0]==="drugs")renderAllDrugs();
    else if(parts[0]==="drug")renderDrug(parts[1]);
    else if(parts[0]==="tests")renderTests();
    else if(parts[0]==="quiz")renderQuiz();
    else if(parts[0]==="search")renderSearch();
    else if(parts[0]==="theory-hub")renderSystemsHub();
    else if(parts[0]==="tables")renderTablesHub();
    else if(parts[0]==="schemes"&&parts.length===1)renderSchemesHub();
    else if(parts[0]==="schemes"&&parts.length>=2)renderSchemesTopic(parts[1]);
    else if(parts[0]==="cards")renderCardsHub();
    else if(parts[0]==="abbr-hub")renderAbbrHub();
    else if(parts[0]==="settings")renderSettingsHub();
    else if(parts[0]==="profile")renderProfile();
    else if(parts[0]==="my-study")renderMyStudy();
    else if(parts[0]==="favorites")renderFavorites();
    else if(parts[0]==="review")renderReview();
    else if(parts[0]==="admin")renderAdmin();
    else renderHome();
    if(!['login','register','quiz','admin','settings','profile','my-study','favorites','review'].includes(parts[0]))recordStudyPosition(inferProgressFromRoute(parts)).catch(()=>{});
  }catch(err){
    console.error("ProPharm render error",err);
    app.innerHTML=header()+`<div class="page"><div class="emptyState routeError"><div class="big">!</div><b>Не удалось открыть раздел</b><p>${esc(err?.message||String(err))}</p><button class="moduleButton" data-route="#home">Вернуться на главную</button></div></div>`+bottomNav("home");bindNav();
  }
}
async function restoreSyncedSettings(){const row=await loadUserSettings().catch(()=>null);if(row?.settings_json){uiSettings=Object.assign({},uiSettings,row.settings_json);localStorage.setItem(UI_SETTINGS_KEY,JSON.stringify(uiSettings));applyUiSettings()}}
async function syncPersonalState(){if(authState.profile?.status!=='approved')return;await syncPending();await hydrateFromCloud();await restoreSyncedSettings()}
async function boot(){
  onAuthState(()=>{if(authState.initialized){router();if(authState.profile?.status==='approved')syncPersonalState().catch(()=>{})}});
  window.addEventListener("hashchange",router);
  window.addEventListener("online",()=>syncPersonalState().catch(()=>{}));
  await initAuth();
  if(authState.profile?.status==='approved')await syncPersonalState().catch(()=>{});else await restoreSyncedSettings().catch(()=>{});
  router();
}
boot();
