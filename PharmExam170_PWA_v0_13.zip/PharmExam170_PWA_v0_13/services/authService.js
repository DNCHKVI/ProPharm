import { SUPABASE_CONFIG } from "../config/supabase-config.js?v=0.13.0";

const PROFILE_CACHE_KEY="propharm_profile_cache_v1";
const SDK_URL="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.115.0/+esm";
const listeners=new Set();
let supabase=null;

export const authState={
  initialized:false,loading:true,configured:false,session:null,user:null,profile:null,error:null,offlineFallback:false
};

function emit(){for(const fn of listeners){try{fn({...authState})}catch(e){console.error(e)}}}
export function onAuthState(fn){listeners.add(fn);return()=>listeners.delete(fn)}
export function isAuthConfigured(){return !!(SUPABASE_CONFIG.enabled&&SUPABASE_CONFIG.url&&SUPABASE_CONFIG.publishableKey)}
export function getSupabase(){return supabase}
export function currentUserId(){return authState.user?.id||(isAuthConfigured()?null:"local-preview")}
export function isApproved(){return !isAuthConfigured()||authState.profile?.status==="approved"}
export function isAdmin(){return authState.profile?.role==="admin"&&authState.profile?.status==="approved"}

function cachedProfile(userId){
  try{const x=JSON.parse(localStorage.getItem(PROFILE_CACHE_KEY)||"null");return x?.user_id===userId?x:null}catch{return null}
}
function saveCachedProfile(p){if(p?.user_id)localStorage.setItem(PROFILE_CACHE_KEY,JSON.stringify(p))}

export async function refreshProfile(){
  if(!supabase||!authState.user)return null;
  try{
    const {data,error}=await supabase.from("profiles").select("user_id,name,email,avatar_url,provider,role,status,created_at,last_login,updated_at").eq("user_id",authState.user.id).maybeSingle();
    if(error)throw error;
    if(data){authState.profile=data;authState.offlineFallback=false;saveCachedProfile(data)}
    else authState.profile=cachedProfile(authState.user.id);
  }catch(err){
    const cached=cachedProfile(authState.user.id);
    if(cached){authState.profile=cached;authState.offlineFallback=true}else authState.error=err;
  }
  emit();return authState.profile;
}

export async function initAuth(){
  authState.loading=true;authState.configured=isAuthConfigured();emit();
  if(!authState.configured){authState.initialized=true;authState.loading=false;authState.profile={user_id:"local-preview",name:"Локальный режим",role:"local",status:"approved",provider:"local"};emit();return authState;}
  try{
    const {createClient}=await import(SDK_URL);
    supabase=createClient(SUPABASE_CONFIG.url,SUPABASE_CONFIG.publishableKey,{auth:{persistSession:true,autoRefreshToken:true,detectSessionInUrl:true,flowType:"pkce"}});
    const {data,error}=await supabase.auth.getSession();if(error)throw error;
    authState.session=data.session||null;authState.user=data.session?.user||null;
    if(authState.user)await refreshProfile();
    supabase.auth.onAuthStateChange((_event,session)=>{
      authState.session=session||null;authState.user=session?.user||null;authState.error=null;
      if(authState.user) setTimeout(()=>refreshProfile(),0); else {authState.profile=null;emit()}
    });
  }catch(err){authState.error=err;console.error("ProPharm auth init",err)}
  authState.initialized=true;authState.loading=false;emit();return authState;
}

export async function signInWithPassword(email,password){
  if(!supabase)throw new Error("Supabase не настроен");
  const {data,error}=await supabase.auth.signInWithPassword({email,password});if(error)throw error;return data;
}
export async function signUpWithPassword(name,email,password){
  if(!supabase)throw new Error("Supabase не настроен");
  const {data,error}=await supabase.auth.signUp({email,password,options:{data:{full_name:name||""},emailRedirectTo:oauthRedirectUrl()}});if(error)throw error;return data;
}
export async function signInWithOAuth(provider){
  if(!supabase)throw new Error("Supabase не настроен");
  if(!["google","apple"].includes(provider))throw new Error("Неподдерживаемый OAuth provider");
  const {data,error}=await supabase.auth.signInWithOAuth({provider,options:{redirectTo:oauthRedirectUrl()}});if(error)throw error;return data;
}
export async function linkIdentity(provider){
  if(!supabase||!authState.user)throw new Error("Сначала войдите в аккаунт");
  const {data,error}=await supabase.auth.linkIdentity({provider,options:{redirectTo:oauthRedirectUrl()}});if(error)throw error;return data;
}
export async function resetPassword(email){
  if(!supabase)throw new Error("Supabase не настроен");
  const {data,error}=await supabase.auth.resetPasswordForEmail(email,{redirectTo:`${oauthRedirectUrl()}#reset-password`});if(error)throw error;return data;
}
export async function updatePassword(password){
  if(!supabase||!authState.session)throw new Error("Нет активной recovery-сессии");
  if(String(password||"").length<8)throw new Error("Пароль должен содержать не менее 8 символов");
  const {data,error}=await supabase.auth.updateUser({password});if(error)throw error;return data;
}
export async function signOut(){if(supabase)await supabase.auth.signOut();authState.session=null;authState.user=null;authState.profile=null;emit()}
export async function updateOwnProfile(patch){
  if(!supabase||!authState.user)throw new Error("Нет активного аккаунта");
  const safe={};if(typeof patch.name==="string")safe.name=patch.name.trim().slice(0,120);if(typeof patch.avatar_url==="string")safe.avatar_url=patch.avatar_url.trim().slice(0,1000);safe.updated_at=new Date().toISOString();
  const {data,error}=await supabase.from("profiles").update(safe).eq("user_id",authState.user.id).select().single();if(error)throw error;authState.profile=data;saveCachedProfile(data);emit();return data;
}
export async function listUsersForAdmin(){
  if(!supabase||!isAdmin())throw new Error("Недостаточно прав");
  const {data,error}=await supabase.from("profiles").select("user_id,name,email,provider,role,status,created_at,last_login").order("created_at",{ascending:false});if(error)throw error;return data||[];
}
export async function adminSetStatus(targetUserId,status){
  if(!supabase||!isAdmin())throw new Error("Недостаточно прав");
  if(!["pending","approved","blocked","rejected"].includes(status))throw new Error("Недопустимый статус");
  const {data,error}=await supabase.rpc("admin_set_user_status",{target_user_id:targetUserId,new_status:status});if(error)throw error;return data;
}
export function oauthRedirectUrl(){
  if(SUPABASE_CONFIG.siteUrl)return new URL(SUPABASE_CONFIG.siteUrl).href;
  return `${location.origin}${location.pathname}`;
}
