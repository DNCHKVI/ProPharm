import fs from 'node:fs';
import crypto from 'node:crypto';
import zlib from 'node:zlib';
const key=process.env.PROPHARM_PACKAGE_KEY||'';
if(!/^[a-f0-9]{64}$/i.test(key))throw Error('Add PROPHARM_PACKAGE_KEY in GitHub Actions secrets');
const raw=fs.readFileSync('release/content.enc');
const decipher=crypto.createDecipheriv('aes-256-gcm',Buffer.from(key,'hex'),raw.subarray(0,12));
decipher.setAuthTag(raw.subarray(12,28));
const content=JSON.parse(zlib.gunzipSync(Buffer.concat([decipher.update(raw.subarray(28)),decipher.final()])));
const manifest=JSON.parse(fs.readFileSync('release/site/asset-manifest.json'));
if(content.build!==manifest.build)throw Error('Client and content build mismatch');
for(const entry of manifest.files){
 if(entry.file.includes('..')||entry.file.startsWith('/'))throw Error('Invalid public path');
 const bytes=fs.readFileSync('release/site/'+entry.file);
 if(crypto.createHash('sha256').update(bytes).digest('hex')!==entry.sha256)throw Error('Public file checksum mismatch');
}
if(process.env.VERIFY_ONLY==='1'){console.log('Package verified: '+content.build);process.exit(0);}
const secret=process.env.PROPHARM_SERVICE_ROLE_KEY;
if(!secret)throw Error('Add PROPHARM_SERVICE_ROLE_KEY in GitHub Actions secrets');
const headers={apikey:secret,'Content-Type':'application/json'};
if(!secret.startsWith('sb_secret_'))headers.Authorization='Bearer '+secret;
const base='https://jrdpjatspvatpqongcon.supabase.co/rest/v1/content_bundles';
// Import one bundle at a time to reduce database work per request.
const rows=Object.entries(content.bundles).map(([bundle_id,payload])=>({build_id:content.build,bundle_id,payload}));
async function request(url,options,label){
 for(let attempt=0;attempt<3;attempt++){
  let r;
  try{r=await fetch(url,{...options,signal:AbortSignal.timeout(90000)});}
  catch{if(attempt===2)throw Error(label+': network error');}
  if(r?.ok)return r;
  let code='unknown';if(r){try{const body=await r.json();if(/^[A-Z0-9_]{1,32}$/.test(body.code))code=body.code;}catch{}}
  if(r&&(![429,500,502,503,504].includes(r.status)||attempt===2))throw Error(label+': HTTP '+r.status+', database code '+code+'. Site publication stopped.');
  console.log(label+': temporary failure; retry '+(attempt+1));
  await new Promise(resolve=>setTimeout(resolve,2000*(attempt+1)));
 }
}
const canonical=v=>Array.isArray(v)?v.map(canonical):v&&typeof v==='object'?Object.fromEntries(Object.keys(v).sort().map(k=>[k,canonical(v[k])])):v;
for(const row of rows){
 await request(base+'?on_conflict=build_id,bundle_id',{method:'POST',headers:{...headers,Prefer:'resolution=merge-duplicates'},body:JSON.stringify([row])},'Import '+row.bundle_id);
 const r=await request(base+'?build_id=eq.'+encodeURIComponent(content.build)+'&bundle_id=eq.'+encodeURIComponent(row.bundle_id)+'&select=bundle_id,payload',{headers},'Verify '+row.bundle_id);
 const saved=await r.json();
 if(saved.length!==1||JSON.stringify(canonical(row.payload))!==JSON.stringify(canonical(saved[0].payload)))throw Error('Saved content differs: '+row.bundle_id);
 console.log('Verified '+row.bundle_id);
}
console.log('Content imported and verified: '+content.build);
