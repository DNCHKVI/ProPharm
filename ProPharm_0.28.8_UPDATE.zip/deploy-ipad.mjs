import fs from 'node:fs';
import crypto from 'node:crypto';
import zlib from 'node:zlib';
const key=process.env.PROPHARM_PACKAGE_KEY||'';
if(!/^[a-f0-9]{64}$/i.test(key))throw Error('Add PROPHARM_PACKAGE_KEY in GitHub Actions secrets');
const raw=fs.readFileSync('release/content.enc');
const decipher=crypto.createDecipheriv('aes-256-gcm',Buffer.from(key,'hex'),raw.subarray(0,12));
decipher.setAuthTag(raw.subarray(12,28));
const content=JSON.parse(zlib.gunzipSync(Buffer.concat([decipher.update(raw.subarray(28)),decipher.final()])));
const manifest=JSON.parse(fs.readFileSync('release/site/asset-manifest.json'));
if(content.build!==manifest.build)throw Error('Client and content build mismatch');
for(const entry of manifest.files){
 if(entry.file.includes('..')||entry.file.startsWith('/'))throw Error('Invalid public path');
 const bytes=fs.readFileSync('release/site/'+entry.file);
 if(crypto.createHash('sha256').update(bytes).digest('hex')!==entry.sha256)throw Error('Public file checksum mismatch');
}
if(process.env.VERIFY_ONLY==='1'){console.log('Package verified: '+content.build);process.exit(0);}
const secret=process.env.PROPHARM_SERVICE_ROLE_KEY;
if(!secret)throw Error('Add PROPHARM_SERVICE_ROLE_KEY in GitHub Actions secrets');
const headers={apikey:secret,'Content-Type':'application/json'};
if(!secret.startsWith('sb_secret_'))headers.Authorization='Bearer '+secret;
const base='https://jrdpjatspvatpqongcon.supabase.co/rest/v1/content_bundles';
// Upsert all bundles in one database request; never modify profiles or passwords.
const rows=Object.entries(content.bundles).map(([bundle_id,payload])=>({build_id:content.build,bundle_id,payload}));
let r=await fetch(base+'?on_conflict=build_id,bundle_id',{method:'POST',headers:{...headers,Prefer:'resolution=merge-duplicates'},body:JSON.stringify(rows),signal:AbortSignal.timeout(180000)});
if(!r.ok)throw Error('Content import failed (HTTP '+r.status+'). Existing site has not been replaced.');
// Fetch back and compare payloads before allowing the public deployment.
r=await fetch(base+'?build_id=eq.'+encodeURIComponent(content.build)+'&select=bundle_id,payload',{headers,signal:AbortSignal.timeout(180000)});
if(!r.ok)throw Error('Content verification failed (HTTP '+r.status+')');
const saved=await r.json();
const canonical=v=>Array.isArray(v)?v.map(canonical):v&&typeof v==='object'?Object.fromEntries(Object.keys(v).sort().map(k=>[k,canonical(v[k])])):v;
if(saved.length!==rows.length||rows.some(row=>JSON.stringify(canonical(row.payload))!==JSON.stringify(canonical(saved.find(x=>x.bundle_id===row.bundle_id)?.payload))))throw Error('Saved content differs from release');
console.log('Content imported and verified: '+content.build);
