import { boot } from './src/core/bootstrap.js';
boot().catch(error=>{console.error(error);const app=document.getElementById('app');app.textContent='Не удалось запустить ProPharm. Обновите страницу.';});
