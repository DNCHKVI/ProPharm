import { SUPABASE_CONFIG } from "../config/supabase-config.js";

const PROFILE_CACHE_KEY="propharm_profile_cache_v3";
const SDK_URL="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.115.0/+esm";
const listeners=new Set();
let supabase=null;
const PROFILE_TIMEOUT_MS=10000;
const PROFILE_RETRY_DELAYS=[0,300,800,1600,3000];
let authEpoch=0;
let authEventQueue=Promise.resolve();
let lastHydratedSessionKey="";

// Authorization comes only from the server profile. No client UUID exceptions.
function serverProfile(profile){return profile;}

function sleep(ms){return new Promise(resolve=>setTimeout(resolve,ms))}
function withTimeout(promise,ms,message){
  let timer;
  return Promise.race([
    Promise.resolve(promise),
    new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Error(message)),ms)})
  ]).finally(()=>clearTimeout(timer));
}

export const authState={
  initialized:false,loading:true,profileLoading:false,configured:false,
  session:null,user:null,profile:null,error:null,offlineFallback:false,
  profileSource:null
};

function emit(){for(const fn of listeners){try{fn({...authState})}catch(e){console.error(e)}}}
export function onAuthState(fn){listeners.add(fn);return()=>listeners.delete(fn)}
export function isAuthConfigured(){return !!(SUPABASE_CONFIG.enabled&&SUPABASE_CONFIG.url&&SUPABASE_CONFIG.publishableKey)}
export function getSupabase(){return supabase}
export function currentUserId(){return authState.user?.id||null}
export function isApproved(){return !!(authState.user&&authState.profile?.status==="approved")}
export function isAdmin(){return authState.profile?.role==="admin"&&authState.profile?.status==="approved"}

function cachedProfile(userId){
  try{const x=JSON.parse(localStorage.getItem(PROFILE_CACHE_KEY)||"null");return x?.user_id===userId?x:null}catch{return null}
}
function saveCachedProfile(p){if(p?.user_id)localStorage.setItem(PROFILE_CACHE_KEY,JSON.stringify({...p,last_verified_at:new Date().toISOString()}))}
function mayKeepProfileOnNetworkError(error,userId){
 const p=cachedProfile(userId),age=Date.now()-Date.parse(p?.last_verified_at||'');
 const status=Number(error?.status||0),text=String(error?.message||error||'');
 return authState.profile?.user_id===userId&&authState.profile.status==='approved'&&age>=0&&age<300000&&(status>=500||/fetch|network|timeout|не ответил|сеть/i.test(text));
}
function cachedProfileIsUsable(p){
  p=serverProfile(p);
  if(!p?.user_id||p.status!=="approved"||!p.last_verified_at)return false;
  const age=Date.now()-Date.parse(p.last_verified_at);
  return Number.isFinite(age)&&age>=0&&age<=7*24*60*60*1000;
}
function clearProfileState({clearCache=false}={}){
  authState.profile=null;
  authState.profileLoading=false;
  authState.profileSource=null;
  authState.offlineFallback=false;
  if(clearCache)localStorage.removeItem(PROFILE_CACHE_KEY);
}
function sessionKey(session){
  if(!session?.user?.id)return "";
  const token=String(session.access_token||"");
  return `${session.user.id}:${token.slice(-24)}`;
}
function isMissingEnsureProfileRpc(error){
  const code=String(error?.code||"");
  const msg=String(error?.message||error||"").toLowerCase();
  return code==="PGRST202"||code==="42883"||(msg.includes("ensure_my_profile")&&(msg.includes("not find")||msg.includes("does not exist")||msg.includes("schema cache")));
}
function normalizeProfile(data,user=null){
  if(!data)return null;
  if(typeof data==="string"){try{return serverProfile(JSON.parse(data),user)}catch{return null}}
  if(Array.isArray(data))return serverProfile(data[0]||null,user);
  return serverProfile(data,user);
}

async function getServerUser(expectedUserId=null){
  const {data,error}=await withTimeout(
    supabase.auth.getUser(),
    PROFILE_TIMEOUT_MS,
    "Supabase Auth не ответил за 10 секунд"
  );
  if(error)throw error;
  const user=data?.user||null;
  if(!user)throw new Error("Supabase не подтвердил пользователя текущей сессии");
  if(expectedUserId&&user.id!==expectedUserId)throw new Error("Серверная сессия изменилась во время проверки");
  return user;
}

async function fetchOwnProfile(expectedUserId){
  // v0.27 preferred path: a SECURITY DEFINER RPC derives the UUID from auth.uid(),
  // creates a missing pending profile only for that same UUID, and returns it.
  const rpc=await withTimeout(
    supabase.rpc("ensure_my_profile"),
    PROFILE_TIMEOUT_MS,
    "Сервер профилей не ответил за 10 секунд"
  );
  if(!rpc.error)return {profile:normalizeProfile(rpc.data, authState.user||authState.session?.user||null),source:"ensure_my_profile"};

  // Safe staged-deployment fallback: existing installations continue to work before
  // migration 003 is applied. This path never creates a profile and remains protected by RLS.
  if(!isMissingEnsureProfileRpc(rpc.error))throw rpc.error;
  const direct=await withTimeout(
    supabase.from("profiles")
      .select("user_id,name,email,avatar_url,provider,role,status,content_access,created_at,last_login,updated_at")
      .eq("user_id",expectedUserId)
      .maybeSingle(),
    PROFILE_TIMEOUT_MS,
    "Сервер профилей не ответил за 10 секунд"
  );
  if(direct.error)throw direct.error;
  if(!direct.data)throw new Error("Профиль не найден. Выполни migration 003_auth_hardening.sql в Supabase.");
  return {profile:serverProfile(direct.data, authState.user||authState.session?.user||null),source:"direct-fallback"};
}

let profileRequest=null;
export function refreshProfile(options={}){if(profileRequest)return profileRequest;profileRequest=refreshProfileOnce(options).finally(()=>{profileRequest=null});return profileRequest;}
async function refreshProfileOnce({verifyUser=true}={}){
  if(!supabase||!authState.session){clearProfileState();emit();return null;}
  const localExpectedId=authState.session?.user?.id||authState.user?.id||null;
  if(!localExpectedId){clearProfileState();authState.error=new Error("В сессии отсутствует UUID пользователя");emit();return null;}

  const epoch=authEpoch;
  authState.profileLoading=!authState.profile;
  authState.error=null;
  authState.offlineFallback=false;
  emit();

  let lastError=null;
  try{
    let verifiedUser=authState.user;
    if(verifyUser){
      try{
        verifiedUser=await getServerUser(localExpectedId);
      }catch(err){
        const cached=cachedProfile(localExpectedId);
        if(!navigator.onLine&&cachedProfileIsUsable(cached)){
          if(epoch!==authEpoch)return authState.profile;
          authState.user=authState.session.user;
          authState.profile=serverProfile(cached,authState.user||authState.session?.user||null);
          authState.profileSource="offline-cache";
          authState.offlineFallback=true;
          authState.error=null;
          return cached;
        }
        throw err;
      }
    }
    if(!verifiedUser||verifiedUser.id!==localExpectedId)throw new Error("Пользователь Auth не соответствует текущей сессии");
    if(epoch!==authEpoch)return authState.profile;
    authState.user=verifiedUser;

    for(let i=0;i<PROFILE_RETRY_DELAYS.length;i++){
      if(PROFILE_RETRY_DELAYS[i])await sleep(PROFILE_RETRY_DELAYS[i]);
      if(epoch!==authEpoch||authState.session?.user?.id!==localExpectedId)return authState.profile;
      try{
        const {profile,source}=await fetchOwnProfile(localExpectedId);
        if(!profile)throw new Error("Supabase не вернул профиль");
        if(profile.user_id!==localExpectedId)throw new Error("Profile UUID не соответствует подтверждённому Auth UUID");
        if(epoch!==authEpoch)return authState.profile;
        authState.profile=serverProfile(profile,verifiedUser||authState.user||authState.session?.user||null);
        authState.profileSource=source;
        authState.error=null;
        authState.offlineFallback=false;
        saveCachedProfile(profile);
        lastHydratedSessionKey=sessionKey(authState.session);
        return profile;
      }catch(err){
        lastError=err;
        if(isMissingEnsureProfileRpc(err))break;
      }
    }
    throw lastError||new Error("Не удалось получить профиль пользователя");
  }catch(err){
    if(epoch!==authEpoch)return authState.profile;
    if(mayKeepProfileOnNetworkError(err,localExpectedId)){authState.backgroundError=err;authState.error=null;return authState.profile;}
    const cached=cachedProfile(localExpectedId);
    if(!navigator.onLine&&cachedProfileIsUsable(cached)){
      authState.profile=serverProfile(cached,authState.user||authState.session?.user||null);
      authState.profileSource="offline-cache";
      authState.offlineFallback=true;
      authState.error=null;
    }else{
      authState.profile=null;
      authState.profileSource=null;
      authState.error=err;
    }
    return authState.profile;
  }finally{
    if(epoch===authEpoch){authState.profileLoading=false;emit();}
  }
}

async function establishSession(session,{forceProfile=false}={}){
  const nextId=session?.user?.id||null;
  const prevId=authState.session?.user?.id||authState.user?.id||null;
  if(prevId!==nextId){authEpoch++;clearProfileState();lastHydratedSessionKey="";}
  authState.session=session||null;
  authState.error=null;
  if(!session){authState.user=null;clearProfileState();emit();return null;}

  const expectedId=session.user.id;
  try{
    const user=await getServerUser(expectedId);
    if(authState.session?.user?.id!==expectedId)return null;
    authState.user=user;
    const key=sessionKey(session);
    if(forceProfile||!authState.profile||authState.profile.user_id!==expectedId||lastHydratedSessionKey!==key){
      await refreshProfile({verifyUser:false});
    }else emit();
    return authState.profile;
  }catch(err){
    if(mayKeepProfileOnNetworkError(err,expectedId)){authState.backgroundError=err;authState.error=null;emit();return authState.profile;}
    const cached=cachedProfile(expectedId);
    if(!navigator.onLine&&cachedProfileIsUsable(cached)){
      authState.user=session.user;
      authState.profile=serverProfile(cached,authState.user||authState.session?.user||null);
      authState.profileSource="offline-cache";
      authState.offlineFallback=true;
      authState.error=null;
      emit();
      return cached;
    }
    authState.user=session.user;
    authState.profile=null;
    authState.profileSource=null;
    authState.error=err;
    emit();
    return null;
  }
}

async function handleAuthEvent(event,session){
  if(event==="SIGNED_OUT"){
    authEpoch++;
    authState.session=null;
    authState.user=null;
    authState.error=null;
    clearProfileState({clearCache:true});
    lastHydratedSessionKey="";
    emit();
    return;
  }
  if(!session)return;
  if(["INITIAL_SESSION","SIGNED_IN","TOKEN_REFRESHED","USER_UPDATED","PASSWORD_RECOVERY"].includes(event)){
    await establishSession(session,{forceProfile:event==="SIGNED_IN"||event==="USER_UPDATED"});
  }
}

export async function initAuth(){
  authState.loading=true;
  authState.configured=isAuthConfigured();
  emit();
  if(!authState.configured){
    authState.initialized=true;authState.loading=false;authState.session=null;authState.user=null;clearProfileState();emit();return authState;
  }
  try{
    const {createClient}=await import(SDK_URL);
    supabase=createClient(SUPABASE_CONFIG.url,SUPABASE_CONFIG.publishableKey,{auth:{persistSession:true,autoRefreshToken:true,detectSessionInUrl:true}});
    const {data,error}=await supabase.auth.getSession();
    if(error)throw error;
    if(data.session)await establishSession(data.session,{forceProfile:true});
    else{authState.session=null;authState.user=null;clearProfileState();}

    supabase.auth.onAuthStateChange((event,session)=>{
      // Keep the callback itself synchronous. Supabase operations run after it returns,
      // serialized to prevent Android/WebView auth events from racing each other.
      authEventQueue=authEventQueue
        .then(()=>new Promise(resolve=>queueMicrotask(resolve)))
        .then(()=>handleAuthEvent(event,session))
        .catch(err=>{authState.error=err;authState.profileLoading=false;emit();console.error("ProPharm auth event",event,err)});
    });
  }catch(err){authState.error=err;console.error("ProPharm auth init",err)}
  authState.initialized=true;
  authState.loading=false;
  emit();
  return authState;
}

export async function signInWithPassword(email,password){
  if(!supabase)throw new Error("Supabase не настроен");
  authEpoch++;
  clearProfileState();
  authState.profileLoading=true;authState.error=null;emit();
  const {data,error}=await supabase.auth.signInWithPassword({email:String(email||"").trim(),password});
  if(error){authState.profileLoading=false;emit();throw error;}
  if(!data.session||!data.user){authState.profileLoading=false;emit();throw new Error("Supabase не создал активную сессию после входа");}
  authState.session=data.session;
  authState.user=data.user;
  await establishSession(data.session,{forceProfile:true});
  if(authState.error)throw authState.error;
  if(!authState.profile||authState.profile.user_id!==data.user.id)throw new Error("Не удалось загрузить профиль текущего аккаунта");
  return {...data,profile:authState.profile};
}

export async function signUpWithPassword(name,email,password){
  if(!supabase)throw new Error("Supabase не настроен");
  authEpoch++;
  clearProfileState();
  authState.profileLoading=true;authState.error=null;emit();
  const {data,error}=await supabase.auth.signUp({
    email:String(email||"").trim(),
    password,
    options:{data:{full_name:String(name||"").trim()}}
  });
  if(error){authState.profileLoading=false;emit();throw error;}
  if(!data.user){authState.profileLoading=false;emit();throw new Error("Supabase не создал пользователя");}
  if(!data.session){
    authState.profileLoading=false;emit();
    throw new Error("Аккаунт создан без активной сессии. В Supabase отключи Authentication → Email → Confirm email.");
  }
  authState.session=data.session;
  authState.user=data.user;
  await establishSession(data.session,{forceProfile:true});
  if(authState.error)throw authState.error;
  if(!authState.profile)throw new Error("Аккаунт создан, но профиль пока недоступен. Выполни migration 003_auth_hardening.sql.");
  return {...data,profile:authState.profile};
}

export async function signInWithOAuth(provider){
  if(!supabase)throw new Error("Supabase не настроен");
  if(!["google","apple"].includes(provider))throw new Error("Неподдерживаемый OAuth provider");
  const {data,error}=await supabase.auth.signInWithOAuth({provider,options:{redirectTo:oauthRedirectUrl()}});if(error)throw error;return data;
}
export async function linkIdentity(provider){
  if(!supabase||!authState.user)throw new Error("Сначала войдите в аккаунт");
  const {data,error}=await supabase.auth.linkIdentity({provider,options:{redirectTo:oauthRedirectUrl()}});if(error)throw error;return data;
}
export async function resetPassword(email){
  if(!supabase)throw new Error("Supabase не настроен");
  const {data,error}=await supabase.auth.resetPasswordForEmail(email,{redirectTo:`${oauthRedirectUrl()}#reset-password`});if(error)throw error;return data;
}
export async function updatePassword(password){
  if(!supabase||!authState.session)throw new Error("Нет активной recovery-сессии");
  if(String(password||"").length<8)throw new Error("Пароль должен содержать не менее 8 символов");
  const {data,error}=await supabase.auth.updateUser({password});if(error)throw error;return data;
}
export async function signOut(){
  try{if(supabase)await supabase.auth.signOut()}finally{
    authEpoch++;
    localStorage.removeItem(PROFILE_CACHE_KEY);
    authState.session=null;authState.user=null;authState.error=null;clearProfileState();lastHydratedSessionKey="";emit();
  }
}

export async function updateOwnProfile(patch){
  if(!supabase||!authState.user)throw new Error("Нет активного аккаунта");
  const safe={};if(typeof patch.name==="string")safe.name=patch.name.trim().slice(0,120);if(typeof patch.avatar_url==="string")safe.avatar_url=patch.avatar_url.trim().slice(0,1000);safe.updated_at=new Date().toISOString();
  const {data,error}=await supabase.from("profiles").update(safe).eq("user_id",authState.user.id).select().single();if(error)throw error;authState.profile=serverProfile(data,authState.user);saveCachedProfile(authState.profile);emit();return authState.profile;
}
export async function listUsersForAdmin(){
  if(!supabase||!isAdmin())throw new Error("Недостаточно прав");
  // Use a SECURITY DEFINER RPC so the admin list works even if an older RLS policy
  // is still active in the project. The SQL patch grants this RPC only to authenticated users
  // and the function itself verifies the bootstrap admin role.
  const {data,error}=await supabase.rpc("admin_list_users_v2");
  if(error)throw error;
  return data||[];
}
export async function adminPendingCount(){
  if(!supabase||!isAdmin())return 0;
  const {data,error}=await supabase.rpc("admin_pending_count");
  if(error)throw error;
  return Number(data||0);
}
export async function listAdminNotifications(limit=30){
  if(!supabase||!isAdmin())return [];
  const {data,error}=await supabase.rpc("admin_list_notifications",{p_limit:Math.max(1,Math.min(100,Number(limit)||30))});
  if(error)throw error;
  return data||[];
}
export async function markAdminNotificationsRead(){
  if(!supabase||!isAdmin())return;
  const {error}=await supabase.rpc("admin_mark_notifications_read");
  if(error)throw error;
}
let adminApplicationsChannel=null;
export async function subscribeAdminApplications(onApplication){
  if(!supabase||!isAdmin())return ()=>{};
  if(adminApplicationsChannel){try{await supabase.removeChannel(adminApplicationsChannel)}catch{} adminApplicationsChannel=null;}
  const channel=supabase.channel(`propharm-admin-applications-${authState.user.id}`)
    .on('postgres_changes',{event:'INSERT',schema:'public',table:'admin_notifications'},payload=>{
      if(payload?.new?.kind==='new_application'){try{onApplication?.(payload.new)}catch(e){console.error(e)}}
    })
    .subscribe();
  adminApplicationsChannel=channel;
  return async()=>{if(adminApplicationsChannel===channel){try{await supabase.removeChannel(channel)}catch{} adminApplicationsChannel=null;}};
}
export async function savePushSubscription(subscription){
  if(!supabase||!isAdmin())throw new Error("Недостаточно прав");
  const json=subscription?.toJSON?subscription.toJSON():subscription;
  const endpoint=json?.endpoint,keys=json?.keys||{};
  if(!endpoint||!keys.p256dh||!keys.auth)throw new Error("Некорректная push-подписка");
  const row={user_id:authState.user.id,endpoint,p256dh:keys.p256dh,auth:keys.auth,user_agent:navigator.userAgent,updated_at:new Date().toISOString()};
  const {error}=await supabase.from('push_subscriptions').upsert(row,{onConflict:'endpoint'});
  if(error)throw error;
}
export async function deletePushSubscription(endpoint){
  if(!supabase||!authState.user||!endpoint)return;
  const {error}=await supabase.from('push_subscriptions').delete().eq('endpoint',endpoint).eq('user_id',authState.user.id);
  if(error)throw error;
}
export async function adminSetStatus(targetUserId,status){
  if(!supabase||!isAdmin())throw new Error("Недостаточно прав");
  if(!["pending","approved","blocked","rejected"].includes(status))throw new Error("Недопустимый статус");
  const {data,error}=await supabase.rpc("admin_set_user_status",{target_user_id:targetUserId,new_status:status});if(error)throw error;return data;
}
export function oauthRedirectUrl(){
  if(SUPABASE_CONFIG.siteUrl)return new URL(SUPABASE_CONFIG.siteUrl).href;
  return `${location.origin}${location.pathname}`;
}

export async function listAdminActions(limit=100,before=null){
 if(!supabase||!isAdmin())throw new Error('Недостаточно прав');
 const {data,error}=await supabase.rpc('admin_list_actions',{p_limit:limit,p_before:before});if(error)throw error;return data||[];
}
export async function adminSetContentAccess(targetUserId,access){
 if(!supabase||!isAdmin())throw new Error('Недостаточно прав');
 const {error}=await supabase.rpc('admin_set_content_access',{p_target:targetUserId,p_access:access});if(error)throw error;
}
