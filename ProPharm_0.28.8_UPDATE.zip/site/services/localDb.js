const DB_NAME = "propharm-personal-v1";
const DB_VERSION = 4;
const STORES = ["test_sessions","question_progress","favorites","review_queue","study_progress","user_settings","sync_queue","meta","memory_progress","memory_events","question_events"];
let dbPromise;

function openDb(){
  if(dbPromise) return dbPromise;
  dbPromise = new Promise((resolve,reject)=>{
    const req=indexedDB.open(DB_NAME,DB_VERSION);
    req.onerror=()=>reject(req.error);
    req.onupgradeneeded=()=>{
      const db=req.result;
      for(const name of STORES){
        if(!db.objectStoreNames.contains(name)) db.createObjectStore(name,{keyPath:"key"});
      }
    };
    req.onsuccess=()=>resolve(req.result);
  });
  return dbPromise;
}

async function withStore(name,mode,fn){
  const db=await openDb();
  return new Promise((resolve,reject)=>{
    const tx=db.transaction(name,mode);const store=tx.objectStore(name);
    let result;
    try{result=fn(store,tx);}catch(err){reject(err);return;}
    tx.oncomplete=()=>resolve(result);
    tx.onerror=()=>reject(tx.error);
    tx.onabort=()=>reject(tx.error||new Error("IndexedDB transaction aborted"));
  });
}

export async function put(store,value){
  return withStore(store,"readwrite",s=>s.put(value));
}
export async function del(store,key){
  return withStore(store,"readwrite",s=>s.delete(key));
}
export async function get(store,key){
  const db=await openDb();
  return new Promise((resolve,reject)=>{const tx=db.transaction(store,"readonly"),req=tx.objectStore(store).get(key);req.onsuccess=()=>resolve(req.result||null);req.onerror=()=>reject(req.error);});
}
export async function all(store){
  const db=await openDb();
  return new Promise((resolve,reject)=>{const tx=db.transaction(store,"readonly"),req=tx.objectStore(store).getAll();req.onsuccess=()=>resolve(req.result||[]);req.onerror=()=>reject(req.error);});
}
export async function allForUser(store,userId){
  const rows=await all(store);return rows.filter(x=>x.user_id===userId);
}
export async function clearUser(store,userId){
  const rows=await allForUser(store,userId);for(const row of rows)await del(store,row.key);
}
export function makeKey(userId,...parts){return [userId,...parts].join("::")}
export function randomId(prefix="evt"){
  if(globalThis.crypto?.randomUUID)return `${prefix}-${crypto.randomUUID()}`;
  return `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2)}`;
}

// Atomically persist an event and its aggregate; replay after reload is idempotent.
export async function applyQuestionEvent(userId,event){
 const db=await openDb(),eventKey=makeKey(userId,event.event_id),progressKey=makeKey(userId,event.question_id);
 return new Promise((resolve,reject)=>{
  const tx=db.transaction(['question_events','question_progress'],'readwrite'),events=tx.objectStore('question_events'),progress=tx.objectStore('question_progress');let applied=false;
  tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error);tx.oncomplete=()=>resolve({applied});
  const exists=events.get(eventKey);exists.onsuccess=()=>{if(exists.result)return;const old=progress.get(progressKey);old.onsuccess=()=>{
   const p=old.result||{key:progressKey,user_id:userId,question_id:event.question_id,attempts:0,correct_count:0,wrong_count:0,first_try_correct_count:0,mastery_streak:0};
   const success=event.first_try&&!event.is_repeat;
   const streak=!event.correct?0:success&&p.last_mastery_session!==event.session_id?(p.mastery_streak||0)+1:(p.mastery_streak||0);
   progress.put({...p,attempts:p.attempts+1,correct_count:p.correct_count+(event.correct?1:0),wrong_count:p.wrong_count+event.wrong_count,first_try_correct_count:p.first_try_correct_count+(event.first_try?1:0),last_result:event.correct?'correct':'wrong',last_seen:event.occurred_at,updated_at:event.occurred_at,system_id:event.system_id,section_id:event.section_id,mastery_streak:streak,last_mastery_session:success?event.session_id:p.last_mastery_session});
   events.put({key:eventKey,user_id:userId,event,synced:false});applied=true;
  };};
 });
}
