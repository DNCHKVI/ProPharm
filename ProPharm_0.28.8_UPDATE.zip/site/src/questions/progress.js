import { authState,getSupabase } from '../../services/authService.js';
import { applyQuestionEvent,allForUser,put,del,makeKey } from '../../services/localDb.js';
import { setReview } from '../../services/userData.js';
export async function flushSessionEvents(session){
 const userId=session.userId;if(userId!==authState.user?.id||authState.profile?.status!=='approved')return;
 for(const event of session.events){
  if(userId!==authState.user?.id||authState.profile?.status!=='approved')return;
  const result=await applyQuestionEvent(userId,event);
  if(result.applied&&!event.correct&&userId===authState.user?.id)await setReview('question',event.question_id,{reason:'wrong_answer',priority:3,next_review:new Date(Date.now()+86400000).toISOString()});
 }
 await syncQuestionEvents(userId);
}
export async function syncQuestionEvents(userId=authState.user?.id){
 if(!navigator.onLine||!userId||userId!==authState.user?.id||authState.profile?.status!=='approved')return;
 const events=await allForUser('question_events',userId);
 for(const row of events.filter(e=>!e.synced).sort((a,b)=>a.event.occurred_at.localeCompare(b.event.occurred_at))){
  if(authState.user?.id!==userId||authState.profile?.status!=='approved')return;
  const {error}=await getSupabase().rpc('record_question_event',{p_event:row.event});if(error)throw error;
  await put('question_events',{...row,synced:true});
 }
}
