export function sourceAnswerIds(q){
 const ids=q.correct?[q.correct]:(q.sourceCorrectIds||[]);
 return [...new Set(ids)].filter(id=>q.options.some(o=>o.id===id));
}
export function sourceAnswerText(q){
 const options=sourceAnswerIds(q).map(id=>q.options.find(o=>o.id===id));
 return options.length?options.map(o=>`${o.id}. ${o.text}`).join('; '):'В источнике однозначный ответ не установлен.';
}
