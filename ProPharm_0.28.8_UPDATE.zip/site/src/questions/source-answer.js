export function sourceAnswerText(q){
 const ids=q.correct?[q.correct]:(q.sourceCorrectIds||[]);
 const options=ids.map(id=>q.options.find(o=>o.id===id)).filter(Boolean);
 return options.length?options.map(o=>`${o.id}. ${o.text}`).join('; '):'В источнике однозначный ответ не установлен.';
}
