export const QUESTION_SCHEMA_VERSION=1;
export const normalizeText=text=>String(text||'').normalize('NFKC').toLowerCase().replace(/ё/g,'е').replace(/[^\p{L}\p{N}]+/gu,' ').trim();
export function questionFingerprint(q){return normalizeText(q.question)+'|'+q.options.map(o=>normalizeText(o.text)).sort().join('|');}
export function validateQuestion(q){
 const errors=[];const fail=m=>errors.push(`${q?.id||'<без ID>'}: ${m}`);
 if(!q||typeof q!=='object')return ['Вопрос должен быть объектом'];
 for(const k of ['id','question','sectionId','sectionTitle','hint'])if(typeof q[k]!=='string'||!q[k].trim())fail(`не заполнено ${k}`);
 if(!Array.isArray(q.options)||q.options.length<2)fail('нужно минимум два варианта');
 const options=Array.isArray(q.options)?q.options:[],ids=new Set();
 for(const o of options){if(typeof o.id!=='string'||!o.id.trim()||ids.has(o.id))fail(`пустой/повторный ID варианта ${o.id}`);ids.add(o.id);if(typeof o.text!=='string'||!o.text.trim())fail(`нет текста варианта ${o.id}`);if(typeof q.optionExplanations?.[o.id]!=='string'||!q.optionExplanations[o.id].trim())fail(`нет объяснения варианта ${o.id}`);}
 if(!ids.has(q.correct)&&!(q.correct===null&&q.examEligible===false&&q.sourceNotes?.length))fail('правильный ответ отсутствует среди вариантов');
 if(!Array.isArray(q.explanation)||!q.explanation.length||q.explanation.some(x=>typeof x!=='string'||!x.trim()))fail('не заполнено основное объяснение');
 if(typeof q.hasImage!=='boolean'||typeof q.isCalculation!=='boolean')fail('теги изображения и расчёта должны быть boolean');
 if(typeof q.examEligible!=='boolean')fail('examEligible должен быть boolean');
 if(q.examEligible===false&&!q.sourceNotes?.length)fail('не указана причина исключения из экзамена');
 return errors;
}
export function validateRegistry(questions,nav=[]){
 const errors=[],duplicates=[],ids=new Set(),texts=new Map();
 const sections=new Set(nav.flatMap(n=>n.children?n.children.flatMap(x=>x[2]||[]):n.sections||[]));
 for(const q of questions){errors.push(...validateQuestion(q));if(ids.has(q.id))errors.push(`Повтор ID: ${q.id}`);ids.add(q.id);if(nav.length&&!sections.has(q.sectionId))errors.push(`${q.id}: раздел ${q.sectionId} отсутствует в навигации`);const key=normalizeText(q.question);if(!texts.has(key))texts.set(key,[]);texts.get(key).push(q.id);}
 for(const [text,ids]of texts)if(ids.length>1)duplicates.push({text,ids});
 return {errors,duplicates};
}

export function answerFingerprint(q){return questionFingerprint(q)+"|correct:"+q.correct+"|exam:"+q.examEligible;}
