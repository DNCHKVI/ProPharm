import { sourceAnswerIds } from './source-answer.js';

export function optionFeedback(question,entry,answer,mode,optionId){
 const selected=!!answer?.selections.includes(optionId);
 if(!answer||mode==='exam')return {className:selected?'selectedAnswer':'',label:selected?'Выбран':''};
 if(entry.unscored){
  const sourceIds=sourceAnswerIds(question),sourceKey=sourceIds.includes(optionId);
  return sourceKey
   ?{className:'correctAnswer',label:'Верно'}
   :{className:selected?'selectedAnswer':'',label:selected?'Выбран · без оценки':''};
 }
 if(optionId===question.correct)return {className:'correctAnswer',label:'Верно'};
 return {className:selected?'wrongAnswer':'',label:selected?'Ошибка':''};
}
