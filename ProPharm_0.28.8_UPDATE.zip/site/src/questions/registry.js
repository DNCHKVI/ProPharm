import { validateRegistry,questionFingerprint } from './schema.js';
export function createRegistry(questions){
 const result=validateRegistry(questions);if(result.errors.length)throw new Error('Ошибка реестра вопросов: '+result.errors.slice(0,8).join('; '));
 const byId=new Map(questions.map(q=>[q.id,Object.freeze(q)]));
 return Object.freeze({questions:Object.freeze([...byId.values()]),get:id=>byId.get(id),has:id=>byId.has(id),fingerprint:id=>byId.has(id)?questionFingerprint(byId.get(id)):null});
}
