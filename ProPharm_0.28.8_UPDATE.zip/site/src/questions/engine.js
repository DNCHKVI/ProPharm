import { questionFingerprint,answerFingerprint } from './schema.js';
export function shuffle(items,random=Math.random){const result=[...items];for(let i=result.length-1;i>0;i--){const j=Math.floor(random()*(i+1));[result[i],result[j]]=[result[j],result[i]];}return result;}
export function isMastered(progress){return Number(progress?.mastery_streak||0)>=2;}
export function isWeak(progress){return !!progress&&!isMastered(progress)&&(progress.last_result==='wrong'||Number(progress.wrong_count)>0);}
export function filterQuestions(questions,{spec='all',filters=[],mode='learn',weakTopics=[]}={},progress={}){
 const [kind,...rest]=spec.split(':'),value=rest.join(':'),set=new Set(value.split(','));
 return questions.filter(q=>{
  if(mode==='exam'&&q.examEligible===false)return false;
  if(kind==='topic'&&q.topic!==value)return false;
  if(kind==='section'&&q.sectionId!==value&&q.sourceSectionId!==value)return false;
  if(kind==='sections'&&!set.has(q.sectionId)&&!set.has(q.sourceSectionId))return false;
  if(kind==='ids'&&!set.has(q.id))return false;
  if(kind==='weak-topic'&&(q.studyTopicId||q.sectionId)!==value)return false;
  const p=progress[q.id];
  return filters.every(f=>f==='new'?!p?.attempts:f==='wrong'?isWeak(p):f==='mastered'?isMastered(p):f==='images'?q.hasImage:f==='calculation'?q.isCalculation:f==='weak-topics'?weakTopics.includes(q.studyTopicId||q.sectionId):true);
 });
}
export function createSession(questions,{userId,mode='learn',count=20,randomOrder=true,shuffleOptions=true,spec='all',now=Date.now(),id=crypto.randomUUID()}={}){
 if(!userId)throw new Error('Для сессии нужен пользователь');if(!['learn','exam'].includes(mode))throw new Error('Неизвестный режим');
 const unique=new Set();let pool=questions.filter(q=>{if(mode==='exam'&&!q.examEligible)return false;const fp=questionFingerprint(q);if(unique.has(fp))return false;unique.add(fp);return true;});
 if(randomOrder)pool=shuffle(pool);if(count!=='all')pool=pool.slice(0,Number(count));if(!pool.length)throw new Error('Нет вопросов для выбранных условий');
 return {version:1,id,userId,mode,spec,startedAt:new Date(now).toISOString(),index:0,originalIds:pool.map(q=>q.id),fingerprints:Object.fromEntries(pool.map(q=>[q.id,answerFingerprint(q)])),queue:pool.map((q,i)=>({key:`${id}:${i}`,questionId:q.id,repeat:0,unscored:q.examEligible===false,options:(shuffleOptions?shuffle(q.options):q.options).map(o=>o.id)})),answers:{},events:[],completedAt:null,saved:false};
}
export function currentEntry(s){return s.queue[s.index]||null;}
export function selectAnswer(session,question,optionId,now=Date.now()){
 const s=structuredClone(session),entry=currentEntry(s);if(!entry||entry.questionId!==question.id)throw new Error('Вопрос не соответствует сессии');
 if(!entry.options.includes(optionId))throw new Error('Неизвестный вариант ответа');
 const old=s.answers[entry.key];if(old?.resolved||old?.selections.includes(optionId))return s;
 const a=old||{selections:[],firstCorrect:optionId===question.correct,resolved:false,shown:false};a.selections.push(optionId);a.resolved=entry.unscored||s.mode==='exam'||optionId===question.correct;s.answers[entry.key]=a;
 if(a.selections.length===1&&!entry.unscored){
  s.events.push({event_id:entry.key,session_id:s.id,question_id:question.id,system_id:question.topic||null,section_id:question.sectionId,correct:a.firstCorrect,first_try:a.firstCorrect,wrong_count:a.firstCorrect?0:1,is_repeat:entry.repeat>0,occurred_at:new Date(now).toISOString()});
  if(!a.firstCorrect&&s.mode==='learn'&&entry.repeat<2){const repeated={...entry,key:entry.key+':repeat',repeat:entry.repeat+1};s.queue.splice(Math.min(s.index+4,s.queue.length),0,repeated);}
 }
 return s;
}
export function revealAnswer(session){const s=structuredClone(session),entry=currentEntry(s);if(s.mode==='exam')throw new Error('Ответы доступны после завершения экзамена');const a=s.answers[entry.key];if(!a)throw new Error('Сначала выберите ответ');a.resolved=true;a.shown=true;return s;}
export function advance(session,now=Date.now()){
 const s=structuredClone(session),entry=currentEntry(s);if(!entry||!s.answers[entry.key]?.resolved)throw new Error('Вопрос ещё не завершён');
 s.index++;if(s.index>=s.queue.length)s.completedAt=new Date(now).toISOString();return s;
}
export function sessionSummary(s){const originals=s.queue.filter(e=>e.repeat===0&&!e.unscored),answers=originals.map(e=>s.answers[e.key]);return {total:originals.length,totalAsked:s.originalIds.length,unscored:s.queue.filter(e=>e.repeat===0&&e.unscored).length,firstCorrect:answers.filter(a=>a?.firstCorrect).length,answered:answers.filter(Boolean).length,wrongQuestions:originals.filter(e=>s.answers[e.key]&&!s.answers[e.key].firstCorrect).map(e=>e.questionId),wrongSelections:s.queue.reduce((n,e)=>{if(e.unscored)return n;const a=s.answers[e.key];return n+(a?a.selections.length-(a.resolved&&!a.shown&&(a.firstCorrect||s.mode==='learn')?1:0):0)},0),repeats:s.queue.filter(e=>e.repeat>0).length};}
export function validateSession(s,userId,registry){
 if(!s||s.version!==1||s.userId!==userId||!Array.isArray(s.queue)||!s.queue.length||!Array.isArray(s.originalIds)||!s.answers||!Array.isArray(s.events)||!['learn','exam'].includes(s.mode))throw new Error('Повреждённое сохранение теста');
 if(!Number.isInteger(s.index)||s.index<0||s.index>s.queue.length)throw new Error('Некорректная позиция теста');
 for(const e of s.queue){const q=registry.get(e.questionId);if(!q||s.fingerprints[e.questionId]!==answerFingerprint(q)||e.options.length!==q.options.length||new Set(e.options).size!==e.options.length||e.options.some(id=>!q.options.some(o=>o.id===id)))throw new Error('Состав теста обновился. Начните новую сессию; прежняя статистика сохранена.');}
 return s;
}
