import { validateSession } from './engine.js';
const PREFIX='propharm_unfinished_v1:';
export function saveDraft(session,storage=localStorage){storage.setItem(PREFIX+session.userId,JSON.stringify(session));}
export function loadDraft(userId,registry,storage=localStorage){let value;try{value=JSON.parse(storage.getItem(PREFIX+userId)||'null')}catch{throw new Error('Не удалось прочитать сохранённую сессию');}return value?validateSession(value,userId,registry):null;}
export function discardDraft(userId,storage=localStorage){storage.removeItem(PREFIX+userId);}
