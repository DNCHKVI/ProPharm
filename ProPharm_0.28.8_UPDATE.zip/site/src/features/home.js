import { canAccessRoute } from '../core/access.js';
import { app, esc } from '../core/shared.js';
import { homeDoodleIcon, capsuleLogo } from '../ui/icons.js';
import { bottomNav, bindNav } from '../ui/shell.js';
import { accountDisplayName } from '../ui/personal.js';
import { isTestsOnlyUser } from '../core/access.js';

export function renderHome(){
 const tiles=[
  ["theory","Базовые дисциплины","Системы организма, фармакокинетика, химия, биохимия и НД Израиля","#foundations","paper"],
  ["drugs","170 препаратов","Полная экзаменационная база","#drugs","blue"],
  ["tests","Тесты","Экзаменационная база + вопросы прошлых лет","#tests","lavender"],
  ["memory","Тренажёр памяти","Циклическое обучение и интервальное повторение","#memory-trainer","blue"],
  ["cards","Карточки","Повторение по препаратам и тестам","#cards","lavender"],
  ["schemes","Схемы","Механизмы и процессы","#schemes","paper"],
  ["tables","Таблицы","Сравнения и диагностические ориентиры","#tables","blue"],
  ["abbr","Аббревиатуры","Расшифровки по системам","#abbr-hub","lavender"],
  ["interactions","Взаимодействия","Поиск опасных взаимодействий по препарату","#interactions-hub","paper"]
 ];
 const restricted=isTestsOnlyUser();
 const tileHtml=tiles.map(([ic,title,desc,route,tone])=>{
   const allowed=canAccessRoute(route);
   const cls=`dashTile chalkTile tone-${tone}${allowed?'':' accessLockedTile'}`;
   if(allowed)return `<button class="${cls}" data-route="${route}"><span class="dashIcon">${homeDoodleIcon(ic)}</span><span class="dashText"><b>${title}</b><small>${desc}</small></span></button>`;
   return `<button class="${cls}" type="button" disabled aria-disabled="true"><span class="accessLockBadge">ВРЕМЕННО ЗАБЛОКИРОВАНО</span><span class="dashIcon">${homeDoodleIcon(ic)}</span><span class="dashText"><b>${title}</b><small>${desc}</small></span></button>`;
 }).join("");
 app.innerHTML=`<div class="homePage page chalkHome">
   <section class="chalkMasthead"><div class="chalkBrand">${capsuleLogo("homeBrandLogo")}<div><div class="chalkBrandName">ProPharm</div><div class="chalkBrandTag">знания лечат ♡</div></div></div><button class="chalkMenu" aria-label="Настройки" data-route="#settings">•••</button></section><button class="homeAccountCapsule" data-route="#profile" aria-label="Открыть профиль"><span class="homeAccountDot">${esc(accountDisplayName().slice(0,1).toUpperCase())}</span><span data-no-translate>${esc(accountDisplayName())}</span></button>
   <section class="chalkIntro"><h1>Главная</h1><p>${restricted?'Тесты, тренировка, 170 препаратов и взаимодействия доступны для подготовки.':'Начни с системного изучения'}</p><span class="handNote">${restricted?'тренируйся · разбирай ошибки · проверяй препараты':'норма → механизм → патология → препарат ♡'}</span></section>
   <section class="dashboardGrid chalkGrid">${tileHtml}</section>
   <div class="chalkFooterNote">${restricted?'закрепляй знания через практику':'понимай связи · не учи изолированные факты'}</div>
 </div>`+bottomNav("home");bindNav();
}
