import { EXAM_MATERIALS } from '../core/content.js';
import { app, esc } from '../core/shared.js';
import { header, bottomNav, bindNav } from '../ui/shell.js';
import { hasFullAccess } from '../core/access.js';

export function studyLinks(q) {
  if (!hasFullAccess()) return '<p class="smallMuted">Теория по вопросу доступна с полным учебным доступом.</p>';
  const ids=q.studyBlockIds||[];
  return `<div class="quizActions">${ids.map(id=>`<a class="moduleButton secondary" href="#foundation/${esc(id)}">Теория · ${esc(id)}</a><a class="moduleButton secondary" href="#foundation/${esc(id)}/analysis">Разборы блока</a>`).join('')}${!ids.length?'<a href="#foundations">Каталог теории · точная связь пока не установлена</a>':''}</div>`;
}
const textRows=rows=>(rows||[]).map(row=>`<p style="white-space:pre-wrap">${esc(row)}</p>`).join('');
export function renderExamMaterials(id, tab='theory') {
  const blocks=EXAM_MATERIALS.blocks||[];
  const b=blocks.find(x=>x.id===id);
  const notice='<p class="sourceNote">Восстановлены блоки 1–16. Блоки 17–39 отсутствуют в сохранённом комплекте. Материалы перенесены из учебных файлов; новая медицинская проверка не заявляется.</p>';
  app.innerHTML=header()+`<div class="page"><h1>${esc(b?b.title:'Базовые дисциплины')}</h1>${notice}${b?`<nav class="quizActions"><a href="#foundations">Все блоки</a><a href="#foundation/${b.id}">Теория</a><a href="#foundation/${b.id}/analysis">Разборы</a><a href="#cards">Карточки</a><a href="#quiz">Вернуться к текущему тесту</a></nav><article class="card">${textRows(tab==='analysis'?b.analysis:b.theory)}</article>`:`<div class="sectionGrid">${blocks.map(x=>`<a class="card" href="#foundation/${x.id}"><h2>${esc(x.title)}</h2><p>Блок ${x.number} · ${x.cardCount} карточек</p></a>`).join('')}</div>`}</div>`+bottomNav('study');
  bindNav();
}
