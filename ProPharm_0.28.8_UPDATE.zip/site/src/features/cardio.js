import { app, esc } from '../core/shared.js';
import { header, bottomNav, bindNav, accordion } from '../ui/shell.js';
import { renderAbbreviationLead } from '../ui/abbreviations.js';
import { renderScientificVisual, renderWhiteboardSources, renderLearningWhiteboard } from '../ui/visuals.js';
import { systemSectionMeta } from '../features/systems.js';
import { bindTestStarters } from '../features/quiz.js';
import { SYSTEM_SECTION_ORDER, CARDIO_PHYSIOLOGY, CARDIO_BIOCHEMISTRY, CARDIO_PATHOLOGIES, CARDIO_TARGETS, CARDIO_DIAGNOSTICS, CARDIO_FLASHCARDS, VISUAL_SOURCES, VISUAL_SOURCE_GROUPS, SCIENTIFIC_VISUALS, TESTS, drugMap } from '../core/content.js';

export const CARDIO_SECTION_ORDER=[
 ['abbr','Аббревиатуры и обозначения','Словарь сокращений, белков, ферментов, каналов, транспортёров и соединений.'],
 ['physiology','Анатомия и физиология','Анатомия сердца, кровоток, проводящая система, сердечный цикл и гемодинамика.'],
 ['biochemistry','Биохимия и клеточные процессы','Рецепторы, вторичные посредники, ионные токи, Ca²⁺-handling и нейрогуморальные каскады.'],
 ['pathophysiology','Патофизиология','Перечень патологий: формирование → изменения → диагностика → фармакотерапия.'],
 ['diseases','Заболевания','Клиническая навигация по тем же патофизиологическим сущностям.'],
 ['targets','Фармакологические мишени','Мишень → процесс → связанные препараты → ожидаемый эффект.'],
 ['drugs','Препараты','Препараты ССС из глобальной базы 170. Взаимодействия — внутри карточки каждого препарата.'],
 ['diagnostics','Диагностика / ЭКГ / лаборатория','ЭКГ, объёмы и EF, электролиты, troponin, BNP/NT-proBNP.'],
 ['cards','Карточки','Карточки из анатомии, физиологии, биохимии, патофизиологии, мишеней и диагностики.'],
 ['tests','Тесты','Существующие экзаменационные вопросы + созданные учебные вопросы по материалу ССС.'],
 ['analysis','Разбор тестов','Почему правильный вариант верен, почему остальные неверны и с каким механизмом это связано.']
];

export function systemSectionOrder(system){return system?.id==='cardiovascular'?CARDIO_SECTION_ORDER:SYSTEM_SECTION_ORDER;}

export function cardioSectionMeta(key){return CARDIO_SECTION_ORDER.find(x=>x[0]===key)||systemSectionMeta(key);}

export function cardioBlockText(item){return [item.title,item.summary,...(item.points||[]),...(item.steps||[]),item.physiology,item.pathology,...(item.commentary||[])].filter(Boolean).join(' ');}

export function renderVisualSources(area){const ids=VISUAL_SOURCE_GROUPS[area]||[];if(!ids.length)return '';return `<details class="sourceAccordion"><summary>Источники и научные референсы схемы</summary><div class="sourceAccordionBody">${ids.map(id=>{const x=VISUAL_SOURCES[id];return `<div class="visualSourceRow"><b>${esc(x.name)}</b><span>${esc(x.license)}</span><p>${esc(x.use)}</p><a href="${esc(x.url)}" target="_blank" rel="noopener noreferrer">Открыть источник ↗</a></div>`}).join('')}<p class="smallMuted">Готовые медицинские иллюстрации используются только из источников с понятным происхождением и лицензией. Если подходящего оригинала нет, процесс отображается как Learning Whiteboard с отдельными научными референсами.</p></div></details>`;}

export function cardioVisualSteps(item){return (item.steps?.length?item.steps:item.commentary?.length?item.commentary:item.formation?.length?item.formation:item.points?.length?item.points:[]).map(x=>String(x).trim()).filter(Boolean)}

export function renderMedicalVisual(item,area='default'){
 const exactKey=SCIENTIFIC_VISUALS[item?.illustration]?item.illustration:(SCIENTIFIC_VISUALS[item?.id]?item.id:null);
 if(exactKey)return `${renderScientificVisual(exactKey)}${cardioVisualSteps(item).length?renderLearningWhiteboard({title:`Упрощённая учебная цепочка: ${item.title||''}`,steps:cardioVisualSteps(item),area,showSources:true}):''}`;
 const steps=cardioVisualSteps(item);return steps.length?renderLearningWhiteboard({title:item.title||'Механизм',steps,area,showSources:true}):'';
}

export function accordionTextList(lines=[]){return `<div class="theoryBody">${lines.map(x=>`<p>• ${esc(x)}</p>`).join('')}</div>`}

export function renderProcessCommentary(item){const rows=item.commentary||item.steps||item.formation||[];return rows.length?`<ol class="processStepsText">${rows.map(x=>`<li>${esc(x)}</li>`).join('')}</ol>`:'';}

export function cardioDrugChips(ids=[],label='Связанные препараты'){return ids.length?`<div class="linkedDrugs"><b>${esc(label)}</b><div class="chips">${ids.map(id=>{const d=drugMap[String(id)];return d?`<button class="chip drugChip" data-route="#drug/${d.n}">${esc(d.name)}</button>`:''}).join('')}</div></div>`:'';}

export function renderPathologyTherapy(p){const linked=cardioDrugChips(p.drugIds||[],'Фармакотерапия · препараты из базы ProPharm');return `<div class="therapyMap">${linked||`<p>В экзаменационном списке 170 нет специфического препарата, который устраняет первичный дефект этой патологии. Основная стратегия: ${esc((p.targets||[]).join('; '))}.</p>`}<p><b>Логика:</b> ${esc(p.why||'')}</p></div>`;}

export function renderContextCards(cards,title=''){if(!cards.length)return '';return `<div class="miniFlashGrid">${cards.map(c=>`<details class="miniFlash"><summary>${esc(c[0])}</summary><p>${esc(c[1])}</p></details>`).join('')}</div>`;}

export function cardioTestSections(area){const map={physiology:['cardiac-basics','cardio-v012-physiology'],biochemistry:['cardio-v012-biochemistry'],pathophysiology:['heart-failure','hypertension','ihd-acs','antiarrhythmics','af','cardio-v012-pathophysiology'],diseases:['heart-failure','hypertension','ihd-acs','antiarrhythmics','af','cardio-v012-pathophysiology'],targets:['heart-failure','hypertension','antiarrhythmics','cardio-v012-targets'],diagnostics:['cardiac-basics','antiarrhythmics','af','cardio-v012-diagnostics']};return map[area]||[];}

export function cardioTests(area){const set=new Set(cardioTestSections(area));return TESTS.filter(q=>set.has(q.sectionId));}

export function renderContextTests(area){const qs=cardioTests(area);if(!qs.length)return '';return `<div class="contextStudy"><div><span class="handMini">Проверить себя</span><h3>Тесты по этому разделу</h3><p>${qs.length} вопросов: существующая экзаменационная база + учебные вопросы.</p></div><button class="moduleButton" data-start-test="cardio-section:${area}">Начать</button></div>`;}

export function renderCardioKnowledge(items,area){
 return `<div class="cardioKnowledge accordionStack">${items.map(item=>{
   const raw=cardioBlockText(item),terms=renderAbbreviationLead(raw)||'<p class="smallMuted">Специальных сокращений в этом блоке не обнаружено.</p>';
   const intro=`<p class="leadText">${esc(item.summary||item.definition||'')}</p>${item.points?.length?accordionTextList(item.points):''}`;
   const physiology=item.physiology?`<div class="dualExplain"><div><b>Связь с физиологией</b><p>${esc(item.physiology)}</p></div><div><b>Связь с патологией</b><p>${esc(item.pathology||'')}</p></div></div>`:'';
   const body=[
     accordion({id:`cv-${area}-${item.id}-terms`,title:'Термины и сокращения',level:3,body:terms}),
     accordion({id:`cv-${area}-${item.id}-intro`,title:'Краткое объяснение',level:3,body:intro}),
     accordion({id:`cv-${area}-${item.id}-visual`,title:'Иллюстрация процесса',level:3,body:renderMedicalVisual(item,area)}),
     accordion({id:`cv-${area}-${item.id}-comment`,title:'Что происходит на схеме',level:3,body:renderProcessCommentary(item)||'<p class="smallMuted">Пошаговый комментарий будет добавлен после проверки источника.</p>'}),
     physiology?accordion({id:`cv-${area}-${item.id}-links`,title:'Физиология и патология',level:3,body:physiology}):'',
     (item.drugIds||[]).length?accordion({id:`cv-${area}-${item.id}-drugs`,title:'Связанные препараты',level:3,body:cardioDrugChips(item.drugIds||[])}):'',
     (item.cards||[]).length?accordion({id:`cv-${area}-${item.id}-cards`,title:'Карточки по теме',level:3,body:renderContextCards(item.cards||[],item.title)}):'',
     accordion({id:`cv-${area}-${item.id}-sources`,title:'Источники и научные референсы',level:3,body:renderVisualSources(area)||renderWhiteboardSources(area)})
   ].filter(Boolean).join('');
   return accordion({id:`cv-${area}-${item.id}`,title:item.title,level:2,body});
 }).join('')}</div>${renderContextTests(area)}`;
}

export function renderCardioPhysiology(){return `<div class="integratedIntro">Раздел построен как раскрывающийся учебный атлас. Готовые анатомические/физиологические изображения берутся из открытых научных ресурсов; объясняющие цепочки отображаются как Learning Whiteboard.</div>${renderCardioKnowledge(CARDIO_PHYSIOLOGY,'physiology')}`;}

export function renderCardioBiochemistry(){return `<div class="integratedIntro">Биохимические механизмы больше не выводятся как AI-сгенерированные картинки. Используется Learning Whiteboard из проверенной последовательности, а где есть подходящая открытая научная схема — она показывается отдельно.</div>${renderCardioKnowledge(CARDIO_BIOCHEMISTRY,'biochemistry')}`;}

export function renderCardioPathologyCard(p,detail=false){
 const allText=[p.title,p.definition,p.normal,p.abnormal,...p.formation,p.biochem,...p.consequences,...p.clinical,...p.diagnostics,...p.targets,p.why].join(' ');
 const body=[
   accordion({id:`path-${p.id}-terms`,title:'Термины и сокращения',level:3,body:renderAbbreviationLead(allText)||'<p class="smallMuted">Нет дополнительных сокращений.</p>'}),
   accordion({id:`path-${p.id}-definition`,title:'Определение',level:3,body:`<p>${esc(p.definition)}</p>`}),
   accordion({id:`path-${p.id}-normal`,title:'Что происходит в норме',level:3,body:`<p>${esc(p.normal)}</p>`}),
   accordion({id:`path-${p.id}-abnormal`,title:'Что нарушается',level:3,body:`<p>${esc(p.abnormal)}</p>`}),
   accordion({id:`path-${p.id}-formation`,title:'Механизм формирования и схема патогенеза',level:3,body:`${renderMedicalVisual({...p,steps:p.formation},'pathophysiology')}${renderProcessCommentary({...p,commentary:p.formation})}`}),
   accordion({id:`path-${p.id}-biochem`,title:'Биохимические изменения',level:3,body:`<p>${esc(p.biochem)}</p>`}),
   accordion({id:`path-${p.id}-consequences`,title:'Физиологические и гемодинамические изменения',level:3,body:accordionTextList(p.consequences||[])}),
   accordion({id:`path-${p.id}-clinical`,title:'Клинические проявления',level:3,body:accordionTextList(p.clinical||[])}),
   accordion({id:`path-${p.id}-diagnostics`,title:'Диагностика',level:3,body:accordionTextList(p.diagnostics||[])}),
   accordion({id:`path-${p.id}-targets`,title:'Фармакологические мишени',level:3,body:`<div class="chips">${(p.targets||[]).map(x=>`<span class="chip">${esc(x)}</span>`).join('')}</div>`}),
   accordion({id:`path-${p.id}-therapy`,title:'Фармакотерапия и почему она работает',level:3,body:renderPathologyTherapy(p)}),
   (p.cards||[]).length?accordion({id:`path-${p.id}-cards`,title:'Карточки',level:3,body:renderContextCards(p.cards,p.title)}):'',
   accordion({id:`path-${p.id}-sources`,title:'Источники',level:3,body:renderVisualSources('pathophysiology')||renderWhiteboardSources('pathophysiology')}),
   detail?accordion({id:`path-${p.id}-tests`,title:'Тесты',level:3,body:renderContextTests('pathophysiology')}):''
 ].filter(Boolean).join('');
 return accordion({id:`path-${p.id}`,title:p.title,level:2,badge:'патогенез · диагностика · терапия',body});
}

export function renderCardioPathophysiology(){return `<div class="integratedIntro">Каждая патология теперь является отдельным раскрывающимся блоком: норма → нарушение → механизм → диагностика → мишень → фармакотерапия.</div><div class="accordionStack">${CARDIO_PATHOLOGIES.map(p=>renderCardioPathologyCard(p,false)).join('')}</div>${renderContextTests('pathophysiology')}`;}

export function renderCardioDiseases(){return `<div class="accordionStack">${CARDIO_PATHOLOGIES.map(p=>accordion({id:`disease-cv-${p.id}`,title:p.title,level:2,body:`<p>${esc(p.definition)}</p><button class="moduleButton secondary" data-route="#cardio-pathology/${p.id}">Открыть полный разбор</button>${(p.cards||[]).length?renderContextCards((p.cards||[]).slice(0,1),p.title):''}`})).join('')}</div>${renderContextTests('diseases')}`;}

export function renderCardioPathologyDetail(id){const p=CARDIO_PATHOLOGIES.find(x=>x.id===id);if(!p){location.hash='#system/cardiovascular/pathophysiology';return;}app.innerHTML=header()+`<div class="page"><div class="breadcrumb"><button data-route="#system/cardiovascular">ССС</button><span>›</span><button data-route="#system/cardiovascular/pathophysiology">Патофизиология</button><span>›</span><span>${esc(p.title)}</span></div>${renderCardioPathologyCard(p,true)}</div>`+bottomNav('study');bindNav();bindTestStarters();}

export function renderCardioTargets(){return `<div class="accordionStack">${CARDIO_TARGETS.map(t=>accordion({id:`target-${t.id}`,title:t.title,level:2,body:[accordion({id:`target-${t.id}-terms`,title:'Термины',level:3,body:renderAbbreviationLead([t.title,t.mechanism,t.effect].join(' '))||'<p class="smallMuted">Нет дополнительных сокращений.</p>'}),accordion({id:`target-${t.id}-mechanism`,title:'Механизм',level:3,body:renderLearningWhiteboard({title:t.title,steps:t.mechanism.split('→').map(x=>x.trim()),area:'biochemistry',showSources:true})}),accordion({id:`target-${t.id}-effect`,title:'Фармакологический эффект',level:3,body:`<p>${esc(t.effect)}</p>`}),accordion({id:`target-${t.id}-drugs`,title:'Связанные препараты',level:3,body:cardioDrugChips(t.drugIds)}),accordion({id:`target-${t.id}-cards`,title:'Карточки',level:3,body:renderContextCards([[`Назови ключевой эффект воздействия на ${t.title}`,t.effect]],t.title)})].join('')})).join('')}</div>${renderContextTests('targets')}`;}

export function renderCardioDiagnostics(){return renderCardioKnowledge(CARDIO_DIAGNOSTICS,'diagnostics');}

export function renderCardioCards(){const groups=['physiology','biochemistry','pathophysiology','diagnostics','targets'];return `<div class="flashStats"><span class="badge blue">${CARDIO_FLASHCARDS.length} карточек ССС</span></div><div class="accordionStack">${groups.map(area=>{const arr=CARDIO_FLASHCARDS.filter(c=>c.area===area),title={physiology:'Анатомия и физиология',biochemistry:'Биохимия',pathophysiology:'Патофизиология',diagnostics:'Диагностика',targets:'Фармакологические мишени'}[area];return accordion({id:`cards-${area}`,title,level:2,badge:String(arr.length),body:`<div class="miniFlashGrid">${arr.map(c=>`<details class="miniFlash"><summary>${esc(c.front)}</summary>${renderAbbreviationLead(c.front+' '+c.back)}<p>${esc(c.back)}</p></details>`).join('')}</div>`})}).join('')}</div>`;}
