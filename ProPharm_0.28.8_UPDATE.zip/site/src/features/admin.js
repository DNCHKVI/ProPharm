import { authState } from '../../services/authService.js';
import { listAdminActions,adminSetContentAccess } from '../../services/authService.js';
import { app, esc } from '../core/shared.js';
import { toast } from '../ui/personal.js';
import { header, bottomNav, bindNav } from '../ui/shell.js';
import { SUPABASE_CONFIG } from '../../config/supabase-config.js';
import { isAdmin, listUsersForAdmin, adminPendingCount, listAdminNotifications, markAdminNotificationsRead, subscribeAdminApplications, savePushSubscription, deletePushSubscription, adminSetStatus } from '../../services/authService.js';
import { adminState } from '../core/admin-state.js';

export let stopAdminApplications=null;

export const ADMIN_NOTIFICATION_KEY="propharm_admin_notifications_enabled_v1";

export function notificationPermission(){return typeof Notification!=="undefined"?Notification.permission:"unsupported"}

export function canUseWebPush(){return !!(navigator.serviceWorker&&window.PushManager&&typeof Notification!=="undefined")}

export function urlBase64ToUint8Array(base64String){
  const padding='='.repeat((4-base64String.length%4)%4),base64=(base64String+padding).replace(/-/g,'+').replace(/_/g,'/');
  const raw=atob(base64),arr=new Uint8Array(raw.length);for(let i=0;i<raw.length;i++)arr[i]=raw.charCodeAt(i);return arr;
}

export async function setAdminAppBadge(count=adminState.pendingTotal){
  try{if('setAppBadge' in navigator){if(count>0)await navigator.setAppBadge(count);else if('clearAppBadge' in navigator)await navigator.clearAppBadge();}}catch{}
}

export async function showAdminApplicationNotification(row={}){
  if(notificationPermission()!=="granted")return;
  const title="Новая заявка ProPharm";
  const body=row.title||row.message||"Новый пользователь ожидает подтверждения.";
  const options={body,icon:"./icons/icon-192.png",badge:"./icons/icon-192.png",tag:`propharm-application-${row.target_user_id||row.id||Date.now()}`,data:{url:"#admin"}};
  try{
    const reg=await navigator.serviceWorker?.ready;
    if(reg?.showNotification)await reg.showNotification(title,options);
    else if(typeof Notification!=="undefined")new Notification(title,options);
  }catch(e){console.warn("Notification failed",e)}
}

export async function requestAdminNotifications(){
  if(!isAdmin())throw new Error("Уведомления доступны только администратору");
  if(typeof Notification==="undefined")throw new Error("Этот браузер не поддерживает системные уведомления");
  const permission=await Notification.requestPermission();
  if(permission!=="granted")throw new Error("Разрешение на уведомления не предоставлено");
  localStorage.setItem(ADMIN_NOTIFICATION_KEY,"1");
  // Real Web Push when the PWA is completely closed is optional and requires a VAPID public key.
  const vapid=SUPABASE_CONFIG.notifications?.vapidPublicKey?.trim();
  if(vapid&&canUseWebPush()){
    const reg=await navigator.serviceWorker.ready;
    let sub=await reg.pushManager.getSubscription();
    if(!sub)sub=await reg.pushManager.subscribe({userVisibleOnly:true,applicationServerKey:urlBase64ToUint8Array(vapid)});
    await savePushSubscription(sub);
  }
  return permission;
}

export async function disableAdminNotifications(){
  localStorage.removeItem(ADMIN_NOTIFICATION_KEY);
  try{const reg=await navigator.serviceWorker?.ready,sub=await reg?.pushManager?.getSubscription();if(sub){await deletePushSubscription(sub.endpoint);await sub.unsubscribe();}}catch{}
}

export async function refreshAdminPendingCount(){
  if(!isAdmin()){adminState.pendingTotal=0;await setAdminAppBadge(0);return 0;}
  try{adminState.pendingTotal=await adminPendingCount();await setAdminAppBadge(adminState.pendingTotal);return adminState.pendingTotal}catch(e){console.warn("pending count",e);return adminState.pendingTotal}
}

export async function startAdminApplicationWatcher(){
  if(stopAdminApplications){try{await stopAdminApplications()}catch{} stopAdminApplications=null;}
  if(!isAdmin())return;
  await refreshAdminPendingCount();
  stopAdminApplications=await subscribeAdminApplications(async row=>{
    await refreshAdminPendingCount();
    toast(`Новая заявка${row.email?`: ${row.email}`:""}`);
    if(localStorage.getItem(ADMIN_NOTIFICATION_KEY)==="1")await showAdminApplicationNotification(row);
    if(location.hash==="#admin")renderAdmin();
  });
}

export async function renderAdmin(){
 const renderOwnerId=authState.user?.id,renderHash=location.hash;

 if(!isAdmin()){location.hash='#settings';return}
 if(authState.user?.id!==renderOwnerId||location.hash!==renderHash)return;app.innerHTML=header()+`<div class="page"><div class="paperTitle"><span class="handMini">Только владелец</span><h2>Администрирование</h2><p>Загружаю заявки…</p></div></div>`+bottomNav('settings');bindNav();
 try{
   const [users,notifications,actions]=await Promise.all([listUsersForAdmin(),listAdminNotifications(30).catch(()=>[]),listAdminActions(100)]);
   adminState.pendingTotal=users.filter(u=>u.status==='pending').length;await setAdminAppBadge(adminState.pendingTotal);
   const notifEnabled=localStorage.getItem(ADMIN_NOTIFICATION_KEY)==='1'&&notificationPermission()==='granted';
   const pushConfigured=!!SUPABASE_CONFIG.notifications?.vapidPublicKey?.trim();
   const pending=users.filter(u=>u.status==='pending'),others=users.filter(u=>u.status!=='pending');
   const renderUser=u=>`<div class="card adminUser ${u.status==='pending'?'pendingUser':''}"><div><div class="resultType">${esc(u.provider||'email')} · ${esc(u.role)}</div><h3 data-no-translate>${esc(u.name||u.email||u.user_id)}</h3><p data-no-translate>${esc(u.email||'')}</p><div class="chips"><span class="chip">${esc(u.status)}</span><span class="smallMuted">${esc((u.created_at||'').replace('T',' ').slice(0,16))}</span></div></div>${u.role==='admin'?`<span class="badge">bootstrap admin</span>`:`<div class="adminActions"><button data-content-access="${u.content_access==='full'?'standard':'full'}" data-access-user="${esc(u.user_id)}">${u.content_access==='full'?'Ограничить до базового доступа':'Открыть полный доступ'}</button><button class="approveBtn" data-admin-status="approved" data-user-id="${esc(u.user_id)}">Одобрить</button><button data-admin-status="rejected" data-user-id="${esc(u.user_id)}">Отклонить</button><button data-admin-status="blocked" data-user-id="${esc(u.user_id)}">Блокировать</button><button data-admin-status="pending" data-user-id="${esc(u.user_id)}">В pending</button></div>`}</div>`;
   if(authState.user?.id!==renderOwnerId||location.hash!==renderHash)return;app.innerHTML=header()+`<div class="page"><div class="paperTitle"><span class="handMini">Только владелец</span><h2>Администрирование</h2><p>Заявки теперь загружаются через защищённую admin-функцию Supabase, а новые регистрации приходят в реальном времени.</p></div>
   <div class="adminSummary"><span class="badge blue">${users.length} пользователей</span><span class="badge ${pending.length?'attentionBadge':''}">${pending.length} ожидают</span></div>
   <div class="card adminNotificationCard"><div><h3>Уведомления о новых заявках</h3><p>${notifEnabled?'Системные уведомления включены.':'Нажми кнопку, чтобы разрешить уведомления на этом устройстве.'}</p><p class="smallMuted">${pushConfigured?'Web Push настроен: уведомления могут приходить через установленное PWA даже когда интерфейс не открыт.':'Сейчас работают realtime + системные уведомления, пока ProPharm запущен. Для уведомлений при полностью закрытом PWA добавь VAPID public key и Edge Function по инструкции.'}</p></div><div class="adminNotifyActions"><button class="moduleButton" id="enableAdminNotifications">${notifEnabled?'Уведомления включены':'Включить уведомления'}</button>${notifEnabled?`<button class="moduleButton secondary" id="disableAdminNotifications">Выключить</button>`:''}<button class="moduleButton secondary" id="refreshApplications">Обновить заявки</button></div></div>
   <div class="sectionTitle"><h2>Новые заявки</h2><span class="muted">${pending.length}</span></div>${pending.length?`<div class="list">${pending.map(renderUser).join('')}</div>`:`<div class="emptyState"><b>Новых заявок нет</b><p>При новой регистрации список обновится автоматически.</p></div>`}
   <details class="sourceAccordion"><summary>Все пользователи (${others.length})</summary><div class="sourceAccordionBody"><div class="list">${others.map(renderUser).join('')}</div></div></details>
   ${notifications.length?`<details class="sourceAccordion"><summary>Журнал заявок (${notifications.length})</summary><div class="sourceAccordionBody"><div class="list">${notifications.map(n=>`<div class="adminNotificationRow"><b>${esc(n.title||'Новая заявка')}</b><p>${esc(n.message||'')}</p><span class="smallMuted">${esc((n.created_at||'').replace('T',' ').slice(0,16))}</span></div>`).join('')}</div></div></details>`:''}
   </div>`+bottomNav('settings');bindNav();
   document.querySelectorAll('[data-admin-status]').forEach(b=>b.addEventListener('click',async()=>{try{await adminSetStatus(b.dataset.userId,b.dataset.adminStatus);toast('Статус обновлён');await renderAdmin()}catch(e){toast(e.message||String(e),'bad')}}));
   document.getElementById('enableAdminNotifications')?.addEventListener('click',async()=>{try{await requestAdminNotifications();toast('Уведомления включены');await renderAdmin()}catch(e){toast(e.message||String(e),'bad')}});
   document.getElementById('disableAdminNotifications')?.addEventListener('click',async()=>{await disableAdminNotifications();toast('Уведомления выключены');await renderAdmin()});
   const audit=document.createElement('section');audit.className='adminAudit';audit.innerHTML=`<h2>Журнал административных действий</h2><p>Последние ${actions.length} событий. Время — на этом устройстве.</p><div class="tableWrap"><table><thead><tr><th>Время</th><th>Кто</th><th>Действие / объект</th><th>Изменение</th></tr></thead><tbody>${actions.map(a=>`<tr><td>${esc(new Date(a.created_at).toLocaleString('ru-RU'))}</td><td>${esc(users.find(u=>u.user_id===a.admin_user_id)?.email||a.admin_user_id||'Сервер / миграция')}</td><td>${esc(a.action)}<br>${esc(users.find(u=>u.user_id===a.target_user_id)?.email||a.resource_id||a.target_user_id||'')}</td><td><div>Было: ${esc(JSON.stringify(a.before_state||{}))}</div><div>Стало: ${esc(JSON.stringify(a.after_state||{}))}</div></td></tr>`).join('')}</tbody></table></div>`;app.querySelector('.page').appendChild(audit);
   app.querySelectorAll('[data-content-access]').forEach(b=>b.onclick=async()=>{b.disabled=true;try{await adminSetContentAccess(b.dataset.accessUser,b.dataset.contentAccess);await renderAdmin()}catch(e){toast(e.message,'bad');b.disabled=false;}});
   document.getElementById('refreshApplications')?.addEventListener('click',()=>renderAdmin());
   markAdminNotificationsRead().catch(()=>{});
 }catch(e){
   if(authState.user?.id!==renderOwnerId||location.hash!==renderHash)return;app.innerHTML=header()+`<div class="page"><div class="emptyState"><b>Не удалось загрузить пользователей</b><p>${esc(e.message||String(e))}</p><p class="smallMuted">Если в Supabase заявки видны, но здесь список пуст или появляется ошибка, выполни SQL-патч <b>004_content_roles_audit.sql</b>.</p></div></div>`+bottomNav('settings');bindNav();
 }
}
