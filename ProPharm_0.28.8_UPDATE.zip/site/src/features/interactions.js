import { app, esc } from '../core/shared.js';
import { doodleIcon } from '../ui/icons.js';
import { header, bottomNav, bindNav, accordion, bindAccordions } from '../ui/shell.js';
import { profileFor, drugSearchText } from '../features/drugs.js';
import { renderLearningWhiteboard } from '../ui/visuals.js';
import { systemIcon, systemAbbreviations } from '../features/systems.js';
import { DRUGS, INTERACTIONS, SYSTEMS, drugMap } from '../core/content.js';

export function interactionSeverity(level=''){const x=String(level).toUpperCase();if(x.includes('КРАС')||x.includes('RED'))return 3;if(x.includes('ОРАНЖ')||x.includes('ORANGE'))return 2;return 1;}

export function interactionCandidatesForDrug(d){
 const p=profileFor(d)||{},base=(p.interactions||[]).map((x,i)=>({id:`profile-${d.n}-${i}`,level:x.level||'ЖЁЛТЫЙ',title:x.text?.split(':')[0]||'Взаимодействие',text:x.text||'',source:'Карточка препарата'}));
 const linked=Object.values(INTERACTIONS).flat().filter(x=>(x.drugIds||[]).includes(d.n)).map(x=>({id:x.id,level:/risk|токс|кровотеч|аритм|SJS|AKI/i.test((x.summary||'')+' '+(x.note||''))?'ОРАНЖЕВЫЙ':'ЖЁЛТЫЙ',title:x.title,text:x.summary||'',chain:x.chain||[],source:'Структурированная база взаимодействий'}));
 const seen=new Set();return [...base,...linked].filter(x=>{const k=(x.title+'|'+x.text).toLowerCase();if(seen.has(k))return false;seen.add(k);return true}).sort((a,b)=>interactionSeverity(b.level)-interactionSeverity(a.level));
}

export function renderInteractionResults(d){const arr=interactionCandidatesForDrug(d);if(!arr.length)return `<div class="emptyState"><b>Структурированные взаимодействия не найдены</b><p>Открой карточку препарата для полной монографии.</p></div>`;
 return `<div class="interactionDrugHeader"><div class="iconFrame">${doodleIcon('interactions')}</div><div><h3>${esc(d.name)}</h3><p>${esc(d.group)}</p></div></div><div class="interactionDangerList">${arr.map(x=>accordion({id:`interaction-search-${d.n}-${x.id}`,title:x.title,subtitle:x.source,level:2,badge:x.level,body:`<div class="interactionSeverity severity-${interactionSeverity(x.level)}"><b>${esc(x.level)}</b></div><p>${esc(x.text)}</p>${x.chain?.length?renderLearningWhiteboard({title:'Механизм взаимодействия',steps:x.chain,showSources:false}):''}`})).join('')}</div>`;}

export function renderInteractionsHub(){
 app.innerHTML=header()+`<div class="page"><div class="paperTitle"><span class="handMini">Поиск по препарату</span><h2>Взаимодействия</h2><p>Начни вводить название препарата. Опасные взаимодействия выводятся первыми и раскрываются по нажатию.</p></div><div class="interactionSearchBox"><label for="interactionDrugSearch">Препарат</label><input id="interactionDrugSearch" autocomplete="off" placeholder="Например: amiodarone, warfarin, tramadol…"><div id="interactionSuggest" class="interactionSuggest"></div></div><div id="interactionResult"><div class="emptyState"><div class="big">${doodleIcon('interactions')}</div><b>Выбери препарат</b><p>Красные и оранжевые взаимодействия будут показаны вверху списка.</p></div></div></div>`+bottomNav('study');bindNav();
 const input=document.getElementById('interactionDrugSearch'),suggest=document.getElementById('interactionSuggest'),out=document.getElementById('interactionResult');
 const choose=d=>{input.value=d.name;suggest.innerHTML='';out.innerHTML=renderInteractionResults(d);bindAccordions(out)};
 input.addEventListener('input',()=>{const q=input.value.trim().toLowerCase();if(!q){suggest.innerHTML='';return}const found=DRUGS.filter(d=>drugSearchText(d).includes(q)).slice(0,10);suggest.innerHTML=found.map(d=>`<button type="button" data-drug-pick="${d.n}"><b>${esc(d.name)}</b><small>${esc(d.group)}</small></button>`).join('');suggest.querySelectorAll('[data-drug-pick]').forEach(b=>b.onclick=()=>choose(drugMap[String(b.dataset.drugPick)]));});
}

export function renderSystemAbbrHub(){app.innerHTML=header()+`<div class="page"><div class="paperTitle"><span class="handMini">Сначала расшифровка</span><h2>Аббревиатуры</h2><p>Словарь организован по новым системам.</p></div><div class="topicGrid">${SYSTEMS.map(s=>{const n=systemAbbreviations(s).length;return `<div class="card clickCard" data-route="#system/${s.id}/abbr"><div class="cardHead"><div class="iconFrame topicLineIcon">${systemIcon(s)}</div><div><h3>${esc(s.title)}</h3><p>${n} сокращений из текущего словаря</p></div></div></div>`}).join("")}</div></div>`+bottomNav("study");bindNav();}
