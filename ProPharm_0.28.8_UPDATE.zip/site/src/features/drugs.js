import { hasFullAccess } from '../core/access.js';
import { app, esc } from '../core/shared.js';
import { favoriteButton, reviewButton } from '../ui/personal.js';
import { header, bottomNav, bindNav } from '../ui/shell.js';
import { renderAbbreviationLead } from '../ui/abbreviations.js';
import { renderVisual } from '../ui/visuals.js';
import { drugRows } from '../features/topics.js';
import { renderProcessCommentary } from '../features/cardio.js';
import { TOPICS, DRUGS, INTERACTIONS, DRUG_KNOWLEDGE, DRUG_PROFILES, CARDIO49, TESTS, TEST_ANALYSES, topicMap, drugMap } from '../core/content.js';

export function profileFor(drugOrNumber){
  const n=typeof drugOrNumber==="object" ? drugOrNumber?.n : drugOrNumber;
  return n==null ? null : (DRUG_PROFILES[String(n)] || null);
}

export function profileSection(title,text,icon="•"){
  if(!text)return "";
  return `<details class="drugProfileSection"><summary><span><span class="profileSectionIcon">${esc(icon)}</span>${esc(title)}</span><span class="schemePlus">＋</span></summary><div class="drugProfileBody">${renderAbbreviationLead(text)}${String(text).split("\\n").filter(Boolean).map(x=>`<p>${esc(x)}</p>`).join("")}</div></details>`;
}

export function interactionRiskClass(level=""){
  const l=String(level).toUpperCase();
  if(l.includes("КРАСН"))return "riskRed";
  if(l.includes("ОРАНЖ"))return "riskOrange";
  if(l.includes("ЖЁЛТ")||l.includes("ЖЕЛТ"))return "riskYellow";
  if(l.includes("ЗЕЛЁН")||l.includes("ЗЕЛЕН"))return "riskGreen";
  return "riskGray";
}

export function renderProfileInteractions(profile){
  if(!profile)return "";
  const arr=Array.isArray(profile.interactions)?profile.interactions:[];
  if(arr.length){
    return `<details class="drugProfileSection"><summary><span><span class="profileSectionIcon">↔</span>Лекарственные взаимодействия</span><span class="schemePlus">＋</span></summary><div class="drugProfileBody"><div class="interactionProfileList">${arr.map(x=>`<div class="profileInteraction">${renderAbbreviationLead(x.text||"")}<span class="riskBadge ${interactionRiskClass(x.level)}">${esc(x.level||"СЕРЫЙ")}</span><p>${esc(x.text||"")}</p></div>`).join("")}</div></div></details>`;
  }
  return profileSection("Лекарственные взаимодействия",profile.interactionsText,"↔");
}

export function drugSearchText(d){
  const p=profileFor(d);
  return [
    d?.name,d?.group,
    ...(d?.topics||[]).map(x=>topicMap[x]?.title||x),
    p?.sourceTitle,p?.mnn,p?.groupSource,p?.basic,p?.indications,p?.contraindications,
    p?.mechanismText,p?.scheme,p?.routes,p?.pharmacodynamics,p?.pharmacokinetics,
    p?.adverseEffects,p?.interactionsText,p?.specialSituations,
    ...(p?.interactions||[]).flatMap(x=>[x.level,x.text])
  ].filter(Boolean).join(" ").toLowerCase();
}

export function renderAllDrugs(){const options=TOPICS.map(t=>`<option value="${t.id}">${esc(t.short)}</option>`).join("");app.innerHTML=header()+`<div class="page"><div class="sectionTitle"><h2>170 препаратов</h2><span class="muted">единая база</span></div><div class="toolbar"><input id="drugSearch" placeholder="Название или фармгруппа…"><select id="drugTopic"><option value="">Все темы</option>${options}</select></div><div id="allDrugList">${drugRows(DRUGS)}</div></div>`+bottomNav("study");bindNav();const s=document.getElementById("drugSearch"),f=document.getElementById("drugTopic"),out=document.getElementById("allDrugList");const apply=()=>{const q=s.value.toLowerCase(),topic=f.value;const rows=DRUGS.filter(d=>(!q||drugSearchText(d).includes(q))&&(!topic||d.topics.includes(topic)));out.innerHTML=drugRows(rows);bindNav();};s.addEventListener("input",apply);f.addEventListener("change",()=>{location.hash="#drugs"+(f.value?"/"+encodeURIComponent(f.value):"")});f.value=decodeURIComponent(location.hash.split("/")[1]||"");apply();}

export function testCommentForDrug(q,d){
  const a=TEST_ANALYSES.find(x=>x.questionId===q.id);
  const all=[];
  const generic=(a?.explanation||q.explanation||[]).filter(Boolean);
  if(generic.length) all.push(...generic);
  const name=(d.name||"").toLowerCase();
  const comments=Object.entries(a?.optionExplanations||q.optionExplanations||{}).filter(([key,text])=>{
    const opt=q.options?.find(o=>o.id===key)?.text||"";
    const hay=(opt+" "+text).toLowerCase();
    return hay.includes(name) || q.drugIds?.length===1;
  }).map(([key,text])=>`${key}: ${text}`);
  if(comments.length) all.push(...comments);
  return [...new Set(all)].slice(0,6);
}

export function renderRelatedTestComments(d,relatedTests){
  if(!relatedTests.length)return `<p class="smallMuted">Пока комментариев из тестов по этому препарату нет.</p>`;
  return `<div class="testCommentList">${relatedTests.slice(0,40).map(q=>{
    const comments=testCommentForDrug(q,d);
    return `<div class="testCommentCard"><div class="resultType">${esc(q.sectionTitle)} · №${q.number}</div>${comments.length?comments.map(x=>`<p>Комментарий: ${esc(x)}</p>`).join(""):`<p>Комментарий: ${esc((q.explanation||[]).join(" ")||"Вопрос связан с препаратом, но отдельный текстовый комментарий в источнике не сохранён.")}</p>`}</div>`;
  }).join("")}</div>`;
}

export function renderDrug(n){
  const d=drugMap[String(n)];if(!d){location.hash="#drugs";return;}
  const p=profileFor(d),cardio=CARDIO49[d.name],k=DRUG_KNOWLEDGE[String(d.n)],relatedTests=TESTS.filter(q=>q.drugIds?.includes(d.n));
  const relatedInteractions=Object.entries(INTERACTIONS).flatMap(([topic,arr])=>arr.map(x=>({...x,topic}))).filter(x=>x.drugIds?.includes(d.n));
  const sourceScheme=p?.schemeSteps?.length?`${renderVisual({title:"Схема механизма",kind:"flow",steps:p.schemeSteps,skipAbbr:true})}${renderProcessCommentary({commentary:p.schemeSteps.map((step,i)=>`${i+1}. ${step}`)})}`:"";
  app.innerHTML=header()+`<div class="page drugDetail">
    <div class="breadcrumb"><button data-route="#drugs">170 препаратов</button><span>›</span><span>#${d.n}</span></div>
    <div class="topicHeader"><div class="iconFrame">Rx</div><div><h2>${esc(p?.mnn||d.name)}</h2><p>${esc(p?.groupSource||d.group)}</p><div class="chips"><span class="badge blue">№ ${d.n}</span>${d.topics.map(x=>`<span class="badge">${esc(topicMap[x]?.short||x)}</span>`).join("")}</div><div class="entityActions">${favoriteButton("drug",d.n,"Избранное")}${reviewButton("drug",d.n,"Повторить")}</div></div></div>

    <div class="sourceNote profileSourceWarning"><b>Учебная карточка ProPharm v1.0.</b> Данные перенесены из загруженной базы. Точные регуляторные формулировки и PK-числа в исходнике отмечены как требующие второго прохода сверки по Israeli Drug Registry, FDA/Drugs@FDA и ГРЛС.</div>

    <div class="drugProfileAccordion">
      ${profileSection("Основная информация",p?.basic,"i")}
      ${profileSection("Показания к применению",p?.indications,"+")}
      ${profileSection("Противопоказания и ограничения",p?.contraindications,"!")}
      ${p?.mechanismText?`<details class="drugProfileSection" open><summary><span><span class="profileSectionIcon">→</span>Механизм действия</span><span class="schemePlus">＋</span></summary><div class="drugProfileBody">${renderAbbreviationLead((p.mechanismText||"")+" "+(p.scheme||""))}<p>${esc(p.mechanismText)}</p>${sourceScheme}</div></details>`:""}
      ${profileSection("Способы применения",p?.routes,"↗")}
      ${profileSection("Фармакодинамика",p?.pharmacodynamics,"PD")}
      ${profileSection("Фармакокинетика",p?.pharmacokinetics,"PK")}
      ${profileSection("Побочные эффекты",p?.adverseEffects,"⚠")}
      ${renderProfileInteractions(p)}
      ${profileSection("Особые ситуации",p?.specialSituations,"★")}
      ${profileSection("Источники для верификации",p?.sources,"≡")}
    </div>

    ${k?`<div class="detailBox"><h3>Дополнительные экзаменационные комментарии</h3>${k.pearls?.map(x=>`<p>• ${esc(x)}</p>`).join("")||""}${k.visual?renderVisual(k.visual):""}</div>`:""}
    ${cardio&&hasFullAccess()?`<div class="detailBox noteCardio"><h3>Связь с электрофизиологией ССС</h3><p>${esc(cardio.note)}</p><a class="moduleButton" href="#cardio-lab">Открыть Cardio-модуль</a></div>`:""}
    ${relatedInteractions.length?`<div class="detailBox"><h3>Дополнительные взаимодействия из тестовой базы</h3>${relatedInteractions.map(x=>`<div class="interactionMini"><b>${esc(x.title)}</b><div>${esc(x.summary)}</div>${renderVisual({title:"Механизм",kind:"flow",steps:x.chain||[]})}</div>`).join("")}</div>`:""}
    <div class="detailBox"><h3>Комментарии из связанных тестов</h3><p class="smallMuted">Сам вопрос здесь не дублируется — показаны только учебные комментарии.</p>${renderRelatedTestComments(d,relatedTests)}</div>
  </div>`+bottomNav("study");bindNav();
}
