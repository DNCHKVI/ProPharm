import { app, esc, UI_SETTINGS_KEY, applyUiSettings } from '../core/shared.js';
import { refreshAdminPendingCount } from '../features/admin.js';
import { authBadge, toast, favoriteButton, reviewButton, resolvePersonalEntity } from '../ui/personal.js';
import { capsuleLogo } from '../ui/icons.js';
import { header, bottomNav, bindNav } from '../ui/shell.js';
import { systemSourceTopics } from '../features/systems.js';
import { renderSystemAbbrHub } from '../features/interactions.js';
import { router } from '../core/router.js';
import { SYSTEMS, TESTS } from '../core/content.js';
import { authState, isAuthConfigured, isAdmin, signInWithPassword, signUpWithPassword, signOut, resetPassword, updatePassword, updateOwnProfile, refreshProfile } from '../../services/authService.js';
import { listFavorites, removeReview, listReview, getLearningStats, lastStudyRoute, saveUserSettings, hydrateFromCloud, syncPending } from '../../services/userData.js';
import { isTestsOnlyUser } from '../core/access.js';
import { preferences } from '../core/preferences.js';

export function renderSettingsHub(){
 const profile=authState.profile;
 if(isTestsOnlyUser()){
   app.innerHTML=header()+`<div class="page"><div class="paperTitle"><span class="handMini">Аккаунт</span><h2>Настройки</h2><p>Для этого аккаунта доступен только экзаменационный модуль тестов.</p>${authBadge()}</div>
   <div class="settingsList"><label class="settingRow"><span><b>Крупный текст</b><small>Увеличить шрифт интерфейса тестов</small></span><input type="checkbox" id="largeText" ${preferences.ui.largeText?"checked":""}></label><label class="settingRow"><span><b>Меньше анимаций</b><small>Уменьшить движение элементов</small></span><input type="checkbox" id="reducedMotion" ${preferences.ui.reducedMotion?"checked":""}></label></div>
   <div class="card"><h3>Режим доступа</h3><p data-no-translate><b>${esc(profile?.name||'Пользователь')}</b><br>${esc(profile?.email||'')}</p><p>Доступ: экзаменационные тесты. Названия остальных разделов остаются видимыми на главной странице, но открыть их нельзя.</p></div>
   <button class="moduleButton secondary" id="syncNow">Синхронизировать результаты тестов</button><button class="moduleButton dangerSoft" id="logoutBtn">Выйти из аккаунта</button></div>`+bottomNav("settings");
   bindNav();
   document.getElementById("largeText").onchange=e=>{preferences.ui.largeText=e.target.checked;localStorage.setItem(UI_SETTINGS_KEY,JSON.stringify(preferences.ui));saveUserSettings(preferences.ui).catch(()=>{});applyUiSettings()};
   document.getElementById("reducedMotion").onchange=e=>{preferences.ui.reducedMotion=e.target.checked;localStorage.setItem(UI_SETTINGS_KEY,JSON.stringify(preferences.ui));saveUserSettings(preferences.ui).catch(()=>{});applyUiSettings()};
   document.getElementById('syncNow')?.addEventListener('click',async()=>{try{await syncPending();await hydrateFromCloud();toast('Синхронизация завершена')}catch(e){toast(e.message||String(e),'bad')}});
   document.getElementById('logoutBtn')?.addEventListener('click',async()=>{await signOut();location.hash='#home';router()});
   return;
 }
 app.innerHTML=header()+`<div class="page"><div class="paperTitle"><span class="handMini">Под себя</span><h2>Настройки</h2><p>Интерфейс, аккаунт и синхронизация.</p>${authBadge()}</div>
 <div class="settingsList"><label class="settingRow"><span><b>Крупный текст</b><small>Увеличить шрифт интерфейса</small></span><input type="checkbox" id="largeText" ${preferences.ui.largeText?"checked":""}></label><label class="settingRow"><span><b>Меньше анимаций</b><small>Уменьшить движение элементов</small></span><input type="checkbox" id="reducedMotion" ${preferences.ui.reducedMotion?"checked":""}></label></div>
 <div class="sectionTitle"><h2>Аккаунт и учёба</h2></div><div class="sectionGrid profileGrid">
 <div class="card clickCard" data-route="#profile"><h3>Профиль</h3><p data-no-translate>${esc(profile?.name||profile?.email||'Профиль')}</p></div>
 <div class="card clickCard" data-route="#my-study"><h3>Моя учёба</h3><p>История тестов и успешность</p></div>
 <div class="card clickCard" data-route="#favorites"><h3>Избранное</h3><p>Сохранённые материалы</p></div>
 <div class="card clickCard" data-route="#review"><h3>Повторить</h3><p>Очередь слабых тем</p></div>
 ${isAdmin()?`<div class="card clickCard adminCard" data-route="#admin"><h3>Администрирование <span id="settingsPendingBadge" class="pendingDot" hidden>0</span></h3><p>Заявки, одобрение и уведомления</p></div>`:""}
 </div><button class="moduleButton secondary" id="syncNow">Синхронизировать сейчас</button><button class="moduleButton dangerSoft" id="logoutBtn">Выйти из аккаунта</button></div>`+bottomNav("settings");bindNav();
 document.getElementById("largeText").onchange=e=>{preferences.ui.largeText=e.target.checked;localStorage.setItem(UI_SETTINGS_KEY,JSON.stringify(preferences.ui));saveUserSettings(preferences.ui).catch(()=>{});applyUiSettings()};
 document.getElementById("reducedMotion").onchange=e=>{preferences.ui.reducedMotion=e.target.checked;localStorage.setItem(UI_SETTINGS_KEY,JSON.stringify(preferences.ui));saveUserSettings(preferences.ui).catch(()=>{});applyUiSettings()};
 document.getElementById('syncNow')?.addEventListener('click',async()=>{try{await syncPending();await hydrateFromCloud();toast('Синхронизация завершена')}catch(e){toast(e.message||String(e),'bad')}});
 document.getElementById('logoutBtn')?.addEventListener('click',async()=>{await signOut();location.hash='#home';router()});
 if(isAdmin())refreshAdminPendingCount().then(n=>{const b=document.getElementById('settingsPendingBadge');if(b){b.textContent=String(n);b.hidden=!n}}).catch(()=>{});
}

export function renderAbbrHub(){return renderSystemAbbrHub();}

export async function renderProfile(){
 const renderOwnerId=authState.user?.id,renderHash=location.hash;

 const p=authState.profile||{};
 if(isTestsOnlyUser()){
   if(authState.user?.id!==renderOwnerId||location.hash!==renderHash)return;app.innerHTML=header()+`<div class="page"><div class="paperTitle"><span class="handMini">Мой ProPharm</span><h2>Профиль</h2><p>Данные аккаунта и режим доступа.</p>${authBadge()}</div>
   <div class="profileHero"><div class="profileAvatar" data-no-translate>${esc((p.name||p.email||'P').slice(0,1).toUpperCase())}</div><div><h3 data-no-translate>${esc(p.name||'Пользователь')}</h3><p data-no-translate>${esc(p.email||'')}</p><div class="chips"><span class="chip">${esc(p.provider||'email')}</span><span class="chip">${esc(p.status||'approved')}</span><span class="chip">тесты · препараты · взаимодействия</span></div></div></div>
   ${isAuthConfigured()?`<div class="card"><h3>Имя профиля</h3><div class="inlineForm"><input id="profileName" value="${esc(p.name||'')}" placeholder="Имя"><button class="drugLink" id="saveProfile">Сохранить</button></div></div>`:''}
   <div class="sectionGrid"><div class="card clickCard" data-route="#tests"><h3>Тесты</h3><p>Доступный учебный раздел</p></div><div class="card clickCard" data-route="#my-study"><h3>Моя статистика</h3><p>Результаты и прогресс</p></div><div class="card clickCard" data-route="#weak-topics"><h3>Слабые темы</h3><p>Тренировка по ошибкам</p></div><div class="card clickCard" data-route="#home"><h3>Все разделы</h3><p>Посмотреть структуру ProPharm; закрытые разделы отображаются с блокировкой.</p></div><div class="card clickCard" data-route="#settings"><h3>Настройки</h3><p>Интерфейс, синхронизация и выход</p></div></div></div>`+bottomNav('settings');bindNav();
   document.getElementById('saveProfile')?.addEventListener('click',async()=>{try{await updateOwnProfile({name:document.getElementById('profileName').value});toast('Профиль сохранён');renderProfile()}catch(e){toast(e.message||String(e),'bad')}});
   return;
 }
 if(authState.user?.id!==renderOwnerId||location.hash!==renderHash)return;app.innerHTML=header()+`<div class="page"><div class="paperTitle"><span class="handMini">Мой ProPharm</span><h2>Профиль</h2><p>Данные аккаунта и способы входа.</p>${authBadge()}</div>
 <div class="profileHero"><div class="profileAvatar" data-no-translate>${esc((p.name||p.email||'P').slice(0,1).toUpperCase())}</div><div><h3 data-no-translate>${esc(p.name||'Пользователь')}</h3><p data-no-translate>${esc(p.email||'')}</p><div class="chips"><span class="chip">${esc(p.provider||'email')}</span><span class="chip">${esc(p.status||'pending')}</span><span class="chip">${esc(p.role||'user')}</span></div></div></div>
 ${isAuthConfigured()?`<div class="card"><h3>Имя профиля</h3><div class="inlineForm"><input id="profileName" value="${esc(p.name||'')}" placeholder="Имя"><button class="drugLink" id="saveProfile">Сохранить</button></div></div><div class="card"><h3>Способ входа</h3><p>Авторизация ProPharm настроена только через подтверждённый e-mail и пароль.</p></div>`:''}
 <div class="sectionGrid"><div class="card clickCard" data-route="#my-study"><h3>Моя учёба</h3><p>Статистика и история тестов</p></div><div class="card clickCard" data-route="#favorites"><h3>Избранное</h3><p>Сохранённые сущности</p></div><div class="card clickCard" data-route="#review"><h3>Повторить</h3><p>Материал для повторения</p></div><div class="card clickCard" data-route="${esc(lastStudyRoute())}"><h3>Продолжить обучение</h3><p>${esc(lastStudyRoute())}</p></div></div></div>`+bottomNav('settings');bindNav();
 document.getElementById('saveProfile')?.addEventListener('click',async()=>{try{await updateOwnProfile({name:document.getElementById('profileName').value});toast('Профиль сохранён');renderProfile()}catch(e){toast(e.message||String(e),'bad')}});
}

export async function renderMyStudy(){
 const renderOwnerId=authState.user?.id,renderHash=location.hash;

 if(authState.user?.id!==renderOwnerId||location.hash!==renderHash)return;app.innerHTML=header()+`<div class="page"><div class="paperTitle"><span class="handMini">Персональная статистика</span><h2>Моя учёба</h2><p>Загружаю локальную историю…</p></div></div>`+bottomNav('settings');bindNav();
 const st=await getLearningStats();
 const recent=[...st.sessions].sort((a,b)=>String(b.completed_at||b.created_at).localeCompare(String(a.completed_at||a.created_at))).slice(0,12);
 const weak=[...st.questions].filter(x=>(x.wrong_count||0)>0).sort((a,b)=>(b.wrong_count||0)-(a.wrong_count||0)).slice(0,10);
 const systemStats=SYSTEMS.map(system=>{
   const source=new Set(systemSourceTopics(system));
   const rows=st.questions.filter(r=>{const q=TESTS.find(x=>x.id===r.question_id);return q&&source.has(q.topic)});
   const correct=rows.reduce((n,r)=>n+(r.correct_count||0),0),wrong=rows.reduce((n,r)=>n+(r.wrong_count||0),0),attempts=rows.reduce((n,r)=>n+(r.attempts||0),0),first=rows.reduce((n,r)=>n+(r.first_try_correct_count||0),0);
   return {system,rows:rows.length,attempts,wrong,accuracy:(correct+wrong)?Math.round(correct/(correct+wrong)*100):0,firstTry:attempts?Math.round(first/attempts*100):0};
 }).filter(x=>x.attempts>0);
 if(authState.user?.id!==renderOwnerId||location.hash!==renderHash)return;app.innerHTML=header()+`<div class="page"><div class="paperTitle"><span class="handMini">Персональная статистика</span><h2>Моя учёба</h2><p>История хранится локально и при настроенном аккаунте синхронизируется между устройствами.</p></div>
 <div class="stats learningStats"><div class="stat"><b>${st.sessions.length}</b><span>тестовых сессий</span></div><div class="stat"><b>${st.accuracy}%</b><span>точность выборов</span></div><div class="stat"><b>${st.firstTryRate}%</b><span>с 1-й попытки</span></div><div class="stat"><b>${st.wrong}</b><span>ошибочных выборов</span></div></div>
 <div class="quickStudy"><button class="moduleButton" data-route="${esc(lastStudyRoute())}">Продолжить обучение</button><button class="moduleButton secondary" data-route="#review">Повторить слабые темы (${st.review.length})</button></div>
 <div class="sectionTitle"><h2>По системам</h2><span class="muted">${systemStats.length}</span></div>${systemStats.length?`<div class="list systemProgressList">${systemStats.map(x=>`<div class="theoryCard"><div class="resultType">${esc(x.system.short||x.system.title)}</div><h3>${x.accuracy}% точность</h3><p>С первой попытки: ${x.firstTry}% · прохождений вопросов: ${x.attempts} · ошибочных выборов: ${x.wrong}</p><button class="drugLink" data-route="#system/${x.system.id}">Открыть систему</button></div>`).join('')}</div>`:`<div class="emptyState"><b>Статистики по системам пока нет</b><p>Она появится после прохождения тематических тестов.</p></div>`}
 <div class="sectionTitle"><h2>Последние тесты</h2><span class="muted">${recent.length}</span></div>${recent.length?`<div class="list">${recent.map(x=>`<div class="theoryCard"><div class="resultType">${esc(x.test_id||'Тест')}</div><h3>${Number(x.score||0).toFixed(0)}% с первой попытки</h3><p>${x.first_try_correct||0}/${x.questions_total||0} с первой попытки · ошибок выбора: ${x.wrong_selections||0}</p><div class="smallMuted">${esc((x.completed_at||x.created_at||'').replace('T',' ').slice(0,16))}</div></div>`).join('')}</div>`:`<div class="emptyState"><b>Истории пока нет</b><p>Пройди первый тест — результат появится здесь.</p></div>`}
 <div class="sectionTitle"><h2>Слабые вопросы</h2></div>${weak.length?`<div class="list">${weak.map(x=>{const q=TESTS.find(q=>q.id===x.question_id);return `<div class="theoryCard"><h3>${esc(q?.question||x.question_id)}</h3><p>Ошибочных выборов: ${x.wrong_count||0} · прохождений: ${x.attempts||0}</p>${reviewButton('question',x.question_id,'Повторить')}</div>`}).join('')}</div>`:`<div class="emptyState"><b>Слабых вопросов пока не выявлено</b></div>`}</div>`+bottomNav('settings');bindNav();
}

export async function renderFavorites(){
 const renderOwnerId=authState.user?.id,renderHash=location.hash;

 const rows=await listFavorites();const resolved=rows.map(x=>({...x,info:resolvePersonalEntity(x.entity_type,x.entity_id)})).filter(x=>x.info);
 if(authState.user?.id!==renderOwnerId||location.hash!==renderHash)return;app.innerHTML=header()+`<div class="page"><div class="paperTitle"><span class="handMini">Сохранённое</span><h2>Избранное</h2><p>Препараты, заболевания, механизмы, карточки и вопросы привязаны к твоему профилю.</p></div>${resolved.length?`<div class="list">${resolved.map(x=>`<div class="card personalRow"><div><div class="resultType">${esc(x.entity_type)}</div><h3>${esc(x.info.title)}</h3><p>${esc(x.info.subtitle||'')}</p></div><div class="rowActions">${favoriteButton(x.entity_type,x.entity_id,'Удалить')}<button class="drugLink" data-route="${esc(x.info.route)}">Открыть</button></div></div>`).join('')}</div>`:`<div class="emptyState"><div class="big">♡</div><b>Избранное пока пусто</b><p>Нажимай ♡ возле препаратов и других учебных сущностей.</p></div>`}</div>`+bottomNav('settings');bindNav();
}

export async function renderReview(){
 const renderOwnerId=authState.user?.id,renderHash=location.hash;

 const rows=await listReview();const resolved=rows.map(x=>({...x,info:resolvePersonalEntity(x.entity_type,x.entity_id)}));
 if(authState.user?.id!==renderOwnerId||location.hash!==renderHash)return;app.innerHTML=header()+`<div class="page"><div class="paperTitle"><span class="handMini">Активное повторение</span><h2>Повторить</h2><button class="moduleButton" data-route="#weak-topics">Тренировать слабые темы</button><p>Отдельно от избранного: сюда попадает материал, который нужно закрепить.</p></div>${resolved.length?`<div class="list">${resolved.map(x=>`<div class="card personalRow"><div><div class="resultType">${esc(x.reason||'manual')}</div><h3>${esc(x.info?.title||x.entity_id)}</h3><p>${esc(x.info?.subtitle||'')}</p></div><div class="rowActions"><button class="miniAction" data-remove-review="${esc(x.entity_type)}|${esc(x.entity_id)}">✓ Готово</button>${x.info?.route?`<button class="drugLink" data-route="${esc(x.info.route)}">Открыть</button>`:''}</div></div>`).join('')}</div>`:`<div class="emptyState"><div class="big">↻</div><b>Очередь повторения пуста</b></div>`}</div>`+bottomNav('settings');bindNav();
 document.querySelectorAll('[data-remove-review]').forEach(b=>b.addEventListener('click',async()=>{const [t,id]=b.dataset.removeReview.split('|');await removeReview(t,id);renderReview()}));
}

export function renderAuthLoading(){app.innerHTML=`<div class="authPage"><div class="authCard"><div class="authLogo">${capsuleLogo('authCapsuleLogo')}</div><h1>ProPharm</h1><p>Проверяем аккаунт…</p><div class="authSpinner"></div></div></div>`}

export function renderAuthProfileError(){
 const raw=authState.error?.message||String(authState.error||'');
 const detail=raw?`Техническая причина: ${raw}`:'Сервер не вернул данные профиля.';
 app.innerHTML=`<div class="authPage"><div class="authCard authUnavailable"><div class="authLogo">${capsuleLogo('authCapsuleLogo')}</div><h1>Не удалось загрузить профиль</h1><p>Сессия входа сохранена, но Supabase не подтвердил статус профиля.</p><div class="sourceNote">${esc(detail)}</div><button class="moduleButton" id="retryProfile">Повторить загрузку</button><button class="moduleButton secondary" id="profileErrorLogout">Выйти из аккаунта</button></div></div>`;
 document.getElementById('retryProfile').onclick=async e=>{e.currentTarget.disabled=true;e.currentTarget.textContent='Проверяем…';await refreshProfile();router()};
 document.getElementById('profileErrorLogout').onclick=async()=>{await signOut();location.hash='#login';router()};
}

export function renderAuthUnconfigured(){app.innerHTML=`<div class="authPage"><div class="authCard authUnavailable"><div class="authLogo">${capsuleLogo('authCapsuleLogo')}</div><h1>ProPharm ещё не подключён</h1><p>Система пользовательских аккаунтов ещё не настроена владельцем приложения. Учебные материалы временно недоступны.</p><div class="sourceNote"><b>Для владельца:</b> настрой Supabase согласно <code>docs/SUPABASE_SETUP_RU.md</code>, затем укажи публичные URL и publishable/anon key в конфигурации.</div></div></div>`}

export function renderLogin(){
 app.innerHTML=`<div class="authPage"><div class="authCard"><div class="authLogo">${capsuleLogo('authCapsuleLogo')}</div><h1>ProPharm</h1><p>Войди в учебный профиль</p><form id="loginForm"><label>E-mail<input type="email" id="loginEmail" autocomplete="email" required></label><label>Пароль<input type="password" id="loginPassword" autocomplete="current-password" required></label><button class="moduleButton" type="submit">Войти</button></form><div class="authLinks"><button data-route="#register">Создать аккаунт</button><button id="forgotPassword">Забыли пароль?</button></div><p class="authPrivacyNote">Учебные материалы доступны только авторизованным и одобренным пользователям ProPharm.</p><div id="authMessage" class="authMessage"></div></div></div>`;bindNav();
 document.getElementById('loginForm').onsubmit=async e=>{e.preventDefault();try{await signInWithPassword(document.getElementById('loginEmail').value,document.getElementById('loginPassword').value);router()}catch(err){showAuthError(err)}};
 document.getElementById('forgotPassword').onclick=async()=>{const email=document.getElementById('loginEmail').value;if(!email)return showAuthError(new Error('Сначала введи e-mail'));try{await resetPassword(email);document.getElementById('authMessage').textContent='Ссылка для восстановления отправлена.'}catch(e){showAuthError(e)}};
}

export function renderRegister(){
 app.innerHTML=`<div class="authPage"><div class="authCard"><div class="authLogo">${capsuleLogo('authCapsuleLogo')}</div><h1>Создание аккаунта</h1><p>Создай учебный профиль. Подтверждение e-mail по ссылке не требуется: новый аккаунт сразу получает <b>user + pending</b> и ждёт одобрения администратора.</p><form id="registerForm"><label>Имя<input id="registerName" autocomplete="name" required></label><label>E-mail<input type="email" id="registerEmail" autocomplete="email" required></label><label>Пароль<input type="password" id="registerPassword" minlength="8" autocomplete="new-password" required></label><label>Повторите пароль<input type="password" id="registerPassword2" minlength="8" autocomplete="new-password" required></label><button class="moduleButton" type="submit">Создать учебный аккаунт</button></form><div class="authLinks"><button data-route="#login">Уже есть аккаунт? Войти</button></div><p class="authPrivacyNote">Учебные материалы откроются только после одобрения администратора ProPharm.</p><div id="authMessage" class="authMessage"></div></div></div>`;
 bindNav();
 document.getElementById('registerForm').onsubmit=async e=>{e.preventDefault();const a=document.getElementById('registerPassword').value,b=document.getElementById('registerPassword2').value;if(a!==b)return showAuthError(new Error('Пароли не совпадают'));const btn=e.currentTarget.querySelector('button[type="submit"]');try{btn.disabled=true;btn.textContent='Создаём профиль…';await signUpWithPassword(document.getElementById('registerName').value,document.getElementById('registerEmail').value,a);location.hash='#home';router()}catch(err){btn.disabled=false;btn.textContent='Создать учебный аккаунт';showAuthError(err)}};
}

export function showAuthError(err){const x=document.getElementById('authMessage');if(x){x.textContent=err?.message||String(err);x.classList.add('error')}else toast(err?.message||String(err),'bad')}

export function renderResetPassword(){app.innerHTML=`<div class="authPage"><div class="authCard"><div class="authLogo">${capsuleLogo('authCapsuleLogo')}</div><h1>Новый пароль</h1><p>Установи новый пароль для текущей recovery-сессии.</p><form id="resetPasswordForm"><label>Новый пароль<input type="password" id="newPassword" minlength="8" required autocomplete="new-password"></label><label>Повтори пароль<input type="password" id="newPassword2" minlength="8" required autocomplete="new-password"></label><button class="moduleButton" type="submit">Сохранить пароль</button></form><div id="authMessage" class="authMessage"></div></div></div>`;document.getElementById('resetPasswordForm').onsubmit=async e=>{e.preventDefault();const a=document.getElementById('newPassword').value,b=document.getElementById('newPassword2').value;if(a!==b)return showAuthError(new Error('Пароли не совпадают'));try{await updatePassword(a);document.getElementById('authMessage').textContent='Пароль обновлён.';setTimeout(()=>{location.hash='#settings'},700)}catch(err){showAuthError(err)}}}

export function renderAccessState(status){
 const map={pending:['Аккаунт создан','Ваш профиль ожидает подтверждения администратора ProPharm. До подтверждения учебные материалы недоступны.'],blocked:['Доступ ограничен','Доступ к аккаунту ограничен администратором.'],rejected:['Заявка отклонена','Администратор отклонил запрос на доступ.']},[title,text]=map[status]||['Доступ недоступен','Проверь статус аккаунта.'];
 const p=authState.profile||{},provider=p.provider||authState.user?.app_metadata?.provider||'email';
 app.innerHTML=`<div class="authPage"><div class="authCard"><div class="authLogo">${capsuleLogo('authCapsuleLogo')}</div><h1>${esc(title)}</h1><p>${esc(text)}</p><div class="pendingIdentity"><b>${esc(p.name||authState.user?.email||'Пользователь')}</b><span>${esc(p.email||authState.user?.email||'')}</span><span>${esc(provider)} · ${esc(status||'pending')}</span></div><button class="moduleButton" id="refreshAccess">Обновить статус</button><button class="moduleButton secondary" id="accessLogout">Выйти</button></div></div>`;
 document.getElementById('refreshAccess').onclick=async()=>{await refreshProfile();router()};
 document.getElementById('accessLogout').onclick=async()=>{await signOut();location.hash='#login';router()};
}
