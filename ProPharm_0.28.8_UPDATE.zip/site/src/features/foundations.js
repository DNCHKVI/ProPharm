import { FULL_UI_TEXT } from '../core/content.js';
import { app, esc } from '../core/shared.js';
import { doodleIcon } from '../ui/icons.js';
import { header, bottomNav, bindNav, accordion } from '../ui/shell.js';
import { renderAbbreviationLead } from '../ui/abbreviations.js';
import { profileFor } from '../features/drugs.js';
import { renderLearningWhiteboard } from '../ui/visuals.js';
import { DRUGS, ACADEMIC_SOURCES, FOUNDATIONAL_SECTIONS, CHEMISTRY_CONTENT, PHARMACOLOGY_FOUNDATIONS, DIURETIC_GROUPS, PERIODIC_ELEMENTS, LANTHANIDES, ACTINIDES, AB_GROUP_LABELS, SOLUBILITY_CATIONS, SOLUBILITY_ANIONS, SOLUBILITY_MATRIX, QUALITATIVE_REACTIONS, FLAME_TESTS, ORGANIC_QUALITATIVE, foundationContent, foundationalMap } from '../core/content.js';

export function chemistryWhiteboard(w){if(!w)return '';
 const nodes=(w.nodes||[]).map(([label,tone])=>`<span class="chemNode chem-${esc(tone||'neutral')}">${esc(label)}</span>`).join('<span class="chemArrow">→</span>');
 const arrows=(w.arrows||[]).map(x=>`<div class="chemFlowLine">${esc(x)}</div>`).join('');
 return `<div class="chemWhiteboard"><div class="chemNodeFlow">${nodes}</div>${arrows}</div>`;
}

export function chemistryTable(t){if(!t)return '';
 return `<div class="tableWrap chemTableWrap"><table class="studyTable chemTable"><thead><tr>${t.headers.map(x=>`<th>${esc(x)}</th>`).join('')}</tr></thead><tbody>${t.rows.map(r=>`<tr>${r.map((x,i)=>`<td>${esc(x)}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`;
}

export function chemistryCards(cards){if(!cards)return '';
 return `<div class="chemClassGrid">${cards.map(([a,b,c])=>`<div class="chemClassCard chem-${esc(c)}"><b>${esc(a)}</b><span>${esc(b)}</span></div>`).join('')}</div>`;
}

export function chemistryScale(items){if(!items)return '';
 return `<div class="chemScale" aria-label="Ряд активности металлов">${items.map((x,i)=>`<span class="${i<8?'activeMetal':'lessMetal'}">${esc(x)}</span>`).join('<b>›</b>')}</div>`;
}

export function renderChemistryTopic(sectionId,item){
 const terms=accordion({id:`chem-${item.id}-terms`,title:'Термины и обозначения',level:3,open:true,body:`<div class="theoryBody">${(item.terms||[]).map(x=>`<p>• ${esc(x)}</p>`).join('')}</div>`});
 const visual=(item.whiteboard?accordion({id:`chem-${item.id}-visual`,title:'Learning Whiteboard',level:3,open:true,body:chemistryWhiteboard(item.whiteboard)}):'')+(item.cards?accordion({id:`chem-${item.id}-classes`,title:'Классификация',level:3,body:chemistryCards(item.cards)}):'')+(item.scale?accordion({id:`chem-${item.id}-scale`,title:'Интерактивная шкала',level:3,body:chemistryScale(item.scale)}):'');
 const theory=accordion({id:`chem-${item.id}-theory`,title:'Теория',level:3,body:`<div class="theoryBody">${(item.theory||[]).map(x=>`<p>${esc(x)}</p>`).join('')}</div>`});
 const table=item.table?accordion({id:`chem-${item.id}-table`,title:'Таблица',level:3,body:chemistryTable(item.table)}):'';
 const reactions=item.reactions?.length?accordion({id:`chem-${item.id}-rx`,title:'Примеры реакций',level:3,body:`<div class="reactionList">${item.reactions.map(x=>`<code>${esc(x)}</code>`).join('')}</div>`}):'';
 const expert=accordion({id:`chem-${item.id}-expert`,title:'Совет эксперта',level:3,body:`<div class="expertTip">${esc(item.expert||'Связывай структуру, условия реакции и наблюдаемый результат.')}</div>`});
 const self=accordion({id:`chem-${item.id}-self`,title:'Проверь себя',level:3,body:`<ol class="selfCheck">${(item.self||[]).map(x=>`<li>${esc(x)}</li>`).join('')}</ol><div class="sourceNote"><b>Важно:</b> это блок самопроверки, а не новая запись в экзаменационной базе тестов.</div>`});
 return accordion({id:`chem-topic-${item.id}`,title:item.title,subtitle:item.subtitle||'',level:2,icon:doodleIcon('chemistry'),body:`<div class="accordionStack">${terms}${visual}${theory}${table}${reactions}${expert}${self}</div>`});
}

export function renderFoundationSources(ids=[],sourceText=''){
 const rows=(ids||[]).map(id=>ACADEMIC_SOURCES[id]).filter(Boolean);
 const academic=rows.length?`<div class="sourceMeta">${rows.map(x=>`<p><b>${esc(x.name)}</b> · ${esc(x.institution||'')}<br><span>${esc(x.use||'')}</span><br><a href="${esc(x.url)}" target="_blank" rel="noopener noreferrer">Открыть источник ↗</a></p>`).join('')}</div>`:'';
 const booklet=sourceText?`<div class="sourceNote"><b>Источник структуры/реакций:</b> ${esc(sourceText)}</div>`:'';
 return academic+booklet||'<p class="smallMuted">Источник будет добавлен после научной сверки.</p>';
}

export function renderFormulaList(xs=[]){return xs?.length?`<div class="formulaStack">${xs.map(x=>`<div class="formulaCard">${esc(x)}</div>`).join('')}</div>`:''}

export function renderSelfCheckCards(cards=[]){
 if(!cards?.length)return '';
 return `<div class="selfCardGrid">${cards.map((x,i)=>{const q=Array.isArray(x)?x[0]:x.question;const a=Array.isArray(x)?x[1]:x.answer;return `<details class="selfStudyCard"><summary><span class="selfCardNo">${i+1}</span><span>${esc(q||'Вопрос')}</span></summary><div class="selfStudyAnswer"><b>Ответ</b><p>${esc(a||'Открой теоретический блок выше и сформулируй ответ самостоятельно.')}</p></div></details>`}).join('')}</div><div class="sourceNote"><b>Проверь себя:</b> карточки относятся только к теоретическому разделу и не добавляются в глобальную экзаменационную базу «Тесты».</div>`;
}

export function renderNamedReactions(items=[]){
 if(!items?.length)return '';
 return `<div class="accordionStack">${items.map((r,i)=>accordion({id:`named-rxn-${i}`,title:r.name,level:4,body:`${r.chain?.length?renderLearningWhiteboard({title:r.name,steps:r.chain,area:'default',showSources:false}):''}${r.equation?`<div class="formulaCard">${esc(r.equation)}</div>`:''}<div class="theoryBody"><p><b>Что происходит.</b> ${esc(r.explanation||'')}</p></div>`})).join('')}</div>`;
}

export function renderExternalVisuals(items=[]){
 if(!items?.length)return '';
 return `<div class="externalVisualGrid">${items.map(x=>`<a class="externalVisualCard" href="${esc(x.url)}" target="_blank" rel="noopener noreferrer"><span class="externalVisualIcon">↗</span><div><b>${esc(x.title)}</b><p>${esc(x.note||'Открыть исходную визуализацию')}</p><small>${esc(x.url)}</small></div></a>`).join('')}</div>`;
}

export function renderAdvancedFoundationTopic(sectionId,item){
 const terms=item.terms?.length?accordion({id:`adv-${item.id}-terms`,title:'Термины и сокращения',level:3,open:true,body:`<div class="theoryBody">${item.terms.map(x=>`<p>• ${esc(x)}</p>`).join('')}</div>`}):'';
 const theory=accordion({id:`adv-${item.id}-theory`,title:'Теоретическая база',level:3,open:true,body:`<div class="theoryBody">${(item.theory||[]).map(x=>`<p>${esc(x)}</p>`).join('')}</div>${renderFormulaList(item.formulas||[])}`});
 const wb=item.steps?.length?accordion({id:`adv-${item.id}-wb`,title:'Learning Whiteboard: процесс',level:3,open:true,body:renderLearningWhiteboard({title:item.title,steps:item.steps,area:sectionId==='biochemistry-biology'?'biochemistry':'default',showSources:false})}):'';
 const tbl=item.table?accordion({id:`adv-${item.id}-table`,title:'Таблица',level:3,body:chemistryTable(item.table)}):'';
 const named=item.namedReactions?.length?accordion({id:`adv-${item.id}-named`,title:'Именные реакции / пробы',level:3,open:true,body:renderNamedReactions(item.namedReactions)}):'';
 const ext=item.externalVisuals?.length?accordion({id:`adv-${item.id}-external`,title:'Внешние визуальные справочники',level:3,open:true,body:renderExternalVisuals(item.externalVisuals)}):'';
 const cards=item.selfCards?.length?accordion({id:`adv-${item.id}-selfcards`,title:'Проверь себя — карточки',level:3,body:renderSelfCheckCards(item.selfCards)}):'';
 let extra='';
 if(sectionId==='general-chemistry'&&(item.id==='gc-periodicity'||item.id==='gc-periodic-tables'))extra+=renderPeriodicTables();
 if(sectionId==='general-chemistry'&&item.id==='gc-solubility')extra+=renderSolubilityTable();
 if(sectionId==='general-chemistry'&&item.id==='gc-qualitative')extra+=renderQualitativeReactions()+renderFlameTests();
 if(sectionId==='organic-chemistry'&&item.id==='oc-qualitative')extra+=renderOrganicQualitative();
 if(sectionId==='pharmacokinetics'&&item.chart)extra+=renderPkMiniChart(item.chart);
 const src=accordion({id:`adv-${item.id}-sources`,title:'Источники',level:3,body:renderFoundationSources(item.sourceIds||[],item.sourceText||'')});
 return accordion({id:`adv-topic-${item.id}`,title:item.title,subtitle:item.subtitle||'',level:2,icon:foundationIcon(sectionId),body:`<div class="accordionStack">${terms}${theory}${wb}${tbl}${named}${ext}${extra}${cards}${src}</div>`});
}

export function renderPkMiniChart(type){
 if(type==='steadyState')return accordion({id:'pk-chart-steady',title:(FULL_UI_TEXT["foundations-1"]||''),level:3,body:`${FULL_UI_TEXT["foundations-2"]||''}`});
 return accordion({id:'pk-chart-ct',title:(FULL_UI_TEXT["foundations-3"]||''),level:3,body:`${FULL_UI_TEXT["foundations-4"]||''}`});
}

export function renderPeriodicTables(){
 const make=(mode)=>{const heads=mode==='iupac'?Array.from({length:18},(_,i)=>String(i+1)):AB_GROUP_LABELS;const cells=[];for(let p=1;p<=7;p++){for(let g=1;g<=18;g++){const e=PERIODIC_ELEMENTS.find(x=>x[2]===p&&x[3]===g);cells.push(e?`<button class="periodicCell" data-el-title="${esc(e[4])}" title="${esc(e[4])}"><small>${e[1]}</small><b>${esc(e[0])}</b><span>${esc(e[4])}</span></button>`:`<span class="periodicEmpty"></span>`)} }return `<div class="periodicWrap"><div class="periodicHead">${heads.map(x=>`<span>${esc(x)}</span>`).join('')}</div><div class="periodicGrid">${cells.join('')}${FULL_UI_TEXT["foundations-5"]||''}${LANTHANIDES.map(x=>`<span title="${esc(x[2])}"><small>${x[1]}</small><b>${x[0]}</b></span>`).join('')}${FULL_UI_TEXT["foundations-6"]||''}${ACTINIDES.map(x=>`<span title="${esc(x[2])}"><small>${x[1]}</small><b>${x[0]}</b></span>`).join('')}</div></div>`};
 return accordion({id:'gc-periodic-tools',title:(FULL_UI_TEXT["foundations-7"]||''),level:3,body:`${FULL_UI_TEXT["foundations-8"]||''}${make('iupac')}${FULL_UI_TEXT["foundations-9"]||''}${make('ab')}${FULL_UI_TEXT["foundations-10"]||''}`});
}

export function renderSolubilityTable(){
 return accordion({id:'gc-solubility-full',title:(FULL_UI_TEXT["foundations-11"]||''),level:3,body:`${FULL_UI_TEXT["foundations-12"]||''}${SOLUBILITY_ANIONS.map(a=>`<th>${esc(a)}</th>`).join('')}</tr></thead><tbody>${SOLUBILITY_CATIONS.map(c=>`<tr><th>${esc(c)}</th>${(SOLUBILITY_MATRIX[c]||[]).map(v=>`<td class="sol-${v==='Р'?'R':v==='М'?'M':v==='Н'?'N':'D'}">${esc(v)}</td>`).join('')}</tr>`).join('')}${FULL_UI_TEXT["foundations-13"]||''}`});
}

export function reactionIcon(kind=''){const map={gas:'↑', 'precip-white':'↓ ◻','precip-blue':'↓ 🟦','precip-green':'↓ 🟩','precip-brown':'↓ 🟫','precip-cream':'↓ ◽','precip-yellow':'↓ 🟨'};return map[kind]||'→'}

export function renderQualitativeReactions(){return accordion({id:'gc-qualitative-table',title:'Качественные реакции: ион → реактив → визуальный признак',level:3,body:`<div class="qualGrid">${QUALITATIVE_REACTIONS.map(x=>`<div class="qualCard"><span class="qualSign">${reactionIcon(x.kind)}</span><div><b>${esc(x.ion)}</b><small>Реактив: ${esc(x.reagent)}</small><code>${esc(x.equation)}</code><p>${esc(x.sign)}</p></div></div>`).join('')}</div>`})}

export function renderFlameTests(){return accordion({id:'gc-flame-table',title:'Окрашивание пламени',level:3,body:`<div class="flameGrid">${FLAME_TESTS.map(x=>`<div class="flameCard"><span class="flame" style="--flame:${esc(x[2])}"></span><b>${esc(x[0])}</b><small>${esc(x[1])}</small></div>`).join('')}</div>`})}

export function renderOrganicQualitative(){return accordion({id:'oc-qual-table',title:'Справочник качественных реакций',level:3,body:`<div class="tableWrap"><table class="studyTable"><thead><tr><th>Фрагмент / класс</th><th>Реактив</th><th>Признак</th></tr></thead><tbody>${ORGANIC_QUALITATIVE.map(r=>`<tr>${r.map(x=>`<td>${esc(x)}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`})}

export function foundationDrugsForCategory(cat){return DRUGS.filter(d=>cat.match.test(d.name||''))}

export function renderDiureticNephron(){
 const rows=DIURETIC_GROUPS.map(g=>`<button class="nephronDrugBtn" data-diuretic="${g.id}"><b>${esc(g.title)}</b><small>${esc(g.segment)}</small></button>`).join('');
 const cards=DIURETIC_GROUPS.map(g=>`<div class="diureticDetail" data-diuretic-detail="${g.id}" hidden><div class="nephronMap"><div class="nephSeg pct ${g.segment.includes('Проксим')?'active':''}${FULL_UI_TEXT["foundations-15"]||''}${g.segment.includes('восход')?'active':''}${FULL_UI_TEXT["foundations-16"]||''}${g.segment.includes('дисталь')?'active':''}${FULL_UI_TEXT["foundations-17"]||''}${g.segment.includes('Собират')?'active':''}${FULL_UI_TEXT["foundations-18"]||''}${esc(g.target)}${FULL_UI_TEXT["foundations-19"]||''}${g.examples.map(esc).join(', ')}${FULL_UI_TEXT["foundations-20"]||''}${esc(g.acidBase)}</p></div>${renderLearningWhiteboard({title:`${g.title}${FULL_UI_TEXT["foundations-14"]||''}`,steps:g.steps,area:'default',showSources:false})}<div class="ionPanel">${Object.entries(g.effects).map(([ion,val])=>`<div><b>${ion}</b><span>${esc(val)}</span></div>`).join('')}</div></div>`).join('');
 return `${FULL_UI_TEXT["foundations-21"]||''}${rows}</div>${cards}</div>`;
}

export function bindDiureticModule(root=document){const btns=[...root.querySelectorAll('[data-diuretic]')],cards=[...root.querySelectorAll('[data-diuretic-detail]')];if(!btns.length)return;const show=id=>{btns.forEach(b=>b.classList.toggle('active',b.dataset.diuretic===id));cards.forEach(c=>c.hidden=c.dataset.diureticDetail!==id)};btns.forEach(b=>b.onclick=()=>show(b.dataset.diuretic));show(btns[0].dataset.diuretic)}

export function renderPharmacologyFoundation(){
 const intro=accordion({id:'pharm-found-intro',title:PHARMACOLOGY_FOUNDATIONS.intro.title,subtitle:PHARMACOLOGY_FOUNDATIONS.intro.summary,level:1,open:true,icon:doodleIcon('drugs'),body:`${renderLearningWhiteboard({title:(FULL_UI_TEXT["foundations-22"]||''),steps:PHARMACOLOGY_FOUNDATIONS.intro.steps,showSources:false})}${FULL_UI_TEXT["foundations-23"]||''}`});
 const groups=PHARMACOLOGY_FOUNDATIONS.categories.map(cat=>{
  const drugs=foundationDrugsForCategory(cat);let body='';
  if(cat.id==='diuretics')body+=renderDiureticNephron();
  body+=`${FULL_UI_TEXT["foundations-24"]||''}${drugs.map(d=>`<button class="chip drugChipButton" data-route="#drug/${d.n}">${esc(d.name)}</button>`).join('')}</div></div>`;
  if(drugs.length){
   const mechRows=drugs.slice(0,10).map((d,i)=>{const p=profileFor(d);return accordion({id:`pharm-${cat.id}-drug-${d.n}`,title:d.name,subtitle:d.group,level:3,body:`${renderAbbreviationLead((p?.mechanismText||'')+' '+(p?.pharmacokinetics||''))}${FULL_UI_TEXT["foundations-28"]||''}${esc(p?.mechanismText||(FULL_UI_TEXT["foundations-25"]||''))}</p>${p?.schemeSteps?.length?renderLearningWhiteboard({title:`${d.name}${FULL_UI_TEXT["foundations-26"]||''}`,steps:p.schemeSteps,showSources:false}):''}${FULL_UI_TEXT["foundations-29"]||''}${esc(p?.pharmacokinetics||(FULL_UI_TEXT["foundations-27"]||''))}</p><button class="drugLink" data-route="#drug/${d.n}${FULL_UI_TEXT["foundations-30"]||''}`})}).join('');
   body+=accordion({id:`pharm-${cat.id}-mechanisms`,title:(FULL_UI_TEXT["foundations-31"]||''),level:2,body:`<div class="accordionStack">${mechRows}</div>`});
  }
  return accordion({id:`pharm-found-${cat.id}`,title:cat.title,level:1,badge:String(drugs.length),icon:doodleIcon('drugs'),body});
 }).join('');
 return `<div class="accordionStack">${intro}${groups}</div>`;
}

export function renderStudyHub(){const items=[["Базовые дисциплины","Системы организма, фармакокинетика, химия, аналитика, биохимия/биология и НД Израиля","#foundations"],["Заболевания","Клинический вход в связанные материалы","#diseases"],["Механизмы","Рецепторы, каналы, ферменты и сигнальные пути","#mechanisms"],["Препараты","170 полных карточек","#drugs"],["Тесты","Интерактивная экзаменационная база","#tests"],["Тренажёр памяти","Интервальное повторение экзаменационного материала","#memory-trainer"],["Схемы","Все визуальные процессы","#schemes"],["Таблицы","Сравнения и диагностические ориентиры","#tables"]];app.innerHTML=header()+`<div class="page"><div class="paperTitle"><span class="handMini">Навигация по знаниям</span><h2>Учёба</h2><p>Разные входы открывают одну и ту же связанную базу — без дублирования сущностей.</p></div><div class="sectionGrid">${items.map(([a,b,c])=>`<div class="card clickCard" data-route="${c}"><h3>${a}</h3><p>${b}</p></div>`).join("")}</div></div>`+bottomNav("study");bindNav();}

export function foundationIcon(id){const map={
  pharmacokinetics:'kinetics','general-chemistry':'chemistry','organic-chemistry':'chemistry','analytical-chemistry':'analytics','biochemistry-biology':'biology','pharmacology':'drugs','israel-regulatory':'law'
 };return doodleIcon(map[id]||'theory');}

export function renderFoundationsHub(){
  const systemsRow=accordion({id:'foundation-hub-systems',title:'Системы организма',subtitle:'Интегрированное изучение: физиология → биохимия → патофизиология → препараты',level:1,icon:doodleIcon('systems'),body:`<div class="sourceNote"><b>Главный системный путь:</b> все 12 систем организма находятся внутри базовых дисциплин.</div><button class="moduleButton" data-route="#systems">Открыть системы</button>`});
  const rows=FOUNDATIONAL_SECTIONS.map(x=>accordion({
    id:`foundation-hub-${x.id}`,title:x.title,subtitle:x.description,level:1,badge:(x.id==='pharmacology'||foundationContent(x.id)?.length||CHEMISTRY_CONTENT[x.id]?.length)?'материалы добавлены':'раздел создан',icon:foundationIcon(x.id),
    body:`<div class="chips">${(x.plannedTopics||[]).slice(0,5).map(t=>`<span class="chip">${esc(t)}</span>`).join('')}</div><button class="moduleButton" data-route="#foundation/${x.id}">Открыть раздел</button>`
  })).join('');
  app.innerHTML=header()+`<div class="page"><div class="paperTitle"><span class="handMini">Общие учебные направления</span><h2>Базовые дисциплины</h2><p>Системы организма теперь являются частью этого раздела вместе с фармакокинетикой, химией, биохимией/биологией и нормативными документами Израиля.</p></div><div class="accordionStack">${systemsRow}${rows}</div></div>`+bottomNav('study');
  bindNav();
}

export function renderFoundationDetail(id){
  const x=foundationalMap[id];if(!x){location.hash='#foundations';return;}
  const advanced=foundationContent(id);
  const legacy=CHEMISTRY_CONTENT[id]||[];
  let topicHtml='';
  if(id==='pharmacology') topicHtml=renderPharmacologyFoundation();
  else if(advanced.length) topicHtml=advanced.map(item=>renderAdvancedFoundationTopic(id,item)).join('');
  else if(legacy.length) topicHtml=legacy.map(item=>renderChemistryTopic(id,item)).join('');
  else topicHtml=(x.plannedTopics||[]).map((t,i)=>accordion({id:`foundation-${x.id}-topic-${i}`,title:t,level:2,icon:foundationIcon(x.id),badge:'будет заполнено позже',body:`<div class="emptyState compactEmpty"><b>Раздел подготовлен</b><p>Материалы по теме «${esc(t)}» будут добавлены на следующем этапе наполнения.</p></div>`})).join('');
  const hasMaterial=id==='pharmacology'||advanced.length||legacy.length;
  const status=hasMaterial?'расширенная учебная база добавлена; материал структурирован как теория → формулы/таблицы → Learning Whiteboard → источники.':'архитектура создана; содержимое ожидает наполнения.';
  const content=[
    accordion({id:`foundation-${x.id}-about`,title:'О разделе',level:1,open:true,body:`<p>${esc(x.description)}</p><div class="sourceNote"><b>Текущий статус:</b> ${esc(status)}</div>`}),
    accordion({id:`foundation-${x.id}-planned`,title:hasMaterial?'Учебные темы':'Планируемая структура',level:1,open:hasMaterial,body:`<div class="accordionStack">${topicHtml}</div>`}),
    accordion({id:`foundation-${x.id}-sources`,title:'Принцип источников и визуализации',level:1,body:`<p><b>Теория:</b> приоритет университетских учебников и академических ресурсов. <b>Химия:</b> реакционные схемы и организация материала дополнительно опираются на предоставленные минисправочники Н.Е. Дерябиной. <b>Визуализация:</b> Learning Whiteboard/HTML/SVG с читаемыми подписями; генеративные научные картинки не используются.</p>`})
  ].join('');
  app.innerHTML=header()+`<div class="page"><div class="breadcrumb"><button data-route="#foundations">Базовые дисциплины</button><span>›</span><span>${esc(x.short)}</span></div><div class="paperTitle"><span class="handMini">${hasMaterial?'Расширенная учебная база':'Раздел создан'}</span><h2>${esc(x.title)}</h2><p>${esc(x.description)}</p></div><div class="accordionStack">${content}</div></div>`+bottomNav('study');
  bindNav();bindDiureticModule();
}
