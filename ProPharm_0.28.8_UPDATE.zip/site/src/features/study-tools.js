import {contentRevision, EXAM_MATERIALS} from '../core/content.js';
import { app, esc } from '../core/shared.js';
import { toast, favoriteButton, reviewButton } from '../ui/personal.js';
import { topicIcon } from '../ui/icons.js';
import { header, bottomNav, bindNav, accordion } from '../ui/shell.js';
import { renderAbbreviationLead } from '../ui/abbreviations.js';
import { profileFor } from '../features/drugs.js';
import { renderWhiteboardSources, renderLearningWhiteboard } from '../ui/visuals.js';
import { cardioBlockText, renderVisualSources, renderMedicalVisual, renderProcessCommentary } from '../features/cardio.js';
import { foundationIcon } from '../features/foundations.js';
import { TOPICS, DRUGS, THEORY, MECHANISMS, INTERACTIONS, DRUG_KNOWLEDGE, SECTION_VISUALS, STUDY_TABLES, FOUNDATIONAL_SECTIONS, CARDIO_PHYSIOLOGY, CARDIO_BIOCHEMISTRY, CARDIO_FLASHCARDS, TESTS, ALL_SOURCE_SECTIONS, foundationContent, topicMap, drugMap } from '../core/content.js';
import { recordStudyPosition } from '../../services/userData.js';

export function renderTablesHub(){
 const topics=TOPICS.map(t=>({t,tables:STUDY_TABLES[t.id]||[]})).filter(x=>x.tables.length);
 const tableHtml=(tbl,topicId,i)=>accordion({id:`table-${topicId}-${i}`,title:tbl.title,level:2,body:`${renderAbbreviationLead([tbl.title,...tbl.columns,...tbl.rows.flat(),tbl.note||""] .join(" "))}<div class="tableScroll"><table><thead><tr>${tbl.columns.map(c=>`<th>${esc(c)}</th>`).join("")}</tr></thead><tbody>${tbl.rows.map(r=>`<tr>${r.map(c=>`<td>${esc(c)}</td>`).join("")}</tr>`).join("")}</tbody></table></div>${tbl.note?`<div class="tableNote">${esc(tbl.note)}</div>`:""}`});
 app.innerHTML=header()+`<div class="page"><div class="paperTitle"><span class="handMini">Быстрый повтор</span><h2>Таблицы</h2><p>Разделы и таблицы свёрнуты по умолчанию. Открой систему/тему, затем конкретную таблицу.</p></div><div class="accordionStack">${topics.map(({t,tables})=>accordion({id:`tables-topic-${t.id}`,title:t.title,count:tables.length,level:1,body:tables.map((x,i)=>tableHtml(x,t.id,i)).join("")})).join("")}</div></div>`+bottomNav("study");bindNav();
}

export function schemeGroups(){
 const out={};
 const add=(topic,item)=>{if(!out[topic])out[topic]=[];const key=(item.title+"|"+(item.steps||[]).join("|")).toLowerCase();if(!out[topic].some(x=>x._key===key))out[topic].push({...item,_key:key});};
 TOPICS.forEach(t=>{
   (THEORY[t.id]||[]).forEach(x=>{if(x.visual?.steps?.length)add(t.id,{title:x.visual.title||x.title,kind:x.visual.kind||"flow",steps:x.visual.steps,explanation:x.summary,details:x.body||[],examples:[]});});
   (MECHANISMS[t.id]||[]).forEach(m=>add(t.id,{title:m.title,kind:"flow",steps:m.chain||[],explanation:`Механизм: ${(m.chain||[]).join(" → ")}.`,details:[],examples:m.examples||[]}));
   (INTERACTIONS[t.id]||[]).forEach(x=>add(t.id,{title:`Взаимодействие: ${x.title}`,kind:"flow",steps:x.chain||[],explanation:x.summary||"Лекарственное взаимодействие из тестовой/теоретической базы.",details:x.note?[x.note]:[],examples:[]}));
 });
 ALL_SOURCE_SECTIONS.forEach(sec=>{const v=SECTION_VISUALS[sec.id];if(v?.steps?.length)add(sec.topic,{title:`${sec.title}: ${v.title}`,kind:v.kind||"flow",steps:v.steps,explanation:`Схема к экзаменационному блоку «${sec.title}».`,details:[],examples:[]});});
 DRUGS.forEach(d=>{const p=profileFor(d);if(p?.schemeSteps?.length)add(d.primaryTopic||d.topics?.[0]||"",{title:`${d.name}: механизм действия`,kind:"flow",steps:p.schemeSteps,explanation:p.mechanismText||p.scheme,details:p.pharmacodynamics?[`Фармакодинамика: ${p.pharmacodynamics}`]:[],examples:[d.name]});});
 CARDIO_BIOCHEMISTRY.forEach(x=>add("cardio",{title:`ССС · ${x.title}`,kind:"integrated-cardio",steps:x.steps||[],explanation:x.summary,details:x.commentary||[],examples:(x.drugIds||[]).map(id=>drugMap[String(id)]?.name).filter(Boolean),integrated:x}));
 CARDIO_PHYSIOLOGY.forEach(x=>add("cardio",{title:`ССС · ${x.title}`,kind:"integrated-cardio",steps:x.points||[],explanation:x.summary,details:x.commentary||[],examples:[],integrated:x}));
 return out;
}

export function schemeHumanTitle(x){
 const raw=String(x.title||''),hay=(raw+' '+(x.steps||[]).join(' ')).toLowerCase();
 const rules=[
  [/β.?1|beta.?1|gs.*camp|camp.*pka/,'Как β₁-адренорецептор усиливает работу сердца'],
  [/α.?1|alpha.?1|gq.*plc|ip3.*dag/,'Как α₁-адренорецептор вызывает сокращение сосудов'],
  [/m.?2|gi.*adenyl|парасимпат/,'Как парасимпатическая система замедляет работу сердца'],
  [/raas|renin|angiotensin|aldosterone/,'Как RAAS повышает давление и объём циркулирующей крови'],
  [/nitric|no.*cgmp|guanylate/,'Как оксид азота расслабляет сосуды'],
  [/na.?\/k|atpase.*ncx|digoxin/,'Как дигоксин повышает внутриклеточный Ca²⁺ и сократимость сердца'],
  [/herg|ikr|qt|torsad/,'Почему некоторые препараты удлиняют QT и повышают риск torsades de pointes'],
  [/nav1|fast na|qrs|натриев.*канал/,'Почему блокада быстрых Na⁺-каналов расширяет QRS'],
  [/action potential|потенциал действия.*кардио/,'Как возникает потенциал действия рабочего кардиомиоцита'],
  [/pacemaker|sa node|синус.*уз|funny current|hcn/,'Как клетки синусового узла самостоятельно создают сердечный ритм'],
  [/excitation|contraction|ryr2|troponin.*ca/,'Как электрический импульс превращается в сокращение кардиомиоцита'],
  [/frank|starling/,'Почему увеличение наполнения сердца усиливает сокращение'],
  [/wiggers|сердечный цикл/,'Что происходит во время одного сердечного цикла'],
  [/coronar/,'Как миокард получает кровь и кислород'],
  [/conduct|his|purkinje|проводящ/,'Как электрический импульс проходит через сердце'],
  [/hmg.?coa|mevalonate|statin/,'Как синтезируется холестерин и где действуют статины'],
  [/gaba.?a|chloride.*gaba/,'Как GABA снижает возбудимость нейрона'],
  [/insulin.*rtk|irs.*pi3k|akt.*glut4/,'Как инсулин увеличивает поступление глюкозы в клетку'],
  [/coag|factor xa|thrombin|fibrin/,'Как формируется фибриновый тромб и где действуют антикоагулянты'],
  [/platelet|p2y12|cox.?1.*txa/,'Как активируются тромбоциты и где действуют антиагреганты'],
  [/nephron|nkcc2|ncc|enac|diure/,'Где диуретики действуют в нефроне и какие ионы изменяют'],
  [/glycolysis|гликолиз/,'Как глюкоза превращается в пируват и образует ATP'],
  [/electron transport|complex i|cytochrome c|atp synthase/,'Как дыхательная цепь создаёт протонный градиент и ATP'],
  [/dna.*rna.*protein|central dogma/,'Как генетическая информация превращается из DNA в RNA и белок'],
  [/replication|helicase|dna polymerase/,'Как клетка копирует DNA перед делением'],
  [/transcription|rna polymerase/,'Как информация DNA переписывается в RNA'],
  [/translation|ribosome|trna/,'Как рибосома синтезирует белок по mRNA'],
  [/apopt|caspase|cytochrome c/,'Как клетка запускает программируемую гибель — апоптоз']
 ];
 for(const [re,title] of rules)if(re.test(hay))return title;
 const clean=raw.replace(/^ССС\s*[·:—-]\s*/,'').replace(/^Взаимодействие:\s*/,'').trim();
 if(/^(Как|Почему|Что|Где|Когда|Путь|Механизм|Сердечный|Потенциал|Коронар|Проводящ|Генетическ|Качественн|Классификац|Метаболизм|Синтез|Распределение|Всасывание|Выведение|Клиренс|Период|Клет)/i.test(clean))return clean;
 if(raw.startsWith('Взаимодействие:'))return `Как развивается лекарственное взаимодействие: ${clean}`;
 return `Как работает процесс: ${clean}`;
}

export function renderSchemeItem(x,topicId,i){
 const humanTitle=schemeHumanTitle(x);
 const terms=x.integrated?renderAbbreviationLead(cardioBlockText(x.integrated)):renderAbbreviationLead([x.title,...(x.steps||[])].join(" "));
 const area=x.integrated?(CARDIO_PHYSIOLOGY.some(z=>z.id===x.integrated.id)?'physiology':'biochemistry'):'default';
 const visual=x.integrated?renderMedicalVisual(x.integrated,area):renderLearningWhiteboard({title:humanTitle,steps:x.steps||[],area,showSources:true});
 const explanation=`<div class="schemeExplanation"><div class="sourceNote"><b>Молекулярная/процессная цепочка:</b> ${esc(x.title||'')}</div><h4>Что показывает схема</h4><p>${esc(x.explanation||"")}</p>${x.details?.length?x.details.map((d,n)=>`<p><b>${n+1}.</b> ${esc(d)}</p>`).join(""):""}${x.examples?.length?`<div class="chips"><span class="smallMuted">Связанные препараты / примеры:</span>${x.examples.map(v=>`<span class="chip">${esc(v)}</span>`).join("")}</div>`:""}</div>`;
 return accordion({id:`scheme-${topicId}-${i}`,title:humanTitle,subtitle:x.title!==humanTitle?x.title:'',level:2,body:`${accordion({id:`scheme-${topicId}-${i}-terms`,title:'Термины и сокращения',level:3,body:terms||'<p class="smallMuted">Отдельных сокращений нет.</p>'})}${accordion({id:`scheme-${topicId}-${i}-visual`,title:'Learning Whiteboard / научная иллюстрация',level:3,body:visual})}${accordion({id:`scheme-${topicId}-${i}-comment`,title:'Что происходит на схеме',level:3,body:x.integrated?renderProcessCommentary(x.integrated):explanation})}${accordion({id:`scheme-${topicId}-${i}-sources`,title:'Источники',level:3,body:x.integrated?renderVisualSources(area)||renderWhiteboardSources(area):renderWhiteboardSources(area)})}`});
}

export function renderSchemesHub(){
 const groups=schemeGroups(),topics=TOPICS.map(t=>({t,items:groups[t.id]||[]})).filter(x=>x.items.length);
 const systemRows=topics.map(({t,items})=>accordion({id:`schemes-topic-${t.id}`,title:t.title,count:items.length,level:1,body:items.map((x,i)=>renderSchemeItem(x,t.id,i)).join("")})).join("");
 const foundationRows=FOUNDATIONAL_SECTIONS.map(sec=>{const items=foundationContent(sec.id).filter(x=>x.steps?.length).map(x=>({title:x.title,steps:x.steps,explanation:(x.theory||[])[0]||x.subtitle||'',details:(x.theory||[]).slice(1),examples:[]}));if(!items.length)return '';return accordion({id:`schemes-found-${sec.id}`,title:`Базовые дисциплины · ${sec.title}`,count:items.length,level:1,icon:foundationIcon(sec.id),body:items.map((x,i)=>renderSchemeItem(x,`foundation-${sec.id}`,i)).join('')})}).join('');
 app.innerHTML=header()+`<div class="page"><div class="paperTitle"><span class="handMini">Наглядно</span><h2>Схемы</h2><p>Каждая схема теперь названа по смыслу процесса. Внутри: расшифровка терминов → Learning Whiteboard/научная иллюстрация → пошаговое объяснение → источники.</p></div><div class="accordionStack">${systemRows}${foundationRows}</div></div>`+bottomNav("study");bindNav();
}

export function renderSchemesTopic(topicId){
 const t=topicMap[topicId];if(!t){location.hash="#schemes";return;}const items=schemeGroups()[topicId]||[];
 app.innerHTML=header()+`<div class="page"><div class="breadcrumb"><button data-route="#schemes">Схемы</button><span>›</span><span>${esc(t.short)}</span></div><div class="topicHeader"><div class="iconFrame topicLineIcon">${topicIcon(t.id)}</div><div><h2>Схемы: ${esc(t.title)}</h2><p>Открой конкретную схему. Медицинские изображения берутся из проверенных источников; процессные схемы — Learning Whiteboard.</p></div></div><div class="accordionStack">${items.map((x,i)=>renderSchemeItem(x,t.id,i)).join("")}</div></div>`+bottomNav("study");bindNav();
}

export let flashIndex=0,flashRevealed=false,flashFilter="all",flashQuery="";

export function stableFlashId(card){
 let h=2166136261,s=[card.type,card.drugId||'',card.topic||'',card.front||''].join('|');
 for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619)}
 return `fc-${card.type}-${(h>>>0).toString(36)}`;
}

let flashCache=null,flashRevision=-1;
export function buildFlashCards(){return EXAM_MATERIALS.cards||[];}
export function buildLegacyFlashCards(){
 if(flashCache&&flashRevision===contentRevision)return flashCache;
 const cards=[];
 DRUGS.forEach(d=>{
   const p=profileFor(d);
   cards.push({type:"drug",topic:d.primaryTopic||d.topics?.[0]||"",drugId:d.n,title:d.name,front:`К какой фармакологической группе относится ${d.name}?`,back:[p?.groupSource||d.group,`Темы: ${d.topics.map(x=>topicMap[x]?.short||x).join(", ")}`]});
   if(p?.mechanismText)cards.push({type:"profileMechanism",topic:d.primaryTopic||d.topics?.[0]||"",drugId:d.n,title:d.name,front:`Механизм действия ${d.name}`,back:[p.mechanismText]});
   if(p?.indications)cards.push({type:"indications",topic:d.primaryTopic||d.topics?.[0]||"",drugId:d.n,title:d.name,front:`Основные показания ${d.name}`,back:[p.indications]});
   if(p?.pharmacokinetics)cards.push({type:"pk",topic:d.primaryTopic||d.topics?.[0]||"",drugId:d.n,title:d.name,front:`Что важно помнить о фармакокинетике ${d.name}?`,back:[p.pharmacokinetics]});
   if(p?.adverseEffects)cards.push({type:"adverse",topic:d.primaryTopic||d.topics?.[0]||"",drugId:d.n,title:d.name,front:`Основные побочные эффекты ${d.name}`,back:[p.adverseEffects]});
   if(p?.interactionsText)cards.push({type:"profileInteraction",topic:d.primaryTopic||d.topics?.[0]||"",drugId:d.n,title:d.name,front:`Ключевые взаимодействия ${d.name}`,back:[p.interactionsText]});
   const k=DRUG_KNOWLEDGE[String(d.n)];
   if(k?.mechanism?.length)cards.push({type:"mechanism",topic:d.primaryTopic||d.topics?.[0]||"",drugId:d.n,title:d.name,front:`Каков механизм действия ${d.name}?`,back:k.mechanism});
   if(k?.pearls?.length)k.pearls.forEach((p,i)=>cards.push({type:"pearl",topic:d.primaryTopic||d.topics?.[0]||"",drugId:d.n,title:d.name,front:`Что важно помнить о ${d.name}? · карточка ${i+1}`,back:[p]}));
 });
 TESTS.forEach(q=>{
   (q.drugIds||[]).forEach(drugId=>{
     const d=drugMap[String(drugId)];if(!d)return;
     const correct=q.options?.find(o=>o.id===q.correct);
     cards.push({type:"test",topic:q.topic||d.primaryTopic,drugId,title:d.name,front:q.question,back:[`Правильный ответ: ${q.correct}. ${correct?.text||q.correctText||""}`,...(q.explanation||[])]});
     Object.entries(q.optionExplanations||{}).forEach(([oid,comment])=>{
       const opt=q.options?.find(o=>o.id===oid);
       if(!comment||!opt)return;
       cards.push({type:"comment",topic:q.topic||d.primaryTopic,drugId,title:d.name,front:`Комментарий к варианту ${oid} в вопросе про ${d.name}: «${opt.text}»`,back:[comment]});
     });
   });
 });
 CARDIO_FLASHCARDS.forEach(c=>cards.push({type:"cardioIntegrated",topic:"cardio",drugId:"",title:c.title,front:c.front,back:[c.back],cardioArea:c.area}));
 flashRevision=contentRevision;flashCache=cards.map(c=>({...c,id:stableFlashId(c)}));return flashCache;
}

export function filteredFlashCards(){
 const all=buildFlashCards();
 return all.filter(c=>(flashFilter==="all"||c.type===flashFilter)&&(!flashQuery||(c.title+" "+c.front+" "+c.back.join(" ")).toLowerCase().includes(flashQuery.toLowerCase())));
}

export function renderCardsHub(){
 const cards=filteredFlashCards();
 if(flashIndex>=cards.length)flashIndex=0;
 const d=cards[flashIndex];
 const typeNames={drug:"Фармгруппа",profileMechanism:"Механизм из базы 170",indications:"Показания",pk:"Фармакокинетика",adverse:"Побочные эффекты",profileInteraction:"Взаимодействия",mechanism:"Механизм из тестов",pearl:"Экзаменационный комментарий",test:"Вопрос из теста",comment:"Комментарий к варианту",cardioIntegrated:"ССС · интегрированная карточка"};
 app.innerHTML=header()+`<div class="page"><div class="paperTitle"><span class="handMini">Повторение</span><h2>Карточки</h2><p>Карточки формируются из 170 препаратов, механизмов, тестовых вопросов и комментариев к вариантам.</p></div>
 <div class="flashToolbar"><input id="flashSearch" value="${esc(flashQuery)}" placeholder="Поиск препарата или текста…"><select id="flashType"><option value="all">Все типы</option>${Object.entries(typeNames).map(([k,v])=>`<option value="${k}" ${flashFilter===k?"selected":""}>${v}</option>`).join("")}</select></div>
 <div class="flashStats"><span class="badge blue">${cards.length} карточек</span><span class="badge">прогресс сохраняется</span></div>
 ${d?`<div class="flashWrap"><button class="flashCard ${flashRevealed?"revealed":""}" id="flashCard"><span class="flashNum">${esc(typeNames[d.type]||d.type)} · #${d.drugId||""}</span><h2>${esc(d.title)}</h2>${renderAbbreviationLead([d.front,...d.back].join(" "))}${flashRevealed?`<div class="flashAnswer">${d.back.map(x=>`<p>${esc(x)}</p>`).join("")}</div>`:`<p>${esc(d.front)}</p><span class="handMini">нажми, чтобы перевернуть ↻</span>`}</button><div class="flashPersonal">${favoriteButton("card",d.id,"Избранное")}${reviewButton("card",d.id,"Повторить")}<button class="miniAction" id="knowCard">✓ Знаю</button></div><div class="flashControls"><button id="prevCard">← Назад</button><span>${flashIndex+1} / ${cards.length}</span><button id="nextCard">Дальше →</button></div></div>`:`<div class="emptyState"><div class="big">🗂️</div><b>Нет карточек по выбранному фильтру</b></div>`}</div>`+bottomNav("study");bindNav();
 const search=document.getElementById("flashSearch"),type=document.getElementById("flashType");
 search.oninput=e=>{flashQuery=e.target.value;flashIndex=0;flashRevealed=false;clearTimeout(window.__flashTimer);window.__flashTimer=setTimeout(renderCardsHub,180)};
 type.onchange=e=>{flashFilter=e.target.value;flashIndex=0;flashRevealed=false;renderCardsHub()};
 if(d){document.getElementById("flashCard").onclick=()=>{flashRevealed=!flashRevealed;renderCardsHub()};document.getElementById("prevCard").onclick=()=>{flashIndex=(flashIndex-1+cards.length)%cards.length;flashRevealed=false;renderCardsHub()};document.getElementById("nextCard").onclick=()=>{flashIndex=(flashIndex+1)%cards.length;flashRevealed=false;renderCardsHub()};document.getElementById("knowCard")?.addEventListener("click",async()=>{await recordStudyPosition({system_id:d.topic||"global",section_id:"cards",entity_id:d.id,route:"#cards",completed:true});toast("Карточка отмечена как изученная");flashIndex=(flashIndex+1)%cards.length;flashRevealed=false;renderCardsHub()});}
}
