import { FULL_UI_TEXT } from '../core/content.js';
import { app } from '../core/shared.js';
import { CARDIO_LAB_DATA } from '../core/content.js';
import { header,bindNav } from '../ui/shell.js';
export function renderCardioLab(){app.innerHTML=header()+'<div class="page"><button data-route="#home">Вернуться в ProPharm</button><div id="cardio-lab-root"></div></div>';mountCardioLab(document.getElementById('cardio-lab-root'),CARDIO_LAB_DATA);bindNav();}
function mountCardioLab(rootElement,data){
 const {DRUGS,GROUPS,OVERRIDE,SPECIAL,ELECTRO}=data;
// Интерактивный конспект: электрофизиология сердца, ЭКГ и 49 препаратов.
// Учебная модель, не клинический симулятор.

const root=rootElement;
const uid="cardio_app";
root.id=uid;







const BASE={hr:70,p:1,pr:160,qrs:90,st:0,t:1,qt:410,u:0};
const merge=(...x)=>Object.assign({},BASE,...x);
const esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));
const $=s=>root.querySelector(s);

const style=document.createElement("style");
style.textContent=`
#${uid}{
  --b:#f4f7fb;
  --b2:#ffffff;
  --f:#18212f;
  --m:#667085;
  --bd:#d8e1ec;
  --a:#2563eb;
  --a2:#eaf2ff;
  --ecg:#0f766e;
  --red:#dc5a67;
  --amber:#b7791f;
  --violet:#7c5ce5;
  --shadow:0 7px 24px rgba(31,41,55,.08);
  color:var(--f);
  background:var(--b);
  font-family:-apple-system,BlinkMacSystemFont,"SF Pro Text","Segoe UI",system-ui,sans-serif;
  font-size:16px;
  line-height:1.45;
  width:100%;
  min-width:0;
  -webkit-text-size-adjust:100%;
  text-size-adjust:100%;
}
#${uid} *{box-sizing:border-box}
#${uid} h1,#${uid} h2,#${uid} h3{color:var(--f);word-break:normal;overflow-wrap:anywhere}
#${uid} h1{font-size:clamp(1.45rem,6vw,2rem);line-height:1.12;margin:0 0 8px}
#${uid} h2{font-size:clamp(1.12rem,4.5vw,1.38rem);line-height:1.22;margin:0 0 10px}
#${uid} p{margin:.55rem 0}
#${uid} .hero,#${uid} .card{
  border:1.5px solid var(--bd);
  border-radius:18px;
  background:var(--b2);
  padding:14px;
  margin-bottom:11px;
  box-shadow:var(--shadow);
  min-width:0;
}
#${uid} .hero{
  background:linear-gradient(145deg,#ffffff 0%,#eef5ff 100%);
  border-color:#cbdcf6;
}
#${uid} .sub,#${uid} .small{color:var(--m)}
#${uid} .small{font-size:.86rem}
#${uid} .tabs{
  position:sticky;
  top:6px;
  z-index:30;
  display:flex;
  gap:6px;
  overflow-x:auto;
  flex-wrap:nowrap;
  margin:8px 0 12px;
  padding:6px;
  border:1.5px solid var(--bd);
  border-radius:16px;
  background:rgba(255,255,255,.96);
  box-shadow:0 5px 18px rgba(31,41,55,.08);
  -webkit-overflow-scrolling:touch;
  scrollbar-width:none;
}
#${uid} .tabs::-webkit-scrollbar{display:none}
#${uid} .tabs button{
  flex:0 0 auto;
  display:flex;
  align-items:center;
  gap:6px;
  min-height:46px;
  padding:6px 9px;
  background:#fff;
  border:1.5px solid var(--bd);
  border-radius:13px;
  color:var(--f);
  font-weight:650;
  white-space:nowrap;
}
#${uid} .tabs button.active{
  background:var(--a2);
  border-color:#91b7f7;
  color:#1549a0;
}
#${uid} .navicon,#${uid} .modeicon{
  display:inline-grid;
  place-items:center;
  width:31px;
  height:31px;
  flex:0 0 31px;
  border:1.5px solid #b9c8dc;
  border-radius:9px;
  background:#fff;
  box-shadow:0 2px 7px rgba(31,41,55,.07);
  font-size:17px;
  line-height:1;
}
#${uid} .panel{display:none}
#${uid} .panel.active{display:block}
#${uid} .grid{
  display:grid;
  grid-template-columns:minmax(0,1fr) minmax(0,1fr);
  gap:10px;
  min-width:0;
}
#${uid} .selects{
  display:grid;
  grid-template-columns:minmax(0,1fr) minmax(0,1fr);
  gap:9px;
}
#${uid} .modes,#${uid} .chips{
  display:flex;
  gap:7px;
  flex-wrap:wrap;
  margin:9px 0;
}
#${uid} button,#${uid} select,#${uid} input{
  font:inherit;
  color:var(--f);
  background:#fff;
  border:1.5px solid var(--bd);
  border-radius:12px;
  padding:9px 10px;
  min-height:44px;
  max-width:100%;
}
#${uid} select,#${uid} input{width:100%}
#${uid} button{cursor:pointer;-webkit-tap-highlight-color:transparent}
#${uid} button.active{
  background:var(--a2);
  border-color:#91b7f7;
  color:#1549a0;
}
#${uid} .mode{
  display:flex;
  align-items:center;
  gap:6px;
  font-weight:600;
}
#${uid} .chip{
  border:1.5px solid #c9d5e5;
  background:#f8fbff;
  border-radius:12px;
}
#${uid} .svg{
  width:100%;
  min-width:0;
  overflow:hidden;
  border:1.5px solid #cbd8e8;
  border-radius:15px;
  background:#fbfdff;
  padding:8px;
}
#${uid} svg{
  width:100%;
  max-width:100%;
  min-width:0;
  height:auto;
  display:block;
  overflow:visible;
}
#${uid} .flow{
  display:flex;
  gap:7px;
  overflow-x:auto;
  align-items:stretch;
  padding:5px 1px 8px;
  -webkit-overflow-scrolling:touch;
}
#${uid} .node{
  min-width:160px;
  border:1.5px solid #cbd8e8;
  border-radius:13px;
  padding:10px;
  background:#f9fbfe;
  color:var(--f);
}
#${uid} .arr{align-self:center;color:#7b8ba1;font-size:1.2rem}
#${uid} .params{
  display:grid;
  grid-template-columns:repeat(3,minmax(0,1fr));
  gap:6px;
  margin-top:9px;
}
#${uid} .p{
  border:1.5px solid #cbd8e8;
  border-radius:11px;
  padding:7px;
  font-size:.82rem;
  background:#fff;
  text-align:center;
}
#${uid} .table{
  max-height:520px;
  overflow:auto;
  border:1.5px solid var(--bd);
  border-radius:12px;
  background:#fff;
}
#${uid} table{width:100%;border-collapse:collapse;font-size:.84rem}
#${uid} th,#${uid} td{
  padding:8px;
  border-bottom:1px solid #e5eaf1;
  text-align:left;
  vertical-align:top;
  color:var(--f);
}
#${uid} th{position:sticky;top:0;background:#eef4fb;z-index:2}
#${uid} .warn{
  border:1.5px solid #f1d18a;
  border-left:5px solid #d39b2c;
  padding:10px;
  background:#fff9e9;
  border-radius:12px;
  margin-top:9px;
  color:#59451d;
}
#${uid} .graph-title{
  display:flex;align-items:center;gap:8px;margin:12px 0 7px;font-weight:750;color:var(--f)
}
#${uid} .graph-title .navicon{width:29px;height:29px;flex-basis:29px}
#${uid} .mobile-note{
  padding:9px 10px;border-radius:11px;background:#f2f7ff;border:1px solid #cfe0f8;color:#36516f;font-size:.86rem
}
@media(max-width:760px){
  #${uid}{font-size:15.5px}
  #${uid} .grid,#${uid} .selects{grid-template-columns:1fr}
  #${uid} .hero,#${uid} .card{padding:12px;border-radius:16px}
  #${uid} .params{grid-template-columns:repeat(2,minmax(0,1fr))}
  #${uid} .flow{
    display:grid;
    grid-template-columns:1fr;
    overflow:visible;
    gap:5px;
  }
  #${uid} .node{min-width:0;width:100%}
  #${uid} .arr{justify-self:center;transform:rotate(90deg);height:22px}
  #${uid} .modes{display:grid;grid-template-columns:1fr 1fr}
  #${uid} .mode{justify-content:flex-start;text-align:left}
  #${uid} table{min-width:660px}
}
@media(max-width:390px){
  #${uid} .tabs button{padding:5px 7px}
  #${uid} .navicon{width:29px;height:29px;flex-basis:29px}
  #${uid} .modes{grid-template-columns:1fr}
}
`;
root.appendChild(style);

root.insertAdjacentHTML("beforeend",`${FULL_UI_TEXT["cardio-lab-1"]||''}${uid}_sel"></select></label><div id="${uid}_hint" class="small"></div></div>
</div>
<div class="grid">
<div class="card"><h2 id="${uid}_title"></h2><div id="${uid}_desc"></div><div class="chips" id="${uid}${FULL_UI_TEXT["cardio-lab-2"]||''}${uid}_ecg"></div><div class="params" id="${uid}${FULL_UI_TEXT["cardio-lab-3"]||''}${uid}${FULL_UI_TEXT["cardio-lab-4"]||''}${uid}${FULL_UI_TEXT["cardio-lab-5"]||''}${uid}_tbl"></table></div></div>
</section>
`);

root.querySelectorAll(".tab").forEach(b=>b.onclick=()=>{
root.querySelectorAll(".tab").forEach(x=>x.classList.toggle("active",x===b));
root.querySelectorAll(".panel").forEach(p=>p.classList.toggle("active",p.dataset.p===b.dataset.t));
});

let mode="group";
const sel=$(`#${uid}_sel`);
function groups(){return Object.keys(GROUPS)}
function fill(){
 if(mode==="group")sel.innerHTML=groups().map(x=>`<option>${esc(x)}</option>`).join("");
 if(mode==="drug")sel.innerHTML=DRUGS.map(d=>`<option value="${esc(d.name)}">#${d.n} ${esc(d.name)}</option>`).join("");
 if(mode==="electro")sel.innerHTML=Object.keys(ELECTRO).map(x=>`<option>${esc(x)}</option>`).join("");
 if(mode==="normal")sel.innerHTML="<option>Норма</option>";
 render();
}
root.querySelectorAll(".mode").forEach(b=>b.onclick=()=>{
 mode=b.dataset.m; root.querySelectorAll(".mode").forEach(x=>x.classList.toggle("active",x===b)); fill();
});
sel.onchange=render;

function profileDrug(d){return merge(GROUPS[d.g].ecg,OVERRIDE[d.name]||{})}
function bioDrug(d){return SPECIAL[d.name]||[d.note,...GROUPS[d.g].bio.slice(1)]}

function selected(){
 if(mode==="group"){let g=sel.value||groups()[0];return {title:g,desc:GROUPS[g].bio.join(" → "),ecg:merge(GROUPS[g].ecg),bio:GROUPS[g].bio,members:DRUGS.filter(d=>d.g===g)}}
 if(mode==="drug"){let d=DRUGS.find(x=>x.name===sel.value)||DRUGS[0];return {title:`#${d.n} ${d.name}`,desc:`${FULL_UI_TEXT["cardio-lab-6"]||''}${esc(d.g)}<br>${esc(d.note)}`,ecg:profileDrug(d),bio:bioDrug(d),members:[]}}
 if(mode==="electro"){let k=sel.value||"Норма";let e=ELECTRO[k];return {title:k,desc:(FULL_UI_TEXT["cardio-lab-7"]||''),ecg:merge(e.ecg),bio:e.bio,members:[]}}
 let e=ELECTRO["Норма"];return {title:"Норма",desc:(FULL_UI_TEXT["cardio-lab-8"]||''),ecg:merge(e.ecg),bio:e.bio,members:[]};
}

function wave(p){
 const y=165, p0=40, pAmp=30*(p.p??1), pr=(p.pr??160)*.72, qs=p0+pr, qw=(p.qrs??90)*.72, qe=qs+qw, qt=(p.qt??410)*.72, te=qs+qt, ts=Math.max(qe+20,te-120), tp=(ts+te)/2;
 const ta=52*(p.t??1), st=y-(p.st??0)*35, u=p.u??0, up=(te+38), ue=te+76;
 const path=`M15 ${y} L${p0} ${y} Q${p0+18} ${y-pAmp} ${p0+36} ${y} L${qs-7} ${y} L${qs} ${y+16} L${qs+qw*.28} ${y-78} L${qs+qw*.55} ${y+38} L${qe} ${st} L${ts} ${st} Q${tp} ${st-ta} ${te} ${y} ${u?`L${up} ${y} Q${(up+ue)/2} ${y-25*u} ${ue} ${y}`:""} L735 ${y}`;
 return `${FULL_UI_TEXT["cardio-lab-9"]||''}${y}" x2="745" y2="${y}" stroke="#aebdce" stroke-dasharray="4 4"/>
 <path d="${path}${FULL_UI_TEXT["cardio-lab-10"]||''}${p.hr}${FULL_UI_TEXT["cardio-lab-11"]||''}${p0+13}" y="${Math.max(38,y-pAmp-8)}" font-size="14">P</text>
   <text x="${qs+qw*.28-4}" y="${Math.max(30,y-90)}" font-size="14">R</text>
   <text x="${tp-3}" y="${Math.max(32,st-ta-8)}" font-size="14">T</text>
   ${u?`<text x="${up+12}" y="${Math.max(34,y-25*u-8)}" font-size="13">U</text>`:""}
 </g>
 </svg>`;
}
function render(){
 let s=selected();
 $(`#${uid}_title`).textContent=s.title;
 $(`#${uid}_desc`).innerHTML=s.desc;
 $(`#${uid}_ecg`).innerHTML=wave(s.ecg);
 $(`#${uid}_params`).innerHTML=[["ЧСС",s.ecg.hr,"/мин"],["PR",s.ecg.pr,"мс"],["QRS",s.ecg.qrs,"мс"],["QT",s.ecg.qt,"мс"],["T",Math.round((s.ecg.t??1)*100),"%"],["U",Math.round((s.ecg.u??0)*100),"%"]].map(x=>`<span class="p"><b>${x[0]}</b> ${x[1]} ${x[2]}</span>`).join("");
 $(`#${uid}_bio`).innerHTML=s.bio.map((x,i)=>`${i?'<div class="arr">→</div>':''}<div class="node"><b>${i+1}</b><br>${esc(x)}</div>`).join("");
 $(`#${uid}_members`).innerHTML=s.members.length?`${FULL_UI_TEXT["cardio-lab-12"]||''}`+s.members.map(d=>`<button class="chip" data-n="${d.name}">#${d.n} ${d.name}</button>`).join(""):"";
 root.querySelectorAll(".chip").forEach(b=>b.onclick=()=>{mode="drug";root.querySelectorAll(".mode").forEach(x=>x.classList.toggle("active",x.dataset.m==="drug"));fill();sel.value=b.dataset.n;render();});
 $(`#${uid}_hint`).innerHTML=mode==="group"?(FULL_UI_TEXT["cardio-lab-13"]||''):mode==="drug"?(FULL_UI_TEXT["cardio-lab-14"]||''):mode==="electro"?(FULL_UI_TEXT["cardio-lab-15"]||''):(FULL_UI_TEXT["cardio-lab-16"]||'');
}

const q=$(`#${uid}_q`);
function table(){
 const s=(q.value||"").toLowerCase();
 const rows=DRUGS.filter(d=>(d.name+" "+d.g+" "+d.note).toLowerCase().includes(s));
 $(`#${uid}_tbl`).innerHTML=(FULL_UI_TEXT["cardio-lab-17"]||'')+rows.map(d=>`<tr><td>${d.n}</td><td><b>${esc(d.name)}</b></td><td>${esc(d.g)}</td><td>${esc(d.note)}</td></tr>`).join("")+"</tbody>";
}
q.oninput=table; table(); fill();
}
