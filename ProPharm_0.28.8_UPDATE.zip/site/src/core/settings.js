import { app, UI_SETTINGS_KEY } from '../core/shared.js';
import { router } from '../core/router.js';
import { authState, isAdmin } from '../../services/authService.js';
import { saveUserSettings } from '../../services/userData.js';
import { createAdminRuntimeI18n } from '../../i18n/admin-runtime-i18n.js';
import { preferences } from '../core/preferences.js';

export function adminLanguageLocalKey(){return `propharm_admin_language_v1:${authState.profile?.user_id||"anonymous"}`}

export function readAdminLanguage(){
  if(!isAdmin())return "ru";
  const local=localStorage.getItem(adminLanguageLocalKey());
  return local||preferences.ui.language||"ru";
}

export const adminI18n=createAdminRuntimeI18n({
  getRoot:()=>app,
  getProfile:()=>authState.profile,
  isAllowed:()=>isAdmin(),
  getStoredLanguage:()=>readAdminLanguage(),
  persistLanguage:async language=>{
    if(!isAdmin())return;
    localStorage.setItem(adminLanguageLocalKey(),language);
    preferences.ui.language=language;
    localStorage.setItem(UI_SETTINGS_KEY,JSON.stringify(preferences.ui));
    saveUserSettings(preferences.ui).catch(()=>{});
  },
  rerender:()=>router(),
});

export function applyAdminI18nAfterRender(){queueMicrotask(()=>adminI18n.afterRender().catch(e=>console.warn("ProPharm admin i18n",e)));}
