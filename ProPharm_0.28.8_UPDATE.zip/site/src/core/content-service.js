import { authState,getSupabase } from '../../services/authService.js';
import { get,put,makeKey,all,del } from '../../services/localDb.js';
import { installContent,resetContent } from './content.js';
import { bundlesForRoute,canAccessRoute,hasFullAccess } from './access.js';
import { BUILD_ID } from './build.js';
let owner=null,access=null,epoch=0;const loaded=new Set(),pending=new Map(),objectUrls=new Map(),embeddedAssets=new Map();
export function clearContent(){owner=null;access=null;epoch++;loaded.clear();pending.clear();embeddedAssets.clear();objectUrls.forEach(URL.revokeObjectURL);objectUrls.clear();resetContent();installContent({EXAM_MATERIALS:{blocks:[],cards:[]}});}
export async function purgeContentCache(){for(const row of await all('meta'))if(String(row.key).includes('content:'))await del('meta',row.key);}
function revive(k,v){return v?.$regexp?new RegExp(v.$regexp,v.flags||''):v;}
export async function ensureContent(route){
 const uid=authState.user?.id,kind=hasFullAccess()?'full':'standard';if(!uid||!canAccessRoute(route))throw new Error('Недостаточно прав для этого раздела');
 if(owner!==uid||access!==kind){clearContent();owner=uid;access=kind;}
 await Promise.all(bundlesForRoute(route).map(loadBundle));
}
async function loadBundle(name){
 if(loaded.has(name))return;if(pending.has(name))return pending.get(name);
 const uid=owner,version=epoch,key=makeKey(uid,'content:'+BUILD_ID+':'+name);
 const task=(async()=>{
  let payload;const cached=await get('meta',key);
  if(navigator.onLine&&cached?.payload&&Date.now()-cached.verifiedAt<7*86400000){payload=cached.payload;}
  else if(!navigator.onLine){const row=await get('meta',key);if(!row||Date.now()-row.verifiedAt>7*86400000||!authState.offlineFallback)throw new Error('Для первой загрузки раздела нужен интернет');payload=row.payload;}
  else{const {data,error}=await getSupabase().rpc('get_content_bundle',{p_bundle:name,p_build:BUILD_ID});if(error)throw new Error('Раздел не загружен: '+error.message);payload=data;if(version!==epoch||uid!==authState.user?.id||authState.profile?.status!=='approved')return;await put('meta',{key,user_id:uid,payload,verifiedAt:Date.now()});}
  if(version!==epoch||uid!==authState.user?.id||authState.profile?.status!=='approved')return;
  const {PRIVATE_ASSETS={},...content}=payload;
  for(const [asset,value]of Object.entries(PRIVATE_ASSETS))embeddedAssets.set(asset,value);
  installContent(JSON.parse(JSON.stringify(content),revive));loaded.add(name);
 })();pending.set(name,task);try{await task;}finally{if(pending.get(name)===task)pending.delete(name);}
}
export async function resolveAsset(path){
 if(!path?.startsWith('protected:'))return path;
 const uid=authState.user?.id,version=epoch;if(!uid||authState.profile?.status!=='approved')throw new Error('Нет доступа к изображению');
 const name=path.slice(10);if(name.startsWith('full/')&&!hasFullAccess())throw new Error('Нет доступа к изображению');
 if(objectUrls.has(path))return objectUrls.get(path);
 const embedded=embeddedAssets.get(name);
 if(embedded){const bytes=Uint8Array.from(atob(embedded.base64),c=>c.charCodeAt(0));const url=URL.createObjectURL(new Blob([bytes],{type:embedded.mime}));objectUrls.set(path,url);return url;}
 const key=makeKey(uid,'content:asset:'+name);let data;const cached=await get('meta',key);
 if(navigator.onLine&&cached?.blob&&Date.now()-cached.verifiedAt<7*86400000){data=cached.blob;}
 else if(!navigator.onLine){const row=await get('meta',key);if(!row?.blob||!row.verifiedAt||Date.now()-row.verifiedAt>7*86400000||!authState.offlineFallback)throw new Error('Для изображения нужен интернет');data=row.blob;}else{const result=await getSupabase().storage.from('propharm-content').download(name);if(result.error)throw result.error;data=result.data;if(version===epoch&&uid===authState.user?.id&&authState.profile?.status==='approved')await put('meta',{key,user_id:uid,blob:data,verifiedAt:Date.now()});}
 if(version!==epoch||uid!==authState.user?.id)throw new Error('Сессия изменилась');
 const url=URL.createObjectURL(data);objectUrls.set(path,url);return url;
}
