import { authState } from '../../services/authService.js';
export const BASE_ROUTES=new Set(['home','tests','quiz','drugs','drug','interactions-hub','memory-trainer','memory-lesson','weak-topics','review','my-study','favorites','profile','settings','search','study']);
export function hasFullAccess(profile=authState.profile){return profile?.status==='approved'&&(profile.role==='admin'||profile.content_access==='full');}
export function isTestsOnlyUser(){return authState.profile?.status==='approved'&&!hasFullAccess();}
export function canAccessRoute(route,profile=authState.profile){const root=String(route).replace(/^#/,'').split('/')[0]||'home';return profile?.status==='approved'&&(root==='admin'?profile.role==='admin':BASE_ROUTES.has(root)||hasFullAccess(profile));}
export function bundlesForRoute(route){const root=String(route).replace(/^#/,'').split('/')[0];const out=['meta','tests'];if(['drugs','drug','interactions-hub','search','favorites','memory-trainer','memory-lesson'].includes(root))out.push('drugs','interactions');if(!BASE_ROUTES.has(root)&&root!=='admin'||root==='study'&&hasFullAccess())out.push('drugs','interactions','full');return [...new Set(out)];}
