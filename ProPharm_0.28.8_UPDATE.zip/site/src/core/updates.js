let registration=null;
export async function initUpdates(){
 if(!navigator.serviceWorker)return;
 try{
  registration=await navigator.serviceWorker.register('./sw.js',{updateViaCache:'none'});
  const offer=()=>{if(!registration.waiting||!navigator.serviceWorker.controller||document.getElementById('propharmUpdate'))return;const box=document.createElement('aside');box.id='propharmUpdate';box.className='updateNotice';box.setAttribute('role','status');const text=document.createElement('span');text.textContent='Доступно обновление ProPharm. ';const button=document.createElement('button');button.textContent='Установить обновление';box.appendChild(text);box.appendChild(button);document.body.appendChild(box);button.onclick=()=>{const worker=registration.waiting;if(!worker)return;button.disabled=true;text.textContent='Установка обновления… ';const ready=()=>{button.disabled=false;button.textContent='Открыть обновлённое приложение';text.textContent='Обновление готово. Тест сохранён на устройстве. ';button.onclick=()=>{window.location.assign(window.location.href);};};navigator.serviceWorker.addEventListener('controllerchange',ready,{once:true});worker.postMessage({type:'ACTIVATE_UPDATE'});};};
  offer();registration.addEventListener('updatefound',()=>{const worker=registration.installing;worker?.addEventListener('statechange',()=>{if(worker.state==='installed')offer()})});
 }catch(e){console.warn('PWA update check',e)}
}
