import {authViewKey,installScrollPersistence} from './view-state.js';
import {initUpdates} from './updates.js';
import { syncQuestionEvents } from '../questions/progress.js';
import { clearMemoryLesson } from '../features/memory.js';
import { clearContent,purgeContentCache } from './content-service.js';
import { clearQuizMemory } from '../features/quiz.js';
import { UI_SETTINGS_KEY, applyUiSettings } from '../core/shared.js';
import { adminLanguageLocalKey, applyAdminI18nAfterRender } from '../core/settings.js';
import { refreshAdminPendingCount, startAdminApplicationWatcher } from '../features/admin.js';
import { router } from '../core/router.js';
import { authState, initAuth, onAuthState, isAdmin, refreshProfile } from '../../services/authService.js';
import { loadUserSettings, hydrateFromCloud, syncPending } from '../../services/userData.js';
import { preferences } from '../core/preferences.js';

export async function restoreSyncedSettings(){const row=await loadUserSettings().catch(()=>null);if(row?.settings_json){preferences.ui=Object.assign({},preferences.ui,row.settings_json);localStorage.setItem(UI_SETTINGS_KEY,JSON.stringify(preferences.ui));if(isAdmin()&&preferences.ui.language)localStorage.setItem(adminLanguageLocalKey(),preferences.ui.language);applyUiSettings();applyAdminI18nAfterRender()}}

export async function syncPersonalState(){if(authState.profile?.status!=='approved')return;await syncPending();await syncQuestionEvents();await hydrateFromCloud();await restoreSyncedSettings()}

export let pendingProfileTimer=null;

export function syncPendingProfilePolling(){
  if(pendingProfileTimer){clearInterval(pendingProfileTimer);pendingProfileTimer=null;}
  if(authState.session&&['pending','approved'].includes(authState.profile?.status)){
    pendingProfileTimer=setInterval(()=>{if(document.visibilityState==='visible')revalidateVisibleSession().catch(()=>{})},30000);
  }
}

let refreshing=null;
export function revalidateVisibleSession(){if(refreshing)return refreshing;refreshing=revalidate().finally(()=>{refreshing=null});return refreshing;}
async function revalidate(){
  if(!authState.session)return;
  try{await refreshProfile()}catch(e){console.warn('ProPharm profile revalidation',e)}
}

export async function boot(){
  applyUiSettings();
  installScrollPersistence();initUpdates();
  let viewKey=null,approvedOwner=null;
  onAuthState(()=>{
    if(!authState.initialized)return;
    const key=authViewKey(authState);if(key===viewKey)return;viewKey=key;
    if(!authState.profileLoading&&(!authState.session||authState.profile?.status!=='approved')){clearContent();clearQuizMemory();clearMemoryLesson();approvedOwner=null;if(!authState.session)purgeContentCache().catch(console.warn);}
    router();syncPendingProfilePolling();
    const owner=authState.profile?.status==='approved'?authState.user?.id:null;
    if(owner&&owner!==approvedOwner){approvedOwner=owner;syncPersonalState().catch(()=>{});startAdminApplicationWatcher().catch(()=>{})}
  });
  window.addEventListener("hashchange",router);
  window.addEventListener("online",()=>{revalidateVisibleSession().catch(()=>{});syncPersonalState().catch(()=>{});refreshAdminPendingCount().catch(()=>{})});
  document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible')revalidateVisibleSession().catch(()=>{})});
  navigator.serviceWorker?.addEventListener?.('message',event=>{if(event.data?.type==='PROPHARM_NOTIFICATION_OPEN'){location.hash=event.data.url||'#admin';}});
  await router();
  await initAuth();
  syncPendingProfilePolling();

}
