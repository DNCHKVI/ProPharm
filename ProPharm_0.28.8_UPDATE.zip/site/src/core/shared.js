import { preferences } from '../core/preferences.js';

export const app = document.getElementById("app");

export const esc = s => String(s ?? "").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));

export const UI_SETTINGS_KEY="propharm_ui_settings_v1";

export function applyUiSettings(){document.documentElement.classList.toggle("largeText",!!preferences.ui.largeText);document.documentElement.classList.toggle("reducedMotion",!!preferences.ui.reducedMotion);}
