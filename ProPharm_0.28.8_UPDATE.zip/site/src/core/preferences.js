let stored={};try{stored=JSON.parse(localStorage.getItem('propharm_ui_settings_v1')||'{}')}catch{}
export const preferences={ui:{largeText:false,reducedMotion:false,language:'ru',...stored}};
