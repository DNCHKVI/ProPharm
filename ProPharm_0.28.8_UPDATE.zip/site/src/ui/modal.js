const stack=[];
export function enhanceModal(el,{label='Диалог',initialFocus}={}){
 const prior=document.activeElement,sheet=el.querySelector('.modalSheet')||el;sheet.setAttribute('role','dialog');sheet.setAttribute('aria-modal','true');sheet.setAttribute('aria-label',label);sheet.tabIndex=-1;
 const heading=sheet.querySelector('h2');if(heading){heading.id||='dialog-'+crypto.randomUUID();sheet.setAttribute('aria-labelledby',heading.id);}
 const app=document.getElementById('app');if(app)app.inert=true;
 const previous=stack.at(-1);if(previous)previous.inert=true;stack.push(el);document.body.classList.add('hasModal');
 const focusable=()=>[...sheet.querySelectorAll('button:not([disabled]),a[href],input:not([disabled]),select,textarea,[tabindex="0"]')].filter(x=>!x.hidden&&x.getClientRects().length);
 const originalRemove=el.remove.bind(el);let removed=false;
 el.remove=()=>{if(removed)return;removed=true;document.removeEventListener('keydown',keydown,true);const index=stack.indexOf(el);if(index!==-1)stack.splice(index,1);originalRemove();const top=stack.at(-1);if(top)top.inert=false;else{if(app)app.inert=false;document.body.classList.remove('hasModal');}if(prior?.isConnected&&!prior.closest('[inert]'))prior.focus();else if(top)top.querySelector('[role="dialog"]')?.focus();};
 function keydown(e){if(stack.at(-1)!==el)return;if(e.key==='Escape'){e.preventDefault();e.stopPropagation();el.remove();}if(e.key==='Tab'){const xs=focusable();if(!xs.length){e.preventDefault();sheet.focus();return;}const first=xs[0],last=xs.at(-1);if(e.shiftKey&&(!sheet.contains(document.activeElement)||document.activeElement===first||document.activeElement===sheet)){e.preventDefault();last.focus();}else if(!e.shiftKey&&(!sheet.contains(document.activeElement)||document.activeElement===last)){e.preventDefault();first.focus();}}}
 document.addEventListener('keydown',keydown,true);queueMicrotask(()=>{if(el.isConnected)(initialFocus?.()||focusable()[0]||sheet).focus()});
 return el;
}
export function modalShell(inner,options={}){const el=document.createElement('div');el.className='modalBackdrop';el.innerHTML=`<div class="modalSheet">${inner}</div>`;document.body.appendChild(el);return enhanceModal(el,options);}
export function closeAllModals(){[...stack].reverse().forEach(x=>x.remove());}
