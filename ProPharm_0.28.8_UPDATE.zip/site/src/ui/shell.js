import {bindVirtualLists} from './virtual-list.js';
import { enhanceModal } from './modal.js';
import { resolveAsset } from '../core/content-service.js';
import { esc } from '../core/shared.js';
import { bindPersonalActions, accountDisplayName } from '../ui/personal.js';
import { doodleIcon, capsuleLogo } from '../ui/icons.js';
import { isTestsOnlyUser } from '../core/access.js';

export function header(){const name=accountDisplayName();return `<div class="topbar innerTopbar chalkTop"><button class="backMini" onclick="history.length>1?history.back():location.hash='#home'">‹</button><div class="brandCompact brandWithLogo">${capsuleLogo("miniCapsuleLogo")}<span><b>ProPharm</b><small>экзаменационная база</small></span></div><button class="topAccountMini" data-route="#profile" title="${esc(name)}"><span class="topAccountDot">${esc((name||'P').slice(0,1).toUpperCase())}</span><span data-no-translate>${esc(name)}</span></button></div>`;}

export function bottomNav(active){
 const items=isTestsOnlyUser()
  ? [["home","#home","home","Главная"],["study","#tests","study","Тесты"],["settings","#settings","settings","Настройки"]]
  : [["home","#home","home","Главная"],["search","#search","search","Поиск"],["study","#study","study","Учёба"],["settings","#settings","settings","Настройки"]];
 return `<nav class="bottomNav">${items.map(([id,route,ic,t])=>`<button class="navBtn ${active===id?"active":""}" data-route="${route}"><span class="navSketch">${doodleIcon(ic)}</span><span>${t}</span></button>`).join("")}</nav>`;
}

export function bindNav(root=document){
 bindVirtualLists(root,bindNav);
 root.querySelectorAll("[data-nav]").forEach(b=>{if(b.dataset.navBound)return;b.dataset.navBound="1";b.addEventListener("click",()=>location.hash=b.dataset.nav==="home"?"#home":`#${b.dataset.nav}`)});
 root.querySelectorAll("[data-route]").forEach(el=>{if(el.dataset.routeBound)return;el.dataset.routeBound="1";el.addEventListener("click",()=>location.hash=el.dataset.route)});
 bindPersonalActions(root);
 bindAccordions(root);
 bindScientificImages(root);
}

export const ACCORDION_SESSION_KEY="propharm_accordion_v014";

export function readAccordionState(){try{return JSON.parse(sessionStorage.getItem(ACCORDION_SESSION_KEY)||"{}")}catch{return {}}}

export function rememberAccordion(id,open){if(!id)return;const state=readAccordionState();state[id]=!!open;sessionStorage.setItem(ACCORDION_SESSION_KEY,JSON.stringify(state));}

export function accordionOpen(id,defaultOpen=false){const state=readAccordionState();return Object.prototype.hasOwnProperty.call(state,id)?!!state[id]:!!defaultOpen}

export function accordion({id,title,body,badge="",count="",subtitle="",level=1,open=false,className="",icon=""}){
 const shouldOpen=accordionOpen(id,open),shownBadge=badge!==""?badge:count;
 return `<details class="learningAccordion level-${level} ${className}" data-accordion-id="${esc(id)}" ${shouldOpen?"open":""}><summary><span class="accordionChevron" aria-hidden="true">›</span>${icon?`<span class="accordionPencilIcon">${icon}</span>`:""}<span class="accordionHeading"><span class="accordionTitle">${esc(title)}</span>${subtitle?`<small>${esc(subtitle)}</small>`:""}</span>${shownBadge!==""?`<span class="accordionBadge">${esc(shownBadge)}</span>`:""}</summary><div class="learningAccordionBody">${body}</div></details>`;
}

export function bindAccordions(root=document){root.querySelectorAll('details[data-accordion-id]').forEach(d=>{if(d.dataset.accordionBound)return;d.dataset.accordionBound='1';d.addEventListener('toggle',()=>rememberAccordion(d.dataset.accordionId,d.open))})}

export function bindScientificImages(root=document){
 root.querySelectorAll('img[data-protected-src]').forEach(async img=>{if(img.dataset.assetPending)return;img.dataset.assetPending='1';try{const url=await resolveAsset(img.dataset.protectedSrc);if(!img.isConnected)return;img.src=url;const button=img.closest('[data-scientific-image]');if(button)button.dataset.imageUrl=url;}catch(e){img.alt='Изображение пока недоступно. Нужен интернет.';img.dataset.assetPending='';}});
root.querySelectorAll('[data-scientific-image]').forEach(btn=>{if(btn.dataset.imageBound)return;btn.dataset.imageBound='1';btn.addEventListener('click',()=>openScientificLightbox(btn.dataset.imageUrl,btn.dataset.imageTitle,btn.dataset.sourceUrl))})}

export async function openScientificLightbox(url,title,sourceUrl){
 try{url=await resolveAsset(url)}catch(e){alert(e.message);return;}
 const modal=document.createElement('div');modal.className='scientificLightbox';modal.innerHTML=`<div class="scientificLightboxBar"><b>${esc(title||'Схема')}</b><button aria-label="Закрыть">×</button></div><div class="scientificLightboxViewport"><img src="${esc(url)}" alt="${esc(title||'Научная иллюстрация')}" draggable="false"></div>${sourceUrl?`<a class="scientificSourceLink" href="${esc(sourceUrl)}" target="_blank" rel="noopener noreferrer">Открыть оригинальный источник ↗</a>`:""}`;document.body.appendChild(modal);enhanceModal(modal,{label:title||'Научная иллюстрация'});
 const img=modal.querySelector('img'),view=modal.querySelector('.scientificLightboxViewport');let scale=1,tx=0,ty=0,lastDist=0,lastX=0,lastY=0,dragging=false;
 const apply=()=>img.style.transform=`translate(${tx}px,${ty}px) scale(${scale})`;
 modal.querySelector('button').onclick=()=>modal.remove();modal.addEventListener('click',e=>{if(e.target===modal)modal.remove()});
 view.addEventListener('wheel',e=>{e.preventDefault();scale=Math.min(5,Math.max(1,scale+(e.deltaY<0?.2:-.2)));apply()},{passive:false});
 view.addEventListener('pointerdown',e=>{dragging=true;lastX=e.clientX;lastY=e.clientY;view.setPointerCapture?.(e.pointerId)});
 view.addEventListener('pointermove',e=>{if(!dragging||scale<=1)return;tx+=e.clientX-lastX;ty+=e.clientY-lastY;lastX=e.clientX;lastY=e.clientY;apply()});
 view.addEventListener('pointerup',()=>dragging=false);view.addEventListener('pointercancel',()=>dragging=false);
 let touches=[];view.addEventListener('touchstart',e=>{touches=[...e.touches];if(touches.length===2)lastDist=Math.hypot(touches[0].clientX-touches[1].clientX,touches[0].clientY-touches[1].clientY)},{passive:true});
 view.addEventListener('touchmove',e=>{if(e.touches.length===2){const d=Math.hypot(e.touches[0].clientX-e.touches[1].clientX,e.touches[0].clientY-e.touches[1].clientY);if(lastDist){scale=Math.min(5,Math.max(1,scale*d/lastDist));apply()}lastDist=d}},{passive:true});
}
