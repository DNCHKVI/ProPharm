

export function doodleIcon(type){
 const common=`viewBox="0 0 64 64" aria-hidden="true" focusable="false"`;
 const svg=(body)=>`<svg ${common} class="chalkSvg"><g fill="none" stroke="currentColor" stroke-width="3.4" stroke-linecap="round" stroke-linejoin="round">${body}</g></svg>`;
 const map={
  tests:svg(`<path d="M19 12h28a5 5 0 0 1 5 5v36H14V17a5 5 0 0 1 5-5Z"/><path d="M24 9h18v9H24z"/><path d="m21 28 3 3 6-7M21 40l3 3 6-7M35 28h10M35 40h10"/>`),
  theory:svg(`<path d="M8 17c9-5 18-4 25 1v35c-7-5-16-6-25-1V17Z"/><path d="M56 17c-9-5-18-4-23 1v35c7-5 14-6 23-1V17Z"/><path d="M15 27h11M15 35h11M40 27h10M40 35h10"/>`),
  tables:svg(`<rect x="9" y="11" width="46" height="42" rx="6"/><path d="M9 25h46M9 39h46M24 11v42M40 11v42"/>`),
  schemes:svg(`<rect x="25" y="8" width="14" height="12" rx="3"/><rect x="8" y="43" width="18" height="13" rx="4"/><rect x="38" y="43" width="18" height="13" rx="4"/><path d="M32 20v11M17 43v-8h30v8"/>`),
  cards:svg(`<path d="m16 17 31-5 5 30-31 5-5-30Z"/><rect x="11" y="24" width="38" height="28" rx="5"/><circle cx="28" cy="37" r="4"/><path d="M36 34h8M36 41h7"/>`),
  drugs:svg(`<path d="M15 41 39 17a10 10 0 0 1 14 14L29 55a10 10 0 0 1-14-14Z"/><path d="m27 29 15 15"/><path d="M18 45h8M38 19h8"/>`),
  abbr:svg(`<rect x="9" y="10" width="46" height="44" rx="8"/><path d="M17 44 25 21l8 23M20 36h10M40 23h8M40 33h8M40 43h6"/>`),
  settings:svg(`<circle cx="32" cy="32" r="9"/><path d="M32 8v7M32 49v7M8 32h7M49 32h7M15 15l5 5M44 44l5 5M49 15l-5 5M20 44l-5 5"/>`),
  search:svg(`<circle cx="27" cy="27" r="15"/><path d="m38 38 14 14"/>`),
  home:svg(`<path d="m10 30 22-18 22 18v24H39V40H25v14H10V30Z"/>`),
  study:svg(`<path d="M8 17c9-5 18-4 25 1v35c-7-5-16-6-25-1V17ZM56 17c-9-5-18-4-23 1v35c7-5 14-6 23-1V17Z"/>`),
  profile:svg(`<circle cx="32" cy="22" r="9"/><path d="M15 54c2-13 10-19 17-19s15 6 17 19"/>`),
  memory:svg(`<path d="M21 15c-7 2-10 10-6 16-4 5-1 12 6 13 3 6 10 5 12 0 7 2 13-5 9-11 5-6 1-15-7-15-2-6-10-7-14-3"/><path d="M31 18v29M22 27h9M31 37h9"/><path d="M47 13v9M43 17h9"/>`),
  interactions:svg(`<circle cx="20" cy="32" r="9"/><circle cx="44" cy="32" r="9"/><path d="M29 32h6M32 22v20"/>`),
  chemistry:svg(`<path d="M24 8v17L11 48a6 6 0 0 0 5 8h32a6 6 0 0 0 5-8L40 25V8"/><path d="M20 38h24M26 8h12"/>`),
  analytics:svg(`<circle cx="27" cy="26" r="13"/><path d="m37 36 14 14M18 26h18M27 17v18"/>`),
  kinetics:svg(`<path d="M9 51h46M13 47c8-26 16-34 24-22 7 10 9 16 15 4"/><path d="M17 14v10M12 19h10"/>`),
  law:svg(`<path d="M32 9v46M17 18h30M14 18l-8 16h16L14 18ZM50 18l-8 16h16L50 18ZM22 55h20"/>`),
  biology:svg(`<path d="M23 10c18 7 23 18 18 44M41 10C23 17 18 28 23 54"/><path d="M23 25h18M22 40h19"/>`),
  systems:svg(`<path d="M32 10c-5 0-8 5-8 10 0 4 2 7 4 9l-6 24M32 10c5 0 8 5 8 10 0 4-2 7-4 9l6 24M20 31h24M26 53h12"/>`)
 };
 return map[type]||map.study;
}

export function homeDoodleIcon(type){
 const common=`viewBox="0 0 88 88" aria-hidden="true" focusable="false"`;
 const svg=(body)=>`<svg ${common} class="homeChalkSvg"><g class="homeChalkMain" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round">${body}</g><g class="homeChalkGhost" fill="none" stroke="currentColor" stroke-width="1.25" stroke-linecap="round" stroke-linejoin="round" opacity=".34" transform="translate(.8 -.6)">${body}</g></svg>`;
 const rays=`<path class="chalkRay" d="M11 44H4M18 19l-5-5M70 19l5-5M77 44h7"/>`;
 const map={
  theory:svg(`<path d="M44 12c-5 0-8 4-8 9 0 4 2 7 5 9l-3 9-7 7-5 18M44 12c5 0 8 4 8 9 0 4-2 7-5 9l3 9 7 7 5 18"/><path d="M37 37c4 3 10 3 14 0M32 45l-12 7M56 45l12 7M38 63l-5 13M50 63l5 13"/>${rays}`),
  drugs:svg(`<path d="M17 55 47 25a12 12 0 0 1 17 17L34 72a12 12 0 0 1-17-17Z"/><path d="m31 41 17 17"/><circle cx="66" cy="65" r="11"/><path d="M59 65h14"/>${rays}`),
  tests:svg(`<path d="M27 18h38a6 6 0 0 1 6 6v48H20V24a6 6 0 0 1 7-6Z"/><path d="M34 13h23v12H34z"/><path d="m30 37 4 4 8-9M30 51l4 4 8-9M48 37h13M48 52h13"/>${rays}`),
  memory:svg(`<path d="M31 18c-10 2-14 13-8 21-6 6-2 17 8 18 4 8 16 6 18-2 10 2 17-9 11-17 6-9 0-20-11-20-4-7-15-7-18 0Z"/><path d="M43 20v37M31 31h12M43 44h12"/><path d="M66 18c8 4 12 11 12 20M78 38l-5-5M78 38l5-5"/>`),
  cards:svg(`<path d="m25 19 39-5 5 43-39 5-5-43Z"/><path d="m19 26 41-3 4 43-41 3-4-43Z"/><rect x="14" y="31" width="45" height="39" rx="7"/><path d="M32 44c2-5 13-6 15 0 2 6-7 7-7 13M40 64v.5"/>${rays}`),
  schemes:svg(`<circle cx="43" cy="44" r="11"/><circle cx="18" cy="60" r="8"/><circle cx="68" cy="61" r="8"/><circle cx="48" cy="16" r="8"/><path d="m35 50-10 7M51 51l10 7M45 33l2-9"/>${rays}`),
  tables:svg(`<rect x="14" y="16" width="48" height="49" rx="5"/><path d="M14 31h48M14 47h48M30 16v49M46 16v49"/><circle cx="62" cy="59" r="13"/><path d="m71 68 10 10"/>${rays}`),
  abbr:svg(`<path d="M20 18h49a6 6 0 0 1 6 6v46H14V24a6 6 0 0 1 6-6Z"/><path d="M27 59 36 32l9 27M30 50h12M52 35h13M52 47h13M52 59h9"/>${rays}`),
  interactions:svg(`<path d="M14 55 36 33a10 10 0 0 1 14 14L28 69a10 10 0 0 1-14-14Z"/><path d="M49 25 60 14a8 8 0 0 1 12 12L61 37"/><path d="m47 50 7 7M24 45l11 11"/><path d="M67 48v13M67 68v1"/>${rays}`)
 };
 return map[type]||doodleIcon(type);
}

export function topicIcon(type){
 const common=`viewBox="0 0 64 64" aria-hidden="true" focusable="false"`;
 const wrap=(body)=>`<svg ${common} class="chalkSvg"><g fill="none" stroke="currentColor" stroke-width="3.2" stroke-linecap="round" stroke-linejoin="round">${body}</g></svg>`;
 const m={
  cardio:`<path d="M32 53S11 41 11 25c0-10 13-14 21-4 8-10 21-6 21 4 0 16-21 28-21 28Z"/>`,
  hemostasis:`<path d="M32 8s15 18 15 31a15 15 0 1 1-30 0C17 26 32 8 32 8Z"/>`,
  endocrine:`<circle cx="32" cy="32" r="6"/><path d="M32 9v12M32 43v12M9 32h12M43 32h12M16 16l8 8M40 40l8 8M48 16l-8 8M24 40l-8 8"/>`,
  psych:`<path d="M24 16c-8 2-11 12-6 18-5 5-2 14 6 15 3 6 13 5 15-1 8 1 13-8 8-14 5-7 0-17-8-17-3-6-12-6-15-1Z"/><path d="M32 17v31M24 27h8M32 37h8"/>`,
  neuro:`<path d="m35 7-17 29h13l-2 21 17-31H33l2-19Z"/>`,
  pain:`<path d="M32 8v16M32 40v16M8 32h16M40 32h16M15 15l11 11M38 38l11 11M49 15 38 26M26 38 15 49"/>`,
  infectious:`<circle cx="32" cy="32" r="12"/><path d="M32 8v12M32 44v12M8 32h12M44 32h12M15 15l9 9M40 40l9 9M49 15l-9 9M24 40l-9 9"/>`,
  resp:`<path d="M30 14v19c-8-14-17-10-18 5-1 13 8 17 18 11V33M34 14v19c8-14 17-10 18 5 1 13-8 17-18 11V33"/>`,
  gi:`<path d="M29 10c0 11 8 10 8 18 0 4-4 6-7 4-9-5-17 1-16 11 1 10 9 14 19 11 11-3 17-14 14-24-3-11-13-10-18-20Z"/>`,
  uro:`<path d="M25 13c-9 0-14 9-12 18 2 9 9 13 16 8V18c-1-3-2-5-4-5ZM39 13c9 0 14 9 12 18-2 9-9 13-16 8V18c1-3 2-5 4-5Z"/><path d="M29 39v14M35 39v14"/>`,
  repro:`<circle cx="32" cy="24" r="12"/><path d="M32 36v20M24 48h16"/>`,
  immune:`<path d="M32 8 50 15v14c0 13-8 21-18 27-10-6-18-14-18-27V15L32 8Z"/>`,
  oncology:`<path d="M22 11c17 6 23 18 20 42M42 11C25 17 19 29 22 53"/><path d="M22 26h20M23 40h18"/>`,
  bone:`<path d="M17 22c-7-7-13 2-7 7l20 20c7 7 16-2 9-9L20 21c-1-1-2-1-3 1ZM47 42c7 7 13-2 7-7L34 15c-7-7-16 2-9 9l19 19c1 1 2 1 3-1Z"/>`,
  ophth:`<path d="M7 32s10-15 25-15 25 15 25 15-10 15-25 15S7 32 7 32Z"/><circle cx="32" cy="32" r="7"/>`,
  local:`<path d="M16 46 42 20l8 8-26 26H16v-8Z"/><path d="m37 25 8 8"/>`,
  toxicology:`<path d="M32 8 56 52H8L32 8Z"/><path d="M32 23v14M32 45v1"/>`
 };
 return wrap(m[type]||m.study||`<circle cx="32" cy="32" r="20"/>`);
}

export function capsuleLogo(cls="brandCapsuleLogo"){
 return `<svg class="${cls}" viewBox="0 0 120 82" aria-hidden="true" focusable="false">
   <g fill="none" stroke="currentColor" stroke-width="6.2" stroke-linecap="round" stroke-linejoin="round">
     <path d="M13 29c8-13 21-17 32-8l18 15-25 27-18-15c-9-7-10-13-7-19Z"/>
     <path d="M107 29c-8-13-21-17-32-8L57 36l25 27 18-15c9-7 10-13 7-19Z"/>
     <path d="M38 23c4 0 8 2 11 5M82 23c-4 0-8 2-11 5" stroke-width="4.4"/>
   </g>
   <g fill="currentColor">
     <circle cx="56" cy="48" r="3.8"/><circle cx="65" cy="53" r="4.7"/><circle cx="52" cy="58" r="3.3"/>
     <circle cx="62" cy="64" r="3.8"/><circle cx="54" cy="69" r="2.4"/><circle cx="67" cy="73" r="2.4"/>
   </g>
 </svg>`;
}
