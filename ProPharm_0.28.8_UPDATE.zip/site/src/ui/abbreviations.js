import { esc } from '../core/shared.js';
import { DRUGS, ABBREVIATIONS, THEORY, MECHANISMS, INTERACTIONS, TESTS, TEST_ANALYSES, ALL_ABBREVIATIONS } from '../core/content.js';

export function countsForTopic(id){return {drugs:DRUGS.filter(d=>d.topics.includes(id)).length,abbr:(ABBREVIATIONS[id]||[]).length,theory:(THEORY[id]||[]).length,mechanisms:(MECHANISMS[id]||[]).length,tests:TESTS.filter(q=>q.topic===id).length,analyses:TEST_ANALYSES.filter(q=>q.topic===id).length,interactions:(INTERACTIONS[id]||[]).length};}

export function abbreviationAliases(abbr){
 return String(abbr||"").split(/\s*\/\s*/).map(x=>x.trim()).filter(Boolean);
}

export function textHasAbbreviation(text,abbr){
 const hay=String(text||"");
 return abbreviationAliases(abbr).some(alias=>{
   const escaped=alias.replace(/[.*+?^${}()|[\]\\]/g,"\\$&");
   return new RegExp(`(^|[^A-Za-zА-Яа-я0-9])${escaped}([^A-Za-zА-Яа-я0-9]|$)`,"i").test(hay);
 });
}

export function abbreviationsInText(text){
 if(!text)return [];
 return ALL_ABBREVIATIONS.filter(a=>textHasAbbreviation(text,a.abbr));
}

export function renderAbbreviationLead(text,exclude=[]){
 const blocked=new Set((exclude||[]).map(x=>String(x).trim().toLowerCase()).filter(Boolean));
 const found=abbreviationsInText(text).filter(a=>!abbreviationAliases(a.abbr).some(alias=>blocked.has(alias.toLowerCase())));
 if(!found.length)return "";
 return `<div class="abbrLead"><div class="abbrLeadTitle">Используемые термины и сокращения</div>${found.map(a=>`<div class="abbrLeadRow"><b>${esc(a.abbr)}</b><span>${esc(a.full||"")}${a.ru?` — ${esc(a.ru)}`:""}</span></div>`).join("")}</div>`;
}

export function renderTextWithAbbreviations(text){
 if(!text)return "";
 return `${renderAbbreviationLead(text)}${String(text).split("\\n").filter(Boolean).map(x=>`<p>${esc(x)}</p>`).join("")}`;
}
