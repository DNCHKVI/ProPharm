import { esc } from '../core/shared.js';
import { buildFlashCards } from '../features/study-tools.js';
import { allCanonicalMechanisms } from '../features/systems.js';
import { CARDIO_PATHOLOGIES, TESTS, drugMap, systemMap, diseaseMap } from '../core/content.js';
import { authState, isAuthConfigured } from '../../services/authService.js';
import { toggleFavorite, isFavorite, setReview } from '../../services/userData.js';

export function authBadge(){
  if(!isAuthConfigured())return `<span class="modeBadge">Аккаунты не настроены</span>`;
  const p=authState.profile;if(!p)return "";
  return `<span class="modeBadge ${p.role==='admin'?'admin':'user'}">${p.role==='admin'?'Администратор':'Профиль'}</span>`;
}

export function toast(message,type="ok"){
  const old=document.querySelector('.toastMessage');if(old)old.remove();
  const el=document.createElement('div');el.className=`toastMessage ${type}`;el.textContent=message;document.body.appendChild(el);setTimeout(()=>el.classList.add('show'),20);setTimeout(()=>{el.classList.remove('show');setTimeout(()=>el.remove(),250)},2200);
}

export function favoriteButton(type,id,label="Избранное"){
  return `<button class="miniAction favoriteAction" data-favorite-type="${esc(type)}" data-favorite-id="${esc(id)}" aria-label="${esc(label)}"><span>♡</span><small>${esc(label)}</small></button>`;
}

export function reviewButton(type,id,label="Повторить"){
  return `<button class="miniAction reviewAction" data-review-type="${esc(type)}" data-review-id="${esc(id)}" aria-label="${esc(label)}"><span>↻</span><small>${esc(label)}</small></button>`;
}

export async function bindPersonalActions(root=document){
  root.querySelectorAll('[data-favorite-type]').forEach(async b=>{
    const type=b.dataset.favoriteType,id=b.dataset.favoriteId;
    try{if(await isFavorite(type,id)){b.classList.add('active');const s=b.querySelector('span');if(s)s.textContent='♥'}}catch{}
    b.onclick=async e=>{e.preventDefault();e.stopPropagation();try{const on=await toggleFavorite(type,id);b.classList.toggle('active',on);const sp=b.querySelector('span');if(sp)sp.textContent=on?'♥':'♡';toast(on?'Добавлено в избранное':'Удалено из избранного')}catch(err){toast(err.message||String(err),'bad')}};
  });
  root.querySelectorAll('[data-review-type]').forEach(b=>{
    b.onclick=async e=>{e.preventDefault();e.stopPropagation();try{await setReview(b.dataset.reviewType,b.dataset.reviewId,{reason:'manual',priority:2});b.classList.add('active');toast('Добавлено в «Повторить»')}catch(err){toast(err.message||String(err),'bad')}};
  });
}

export function inferProgressFromRoute(parts){
  if(parts[0]==='system')return {system_id:parts[1]||null,section_id:parts[2]||'overview',entity_id:null,route:location.hash};
  if(parts[0]==='drug')return {system_id:null,section_id:'drug',entity_id:parts[1],route:location.hash};
  if(parts[0]==='disease'||parts[0]==='cardio-pathology')return {system_id:parts[0]==='cardio-pathology'?'cardiovascular':null,section_id:'disease',entity_id:parts[1],route:location.hash};
  if(parts[0]==='mechanism')return {system_id:null,section_id:'mechanism',entity_id:parts[1],route:location.hash};
  return {system_id:null,section_id:parts[0]||'home',entity_id:null,route:location.hash};
}

export function resolvePersonalEntity(type,id){
  if(type==='drug'){const d=drugMap[String(id)];return d?{title:d.name,subtitle:d.group,route:`#drug/${d.n}`}:null}
  if(type==='disease'){const d=diseaseMap[id];return d?{title:d.title,subtitle:systemMap[d.systemId]?.title||'Заболевание',route:`#disease/${id}`}:null}
  if(type==='cardio-pathology'){const d=CARDIO_PATHOLOGIES.find(x=>x.id===id);return d?{title:d.title,subtitle:'Сердечно-сосудистая система',route:`#cardio-pathology/${id}`}:null}
  if(type==='mechanism'){const m=allCanonicalMechanisms().find(x=>x.id===id);return m?{title:m.title,subtitle:systemMap[m.systemId]?.title||'Механизм',route:`#mechanism/${id}`}:null}
  if(type==='question'){const q=TESTS.find(x=>x.id===id);return q?{title:q.question,subtitle:q.sectionTitle||'Тестовый вопрос',route:'#tests'}:null}
  if(type==='system'){const x=systemMap[id];return x?{title:x.title,subtitle:'Система',route:`#system/${id}`}:null}
  if(type==='card'){const c=buildFlashCards().find(x=>x.id===id);return c?{title:c.title,subtitle:c.front,route:'#cards'}:null}
  return {title:`${type}: ${id}`,subtitle:'Сохранённый материал',route:'#study'};
}

export function accountDisplayName(){
 const p=authState.profile||{};return String(p.name||p.email||'Профиль').trim();
}
