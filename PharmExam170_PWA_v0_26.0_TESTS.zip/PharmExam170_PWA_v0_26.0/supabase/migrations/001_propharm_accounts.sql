-- ProPharm v0.16 — profiles, approval gate, progress, favorites and review queue.
-- Run in Supabase SQL Editor. Then bootstrap the ONE administrator manually (see README).

create extension if not exists pgcrypto;

do $$ begin
  create type public.propharm_role as enum ('user','admin');
exception when duplicate_object then null; end $$;
do $$ begin
  create type public.propharm_status as enum ('pending','approved','blocked','rejected');
exception when duplicate_object then null; end $$;

create table if not exists public.profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  name text not null default '',
  email text,
  avatar_url text,
  provider text,
  role public.propharm_role not null default 'user',
  status public.propharm_status not null default 'pending',
  created_at timestamptz not null default now(),
  last_login timestamptz,
  updated_at timestamptz not null default now()
);

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path=public as $$
begin
  insert into public.profiles(user_id,name,email,avatar_url,provider,role,status)
  values(
    new.id,
    coalesce(new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'name',''),
    new.email,
    coalesce(new.raw_user_meta_data->>'avatar_url',new.raw_user_meta_data->>'picture'),
    coalesce(new.raw_app_meta_data->>'provider','email'),
    'user','pending'
  ) on conflict(user_id) do nothing;
  return new;
end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();

create table if not exists public.test_sessions (
  id text primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  test_id text,
  system_id text,
  section_id text,
  started_at timestamptz,
  completed_at timestamptz,
  questions_total int not null default 0,
  first_try_correct int not null default 0,
  questions_with_retries int not null default 0,
  wrong_selections int not null default 0,
  score numeric,
  duration_seconds int,
  created_at timestamptz not null default now()
);

create table if not exists public.question_progress (
  user_id uuid not null references auth.users(id) on delete cascade,
  question_id text not null,
  system_id text,
  section_id text,
  attempts int not null default 0,
  correct_count int not null default 0,
  wrong_count int not null default 0,
  first_try_correct_count int not null default 0,
  last_seen timestamptz,
  last_result text,
  updated_at timestamptz not null default now(),
  primary key(user_id,question_id)
);

create table if not exists public.favorites (
  user_id uuid not null references auth.users(id) on delete cascade,
  entity_type text not null,
  entity_id text not null,
  created_at timestamptz not null default now(),
  primary key(user_id,entity_type,entity_id)
);

create table if not exists public.review_queue (
  user_id uuid not null references auth.users(id) on delete cascade,
  entity_type text not null,
  entity_id text not null,
  reason text not null default 'manual',
  priority int not null default 1,
  next_review timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  primary key(user_id,entity_type,entity_id)
);

create table if not exists public.study_progress (
  user_id uuid not null references auth.users(id) on delete cascade,
  system_id text not null default 'global',
  section_id text not null default 'route',
  entity_id text not null default '',
  route text,
  viewed boolean not null default true,
  completed boolean not null default false,
  last_opened timestamptz,
  updated_at timestamptz not null default now(),
  primary key(user_id,system_id,section_id,entity_id)
);

create table if not exists public.user_settings (
  user_id uuid primary key references auth.users(id) on delete cascade,
  settings_json jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

create table if not exists public.admin_actions (
  id uuid primary key default gen_random_uuid(),
  admin_user_id uuid not null references auth.users(id),
  target_user_id uuid not null references auth.users(id),
  action text not null,
  created_at timestamptz not null default now()
);

create or replace function public.is_propharm_admin()
returns boolean language sql stable security definer set search_path=public as $$
  select exists(select 1 from public.profiles p where p.user_id=auth.uid() and p.role='admin' and p.status='approved');
$$;

create or replace function public.admin_set_user_status(target_user_id uuid,new_status text)
returns void language plpgsql security definer set search_path=public as $$
begin
  if not public.is_propharm_admin() then raise exception 'admin required'; end if;
  if new_status not in ('pending','approved','blocked','rejected') then raise exception 'invalid status'; end if;
  if target_user_id=auth.uid() and new_status<>'approved' then raise exception 'bootstrap admin cannot self-disable here'; end if;
  update public.profiles set status=new_status::public.propharm_status,updated_at=now() where user_id=target_user_id and role<>'admin';
  insert into public.admin_actions(admin_user_id,target_user_id,action) values(auth.uid(),target_user_id,'status:'||new_status);
end $$;

create or replace function public.record_question_result(p_question_id text,p_system_id text default null,p_section_id text default null,p_correct boolean default true,p_first_try boolean default false,p_wrong_count integer default 0)
returns void language plpgsql security invoker set search_path=public as $$
begin
  insert into public.question_progress(user_id,question_id,system_id,section_id,attempts,correct_count,wrong_count,first_try_correct_count,last_seen,last_result,updated_at)
  values(auth.uid(),p_question_id,p_system_id,p_section_id,1,case when p_correct then 1 else 0 end,greatest(p_wrong_count,0),case when p_first_try then 1 else 0 end,now(),case when p_correct then 'correct' else 'wrong' end,now())
  on conflict(user_id,question_id) do update set
    attempts=public.question_progress.attempts+1,
    correct_count=public.question_progress.correct_count+case when excluded.last_result='correct' then 1 else 0 end,
    wrong_count=public.question_progress.wrong_count+excluded.wrong_count,
    first_try_correct_count=public.question_progress.first_try_correct_count+excluded.first_try_correct_count,
    system_id=coalesce(excluded.system_id,public.question_progress.system_id),
    section_id=coalesce(excluded.section_id,public.question_progress.section_id),
    last_seen=now(),last_result=excluded.last_result,updated_at=now();
end $$;

alter table public.profiles enable row level security;
alter table public.test_sessions enable row level security;
alter table public.question_progress enable row level security;
alter table public.favorites enable row level security;
alter table public.review_queue enable row level security;
alter table public.study_progress enable row level security;
alter table public.user_settings enable row level security;
alter table public.admin_actions enable row level security;

-- Profiles: own row, or all rows for the single admin.
drop policy if exists profiles_select on public.profiles;
create policy profiles_select on public.profiles for select using (user_id=auth.uid() or public.is_propharm_admin());
drop policy if exists profiles_update_self on public.profiles;
create policy profiles_update_self on public.profiles for update using(user_id=auth.uid()) with check(user_id=auth.uid());
-- Critical role/status protection: privileges plus trigger prevent client-side escalation.
revoke update on public.profiles from authenticated;
grant update (name,avatar_url,updated_at,last_login) on public.profiles to authenticated;

-- Own-data policies.
do $$ declare t text; begin
  foreach t in array array['test_sessions','question_progress','favorites','review_queue','study_progress','user_settings'] loop
    execute format('drop policy if exists %I on public.%I',t||'_own',t);
    execute format('create policy %I on public.%I for all using (user_id=auth.uid()) with check (user_id=auth.uid())',t||'_own',t);
  end loop;
end $$;

drop policy if exists admin_actions_admin on public.admin_actions;
create policy admin_actions_admin on public.admin_actions for select using(public.is_propharm_admin());

-- Explicit client privileges. RLS still limits every row to auth.uid().
grant select on public.profiles to authenticated;
grant select,insert,update,delete on public.test_sessions to authenticated;
grant select,insert,update,delete on public.question_progress to authenticated;
grant select,insert,update,delete on public.favorites to authenticated;
grant select,insert,update,delete on public.review_queue to authenticated;
grant select,insert,update,delete on public.study_progress to authenticated;
grant select,insert,update,delete on public.user_settings to authenticated;
grant select on public.admin_actions to authenticated;

-- RPC permissions.
revoke all on function public.admin_set_user_status(uuid,text) from public;
grant execute on function public.admin_set_user_status(uuid,text) to authenticated;
grant execute on function public.record_question_result(text,text,text,boolean,boolean,integer) to authenticated;

-- IMPORTANT: after registering the owner, bootstrap ONE admin manually:
-- update public.profiles set role='admin', status='approved' where user_id='YOUR-OWNER-UUID';
