// ProPharm v0.16 — optional Web Push sender for new admin applications.
// Deploy with JWT verification enabled and call from a Supabase Database Webhook
// on public.admin_notifications INSERT with "Add auth header with service key".
import webpush from 'npm:web-push@3.6.7'
import { createClient } from 'npm:@supabase/supabase-js@2.57.4'

const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!
const SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
const VAPID_PUBLIC_KEY = Deno.env.get('VAPID_PUBLIC_KEY') || ''
const VAPID_PRIVATE_KEY = Deno.env.get('VAPID_PRIVATE_KEY') || ''
const VAPID_SUBJECT = Deno.env.get('VAPID_SUBJECT') || 'mailto:admin@example.com'

if (VAPID_PUBLIC_KEY && VAPID_PRIVATE_KEY) {
  webpush.setVapidDetails(VAPID_SUBJECT, VAPID_PUBLIC_KEY, VAPID_PRIVATE_KEY)
}

Deno.serve(async (req) => {
  try {
    if (req.method !== 'POST') return new Response('Method not allowed', { status: 405 })
    if (!VAPID_PUBLIC_KEY || !VAPID_PRIVATE_KEY) {
      return Response.json({ ok: false, error: 'VAPID secrets are not configured' }, { status: 500 })
    }
    const payload = await req.json()
    const record = payload?.record || payload
    if (record?.kind !== 'new_application') return Response.json({ ok: true, skipped: true })

    const admin = createClient(SUPABASE_URL, SERVICE_ROLE_KEY, { auth: { persistSession: false } })
    const { data: admins, error: adminError } = await admin
      .from('profiles').select('user_id').eq('role', 'admin').eq('status', 'approved')
    if (adminError) throw adminError
    const adminIds = (admins || []).map((x:any) => x.user_id)
    if (!adminIds.length) return Response.json({ ok: true, sent: 0 })

    const { data: subs, error: subError } = await admin
      .from('push_subscriptions').select('id,user_id,endpoint,p256dh,auth').in('user_id', adminIds)
    if (subError) throw subError

    const message = JSON.stringify({
      title: record.title || 'Новая заявка ProPharm',
      body: record.message || `${record.email || 'Новый пользователь'} ожидает подтверждения.`,
      url: '#admin',
      tag: `propharm-application-${record.target_user_id || record.id || Date.now()}`,
    })

    let sent = 0
    for (const sub of subs || []) {
      try {
        await webpush.sendNotification({
          endpoint: sub.endpoint,
          keys: { p256dh: sub.p256dh, auth: sub.auth },
        }, message, { TTL: 86400, urgency: 'high' })
        sent++
      } catch (err:any) {
        const status = Number(err?.statusCode || 0)
        if (status === 404 || status === 410) {
          await admin.from('push_subscriptions').delete().eq('id', sub.id)
        } else {
          console.error('Push failed', status, err?.message || err)
        }
      }
    }
    return Response.json({ ok: true, sent })
  } catch (err:any) {
    console.error(err)
    return Response.json({ ok: false, error: err?.message || String(err) }, { status: 500 })
  }
})
