export const PHARMACOLOGY_FOUNDATIONS = {
  intro:{title:'Общая фармакология',summary:'Фармакодинамика, мишени, dose–response, агонисты/антагонисты, безопасность и связь с фармакокинетикой.',steps:['Лекарство','Мишень','Изменение функции клетки','Изменение органа','Клинический эффект']},
  categories:[
    {id:'diuretics',title:'Диуретики',match:/furosemide|hydrochlorothiazide|spironolactone|dapagliflozin/i},
    {id:'beta-blockers',title:'β-адреноблокаторы',match:/atenolol|metoprolol|propranolol|timolol/i},
    {id:'ccb',title:'Блокаторы кальциевых каналов',match:/amlodipine|nifedipine|diltiazem|verapamil|cinnarizine/i},
    {id:'raas',title:'Ингибиторы RAAS',match:/enalapril|losartan/i},
    {id:'antiarrhythmics',title:'Антиаритмические препараты',match:/amiodarone|propafenone|digoxin|diltiazem|verapamil/i},
    {id:'antithrombotics',title:'Антиагреганты и антикоагулянты',match:/aspirin|clopidogrel|dabigatran|enoxaparin|rivaroxaban|warfarin/i},
    {id:'lipids',title:'Гиполипидемические препараты',match:/atorvastatin|simvastatin|bezafibrate|ezetimibe/i},
    {id:'diabetes',title:'Антидиабетические препараты',match:/insulin|metformin|glibenclamide|repaglinide|sitagliptin|exenatide|liraglutide|dapagliflozin|pioglitazone/i},
    {id:'antidepressants',title:'Антидепрессанты',match:/amitriptyline|nortriptyline|duloxetine|escitalopram|fluoxetine|paroxetine|sertraline|trazodone|venlafaxine|bupropion/i},
    {id:'antiepileptics',title:'Противоэпилептические',match:/carbamazepine|gabapentin|lamotrigine|levetiracetam|oxcarbazepine|phenytoin|pregabalin|topiramate|valproic acid/i},
    {id:'parkinson',title:'Противопаркинсонические',match:/biperiden|bromocriptine|carbidopa|entacapone|levodopa|rasagiline/i},
    {id:'antipsychotics',title:'Антипсихотики',match:/clozapine|haloperidol|olanzapine|perphenazine|quetiapine|risperidone/i},
    {id:'sedatives',title:'Бензодиазепины и снотворные',match:/brotizolam|diazepam|lorazepam|oxazepam|zolpidem|melatonin/i},
    {id:'pain',title:'Анальгетики, НПВС и опиоиды',match:/aspirin|celecoxib|codeine|diclofenac|dipyrone|ibuprofen|naproxen|oxycodone|paracetamol|tramadol/i},
    {id:'resp',title:'Бронходилататоры и противоастматические',match:/salbutamol|tiotropium|montelukast|budesonide|fluticasone/i},
    {id:'antibiotics',title:'Антибактериальные препараты',match:/amoxicillin|azithromycin|cefuroxime|cephalexin|chloramphenicol|ciprofloxacin|clindamycin|doxycycline|gentamicin|metronidazole|penicillin|roxithromycin/i},
    {id:'antifungals',title:'Противогрибковые',match:/fluconazole|ketoconazole|terbinafine/i},
    {id:'glucocorticoids',title:'Глюкокортикоиды',match:/budesonide|fluticasone|prednisone/i},
    {id:'immuno',title:'Иммунодепрессанты и иммуномодуляторы',match:/adalimumab|cyclosporine|methotrexate|tacrolimus/i}
  ]
};

export const DIURETIC_GROUPS = [
  {id:'ca-inhibitors',title:'Ингибиторы карбоангидразы',segment:'Проксимальный каналец',target:'Carbonic anhydrase',examples:['Acetazolamide (теоретический пример; не из списка 170)'],effects:{Na:'↑',K:'↑',Cl:'↔/↑',Ca:'↔',Mg:'↔',HCO3:'↑↑',H2O:'↑'},acidBase:'Метаболический ацидоз',steps:['Carbonic anhydrase ↓','Реабсорбция HCO₃⁻ ↓','Реабсорбция Na⁺ ↓','Осмотическое выведение H₂O ↑','K⁺ теряется вторично']},
  {id:'loop',title:'Петлевые диуретики',segment:'Толстый восходящий сегмент петли Генле',target:'NKCC2 — Na⁺/K⁺/2Cl⁻ cotransporter',examples:['Furosemide'],effects:{Na:'↑↑↑',K:'↑',Cl:'↑↑↑',Ca:'↑',Mg:'↑',HCO3:'↔',H2O:'↑↑↑'},acidBase:'Гипокалиемический метаболический алкалоз',steps:['NKCC2 блокирован','NaCl reabsorption ↓','ROMK-dependent lumen-positive potential ↓','Paracellular Ca²⁺ и Mg²⁺ reabsorption ↓','Медуллярный осмотический градиент ↓','Натрий и вода выводятся ↑']},
  {id:'thiazide',title:'Тиазидные диуретики',segment:'Ранний дистальный извитой каналец',target:'NCC — Na⁺/Cl⁻ cotransporter',examples:['Hydrochlorothiazide'],effects:{Na:'↑↑',K:'↑',Cl:'↑↑',Ca:'↓ (сохраняется)',Mg:'↑/↔',HCO3:'↔',H2O:'↑↑'},acidBase:'Гипокалиемический метаболический алкалоз',steps:['NCC блокирован','NaCl reabsorption ↓','Внутриклеточный Na⁺ ↓','Basolateral Na⁺/Ca²⁺ exchange ↑','Ca²⁺ reabsorption ↑','Ca²⁺ в моче ↓']},
  {id:'enac',title:'ENaC-блокаторы',segment:'Собирательная трубочка, principal cell',target:'ENaC — epithelial sodium channel',examples:['Amiloride / Triamterene (теоретические примеры; не из списка 170)'],effects:{Na:'↑',K:'↓ (сохраняется)',Cl:'↔',Ca:'↔',Mg:'↔',HCO3:'↔',H2O:'↑'},acidBase:'Риск метаболического ацидоза при гиперкалиемии',steps:['ENaC блокирован','Na⁺ uptake ↓','Lumen negativity ↓','K⁺ secretion ↓','Na⁺ и вода выводятся ↑','K⁺ сохраняется']},
  {id:'mra',title:'Антагонисты минералокортикоидного рецептора',segment:'Собирательная трубочка, principal cell',target:'Mineralocorticoid receptor',examples:['Spironolactone'],effects:{Na:'↑',K:'↓ (сохраняется)',Cl:'↔',Ca:'↔',Mg:'↔',HCO3:'↔',H2O:'↑'},acidBase:'Риск гиперкалиемии и метаболического ацидоза',steps:['Aldosterone signaling ↓','ENaC и Na⁺/K⁺-ATPase expression/activity ↓','Na⁺ reabsorption ↓','K⁺ secretion ↓','Na⁺/H₂O выводятся ↑','K⁺ сохраняется']},
  {id:'sglt2',title:'SGLT2 inhibitors: осмотический диурез и натрийурез',segment:'Проксимальный каналец',target:'SGLT2 — sodium-glucose cotransporter 2',examples:['Dapagliflozin'],effects:{Na:'↑',K:'↔/variable',Cl:'↔',Ca:'↔',Mg:'↔',HCO3:'↔',H2O:'↑'},acidBase:'Не классический диуретик; возможен кетоацидоз как отдельный риск класса',steps:['SGLT2 блокирован','Glucose reabsorption ↓','Na⁺ reabsorption ↓','Глюкозурия ↑','Осмотический диурез ↑','Натрийурез ↑']}
];
