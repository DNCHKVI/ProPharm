export const DISEASES = [
  {
    "id": "heart-failure",
    "title": "Сердечная недостаточность",
    "systemId": "cardiovascular",
    "sectionIds": [
      "heart-failure"
    ],
    "theoryIds": [
      "hf-core"
    ]
  },
  {
    "id": "hypertension",
    "title": "Артериальная гипертензия",
    "systemId": "cardiovascular",
    "sectionIds": [
      "hypertension"
    ],
    "theoryIds": [
      "htn-core"
    ]
  },
  {
    "id": "ihd-acs",
    "title": "ИБС и острый коронарный синдром",
    "systemId": "cardiovascular",
    "sectionIds": [
      "ihd-acs"
    ],
    "theoryIds": [
      "ihd-core"
    ]
  },
  {
    "id": "arrhythmias",
    "title": "Аритмии",
    "systemId": "cardiovascular",
    "sectionIds": [
      "antiarrhythmics"
    ],
    "theoryIds": [
      "arrhythmia-core"
    ]
  },
  {
    "id": "atrial-fibrillation",
    "title": "Фибрилляция предсердий",
    "systemId": "cardiovascular",
    "sectionIds": [
      "af"
    ],
    "theoryIds": [
      "arrhythmia-core"
    ]
  },
  {
    "id": "parkinson",
    "title": "Болезнь Паркинсона",
    "systemId": "nervous",
    "sectionIds": [
      "parkinson"
    ],
    "theoryIds": [
      "parkinson-theory",
      "neuro-parkinson-path"
    ]
  },
  {
    "id": "psychosis",
    "title": "Психотические расстройства",
    "systemId": "nervous",
    "sectionIds": [
      "antipsychotics"
    ],
    "theoryIds": [
      "antipsychotics-theory",
      "psych-antipsychotic-targets"
    ]
  },
  {
    "id": "depression",
    "title": "Депрессивные расстройства",
    "systemId": "nervous",
    "sectionIds": [
      "antidepressants"
    ],
    "theoryIds": [
      "antidepressants-theory",
      "psych-depression-path",
      "psych-monoamine"
    ]
  },
  {
    "id": "insomnia-anxiety",
    "title": "Бессонница и тревога",
    "systemId": "nervous",
    "sectionIds": [
      "benzodiazepines"
    ],
    "theoryIds": [
      "benzodiazepines-theory"
    ]
  },
  {
    "id": "epilepsy",
    "title": "Эпилепсия",
    "systemId": "nervous",
    "sectionIds": [
      "epilepsy"
    ],
    "theoryIds": [
      "epilepsy-theory",
      "neuro-epilepsy-targets",
      "neuro-membrane",
      "neuro-synapse"
    ]
  },
  {
    "id": "migraine-neuropathic",
    "title": "Мигрень и нейропатическая боль",
    "systemId": "nervous",
    "sectionIds": [
      "migraine-neuropathic"
    ],
    "theoryIds": [
      "migraine-neuropathic-theory"
    ]
  },
  {
    "id": "diabetes",
    "title": "Сахарный диабет",
    "systemId": "endocrine",
    "sectionIds": [
      "diabetes"
    ],
    "theoryIds": [
      "diabetes-theory",
      "acarbose-theory",
      "endo-insulin",
      "endo-diabetes-path",
      "endo-diabetes-targets"
    ]
  },
  {
    "id": "thrombosis",
    "title": "Тромбоз и антитромботическая терапия",
    "systemId": "blood",
    "sectionIds": [
      "hemostasis"
    ],
    "theoryIds": [
      "hemostasis-core",
      "hemostasis-primary",
      "hemostasis-secondary",
      "hemostasis-thrombosis",
      "hemostasis-targets"
    ]
  },
  {
    "id": "acid-disorders",
    "title": "Кислотозависимые заболевания ЖКТ",
    "systemId": "gastrointestinal",
    "sectionIds": [
      "gi-acid"
    ],
    "theoryIds": [
      "gastric-acid-theory",
      "ppi-theory",
      "gi-motility"
    ]
  },
  {
    "id": "allergy",
    "title": "Аллергические заболевания",
    "systemId": "respiratory",
    "sectionIds": [
      "antihistamines"
    ],
    "theoryIds": [
      "antihistamine-theory"
    ]
  },
  {
    "id": "inflammatory-pain",
    "title": "Воспалительная боль",
    "systemId": "pain",
    "sectionIds": [
      "nsaids",
      "analgesics-local"
    ],
    "theoryIds": [
      "nsaid-theory",
      "paracetamol-theory"
    ]
  },
  {
    "id": "opioid-pain",
    "title": "Опиоидная анальгезия",
    "systemId": "pain",
    "sectionIds": [
      "opioids"
    ],
    "theoryIds": [
      "opioid-theory"
    ]
  },
  {
    "id": "steroid-inflammatory",
    "title": "Глюкокортикостероидная противовоспалительная терапия",
    "systemId": "immune",
    "sectionIds": [
      "steroids"
    ],
    "theoryIds": [
      "steroid-theory",
      "immune-cytokines",
      "immune-autoimmune",
      "immune-targets"
    ]
  }  ,
  {
    "id": "asthma",
    "title": "Бронхиальная астма",
    "systemId": "respiratory",
    "sectionIds": [],
    "theoryIds": ["resp-ventilation", "resp-bronchomotor", "resp-asthma", "resp-targets"]
  },
  {
    "id": "copd",
    "title": "ХОБЛ — физиологическая и фармакологическая основа",
    "systemId": "respiratory",
    "sectionIds": [],
    "theoryIds": ["resp-ventilation", "resp-bronchomotor", "resp-targets"]
  },
  {
    "id": "renal-electrolyte-disorders",
    "title": "Нарушения объёма и электролитов",
    "systemId": "renal",
    "sectionIds": [],
    "theoryIds": ["renal-nephron", "renal-transporters", "renal-electrolytes", "renal-diuretics"]
  },
  {
    "id": "gi-motility-disorders",
    "title": "Нарушения моторики, диарея и запор",
    "systemId": "gastrointestinal",
    "sectionIds": [],
    "theoryIds": ["gi-motility", "gi-emesis", "gi-diarrhea-constipation"]
  },
  {
    "id": "thyroid-disorders",
    "title": "Нарушения функции щитовидной железы",
    "systemId": "endocrine",
    "sectionIds": [],
    "theoryIds": ["endo-hormone-signaling", "endo-thyroid"]
  },
  {
    "id": "antimicrobial-resistance",
    "title": "Инфекция и антимикробная устойчивость",
    "systemId": "infectious",
    "sectionIds": [],
    "theoryIds": ["infect-bacterial-structure", "infect-antibacterial-targets", "infect-resistance", "infect-antiviral-antifungal"]
  },
  {
    "id": "autoimmune-inflammation",
    "title": "Хроническое аутоиммунное воспаление",
    "systemId": "immune",
    "sectionIds": [],
    "theoryIds": ["immune-innate-adaptive", "immune-cytokines", "immune-autoimmune", "immune-targets"]
  },
  {
    "id": "osteoporosis",
    "title": "Остеопороз",
    "systemId": "musculoskeletal",
    "sectionIds": [],
    "theoryIds": ["bone-remodeling", "bone-calcium-vitd", "bone-osteoporosis", "bone-targets"]
  },
  {
    "id": "ovulatory-prolactin-disorders",
    "title": "Нарушения овуляции и гиперпролактинемия",
    "systemId": "reproductive",
    "sectionIds": [],
    "theoryIds": ["repro-hpg-axis", "repro-cycle", "repro-disorders", "repro-targets"]
  }

];
