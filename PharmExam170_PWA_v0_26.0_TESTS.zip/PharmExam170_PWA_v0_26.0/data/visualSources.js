export const VISUAL_SOURCES={
  servier:{name:'Servier Medical Art',url:'https://smart.servier.com/',license:'CC BY 4.0',use:'Анатомические и клеточные визуальные референсы; при прямом использовании изображения требуется атрибуция и отметка об адаптации.'},
  reactome:{name:'Reactome',url:'https://reactome.org/',license:'Pathway illustrations: CC BY 4.0; pathway data: CC0',use:'Научная основа сигнальных и биохимических путей; сложные pathways упрощаются до экзаменационно значимой цепочки.'},
  wikipathways:{name:'WikiPathways',url:'https://www.wikipathways.org/',license:'CC0',use:'Дополнительный открытый референс для metabolic/signaling pathways.'},
  openstax:{name:'OpenStax Anatomy & Physiology 2e',url:'https://openstax.org/details/books/anatomy-and-physiology-2e',license:'CC BY-NC-SA 4.0',use:'Учебный референс по анатомии и физиологии. В ProPharm не копировать напрямую без проверки условий конкретного изображения.'},
  ncbi:{name:'NCBI Bookshelf',url:'https://www.ncbi.nlm.nih.gov/books/',license:'Условия зависят от конкретной книги/главы',use:'Академическая проверка физиологии, патофизиологии и фармакологических механизмов; предпочтительно как источник содержания и ссылок на литературу.'},
  wikimedia:{name:'Wikimedia Commons',url:'https://commons.wikimedia.org/',license:'Лицензия проверяется для каждого файла',use:'Только legacy-визуальные assets с проверенной лицензией; не использовать как основной источник теории или механизма.'}
};
export const VISUAL_SOURCE_GROUPS={
  physiology:['openstax','ncbi','servier'],
  biochemistry:['reactome','wikipathways','ncbi'],
  pathophysiology:['reactome','wikipathways','servier'],
  diagnostics:['openstax','ncbi'],
  targets:['reactome','wikipathways']
};
