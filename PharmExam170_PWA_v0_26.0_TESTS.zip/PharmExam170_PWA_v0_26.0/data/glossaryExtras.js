export const GLOSSARY_EXTRAS = [
  {
    "abbr": "HFrEF",
    "full": "Heart Failure with Reduced Ejection Fraction",
    "ru": "сердечная недостаточность со сниженной фракцией выброса"
  },
  {
    "abbr": "HF",
    "full": "Heart Failure",
    "ru": "сердечная недостаточность"
  },
  {
    "abbr": "SNS",
    "full": "Sympathetic Nervous System",
    "ru": "симпатическая нервная система"
  },
  {
    "abbr": "ACEi",
    "full": "Angiotensin-Converting Enzyme inhibitor",
    "ru": "ингибитор ангиотензинпревращающего фермента"
  },
  {
    "abbr": "MRA",
    "full": "Mineralocorticoid Receptor Antagonist",
    "ru": "антагонист минералокортикоидных рецепторов"
  },
  {
    "abbr": "SGLT2",
    "full": "Sodium-Glucose Cotransporter 2",
    "ru": "натрий-глюкозный котранспортер 2"
  },
  {
    "abbr": "CYP",
    "full": "Cytochrome P450",
    "ru": "система цитохрома P450"
  },
  {
    "abbr": "CYP3A4",
    "full": "Cytochrome P450 3A4",
    "ru": "изофермент цитохрома P450 3A4"
  },
  {
    "abbr": "CYP2D6",
    "full": "Cytochrome P450 2D6",
    "ru": "изофермент цитохрома P450 2D6"
  },
  {
    "abbr": "CYP2C19",
    "full": "Cytochrome P450 2C19",
    "ru": "изофермент цитохрома P450 2C19"
  },
  {
    "abbr": "CYP2C9",
    "full": "Cytochrome P450 2C9",
    "ru": "изофермент цитохрома P450 2C9"
  },
  {
    "abbr": "CYP1A2",
    "full": "Cytochrome P450 1A2",
    "ru": "изофермент цитохрома P450 1A2"
  },
  {
    "abbr": "P-gp",
    "full": "P-glycoprotein",
    "ru": "P-гликопротеин, мембранный транспортёр"
  },
  {
    "abbr": "PK",
    "full": "Pharmacokinetics",
    "ru": "фармакокинетика"
  },
  {
    "abbr": "PD",
    "full": "Pharmacodynamics",
    "ru": "фармакодинамика"
  },
  {
    "abbr": "Cmax",
    "full": "Maximum plasma concentration",
    "ru": "максимальная концентрация в плазме"
  },
  {
    "abbr": "Tmax",
    "full": "Time to maximum plasma concentration",
    "ru": "время достижения максимальной концентрации"
  },
  {
    "abbr": "AUC",
    "full": "Area Under the Curve",
    "ru": "площадь под кривой концентрация–время"
  },
  {
    "abbr": "Vd",
    "full": "Volume of distribution",
    "ru": "объём распределения"
  },
  {
    "abbr": "t½",
    "full": "Elimination half-life",
    "ru": "период полувыведения"
  },
  {
    "abbr": "BBB / ГЭБ",
    "full": "Blood–Brain Barrier",
    "ru": "гематоэнцефалический барьер"
  },
  {
    "abbr": "CNS / ЦНС",
    "full": "Central Nervous System",
    "ru": "центральная нервная система"
  },
  {
    "abbr": "GI / ЖКТ",
    "full": "Gastrointestinal tract",
    "ru": "желудочно-кишечный тракт"
  },
  {
    "abbr": "AKI / ОПП",
    "full": "Acute Kidney Injury",
    "ru": "острое повреждение почек"
  },
  {
    "abbr": "CKD / ХБП",
    "full": "Chronic Kidney Disease",
    "ru": "хроническая болезнь почек"
  },
  {
    "abbr": "NSAID / НПВС",
    "full": "Nonsteroidal Anti-Inflammatory Drug",
    "ru": "нестероидное противовоспалительное средство"
  },
  {
    "abbr": "SSRI / СИОЗС",
    "full": "Selective Serotonin Reuptake Inhibitor",
    "ru": "селективный ингибитор обратного захвата серотонина"
  },
  {
    "abbr": "SNRI / СИОЗСН",
    "full": "Serotonin–Norepinephrine Reuptake Inhibitor",
    "ru": "ингибитор обратного захвата серотонина и норадреналина"
  },
  {
    "abbr": "TCA / ТЦА",
    "full": "Tricyclic Antidepressant",
    "ru": "трициклический антидепрессант"
  },
  {
    "abbr": "MAO-B",
    "full": "Monoamine Oxidase B",
    "ru": "моноаминоксидаза B"
  },
  {
    "abbr": "COMT",
    "full": "Catechol-O-Methyltransferase",
    "ru": "катехол-O-метилтрансфераза"
  },
  {
    "abbr": "DAT",
    "full": "Dopamine Transporter",
    "ru": "дофаминовый транспортёр"
  },
  {
    "abbr": "NET",
    "full": "Norepinephrine Transporter",
    "ru": "норадреналиновый транспортёр"
  },
  {
    "abbr": "SERT",
    "full": "Serotonin Transporter",
    "ru": "серотониновый транспортёр"
  },
  {
    "abbr": "GABA",
    "full": "Gamma-Aminobutyric Acid",
    "ru": "гамма-аминомасляная кислота"
  },
  {
    "abbr": "GABA-A",
    "full": "Gamma-Aminobutyric Acid type A receptor",
    "ru": "ГАМК-A-рецептор"
  },
  {
    "abbr": "EPS / ЭПС",
    "full": "Extrapyramidal Symptoms",
    "ru": "экстрапирамидные симптомы"
  },
  {
    "abbr": "D₂",
    "full": "Dopamine D2 receptor",
    "ru": "дофаминовый рецептор D2"
  },
  {
    "abbr": "H₁",
    "full": "Histamine H1 receptor",
    "ru": "гистаминовый H1-рецептор"
  },
  {
    "abbr": "H₂",
    "full": "Histamine H2 receptor",
    "ru": "гистаминовый H2-рецептор"
  },
  {
    "abbr": "PDE5",
    "full": "Phosphodiesterase type 5",
    "ru": "фосфодиэстераза типа 5"
  },
  {
    "abbr": "COX-1",
    "full": "Cyclooxygenase-1",
    "ru": "циклооксигеназа-1"
  },
  {
    "abbr": "COX-2",
    "full": "Cyclooxygenase-2",
    "ru": "циклооксигеназа-2"
  },
  {
    "abbr": "PBP",
    "full": "Penicillin-Binding Protein",
    "ru": "пенициллин-связывающий белок"
  },
  {
    "abbr": "MIC",
    "full": "Minimum Inhibitory Concentration",
    "ru": "минимальная подавляющая концентрация"
  },
  {
    "abbr": "DNA / ДНК",
    "full": "Deoxyribonucleic Acid",
    "ru": "дезоксирибонуклеиновая кислота"
  },
  {
    "abbr": "RNA / РНК",
    "full": "Ribonucleic Acid",
    "ru": "рибонуклеиновая кислота"
  },
  {
    "abbr": "TNF-α",
    "full": "Tumor Necrosis Factor alpha",
    "ru": "фактор некроза опухоли альфа"
  },
  {
    "abbr": "NF-κB",
    "full": "Nuclear Factor kappa B",
    "ru": "ядерный фактор κB"
  },
  {
    "abbr": "MAPK",
    "full": "Mitogen-Activated Protein Kinase",
    "ru": "митоген-активируемая протеинкиназа"
  },
  {
    "abbr": "PPAR-α",
    "full": "Peroxisome Proliferator-Activated Receptor alpha",
    "ru": "рецептор, активируемый пролифераторами пероксисом, α"
  },
  {
    "abbr": "PPARγ",
    "full": "Peroxisome Proliferator-Activated Receptor gamma",
    "ru": "рецептор, активируемый пролифераторами пероксисом, γ"
  },
  {
    "abbr": "LDL",
    "full": "Low-Density Lipoprotein",
    "ru": "липопротеины низкой плотности"
  },
  {
    "abbr": "HDL",
    "full": "High-Density Lipoprotein",
    "ru": "липопротеины высокой плотности"
  },
  {
    "abbr": "TG",
    "full": "Triglycerides",
    "ru": "триглицериды"
  },
  {
    "abbr": "GLP-1",
    "full": "Glucagon-Like Peptide-1",
    "ru": "глюкагоноподобный пептид-1"
  },
  {
    "abbr": "DPP-4",
    "full": "Dipeptidyl Peptidase-4",
    "ru": "дипептидилпептидаза-4"
  },
  {
    "abbr": "TSH",
    "full": "Thyroid-Stimulating Hormone",
    "ru": "тиреотропный гормон"
  },
  {
    "abbr": "T4",
    "full": "Thyroxine",
    "ru": "тироксин"
  },
  {
    "abbr": "T3",
    "full": "Triiodothyronine",
    "ru": "трийодтиронин"
  },
  {
    "abbr": "INR",
    "full": "International Normalized Ratio",
    "ru": "международное нормализованное отношение"
  },
  {
    "abbr": "PT",
    "full": "Prothrombin Time",
    "ru": "протромбиновое время"
  },
  {
    "abbr": "aPTT",
    "full": "Activated Partial Thromboplastin Time",
    "ru": "активированное частичное тромбопластиновое время"
  },
  {
    "abbr": "DOAC",
    "full": "Direct Oral Anticoagulant",
    "ru": "прямой пероральный антикоагулянт"
  },
  {
    "abbr": "LMWH",
    "full": "Low-Molecular-Weight Heparin",
    "ru": "низкомолекулярный гепарин"
  }
];
