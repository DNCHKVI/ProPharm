export const ADVANCED_TABLES = {
  "hemostasis": [
    {
      "id": "hemostasis-layers",
      "title": "Первичный и вторичный гемостаз",
      "type": "Физиология / фармакология",
      "columns": [
        "Уровень",
        "Ключевые звенья",
        "Препараты из базы"
      ],
      "rows": [
        [
          "Первичный гемостаз",
          "vWF → platelet adhesion → ADP/TXA₂ → GPIIb/IIIa",
          "Aspirin, Clopidogrel"
        ],
        [
          "Вторичный гемостаз",
          "Xa → thrombin → fibrin",
          "Rivaroxaban, Dabigatran, Warfarin, Enoxaparin"
        ]
      ],
      "note": "Учебная схема разделяет тромбоцитарное и коагуляционное звено; in vivo процессы тесно взаимодействуют."
    }
  ],
  "uro": [
    {
      "id": "nephron-targets",
      "title": "Сегменты нефрона и фармакологические мишени",
      "type": "Физиология / фармакология",
      "columns": [
        "Сегмент",
        "Транспортёр / регуляция",
        "Препараты из базы"
      ],
      "rows": [
        [
          "Проксимальный каналец",
          "SGLT2",
          "Dapagliflozin"
        ],
        [
          "Толстое восходящее колено",
          "NKCC2",
          "Furosemide"
        ],
        [
          "Дистальный извитой каналец",
          "NCC",
          "Hydrochlorothiazide"
        ],
        [
          "Собирательная трубочка",
          "Mineralocorticoid receptor / ENaC",
          "Spironolactone"
        ]
      ],
      "note": "Расположение мишени объясняет силу натрийуреза и характер электролитных эффектов."
    }
  ],
  "resp": [
    {
      "id": "bronchial-targets",
      "title": "Регуляция бронхиального тонуса",
      "type": "Физиология / фармакология",
      "columns": [
        "Мишень",
        "Сигнал",
        "Фармакологический результат"
      ],
      "rows": [
        [
          "β₂ receptor",
          "Gs → cAMP ↑",
          "Salbutamol → бронходилатация"
        ],
        [
          "Muscarinic receptor",
          "Gq/Ca²⁺ → bronchoconstriction",
          "Tiotropium → cholinergic tone ↓"
        ],
        [
          "CysLT₁",
          "Leukotriene signaling",
          "Montelukast → leukotriene effects ↓"
        ],
        [
          "Glucocorticoid receptor",
          "Gene transcription",
          "Budesonide/Fluticasone → inflammation ↓"
        ]
      ]
    }
  ],
  "gi": [
    {
      "id": "gi-function-targets",
      "title": "Функция ЖКТ и основные лекарственные мишени",
      "type": "Физиология / фармакология",
      "columns": [
        "Процесс",
        "Мишень",
        "Пример"
      ],
      "rows": [
        [
          "Кислотопродукция",
          "H₂ / H⁺K⁺-ATPase",
          "Famotidine / Omeprazole"
        ],
        [
          "Прокинетика / antiemesis",
          "D₂-related pathways",
          "Metoclopramide, Domperidone"
        ],
        [
          "Диарея",
          "μ-opioid receptors в кишечнике",
          "Loperamide"
        ],
        [
          "Запор",
          "Осмотическая нагрузка / объём стула",
          "Lactulose, Psyllium, Bisacodyl"
        ]
      ]
    }
  ],
  "endocrine": [
    {
      "id": "hormone-receptor-types",
      "title": "Типы гормональных рецепторов",
      "type": "Биохимия",
      "columns": [
        "Группа сигнала",
        "Расположение рецептора",
        "Типичный механизм"
      ],
      "rows": [
        [
          "Пептидные гормоны / катехоламины",
          "Мембрана",
          "GPCR или receptor kinase → second messengers"
        ],
        [
          "Стероидные гормоны",
          "Цитозоль / ядро",
          "Ligand-receptor complex → transcription"
        ],
        [
          "Тиреоидные гормоны",
          "Ядро",
          "Nuclear receptor → transcriptional regulation"
        ]
      ]
    }
  ],
  "infectious": [
    {
      "id": "antiinfective-targets",
      "title": "Противоинфекционные мишени по типу возбудителя",
      "type": "Фармакология",
      "columns": [
        "Мишень",
        "Классы / примеры",
        "Ключевая идея"
      ],
      "rows": [
        [
          "Клеточная стенка",
          "Penicillin V, amoxicillin/clavulanate, cephalosporins",
          "Peptidoglycan synthesis ↓"
        ],
        [
          "30S ribosome",
          "Doxycycline, Gentamicin",
          "Bacterial protein synthesis ↓"
        ],
        [
          "50S ribosome",
          "Azithromycin, Roxithromycin, Clindamycin, Chloramphenicol",
          "Bacterial protein synthesis ↓"
        ],
        [
          "DNA enzymes / damage",
          "Ciprofloxacin, Metronidazole",
          "Nucleic acid function disrupted"
        ],
        [
          "Viral DNA polymerase",
          "Acyclovir",
          "Selective inhibition after activation in infected cells"
        ],
        [
          "Ergosterol pathway",
          "Fluconazole, Ketoconazole, Terbinafine",
          "Fungal membrane synthesis disrupted"
        ]
      ]
    }
  ],
  "immune": [
    {
      "id": "immune-drug-targets",
      "title": "Иммунологические мишени препаратов",
      "type": "Фармакология",
      "columns": [
        "Мишень",
        "Препарат",
        "Эффект"
      ],
      "rows": [
        [
          "TNF",
          "Adalimumab",
          "Pro-inflammatory TNF signaling ↓"
        ],
        [
          "Calcineurin",
          "Cyclosporine, Tacrolimus",
          "T-cell activation / IL-2 transcription ↓"
        ],
        [
          "Glucocorticoid receptor",
          "Prednisone, Budesonide, Fluticasone",
          "Inflammatory gene expression modified"
        ],
        [
          "Folate / inflammatory pathways",
          "Methotrexate",
          "Immune-inflammatory activity ↓"
        ]
      ]
    }
  ],
  "bone": [
    {
      "id": "bone-homeostasis",
      "title": "Костное ремоделирование и минеральный обмен",
      "type": "Физиология / фармакология",
      "columns": [
        "Процесс",
        "Регулятор / мишень",
        "Пример препарата"
      ],
      "rows": [
        [
          "Костная резорбция",
          "Osteoclast activity",
          "Alendronate ↓ osteoclast function"
        ],
        [
          "Минеральная доступность",
          "Ca²⁺ intake / absorption",
          "Calcium"
        ],
        [
          "Кишечное всасывание Ca²⁺",
          "Vitamin D signaling",
          "Vitamin D"
        ],
        [
          "Воспаление суставов",
          "COX / immune pathways",
          "NSAID, Methotrexate, Adalimumab"
        ]
      ]
    }
  ],
  "repro": [
    {
      "id": "repro-hormone-targets",
      "title": "Репродуктивная гормональная ось и препараты",
      "type": "Физиология / фармакология",
      "columns": [
        "Звено",
        "Физиология",
        "Пример из базы"
      ],
      "rows": [
        [
          "Prolactin",
          "D₂ signaling тормозит secretion",
          "Bromocriptine, Cabergoline"
        ],
        [
          "Estrogen feedback / ovulation",
          "Feedback on hypothalamus-pituitary axis",
          "Clomiphene"
        ],
        [
          "Estrogen synthesis",
          "Aromatase",
          "Anastrozole, Letrozole"
        ],
        [
          "Estrogen receptor",
          "Tissue-specific receptor signaling",
          "Tamoxifen / conjugated estrogens"
        ],
        [
          "Контрацепция",
          "Suppression/modulation of HPG axis",
          "Oral contraceptive"
        ]
      ]
    }
  ],
  "neuro": [
    {
      "id": "neural-targets-summary",
      "title": "Нейрональная возбудимость и лекарственные мишени",
      "type": "Физиология / фармакология",
      "columns": [
        "Процесс",
        "Мишень",
        "Примеры"
      ],
      "rows": [
        [
          "Высокочастотное возбуждение",
          "Voltage-gated Na⁺ channels",
          "Carbamazepine, Phenytoin, Lamotrigine"
        ],
        [
          "Пресинаптическое высвобождение",
          "α₂δ VGCC",
          "Gabapentin, Pregabalin"
        ],
        [
          "Dopamine metabolism",
          "MAO-B / COMT",
          "Rasagiline / Entacapone"
        ],
        [
          "Cholinergic balance",
          "Muscarinic receptors",
          "Biperiden"
        ]
      ]
    }
  ],
  "psych": [
    {
      "id": "psych-transmitters",
      "title": "Психофармакология: основные нейромедиаторные мишени",
      "type": "Биохимия / фармакология",
      "columns": [
        "Система",
        "Мишень",
        "Примеры"
      ],
      "rows": [
        [
          "Serotonin",
          "SERT / 5-HT receptors",
          "SSRIs, trazodone"
        ],
        [
          "Norepinephrine",
          "NET",
          "Venlafaxine, Duloxetine, Bupropion"
        ],
        [
          "Dopamine",
          "D₂ receptors / DAT",
          "Antipsychotics / Methylphenidate"
        ],
        [
          "GABA",
          "GABA-A receptor",
          "Diazepam, Lorazepam, Oxazepam, Brotizolam, Zolpidem"
        ]
      ]
    }
  ],
  "pain": [
    {
      "id": "pain-mechanism-map",
      "title": "Механизмы анальгезии",
      "type": "Фармакология",
      "columns": [
        "Тип боли / процесс",
        "Мишень",
        "Примеры"
      ],
      "rows": [
        [
          "Воспалительная сенситизация",
          "COX → prostaglandins",
          "Ibuprofen, Naproxen, Diclofenac, Celecoxib"
        ],
        [
          "Опиоидная передача",
          "μ-opioid receptor",
          "Oxycodone, Codeine, Tramadol"
        ],
        [
          "Нейропатическая передача",
          "α₂δ / monoamine pathways",
          "Pregabalin, Gabapentin, Duloxetine"
        ],
        [
          "Боль/лихорадка",
          "Central prostaglandin-related pathways",
          "Paracetamol, Dipyrone"
        ]
      ]
    }
  ]
};
