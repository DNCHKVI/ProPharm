export const TEST_NAV_STRUCTURE=[
 {id:'basic-sciences',title:'Базовые науки',children:[
  ['chemistry','Химия',['chemistry-success-pharm']],['biochemistry-biology','Биохимия и биология',['biochemistry-success-pharm-2018']],['analytical','Аналитические методы',['analytical-success-pharm']],['pharm-tech','Фармацевтические технологии',['pharm-tech-success-pharm']],['pharm-formulation','Фармацевтическая рецептура',[]],['phys-neuro','Физиология нервной системы',[]],['phys-gi','Физиология пищеварительной системы',[]],['phys-resp','Физиология дыхательной системы',[]],['phys-blood','Физиология системы крови',['hemostasis']],['phys-cardio','Физиология сердечно-сосудистой системы',['cardiac-basics']],['phys-renal','Физиология нефрологической системы',[]],['endocrinology','Эндокринология',['endocrinology-success-pharm','diabetes']]
 ]},
 {id:'pk-a',title:'Фармакокинетика — Часть A',sections:[]},
 {id:'pk-b',title:'Фармакокинетика — Часть B',sections:[]},
 {id:'calculations',title:'Фармацевтические расчёты',sections:[]},
 {id:'law',title:'Фармацевтический закон',sections:[]},
 {id:'intro-pharm',title:'Введение в фармакологию',sections:[]},
 {id:'pharmacology',title:'Фармакология',children:[
  ['hf','Фармакология хронической сердечной недостаточности',['heart-failure']],
  ['constipation','Запор',[]],
  ['htn','Фармакология гипертонии',['hypertension']],
  ['ihd','Ишемическая болезнь сердца',['ihd-acs']],
  ['arrhythmias','Фармакология аритмий',['antiarrhythmics','af']],
  ['ritalin','Фармакология Риталина',['methylphenidate']],
  ['parkinson','Фармакология болезни Паркинсона',['parkinson']],
  ['psychosis','Фармакология психозов',['antipsychotics']],
  ['depression','Фармакология депрессии',['antidepressants']],
  ['sleep','Фармакология снотворных средств',['benzodiazepines']],
  ['epilepsy','Фармакология при эпилепсии',['epilepsy']],
  ['pain','Фармакология боли',['nsaids','opioids','migraine-neuropathic','analgesics-local']],
  ['histamine','Фармакология гистаминов',['gi-acid','antihistamines']],
  ['steroids','Фармакология стероидов',['steroids']],
  ['diabetes','Фармакология диабета',['diabetes']],
  ['blood','Фармакология крови',['hemostasis']],
  ['dyslipidemia','Фармакология дислипидемии',[]],
  ['antibiotics','Фармакология антибиотиков',[]],
  ['antifungal','Противогрибковая фармакология',[]],
  ['misc','Фармакология — Разное',[]],
  ['interactions','Взаимодействие',[]],
  ['asthma','Фармакология при астме',[]]
 ]},
 {id:'practical',title:'Практический экзамен',children:Array.from({length:17},(_,i)=>[`practical-${i+1}`,`Практический экзамен ${i+1}`,[]])}
];
