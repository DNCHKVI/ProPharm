import { ADVANCED_THEORY } from "./advancedTheory.js";

const BASE_THEORY = {
  "cardio": [
    {
      "id": "cardio-electrophysiology",
      "title": "Электрофизиология сердца, Ca²⁺ и ЭКГ",
      "summary": "Проводящая система, потенциалы действия, excitation–contraction coupling, ЭКГ и влияние 49 препаратов.",
      "type": "interactive",
      "url": "modules/cardio/index.html"
    },
    {
      "id": "cardio-core-chain",
      "title": "Главная интеграционная цепочка",
      "summary": "СА-узел → проведение → QRS → L-type Ca²⁺ → RyR2/CICR → TnC → actin/myosin → SERCA/NCX → расслабление.",
      "type": "note",
      "body": [
        "ЭКГ регистрирует электрическую активность, а не механическое сокращение.",
        "Фаза 0 рабочего миокарда зависит от быстрых Na⁺-каналов; фаза 0 СА/АВ-узлов — от L-type Ca²⁺-каналов.",
        "Ca²⁺, вошедший через L-type канал, активирует RyR2 и запускает CICR.",
        "SERCA2a возвращает Ca²⁺ в СПР; NCX в обычном диастолическом режиме выводит Ca²⁺ из клетки."
      ]
    },
    {
      "id": "hf-core",
      "title": "Сердечная недостаточность: базовая логика",
      "summary": "HFrEF, Frank–Starling, preload/afterload и терапевтические цели.",
      "type": "note",
      "body": [
        "HFrEF: в экзаменационном блоке используется EF ≤40%.",
        "Frank–Starling: в физиологическом диапазоне EDV/preload ↑ → растяжение волокон ↑ → SV ↑.",
        "Preload определяется венозным возвратом и ёмкостью венозного русла; afterload связан с сопротивлением выбросу.",
        "Недигидропиридиновые БКК уменьшают сократимость и могут быть нежелательны при HFrEF."
      ],
      "visual": {
        "title": "Frank–Starling",
        "kind": "flow",
        "steps": [
          "венозный возврат ↑",
          "EDV / preload ↑",
          "растяжение саркомера ↑",
          "сила сокращения ↑",
          "SV ↑"
        ]
      },
      "tags": []
    },
    {
      "id": "htn-core",
      "title": "Артериальная гипертензия: β-блокаторы, диуретики и CCB",
      "summary": "Как классы меняют CO, SVR, объём и АВ-проводимость.",
      "type": "note",
      "body": [
        "β₁-блокада → ЧСС/сократимость/renin ↓.",
        "Диуретики уменьшают Na⁺ и объём; электролитные изменения могут менять ЭКГ.",
        "DHP-CCB преимущественно вазодилатируют; verapamil/diltiazem сильнее влияют на сердце и АВ-узел."
      ],
      "visual": {
        "title": "Гемодинамика",
        "kind": "flow",
        "steps": [
          "АД ≈ CO × SVR",
          "β-блокатор → CO ↓",
          "DHP-CCB → SVR ↓",
          "диуретик → объём ↓",
          "АД ↓"
        ]
      },
      "tags": []
    },
    {
      "id": "ihd-core",
      "title": "ИБС, нитраты и ОКС",
      "summary": "NO/cGMP, венодилатация и взаимодействие с PDE5.",
      "type": "note",
      "body": [
        "Нитраты высвобождают NO → sGC → cGMP ↑ → расслабление гладкой мышцы.",
        "Венодилатация уменьшает preload и потребность миокарда в O₂.",
        "Комбинация нитратов с PDE5 inhibitors опасна выраженной гипотензией."
      ],
      "visual": {
        "title": "NO–cGMP",
        "kind": "flow",
        "steps": [
          "нитрат",
          "NO ↑",
          "sGC ↑",
          "cGMP ↑",
          "Ca²⁺ гладкой мышцы ↓",
          "вазодилатация"
        ]
      },
      "tags": []
    },
    {
      "id": "arrhythmia-core",
      "title": "Антиаритмики и потенциал действия",
      "summary": "Связь фаз потенциала действия с QRS, QT и АВ-проводимостью.",
      "type": "note",
      "body": [
        "Fast Na⁺-каналы рабочего миокарда определяют фазу 0 и скорость проведения.",
        "L-type Ca²⁺ определяет фазу 0 узловой ткани и участвует в плато.",
        "K⁺-токи определяют реполяризацию; IKr-блокада может удлинять QT."
      ],
      "visual": {
        "title": "Потенциал действия",
        "kind": "flow",
        "steps": [
          "INa → фаза 0",
          "ICaL → фаза 2",
          "IKr/IKs → фаза 3",
          "ЭКГ: QRS / QT"
        ]
      },
      "tags": []
    }
  ],
  "hemostasis": [
    {
      "id": "hemostasis-core",
      "title": "Антиагреганты и антикоагулянты",
      "summary": "P2Y12, thrombin, Xa и ключевые различия.",
      "type": "note",
      "body": [
        "Clopidogrel требует метаболической активации и блокирует P2Y12.",
        "Dabigatran напрямую ингибирует thrombin (IIa).",
        "Rivaroxaban ингибирует Xa.",
        "Warfarin снижает синтез витамин-K-зависимых факторов."
      ],
      "visual": {
        "title": "Гемостаз",
        "kind": "flow",
        "steps": [
          "тромбоцит → P2Y12",
          "коагуляция → Xa",
          "Xa → thrombin IIa",
          "fibrinogen → fibrin"
        ]
      },
      "tags": []
    }
  ],
  "psych": [
    {
      "id": "methylphenidate-theory",
      "title": "Метилфенидат: DAT/NET и формы высвобождения",
      "summary": "Механизм стимулятора и экзаменационные различия Ritalin/Concerta.",
      "type": "note",
      "body": [
        "Метилфенидат блокирует DAT и NET → обратный захват dopamine и norepinephrine ↓ → их концентрация в синапсе ↑.",
        "Ritalin IR действует короче; LA/SR дольше; Concerta в блоке теста — наиболее длительная форма.",
        "Стимуляция симпатического тонуса может повышать ЧСС и АД; у детей контролируют аппетит, массу и рост."
      ],
      "visual": {
        "title": "Синапс при methylphenidate",
        "kind": "synapse",
        "steps": [
          "DAT блокирован",
          "NET блокирован",
          "DA ↑",
          "NE ↑"
        ]
      },
      "tags": []
    },
    {
      "id": "antipsychotics-theory",
      "title": "Антипсихотики: D₂-пути и экстрапирамидные эффекты",
      "summary": "Нигростриарная D₂-блокада, tardive dyskinesia и dopamine agonists.",
      "type": "note",
      "body": [
        "Блокада D₂ в мезолимбическом пути уменьшает позитивные психотические симптомы.",
        "Блокада D₂ в нигростриарном пути повышает риск EPS; высокопотентные типичные препараты дают больший риск.",
        "Tardive dyskinesia после длительной D₂-блокады может быть стойкой/необратимой.",
        "D₂-агонист bromocriptine способен усиливать психоз."
      ],
      "visual": {
        "title": "D₂-пути",
        "kind": "flow",
        "steps": [
          "D₂-блокада",
          "мезолимбический путь → психоз ↓",
          "нигростриарный путь → EPS ↑"
        ]
      },
      "tags": []
    },
    {
      "id": "antidepressants-theory",
      "title": "Антидепрессанты: TCA, SSRI и серотониновый синдром",
      "summary": "Антихолинергические эффекты, bleeding-risk и serotonergic toxicity.",
      "type": "note",
      "body": [
        "TCA блокируют muscarinic receptors → сухость во рту, запор, задержка мочи, мидриаз и тахикардия.",
        "SSRI уменьшают uptake serotonin в тромбоциты → функция тромбоцитов ослабевает; с antiplatelet drugs bleeding-risk выше.",
        "Серотониновый синдром связан с чрезмерной serotonergic activity и особенно важен при комбинациях нескольких serotonergic drugs."
      ],
      "visual": {
        "title": "SSRI и тромбоциты",
        "kind": "flow",
        "steps": [
          "SERT в тромбоците ↓",
          "serotonin uptake ↓",
          "агрегационная функция ↓",
          "+ clopidogrel",
          "кровотечение ↑"
        ]
      },
      "tags": []
    },
    {
      "id": "benzodiazepines-theory",
      "title": "Бензодиазепины и zolpidem",
      "summary": "GABA-A, Cl⁻, зависимость и фармакокинетика.",
      "type": "note",
      "body": [
        "Бензодиазепины — positive allosteric modulators GABA-A и требуют присутствия эндогенной GABA.",
        "Они увеличивают частоту открытия Cl⁻-канала → hyperpolarization → neuronal excitability ↓.",
        "Diazepam интенсивнее зависит от CYP metabolism; lorazepam/oxazepam преимущественно glucuronidation и имеют меньше CYP-interactions.",
        "Zolpidem относительно селективен к α1/BZ1 site и преимущественно вызывает hypnotic effect."
      ],
      "visual": {
        "title": "GABA-A receptor",
        "kind": "gaba",
        "steps": [
          "GABA",
          "benzodiazepine",
          "Cl⁻ influx ↑",
          "hyperpolarization",
          "возбудимость ↓"
        ]
      },
      "tags": []
    }
  ],
  "neuro": [
    {
      "id": "parkinson-theory",
      "title": "Паркинсон: levodopa, carbidopa, entacapone, rasagiline, biperiden",
      "summary": "Как повысить dopamine в ЦНС и уменьшить холинергический дисбаланс.",
      "type": "note",
      "body": [
        "Levodopa проходит ГЭБ и превращается в dopamine в ЦНС; сам dopamine ГЭБ проходит плохо.",
        "Carbidopa ингибирует периферическую DOPA-decarboxylase → меньше периферического dopamine и больше levodopa достигает мозга.",
        "Entacapone ингибирует COMT и уменьшает периферический метаболизм levodopa; полезен при wearing-off.",
        "Rasagiline селективно ингибирует MAO-B → разрушение dopamine в ЦНС ↓.",
        "Biperiden — центральный antimuscarinic: уменьшает относительное преобладание ACh в striatum."
      ],
      "visual": {
        "title": "Levodopa через ГЭБ",
        "kind": "bbb",
        "steps": [
          "Levodopa",
          "carbidopa ⊣ периферическая DDC",
          "ГЭБ",
          "dopamine в ЦНС ↑",
          "entacapone ⊣ COMT"
        ]
      },
      "tags": []
    },
    {
      "id": "epilepsy-theory",
      "title": "Противоэпилептические механизмы и взаимодействия",
      "summary": "Na⁺-каналы, GABA, α₂δ и клинически важные комбинации.",
      "type": "note",
      "body": [
        "Стабилизация inactivated state Na⁺ channels уменьшает высокочастотную повторную импульсацию.",
        "Усиление GABAergic inhibition снижает neuronal excitability.",
        "Pregabalin связывается с α₂δ-субъединицей VGCC → presynaptic Ca²⁺ influx ↓ → excitatory transmitter release ↓.",
        "Valproate тормозит metabolism lamotrigine → lamotrigine exposure ↑ и риск rash/SJS ↑.",
        "Carbamazepine индуцирует CYP3A4 → эффективность oral contraceptives может снижаться."
      ],
      "visual": {
        "title": "Антиэпилептическая логика",
        "kind": "flow",
        "steps": [
          "Na⁺-каналы ↓ → firing ↓",
          "GABA ↑ → inhibition ↑",
          "α₂δ VGCC → Ca²⁺ ↓",
          "excitation ↓"
        ]
      },
      "tags": []
    },
    {
      "id": "migraine-neuropathic-theory",
      "title": "Мигрень и нейропатическая боль",
      "summary": "Triptans, duloxetine и pregabalin.",
      "type": "note",
      "body": [
        "Triptans — 5-HT1B/1D agonists: cranial vasoconstriction + CGRP release ↓ → купирование острого приступа.",
        "Duloxetine (SNRI) усиливает descending inhibitory pain pathways и используется при neuropathic pain.",
        "Pregabalin через α₂δ VGCC уменьшает excitatory transmitter release."
      ],
      "visual": {
        "title": "Триптан",
        "kind": "flow",
        "steps": [
          "5-HT1B/1D agonist",
          "cranial vasoconstriction",
          "CGRP ↓",
          "мигрень ↓"
        ]
      },
      "tags": []
    }
  ],
  "pain": [
    {
      "id": "nsaid-theory",
      "title": "НПВС: COX-1/COX-2, желудок, тромбоциты и почки",
      "summary": "Почему селективность влияет на ЖКТ, CV-risk и renal perfusion.",
      "type": "note",
      "body": [
        "COX-1 преимущественно конститутивна и участвует в gastroprotection и platelet TXA₂.",
        "COX-2 сильнее ассоциирована с воспалением; селективная блокада меньше повреждает желудок, но может сдвигать thrombotic balance.",
        "NSAID уменьшают renal prostaglandins → afferent vasodilation ↓, Na⁺/water retention ↑ и GFR может снижаться.",
        "NSAID + ACE inhibitor: afferent constriction + efferent dilation → intraglomerular pressure ↓."
      ],
      "visual": {
        "title": "COX-1 vs COX-2",
        "kind": "cox",
        "steps": [
          "Arachidonic acid",
          "COX-1 → gastric PG + TXA₂",
          "COX-2 → inflammatory PG"
        ]
      },
      "tags": []
    },
    {
      "id": "opioid-theory",
      "title": "Опиоиды: μ-рецептор, побочные эффекты и CYP2D6",
      "summary": "Полные μ-агонисты, oxycodone, tramadol и codeine.",
      "type": "note",
      "body": [
        "μ-receptor через Gi/o уменьшает presynaptic Ca²⁺ influx и увеличивает postsynaptic K⁺ conductance → neurotransmitter release/neuronal firing ↓.",
        "Типичные эффекты: analgesia, sedation, constipation и dose-dependent respiratory depression.",
        "Tramadol сочетает opioid activity с monoamine reuptake effects; с SSRI повышает риск serotonin syndrome и seizures.",
        "Codeine частично превращается CYP2D6 в morphine; phenotype CYP2D6 и CYP2D6 inhibitors меняют analgesic response."
      ],
      "visual": {
        "title": "μ-opioid receptor",
        "kind": "flow",
        "steps": [
          "μ / Gi/o",
          "Ca²⁺ presynaptic ↓",
          "K⁺ postsynaptic ↑",
          "transmitter release ↓",
          "аналгезия + НР"
        ]
      },
      "tags": []
    },
    {
      "id": "paracetamol-theory",
      "title": "Paracetamol: центральный эффект и NAPQI",
      "summary": "Анальгезия/антипирез и механизм гепатотоксичности передозировки.",
      "type": "note",
      "body": [
        "Paracetamol уменьшает prostaglandin synthesis преимущественно в ЦНС и имеет слабую peripheral anti-inflammatory activity.",
        "Большая часть метаболизируется glucuronidation/sulfation; небольшая часть через CYP2E1 превращается в NAPQI.",
        "Glutathione detoxifies NAPQI; overdose → glutathione depletion → NAPQI accumulation → hepatotoxicity.",
        "N-acetylcysteine восстанавливает detoxification capacity и используется как antidote."
      ],
      "visual": {
        "title": "Paracetamol metabolism",
        "kind": "paracetamol",
        "steps": [
          "Paracetamol",
          "glucuronidation/sulfation → safe",
          "CYP2E1 → NAPQI",
          "glutathione",
          "overdose → liver injury"
        ]
      },
      "tags": []
    }
  ],
  "gi": [
    {
      "id": "gastric-acid-theory",
      "title": "Желудочная кислотность: gastrin → histamine → H₂ → proton pump",
      "summary": "Связь ECL, H₂-рецептора и H⁺/K⁺-АТФазы.",
      "type": "note",
      "body": [
        "G-cells release gastrin → stimulation of ECL cells → histamine release.",
        "Histamine activates H₂ receptor on parietal cell → cAMP ↑ → H⁺/K⁺-ATPase activity ↑ → HCl secretion ↑.",
        "Famotidine blocks H₂; omeprazole irreversibly inhibits H⁺/K⁺-ATPase after activation in acidic canaliculus."
      ],
      "visual": {
        "title": "Секреция HCl",
        "kind": "stomach",
        "steps": [
          "G-cell → gastrin",
          "ECL → histamine",
          "H₂ → cAMP",
          "H⁺/K⁺-ATPase",
          "HCl ↑"
        ]
      },
      "tags": []
    },
    {
      "id": "ppi-theory",
      "title": "Omeprazole: proton pump и CYP2C19 interactions",
      "summary": "Почему эффект необратим и какие взаимодействия важны.",
      "type": "note",
      "body": [
        "Omeprazole всасывается, достигает parietal cells и активируется в кислой среде canaliculi.",
        "Активная форма ковалентно и необратимо ингибирует H⁺/K⁺-ATPase; эффект длится дольше plasma half-life.",
        "CYP2C19 inhibition может повышать phenytoin exposure.",
        "Clopidogrel — prodrug; CYP2C19 inhibition omeprazole может уменьшать formation of active metabolite и antiplatelet effect."
      ],
      "visual": {
        "title": "Omeprazole + clopidogrel",
        "kind": "flow",
        "steps": [
          "clopidogrel prodrug",
          "CYP2C19",
          "active metabolite",
          "P2Y12 block",
          "omeprazole ⊣ CYP2C19",
          "effect ↓"
        ]
      },
      "tags": []
    }
  ],
  "resp": [
    {
      "id": "antihistamine-theory",
      "title": "H₁-антигистаминные: I и II поколения",
      "summary": "Проникновение через ГЭБ и седативность.",
      "type": "note",
      "body": [
        "H₁-blockers I generation лучше проходят ГЭБ → CNS H₁ blockade → sedation.",
        "Fexofenadine относится к менее седативным H₁-blockers II generation.",
        "Dimenhydrinate даёт H₁-blockade, sedation и anticholinergic adverse effects."
      ],
      "visual": {
        "title": "H₁ и ГЭБ",
        "kind": "flow",
        "steps": [
          "I поколение → ГЭБ проходит",
          "CNS H₁ block",
          "седация ↑",
          "II поколение → ГЭБ хуже",
          "седация ↓"
        ]
      },
      "tags": []
    }
  ],
  "immune": [
    {
      "id": "steroid-theory",
      "title": "Глюкокортикостероиды: геномный механизм и побочные эффекты",
      "summary": "Внутриклеточный receptor, Hsp90, nucleus и gene transcription.",
      "type": "note",
      "body": [
        "Steroid crosses cell membrane and binds cytoplasmic glucocorticoid receptor associated with Hsp90.",
        "Ligand binding changes receptor conformation → Hsp90 dissociates → complex translocates to nucleus.",
        "Complex binds DNA response elements and alters transcription → protein synthesis and pharmacologic effect.",
        "Chronic systemic effects include hyperglycemia, hypertension, osteoporosis and glaucoma; sudden withdrawal after prolonged use risks adrenal insufficiency."
      ],
      "visual": {
        "title": "Steroid receptor",
        "kind": "steroid",
        "steps": [
          "steroid crosses membrane",
          "GR + Hsp90",
          "Hsp90 off",
          "nucleus",
          "DNA/GRE",
          "transcription"
        ]
      },
      "tags": []
    }
  ],
  "endocrine": [
    {
      "id": "diabetes-theory",
      "title": "Диабет: диагностика, гипергликемия и тип 2",
      "summary": "Диагностические пороги и патофизиология insulin resistance.",
      "type": "note",
      "body": [
        "2-h OGTT glucose ≥200 mg/dL и HbA1c ≥6.5% являются диагностическими критериями diabetes в блоке.",
        "Fasting glucose 100–125 mg/dL соответствует impaired fasting glucose/prediabetes; diabetes threshold is ≥126 mg/dL.",
        "Type 2 starts with insulin resistance and compensatory hyperinsulinemia, then progressive β-cell dysfunction.",
        "Hyperglycemia causes polyuria/polydipsia and impaired wound healing; sweating is more typical for hypoglycemia."
      ],
      "visual": {
        "title": "Гликемия: ориентиры",
        "kind": "thresholds",
        "steps": [
          "FPG 100–125 → prediabetes",
          "FPG ≥126 → diabetes",
          "2h OGTT ≥200 → diabetes",
          "HbA1c ≥6.5% → diabetes"
        ]
      },
      "tags": []
    },
    {
      "id": "acarbose-theory",
      "title": "Acarbose: кишечная α-glucosidase",
      "summary": "Механизм уменьшения postprandial glucose.",
      "type": "note",
      "body": [
        "Acarbose inhibits intestinal brush-border α-glucosidases.",
        "Digestion of complex carbohydrates is delayed → glucose absorption is slower → postprandial glycemic excursion decreases.",
        "В исходном webarchive после этого вопроса была вставлена несвязанная схема Humalog Mix 50; она исключена из теоретического блока."
      ],
      "visual": {
        "title": "Acarbose",
        "kind": "flow",
        "steps": [
          "α-glucosidase ⊣",
          "complex carbohydrate breakdown ↓",
          "glucose absorption slower",
          "postprandial glucose ↓"
        ]
      },
      "tags": []
    }
  ]
};

export const THEORY = Object.freeze(Object.fromEntries(
  Array.from(new Set([...Object.keys(BASE_THEORY), ...Object.keys(ADVANCED_THEORY)])).map(key => [
    key,
    [...(BASE_THEORY[key] || []), ...(ADVANCED_THEORY[key] || [])]
  ])
));
