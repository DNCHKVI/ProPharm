import { ADVANCED_TABLES } from "./advancedTables.js";

const BASE_STUDY_TABLES = {
  "cardio": [
    {
      "id": "ecg-standards",
      "title": "Основные элементы ЭКГ — экзаменационные ориентиры",
      "type": "Стандарты / физиология",
      "columns": [
        "Элемент",
        "Что отражает",
        "Ориентир"
      ],
      "rows": [
        [
          "P",
          "Деполяризация предсердий",
          "< 120 мс"
        ],
        [
          "PR",
          "Проведение предсердия → AV-узел → желудочки",
          "120–200 мс"
        ],
        [
          "QRS",
          "Деполяризация желудочков",
          "обычно 60–100 мс; до ~110 мс"
        ],
        [
          "ST",
          "Период после деполяризации до реполяризации желудочков",
          "обычно на изолинии"
        ],
        [
          "QT / QTc",
          "Электрическая систола желудочков",
          "QT зависит от ЧСС; QTc >500 мс — высокий риск TdP"
        ]
      ],
      "note": "Ориентиры используются для учебной подготовки; конкретные нормы зависят от метода измерения и клинического контекста."
    },
    {
      "id": "pacemaker-rates",
      "title": "Иерархия водителей ритма",
      "type": "Физиология",
      "columns": [
        "Уровень",
        "Структура",
        "Собственная частота"
      ],
      "rows": [
        [
          "1",
          "SA node",
          "60–100/мин"
        ],
        [
          "2",
          "AV junction",
          "40–60/мин"
        ],
        [
          "3",
          "His–Purkinje",
          "20–40/мин"
        ]
      ],
      "note": "При выпадении вышележащего пейсмекера нижележащий может формировать замещающий ритм."
    },
    {
      "id": "electrolyte-ecg",
      "title": "Электролиты и типичные изменения ЭКГ",
      "type": "Теоретический материал",
      "columns": [
        "Состояние",
        "Ключевая электрофизиология",
        "Типичный учебный профиль ЭКГ"
      ],
      "rows": [
        [
          "Гипокалиемия",
          "реполяризационный резерв ↓",
          "T уплощается, U появляется; риск QT/TdP ↑"
        ],
        [
          "Гиперкалиемия",
          "часть fast Na⁺-каналов инактивируется",
          "высокий заострённый T → PR/QRS ↑ при нарастании"
        ],
        [
          "Гипокальциемия",
          "плато/ST удлиняется",
          "QT ↑"
        ],
        [
          "Гиперкальциемия",
          "плато завершается быстрее",
          "QT ↓"
        ]
      ]
    },
    {
      "id": "ccb-contrast",
      "title": "DHP и non-DHP блокаторы Ca²⁺-каналов",
      "type": "Фармакология",
      "columns": [
        "Группа",
        "Примеры",
        "Главный экзаменационный акцент"
      ],
      "rows": [
        [
          "DHP CCB",
          "Amlodipine, Nifedipine",
          "преимущественно сосудистая вазодилатация; возможна рефлекторная тахикардия"
        ],
        [
          "non-DHP CCB",
          "Verapamil, Diltiazem",
          "SA/AV-узел и миокард: ЧСС/AV conduction/contractility ↓"
        ]
      ]
    }
  ],
  "psych": [
    {
      "id": "methylphenidate-forms",
      "title": "Формы methylphenidate из тестовой базы",
      "type": "Теоретический материал",
      "columns": [
        "Форма",
        "Учебная продолжительность",
        "Акцент"
      ],
      "rows": [
        [
          "Ritalin IR",
          "≈ 3–4 ч",
          "немедленное высвобождение"
        ],
        [
          "Ritalin SR",
          "промежуточная",
          "замедленное высвобождение"
        ],
        [
          "Ritalin LA",
          "≈ 6–8 ч",
          "пролонгированная форма"
        ],
        [
          "Concerta",
          "≈ 10–12 ч",
          "самая длительная из вариантов теста"
        ]
      ]
    },
    {
      "id": "benzodiazepine-pk",
      "title": "Benzodiazepines / Z-drugs — экзаменационные различия",
      "type": "Теоретический материал",
      "columns": [
        "Препарат/группа",
        "Метаболизм / особенность",
        "Что запомнить"
      ],
      "rows": [
        [
          "Diazepam",
          "значимо зависит от CYP450",
          "больше потенциал CYP-взаимодействий; длительное действие"
        ],
        [
          "Lorazepam / Oxazepam",
          "преимущественно glucuronidation",
          "меньше CYP-взаимодействий"
        ],
        [
          "Zolpidem",
          "относительная селективность α1/BZ1",
          "преимущественно гипнотический эффект; короткий T½"
        ]
      ]
    }
  ],
  "neuro": [
    {
      "id": "parkinson-targets",
      "title": "Препараты болезни Паркинсона — мишени",
      "type": "Фармакология",
      "columns": [
        "Препарат",
        "Мишень",
        "Следствие"
      ],
      "rows": [
        [
          "Levodopa",
          "предшественник dopamine",
          "dopamine в ЦНС ↑ после прохождения ГЭБ"
        ],
        [
          "Carbidopa",
          "периферическая DOPA-decarboxylase",
          "периферическое превращение levodopa ↓ → больше levodopa в мозг"
        ],
        [
          "Entacapone",
          "COMT",
          "периферический метаболизм levodopa ↓; wearing-off уменьшается"
        ],
        [
          "Rasagiline",
          "MAO-B",
          "разрушение dopamine в ЦНС ↓"
        ],
        [
          "Biperiden",
          "центральные muscarinic receptors",
          "холинергическая активность в striatum ↓"
        ]
      ]
    },
    {
      "id": "antiepileptic-mechanisms",
      "title": "Противоэпилептические механизмы из тестов",
      "type": "Фармакология",
      "columns": [
        "Механизм",
        "Примеры из базы",
        "Результат"
      ],
      "rows": [
        [
          "Voltage-gated Na⁺ channel modulation",
          "Carbamazepine, Phenytoin, Lamotrigine",
          "высокочастотное повторное возбуждение ↓"
        ],
        [
          "GABAergic inhibition ↑",
          "Valproic acid и др.",
          "нейрональная возбудимость ↓"
        ],
        [
          "Ca²⁺-зависимое высвобождение transmitter ↓",
          "Gabapentin, Pregabalin (α2δ)",
          "возбуждающая передача ↓"
        ]
      ]
    }
  ],
  "pain": [
    {
      "id": "cox-table",
      "title": "COX-1 / COX-2 — теоретическая таблица",
      "type": "Фармакология",
      "columns": [
        "Мишень",
        "Физиологический акцент",
        "Ингибирование"
      ],
      "rows": [
        [
          "COX-1",
          "желудочная защита, тромбоциты, почечные простаноиды",
          "GI/platelet/renal эффекты"
        ],
        [
          "COX-2",
          "воспалительная индукция; также физиологическая экспрессия в ряде тканей",
          "противовоспалительный эффект; CV/renal контекст важен"
        ]
      ]
    },
    {
      "id": "paracetamol-metabolism",
      "title": "Paracetamol — метаболические пути",
      "type": "Токсикология / фармакология",
      "columns": [
        "Путь",
        "Доля/роль",
        "Итог"
      ],
      "rows": [
        [
          "Glucuronidation / sulfation",
          "основная часть",
          "нетоксичные метаболиты"
        ],
        [
          "CYP2E1 → NAPQI",
          "небольшая часть при обычной дозе",
          "NAPQI обезвреживается glutathione"
        ],
        [
          "Передозировка",
          "glutathione истощается",
          "NAPQI ↑ → hepatotoxicity"
        ],
        [
          "N-acetylcysteine",
          "антидот",
          "восстановление detoxification capacity"
        ]
      ]
    }
  ],
  "gi": [
    {
      "id": "acid-control",
      "title": "Контроль секреции кислоты в желудке",
      "type": "Физиология / фармакология",
      "columns": [
        "Звено",
        "Рецептор/мишень",
        "Результат"
      ],
      "rows": [
        [
          "G-cell",
          "gastrin",
          "ECL stimulation и прямая стимуляция parietal cell"
        ],
        [
          "ECL-cell",
          "histamine → H2",
          "cAMP ↑ в parietal cell"
        ],
        [
          "Parietal cell",
          "H⁺/K⁺-ATPase",
          "HCl в просвет ↑"
        ],
        [
          "Famotidine",
          "H2 blockade",
          "acid secretion ↓"
        ],
        [
          "Omeprazole",
          "необратимая блокада H⁺/K⁺-ATPase после активации",
          "acid secretion ↓ длительно"
        ]
      ]
    }
  ],
  "endocrine": [
    {
      "id": "diabetes-classes",
      "title": "Антидиабетические препараты — ключевые мишени",
      "type": "Фармакология",
      "columns": [
        "Класс",
        "Примеры",
        "Основной механизм"
      ],
      "rows": [
        [
          "SGLT2 inhibitor",
          "Dapagliflozin",
          "renal glucose reabsorption ↓ → glucosuria ↑"
        ],
        [
          "GLP-1 receptor agonist",
          "Exenatide, Liraglutide",
          "glucose-dependent insulin ↑, glucagon ↓, gastric emptying ↓"
        ],
        [
          "DPP-4 inhibitor",
          "Sitagliptin",
          "эндогенный incretin effect ↑"
        ],
        [
          "Sulfonylurea",
          "Glibenclamide",
          "KATP closure в β-cell → insulin release ↑"
        ],
        [
          "Biguanide",
          "Metformin",
          "hepatic gluconeogenesis ↓; insulin sensitivity ↑"
        ]
      ]
    }
  ]
};

export const STUDY_TABLES = Object.freeze(Object.fromEntries(
  Array.from(new Set([...Object.keys(BASE_STUDY_TABLES), ...Object.keys(ADVANCED_TABLES)])).map(key => [key, [...(BASE_STUDY_TABLES[key] || []), ...(ADVANCED_TABLES[key] || [])]])
));
