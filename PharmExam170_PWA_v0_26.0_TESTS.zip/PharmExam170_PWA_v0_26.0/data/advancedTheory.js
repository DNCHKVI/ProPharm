export const ADVANCED_THEORY = {
  "hemostasis": [
    {
      "id": "hemostasis-primary",
      "title": "Первичный гемостаз: сосудистая реакция и тромбоцитарная пробка",
      "section": "physiology",
      "status": "advanced-theory",
      "lastReviewed": "2026-09-07",
      "summary": "Первичный гемостаз быстро ограничивает кровопотерю за счёт адгезии, активации и агрегации тромбоцитов.",
      "type": "note",
      "body": [
        "Повреждение эндотелия открывает субэндотелиальный матрикс и фактор фон Виллебранда.",
        "Тромбоциты адгезируют, меняют форму и высвобождают медиаторы.",
        "ADP и тромбоксан A₂ усиливают рекрутирование тромбоцитов.",
        "Активированный GPIIb/IIIa связывает фибриноген и формирует мостики между тромбоцитами."
      ],
      "visual": {
        "title": "Первичный гемостаз: сосудистая реакция и тромбоцитарная пробка",
        "kind": "flow",
        "steps": [
          "повреждение эндотелия",
          "vWF / коллаген",
          "адгезия тромбоцитов",
          "ADP + TXA₂",
          "GPIIb/IIIa",
          "агрегация"
        ],
        "sourceIds": [
          "openstax-ap",
          "ncbi-books"
        ]
      },
      "sources": [
        "openstax-ap",
        "ncbi-books"
      ]
    },
    {
      "id": "hemostasis-secondary",
      "title": "Вторичный гемостаз: образование тромбина и фибрина",
      "section": "biochemistry",
      "status": "advanced-theory",
      "lastReviewed": "2026-09-07",
      "summary": "Коагуляционные реакции усиливают тромбоцитарную пробку формированием стабилизированной фибриновой сети.",
      "type": "note",
      "body": [
        "Тканевой фактор запускает внешнюю ветвь коагуляции.",
        "Комплексы факторов активируют фактор X.",
        "Xa вместе с кофакторами приводит к образованию тромбина из протромбина.",
        "Тромбин превращает фибриноген в фибрин и усиливает коагуляционный каскад."
      ],
      "visual": {
        "title": "Вторичный гемостаз: образование тромбина и фибрина",
        "kind": "flow",
        "steps": [
          "tissue factor",
          "factor X → Xa",
          "prothrombin → thrombin",
          "fibrinogen → fibrin"
        ],
        "sourceIds": [
          "openstax-ap",
          "reactome",
          "ncbi-books"
        ]
      },
      "sources": [
        "openstax-ap",
        "reactome",
        "ncbi-books"
      ]
    },
    {
      "id": "hemostasis-thrombosis",
      "title": "Тромбоз: дисбаланс про- и антикоагулянтных факторов",
      "section": "pathophysiology",
      "status": "advanced-theory",
      "lastReviewed": "2026-09-07",
      "summary": "Тромбоз возникает при смещении гемостатического равновесия в сторону патологического образования тромба.",
      "type": "note",
      "body": [
        "Классически риск описывают через повреждение эндотелия, стаз/нарушение кровотока и гиперкоагуляцию.",
        "Артериальные тромбы особенно зависят от активации тромбоцитов; венозные — от коагуляции и стаза.",
        "Терапевтическая мишень выбирается по типу тромбоза и клинической ситуации."
      ],
      "visual": {
        "title": "Тромбоз: дисбаланс про- и антикоагулянтных факторов",
        "kind": "flow",
        "steps": [
          "эндотелиальная дисфункция / стаз / гиперкоагуляция",
          "platelet activation ↑",
          "coagulation ↑",
          "pathologic thrombus"
        ],
        "sourceIds": [
          "openstax-ap",
          "ncbi-books",
          "pubmed"
        ]
      },
      "sources": [
        "openstax-ap",
        "ncbi-books",
        "pubmed"
      ]
    },
    {
      "id": "hemostasis-targets",
      "title": "Антитромботические мишени: COX-1, P2Y12, Xa, IIa и витамин K",
      "section": "targets",
      "status": "advanced-theory",
      "lastReviewed": "2026-09-07",
      "summary": "Антиагреганты уменьшают функцию тромбоцитов, а антикоагулянты воздействуют на образование или активность факторов коагуляции.",
      "type": "note",
      "body": [
        "Aspirin необратимо ацетилирует тромбоцитарную COX-1 и уменьшает синтез TXA₂.",
        "Clopidogrel после метаболической активации блокирует P2Y12.",
        "Rivaroxaban ингибирует factor Xa, dabigatran — thrombin (IIa).",
        "Warfarin уменьшает восстановление витамина K и синтез функциональных витамин-K-зависимых факторов."
      ],
      "visual": {
        "title": "Антитромботические мишени: COX-1, P2Y12, Xa, IIa и витамин K",
        "kind": "flow",
        "steps": [
          "COX-1 / TXA₂",
          "P2Y12",
          "factor Xa",
          "thrombin IIa",
          "vitamin K cycle"
        ],
        "sourceIds": [
          "ncbi-pharm",
          "fda",
          "israel-drugs"
        ]
      },
      "sources": [
        "ncbi-pharm",
        "fda",
        "israel-drugs"
      ]
    }
  ],
  "uro": [
    {
      "id": "renal-nephron",
      "title": "Нефрон: фильтрация, реабсорбция и секреция",
      "section": "physiology",
      "status": "advanced-theory",
      "lastReviewed": "2026-09-07",
      "summary": "Нефрон поддерживает объём, осмолярность, электролиты и кислотно-основное состояние через сегмент-специфический транспорт.",
      "type": "note",
      "body": [
        "Клубочек фильтрует плазму через фильтрационный барьер.",
        "Проксимальный каналец реабсорбирует большую часть фильтрованных Na⁺ и воды, а также глюкозу и бикарбонат.",
        "Петля Генле формирует осмотический градиент мозгового вещества.",
        "Дистальные отделы тонко регулируют Na⁺, K⁺, H⁺ и воду под влиянием гормонов."
      ],
      "visual": {
        "title": "Нефрон: фильтрация, реабсорбция и секреция",
        "kind": "flow",
        "steps": [
          "glomerular filtration",
          "proximal reabsorption",
          "loop of Henle",
          "distal nephron",
          "urine"
        ],
        "sourceIds": [
          "openstax-ap",
          "ncbi-books"
        ]
      },
      "sources": [
        "openstax-ap",
        "ncbi-books"
      ]
    },
    {
      "id": "renal-transporters",
      "title": "Ключевые транспортёры нефрона и точки действия диуретиков",
      "section": "biochemistry",
      "status": "advanced-theory",
      "lastReviewed": "2026-09-07",
      "summary": "Локализация транспортёров определяет силу диуреза и характер электролитных изменений.",
      "type": "note",
      "body": [
        "SGLT2 расположен преимущественно в проксимальном канальце и участвует в реабсорбции глюкозы вместе с Na⁺.",
        "NKCC2 в толстом восходящем колене переносит Na⁺, K⁺ и Cl⁻.",
        "NCC в дистальном извитом канальце переносит Na⁺ и Cl⁻.",
        "ENaC и минералокортикоидный рецептор регулируют конечную реабсорбцию Na⁺ и секрецию K⁺."
      ],
      "visual": {
        "title": "Ключевые транспортёры нефрона и точки действия диуретиков",
        "kind": "flow",
        "steps": [
          "SGLT2",
          "NKCC2",
          "NCC",
          "ENaC / MR",
          "Na⁺ / K⁺ / H₂O balance"
        ],
        "sourceIds": [
          "openstax-ap",
          "reactome",
          "ncbi-pharm"
        ]
      },
      "sources": [
        "openstax-ap",
        "reactome",
        "ncbi-pharm"
      ]
    },
    {
      "id": "renal-electrolytes",
      "title": "Нарушения объёма и электролитов: механизм и последствия",
      "section": "pathophysiology",
      "status": "advanced-theory",
      "lastReviewed": "2026-09-07",
      "summary": "Изменения транспорта Na⁺, воды и K⁺ меняют объём циркулирующей жидкости, давление и электрическую стабильность клеток.",
      "type": "note",
      "body": [
        "Задержка Na⁺ ведёт к задержке воды и увеличению внеклеточного объёма.",
        "Избыточный диурез или потери жидкости снижают эффективный циркулирующий объём.",
        "Гипо- и гиперкалиемия изменяют мембранный потенциал и сердечную электрофизиологию.",
        "При снижении GFR возрастает риск накопления почечно выводимых лекарств."
      ],
      "visual": {
        "title": "Нарушения объёма и электролитов: механизм и последствия",
        "kind": "flow",
        "steps": [
          "Na⁺ retention / loss",
          "ECF volume change",
          "K⁺ disturbance",
          "electrical effects",
          "dose adjustment"
        ],
        "sourceIds": [
          "openstax-ap",
          "kdigo",
          "ncbi-books"
        ]
      },
      "sources": [
        "openstax-ap",
        "kdigo",
        "ncbi-books"
      ]
    },
    {
      "id": "renal-diuretics",
      "title": "Диуретики и RAAS: фармакологические мишени почек",
      "section": "targets",
      "status": "advanced-theory",
      "lastReviewed": "2026-09-07",
      "summary": "Диуретики уменьшают реабсорбцию Na⁺ в разных сегментах нефрона; RAAS-блокаторы влияют на нейрогормональную регуляцию объёма и давления.",
      "type": "note",
      "body": [
        "Furosemide блокирует NKCC2.",
        "Hydrochlorothiazide блокирует NCC.",
        "Spironolactone антагонизирует минералокортикоидный рецептор и уменьшает Na⁺-реабсорбцию при сохранении K⁺.",
        "Dapagliflozin ингибирует SGLT2; enalapril и losartan уменьшают эффекты RAAS на уровне ACE и AT₁."
      ],
      "visual": {
        "title": "Диуретики и RAAS: фармакологические мишени почек",
        "kind": "flow",
        "steps": [
          "NKCC2 ⊣",
          "NCC ⊣",
          "MR ⊣",
          "SGLT2 ⊣",
          "ACE / AT₁ blockade"
        ],
        "sourceIds": [
          "ncbi-pharm",
          "kdigo",
          "fda",
          "israel-drugs"
        ]
      },
      "sources": [
        "ncbi-pharm",
        "kdigo",
        "fda",
        "israel-drugs"
      ]
    }
  ],
  "resp": [
    {
      "id": "resp-ventilation",
      "title": "Вентиляция, перфузия и газообмен",
      "section": "physiology",
      "status": "advanced-theory",
      "lastReviewed": "2026-09-07",
      "summary": "Эффективный газообмен требует вентиляции альвеол, перфузии лёгочных капилляров и диффузии газов через альвеолярно-капиллярную мембрану.",
      "type": "note",
      "body": [
        "Вентиляция доставляет свежий газ в альвеолы.",
        "Перфузия приносит венозную кровь к альвеолярным капиллярам.",
        "O₂ диффундирует в кровь, CO₂ — в альвеолу по градиентам парциального давления.",
        "Несоответствие вентиляции и перфузии снижает эффективность газообмена."
      ],
      "visual": {
        "title": "Вентиляция, перфузия и газообмен",
        "kind": "flow",
        "steps": [
          "alveolar ventilation",
          "pulmonary perfusion",
          "diffusion",
          "V/Q matching",
          "gas exchange"
        ],
        "sourceIds": [
          "openstax-ap",
          "ncbi-books"
        ]
      },
      "sources": [
        "openstax-ap",
        "ncbi-books"
      ]
    },
    {
      "id": "resp-bronchomotor",
      "title": "Регуляция тонуса бронхов: β₂, M₃ и воспалительные медиаторы",
      "section": "biochemistry",
      "status": "advanced-theory",
      "lastReviewed": "2026-09-07",
      "summary": "Тонус бронхиальной гладкой мускулатуры определяется балансом бронходилатирующих и бронхоконстрикторных сигналов.",
      "type": "note",
      "body": [
        "β₂-рецептор через Gs повышает cAMP и способствует расслаблению гладкой мышцы.",
        "M₃-рецептор через Gq повышает внутриклеточный Ca²⁺ и способствует бронхоконстрикции и секреции.",
        "Лейкотриены усиливают бронхоконстрикцию, отёк и воспаление."
      ],
      "visual": {
        "title": "Регуляция тонуса бронхов: β₂, M₃ и воспалительные медиаторы",
        "kind": "flow",
        "steps": [
          "β₂ → Gs → cAMP ↑",
          "M₃ → Gq → Ca²⁺ ↑",
          "cysteinyl leukotrienes",
          "bronchial tone"
        ],
        "sourceIds": [
          "openstax-ap",
          "reactome",
          "ncbi-pharm"
        ]
      },
      "sources": [
        "openstax-ap",
        "reactome",
        "ncbi-pharm"
      ]
    },
    {
      "id": "resp-asthma",
      "title": "Астма: воспаление, гиперреактивность и вариабельная обструкция",
      "section": "pathophysiology",
      "status": "advanced-theory",
      "lastReviewed": "2026-09-07",
      "summary": "Астма сочетает хроническое воспаление дыхательных путей, бронхиальную гиперреактивность и вариабельное ограничение воздушного потока.",
      "type": "note",
      "body": [
        "Воспаление повышает чувствительность бронхов к триггерам.",
        "Сокращение гладкой мускулатуры и отёк уменьшают просвет дыхательных путей.",
        "Слизистая гиперсекреция дополнительно повышает сопротивление.",
        "Противовоспалительная терапия снижает активность воспалительного процесса, а бронходилататоры уменьшают бронхоспазм."
      ],
      "visual": {
        "title": "Астма: воспаление, гиперреактивность и вариабельная обструкция",
        "kind": "flow",
        "steps": [
          "airway inflammation",
          "hyperresponsiveness",
          "bronchoconstriction + edema + mucus",
          "variable airflow limitation"
        ],
        "sourceIds": [
          "openstax-ap",
          "gina",
          "pubmed"
        ]
      },
      "sources": [
        "openstax-ap",
        "gina",
        "pubmed"
      ]
    },
    {
      "id": "resp-targets",
      "title": "Мишени респираторной терапии: β₂, M₃, CysLT₁ и глюкокортикоидный рецептор",
      "section": "targets",
      "status": "advanced-theory",
      "lastReviewed": "2026-09-07",
      "summary": "Препараты из экзаменационной базы воздействуют на бронхиальный тонус и воспаление через разные мишени.",
      "type": "note",
      "body": [
        "Salbutamol активирует β₂-рецепторы и вызывает бронходилатацию.",
        "Tiotropium блокирует muscarinic receptors в дыхательных путях и уменьшает холинергическую бронхоконстрикцию.",
        "Montelukast блокирует CysLT₁-рецепторы.",
        "Budesonide и fluticasone активируют внутриклеточный glucocorticoid receptor и изменяют транскрипцию воспалительных генов."
      ],
      "visual": {
        "title": "Мишени респираторной терапии: β₂, M₃, CysLT₁ и глюкокортикоидный рецептор",
        "kind": "flow",
        "steps": [
          "β₂ agonism",
          "muscarinic blockade",
          "CysLT₁ blockade",
          "glucocorticoid receptor"
        ],
        "sourceIds": [
          "ncbi-pharm",
          "gina",
          "gold",
          "fda"
        ]
      },
      "sources": [
        "ncbi-pharm",
        "gina",
        "gold",
        "fda"
      ]
    }
  ],
  "gi": [
    {
      "id": "gi-motility",
      "title": "Моторика ЖКТ и энтеральная нервная система",
      "section": "physiology",
      "status": "advanced-theory",
      "lastReviewed": "2026-09-07",
      "summary": "Моторика желудочно-кишечного тракта координируется гладкой мускулатурой, энтеральной нервной системой и вегетативными влияниями.",
      "type": "note",
      "body": [
        "Перистальтика перемещает содержимое вдоль ЖКТ.",
        "Сегментация способствует смешиванию содержимого и контакту с эпителием.",
        "Парасимпатические влияния обычно усиливают моторную и секреторную активность, симпатические — тормозят.",
        "Сфинктеры регулируют переход содержимого между отделами."
      ],
      "visual": {
        "title": "Моторика ЖКТ и энтеральная нервная система",
        "kind": "flow",
        "steps": [
          "enteric circuits",
          "smooth muscle",
          "peristalsis / segmentation",
          "sphincters"
        ],
        "sourceIds": [
          "openstax-ap",
          "ncbi-books"
        ]
      },
      "sources": [
        "openstax-ap",
        "ncbi-books"
      ]
    },
    {
      "id": "gi-emesis",
      "title": "Рвотный рефлекс: дофамин, серотонин, гистамин и холинергические пути",
      "section": "biochemistry",
      "status": "advanced-theory",
      "lastReviewed": "2026-09-07",
      "summary": "Тошнота и рвота интегрируют сигналы из ЖКТ, вестибулярной системы и центральных хеморецепторных зон.",
      "type": "note",
      "body": [
        "D₂-рецепторы участвуют в центральных эметогенных сигналах.",
        "5-HT₃-сигнализация особенно важна в вагальных афферентах и триггерных путях.",
        "H₁ и muscarinic signaling особенно значимы при вестибулярной тошноте.",
        "Разные противорвотные препараты блокируют разные звенья этого рефлекса."
      ],
      "visual": {
        "title": "Рвотный рефлекс: дофамин, серотонин, гистамин и холинергические пути",
        "kind": "flow",
        "steps": [
          "GI / vestibular inputs",
          "D₂ / 5-HT₃ / H₁ / M receptors",
          "brainstem integration",
          "emesis"
        ],
        "sourceIds": [
          "openstax-ap",
          "ncbi-pharm",
          "ncbi-books"
        ]
      },
      "sources": [
        "openstax-ap",
        "ncbi-pharm",
        "ncbi-books"
      ]
    },
    {
      "id": "gi-diarrhea-constipation",
      "title": "Диарея и запор: баланс секреции, всасывания и моторики",
      "section": "pathophysiology",
      "status": "advanced-theory",
      "lastReviewed": "2026-09-07",
      "summary": "Изменение скорости транзита и транспорта воды/электролитов определяет консистенцию и частоту стула.",
      "type": "note",
      "body": [
        "Ускоренный транзит сокращает время для реабсорбции воды.",
        "Осмотически активные вещества удерживают воду в просвете.",
        "Сниженная моторика и недостаток воды в каловых массах способствуют запору.",
        "Лекарственная терапия может изменять моторную функцию, осмотическую нагрузку или объём содержимого."
      ],
      "visual": {
        "title": "Диарея и запор: баланс секреции, всасывания и моторики",
        "kind": "flow",
        "steps": [
          "secretion / absorption balance",
          "transit time",
          "water content",
          "diarrhea ↔ constipation"
        ],
        "sourceIds": [
          "openstax-ap",
          "ncbi-pharm"
        ]
      },
      "sources": [
        "openstax-ap",
        "ncbi-pharm"
      ]
    },
    {
      "id": "gi-targets",
      "title": "Фармакологические мишени моторики, секреции и стула",
      "section": "targets",
      "status": "advanced-theory",
      "lastReviewed": "2026-09-07",
      "summary": "Препараты ЖКТ воздействуют на кислотопродукцию, дофаминергическую регуляцию моторики, кишечные opioid receptors и физико-химические свойства содержимого.",
      "type": "note",
      "body": [
        "Famotidine блокирует H₂-receptors, omeprazole — H⁺/K⁺-ATPase.",
        "Metoclopramide и domperidone действуют через D₂-related mechanisms и изменяют моторно-эметические pathways.",
        "Loperamide активирует периферические μ-opioid receptors в кишечнике и замедляет транзит.",
        "Lactulose, psyllium и bisacodyl увеличивают воду/объём стула или стимулируют кишечную активность."
      ],
      "visual": {
        "title": "Фармакологические мишени моторики, секреции и стула",
        "kind": "flow",
        "steps": [
          "H₂ / proton pump",
          "D₂-related motility",
          "intestinal μ receptor",
          "osmotic/bulk/stimulant laxation"
        ],
        "sourceIds": [
          "openstax-ap",
          "ncbi-pharm",
          "fda"
        ]
      },
      "sources": [
        "openstax-ap",
        "ncbi-pharm",
        "fda"
      ]
    }
  ],
  "endocrine": [
    {
      "id": "endo-hormone-signaling",
      "title": "Типы гормональных рецепторов и сигнальных механизмов",
      "section": "physiology",
      "status": "advanced-theory",
      "lastReviewed": "2026-09-07",
      "summary": "Водорастворимые и липофильные гормоны передают сигнал через принципиально разные типы рецепторов.",
      "type": "note",
      "body": [
        "Пептидные и многие аминовые гормоны действуют через мембранные рецепторы и вторичные посредники.",
        "Стероидные и тиреоидные гормоны связываются с внутриклеточными/ядерными рецепторами и изменяют экспрессию генов.",
        "Отрицательная обратная связь стабилизирует гормональные оси."
      ],
      "visual": {
        "title": "Типы гормональных рецепторов и сигнальных механизмов",
        "kind": "flow",
        "steps": [
          "membrane receptor / second messenger",
          "intracellular receptor",
          "gene transcription",
          "negative feedback"
        ],
        "sourceIds": [
          "openstax-ap",
          "reactome",
          "ncbi-books"
        ]
      },
      "sources": [
        "openstax-ap",
        "reactome",
        "ncbi-books"
      ]
    },
    {
      "id": "endo-insulin",
      "title": "Инсулин и глюкагон: регуляция глюкозы",
      "section": "biochemistry",
      "status": "advanced-theory",
      "lastReviewed": "2026-09-07",
      "summary": "Инсулин способствует утилизации и запасанию питательных веществ, тогда как глюкагон поддерживает доступность глюкозы в период голодания.",
      "type": "note",
      "body": [
        "Инсулиновый рецептор обладает тирозинкиназной активностью и запускает сигнальные каскады, усиливающие захват и метаболизм глюкозы.",
        "В мышце и жировой ткани инсулин способствует транслокации GLUT4.",
        "Глюкагон через Gs/cAMP поддерживает печёночный гликогенолиз и глюконеогенез."
      ],
      "visual": {
        "title": "Инсулин и глюкагон: регуляция глюкозы",
        "kind": "flow",
        "steps": [
          "insulin receptor TK",
          "PI3K/Akt signaling",
          "GLUT4 trafficking",
          "glucagon → Gs → cAMP"
        ],
        "sourceIds": [
          "openstax-ap",
          "reactome",
          "ncbi-books"
        ]
      },
      "sources": [
        "openstax-ap",
        "reactome",
        "ncbi-books"
      ]
    },
    {
      "id": "endo-diabetes-path",
      "title": "Сахарный диабет 1 и 2 типа: механистическое различие",
      "section": "pathophysiology",
      "status": "advanced-theory",
      "lastReviewed": "2026-09-07",
      "summary": "Гипергликемия может быть следствием абсолютной недостаточности инсулина или сочетания инсулинорезистентности и прогрессирующей β-клеточной дисфункции.",
      "type": "note",
      "body": [
        "При СД1 аутоиммунное разрушение β-клеток приводит к абсолютному дефициту инсулина.",
        "При СД2 инсулинорезистентность первоначально компенсируется повышенной секрецией инсулина, затем функция β-клеток ухудшается.",
        "Хроническая гипергликемия связана с микро- и макрососудистыми осложнениями."
      ],
      "visual": {
        "title": "Сахарный диабет 1 и 2 типа: механистическое различие",
        "kind": "flow",
        "steps": [
          "β-cell loss → insulin deficiency",
          "insulin resistance → compensatory insulin ↑",
          "β-cell failure",
          "chronic hyperglycemia"
        ],
        "sourceIds": [
          "openstax-ap",
          "ada-2026",
          "pubmed"
        ]
      },
      "sources": [
        "openstax-ap",
        "ada-2026",
        "pubmed"
      ]
    },
    {
      "id": "endo-diabetes-targets",
      "title": "Фармакологические мишени при диабете",
      "section": "targets",
      "status": "advanced-theory",
      "lastReviewed": "2026-09-07",
      "summary": "Разные классы препаратов уменьшают гипергликемию через печень, почки, кишечник, β-клетки, инкретиновую систему и периферические ткани.",
      "type": "note",
      "body": [
        "Metformin преимущественно снижает печёночную продукцию глюкозы и улучшает чувствительность к инсулину.",
        "Sulfonylureas и repaglinide стимулируют секрецию инсулина через KATP-зависимый механизм.",
        "SGLT2 inhibition повышает выведение глюкозы с мочой.",
        "GLP-1 receptor agonists усиливают глюкозозависимую секрецию инсулина, а DPP-4 inhibition продлевает действие эндогенных инкретинов."
      ],
      "visual": {
        "title": "Фармакологические мишени при диабете",
        "kind": "flow",
        "steps": [
          "hepatic glucose output ↓",
          "KATP closure → insulin release",
          "SGLT2 blockade",
          "GLP-1 / DPP-4 axis"
        ],
        "sourceIds": [
          "ncbi-pharm",
          "ada-2026",
          "fda",
          "israel-drugs"
        ]
      },
      "sources": [
        "ncbi-pharm",
        "ada-2026",
        "fda",
        "israel-drugs"
      ]
    },
    {
      "id": "endo-thyroid",
      "title": "Ось гипоталамус–гипофиз–щитовидная железа",
      "section": "physiology",
      "status": "advanced-theory",
      "lastReviewed": "2026-09-07",
      "summary": "Тиреоидная ось регулируется отрицательной обратной связью и определяет синтез и секрецию T4/T3.",
      "type": "note",
      "body": [
        "TRH стимулирует гипофизарную секрецию TSH.",
        "TSH стимулирует захват йодида, синтез тиреоглобулина и образование тиреоидных гормонов.",
        "T4 и T3 подавляют TRH и TSH по механизму обратной связи.",
        "Methimazole снижает синтез тиреоидных гормонов; levothyroxine восполняет T4."
      ],
      "visual": {
        "title": "Ось гипоталамус–гипофиз–щитовидная железа",
        "kind": "flow",
        "steps": [
          "TRH",
          "TSH",
          "thyroid hormone synthesis",
          "T4/T3 feedback"
        ],
        "sourceIds": [
          "openstax-ap",
          "ncbi-books",
          "ncbi-pharm"
        ]
      },
      "sources": [
        "openstax-ap",
        "ncbi-books",
        "ncbi-pharm"
      ]
    }
  ],
  "neuro": [
    {
      "id": "neuro-membrane",
      "title": "Мембранный потенциал и потенциал действия нейрона",
      "section": "physiology",
      "status": "advanced-theory",
      "lastReviewed": "2026-09-07",
      "summary": "Нейрональная возбудимость определяется ионными градиентами, селективной проницаемостью мембраны и последовательной активацией voltage-gated channels.",
      "type": "note",
      "body": [
        "Na⁺/K⁺-ATPase поддерживает трансмембранные градиенты.",
        "Деполяризация открывает voltage-gated Na⁺ channels и запускает восходящую фазу потенциала действия.",
        "Инактивация Na⁺-каналов и активация K⁺-токов обеспечивают реполяризацию.",
        "Рефрактерность ограничивает частоту повторного возбуждения."
      ],
      "visual": {
        "title": "Мембранный потенциал и потенциал действия нейрона",
        "kind": "flow",
        "steps": [
          "ion gradients",
          "VG Na⁺ opening",
          "depolarization",
          "K⁺-mediated repolarization",
          "refractory period"
        ],
        "sourceIds": [
          "openstax-ap",
          "ncbi-books"
        ]
      },
      "sources": [
        "openstax-ap",
        "ncbi-books"
      ]
    },
    {
      "id": "neuro-synapse",
      "title": "Химический синапс: Ca²⁺-зависимое высвобождение медиатора",
      "section": "biochemistry",
      "status": "advanced-theory",
      "lastReviewed": "2026-09-07",
      "summary": "Пресинаптический Ca²⁺ связывает электрический сигнал с экзоцитозом нейромедиатора.",
      "type": "note",
      "body": [
        "Потенциал действия деполяризует пресинаптическое окончание.",
        "Voltage-gated Ca²⁺ channels открываются, Ca²⁺ входит в терминаль.",
        "Ca²⁺ запускает слияние везикул с мембраной и экзоцитоз медиатора.",
        "Медиатор связывается с постсинаптическими рецепторами и меняет возбудимость клетки."
      ],
      "visual": {
        "title": "Химический синапс: Ca²⁺-зависимое высвобождение медиатора",
        "kind": "flow",
        "steps": [
          "action potential",
          "VG Ca²⁺ channel",
          "vesicle fusion",
          "neurotransmitter release",
          "postsynaptic receptor"
        ],
        "sourceIds": [
          "openstax-ap",
          "reactome",
          "ncbi-books"
        ]
      },
      "sources": [
        "openstax-ap",
        "reactome",
        "ncbi-books"
      ]
    },
    {
      "id": "neuro-parkinson-path",
      "title": "Болезнь Паркинсона: дофаминергический дефицит и моторные цепи",
      "section": "pathophysiology",
      "status": "advanced-theory",
      "lastReviewed": "2026-09-07",
      "summary": "Дегенерация нигростриарных дофаминергических нейронов нарушает баланс базальных ганглиев и приводит к брадикинезии, ригидности и другим моторным проявлениям.",
      "type": "note",
      "body": [
        "Снижение dopamine в striatum изменяет активность прямого и непрямого путей базальных ганглиев.",
        "Фармакотерапия повышает дофаминергическую стимуляцию или уменьшает относительный холинергический вклад.",
        "Лекарственные эффекты и осложнения отражают вмешательство в центральную дофаминергическую передачу."
      ],
      "visual": {
        "title": "Болезнь Паркинсона: дофаминергический дефицит и моторные цепи",
        "kind": "flow",
        "steps": [
          "nigrostriatal dopamine ↓",
          "basal ganglia output altered",
          "motor inhibition ↑",
          "dopaminergic therapy"
        ],
        "sourceIds": [
          "openstax-ap",
          "ncbi-books",
          "pubmed"
        ]
      },
      "sources": [
        "openstax-ap",
        "ncbi-books",
        "pubmed"
      ]
    },
    {
      "id": "neuro-epilepsy-targets",
      "title": "Мишени противоэпилептической терапии",
      "section": "targets",
      "status": "advanced-theory",
      "lastReviewed": "2026-09-07",
      "summary": "Антиэпилептические препараты уменьшают патологическую синхронную возбудимость через Na⁺-каналы, Ca²⁺-зависимую передачу и GABAergic inhibition.",
      "type": "note",
      "body": [
        "Use-dependent стабилизация инактивированных Na⁺-каналов ограничивает высокочастотное возбуждение.",
        "α₂δ-лиганды уменьшают Ca²⁺-зависимое высвобождение возбуждающих медиаторов.",
        "Усиление GABAergic inhibition сдвигает сеть в сторону торможения."
      ],
      "visual": {
        "title": "Мишени противоэпилептической терапии",
        "kind": "flow",
        "steps": [
          "VG Na⁺ modulation",
          "α₂δ / Ca²⁺ release ↓",
          "GABAergic inhibition ↑",
          "seizure propagation ↓"
        ],
        "sourceIds": [
          "ncbi-pharm",
          "ncbi-books",
          "pubmed"
        ]
      },
      "sources": [
        "ncbi-pharm",
        "ncbi-books",
        "pubmed"
      ]
    }
  ],
  "psych": [
    {
      "id": "psych-monoamine",
      "title": "Моноаминовые синапсы: serotonin, norepinephrine и dopamine",
      "section": "biochemistry",
      "status": "advanced-theory",
      "lastReviewed": "2026-09-07",
      "summary": "Концентрация моноаминов в синапсе зависит от синтеза, везикулярного хранения, высвобождения, обратного захвата и ферментативного метаболизма.",
      "type": "note",
      "body": [
        "SERT, NET и DAT удаляют медиатор из синаптической щели обратно в пресинаптическую клетку.",
        "MAO участвует в внутриклеточном метаболизме моноаминов.",
        "Препараты могут повышать синаптический уровень медиатора через inhibition of reuptake или metabolism."
      ],
      "visual": {
        "title": "Моноаминовые синапсы: serotonin, norepinephrine и dopamine",
        "kind": "flow",
        "steps": [
          "monoamine release",
          "SERT / NET / DAT",
          "reuptake",
          "MAO metabolism",
          "synaptic concentration"
        ],
        "sourceIds": [
          "openstax-ap",
          "reactome",
          "ncbi-pharm"
        ]
      },
      "sources": [
        "openstax-ap",
        "reactome",
        "ncbi-pharm"
      ]
    },
    {
      "id": "psych-depression-path",
      "title": "Депрессивные расстройства: нейросетевой и моноаминергический контекст",
      "section": "pathophysiology",
      "status": "advanced-theory",
      "lastReviewed": "2026-09-07",
      "summary": "Современное понимание депрессии не сводится к простой «нехватке одного медиатора»; фармакология моноаминов изменяет нейротрансмиссию, а клинический эффект развивается во времени.",
      "type": "note",
      "body": [
        "Антидепрессанты быстро меняют transporter/receptor signaling, но клинический ответ обычно требует более длительной адаптации сетей.",
        "Serotonergic, noradrenergic и dopaminergic systems участвуют в регуляции настроения, мотивации и сна.",
        "Комбинации serotonergic drugs повышают риск serotonin toxicity."
      ],
      "visual": {
        "title": "Депрессивные расстройства: нейросетевой и моноаминергический контекст",
        "kind": "flow",
        "steps": [
          "monoamine signaling altered",
          "acute transporter effect",
          "downstream adaptation",
          "clinical response"
        ],
        "sourceIds": [
          "ncbi-books",
          "pubmed",
          "ncbi-pharm"
        ]
      },
      "sources": [
        "ncbi-books",
        "pubmed",
        "ncbi-pharm"
      ]
    },
    {
      "id": "psych-antipsychotic-targets",
      "title": "Антипсихотические мишени: D₂ и серотониновые рецепторы",
      "section": "targets",
      "status": "advanced-theory",
      "lastReviewed": "2026-09-07",
      "summary": "Антипсихотические эффекты и нежелательные реакции зависят от профиля рецепторной блокады в разных дофаминергических путях.",
      "type": "note",
      "body": [
        "D₂-blockade в мезолимбическом пути уменьшает позитивные психотические симптомы.",
        "D₂-blockade в нигростриарном пути может вызывать extrapyramidal symptoms.",
        "D₂-blockade в тубероинфундибулярном пути может повышать prolactin.",
        "Рецепторный профиль атипичных антипсихотиков включает и serotonin receptors."
      ],
      "visual": {
        "title": "Антипсихотические мишени: D₂ и серотониновые рецепторы",
        "kind": "flow",
        "steps": [
          "mesolimbic D₂ block",
          "nigrostriatal D₂ block",
          "tuberoinfundibular D₂ block",
          "5-HT receptor profile"
        ],
        "sourceIds": [
          "ncbi-pharm",
          "ncbi-books"
        ]
      },
      "sources": [
        "ncbi-pharm",
        "ncbi-books"
      ]
    }
  ],
  "infectious": [
    {
      "id": "infect-bacterial-structure",
      "title": "Бактериальная клетка как источник фармакологических мишеней",
      "section": "physiology",
      "status": "advanced-theory",
      "lastReviewed": "2026-09-07",
      "summary": "Антимикробная селективность возникает потому, что бактерии содержат структуры и процессы, отличающиеся от человеческих клеток.",
      "type": "note",
      "body": [
        "Пептидогликан клеточной стенки отсутствует у человеческих клеток.",
        "Бактериальные рибосомы 70S структурно отличаются от цитозольных рибосом человека.",
        "Бактериальные ферменты репликации ДНК и пути фолата отличаются по фармакологической уязвимости."
      ],
      "visual": {
        "title": "Бактериальная клетка как источник фармакологических мишеней",
        "kind": "flow",
        "steps": [
          "cell wall",
          "70S ribosome",
          "DNA replication enzymes",
          "folate pathway"
        ],
        "sourceIds": [
          "openstax-micro",
          "ncbi-pharm"
        ]
      },
      "sources": [
        "openstax-micro",
        "ncbi-pharm"
      ]
    },
    {
      "id": "infect-antibacterial-targets",
      "title": "Основные антибактериальные мишени",
      "section": "biochemistry",
      "status": "advanced-theory",
      "lastReviewed": "2026-09-07",
      "summary": "Экзаменационные антибиотики группируются по мишени: клеточная стенка, рибосома, нуклеиновые кислоты и другие бактериальные процессы.",
      "type": "note",
      "body": [
        "β-lactams нарушают поздние этапы синтеза peptidoglycan через penicillin-binding proteins.",
        "Macrolides и clindamycin действуют на 50S-subunit; tetracyclines и aminoglycosides — на 30S-subunit.",
        "Fluoroquinolones ингибируют bacterial DNA gyrase/topoisomerase.",
        "Metronidazole формирует реактивные метаболиты в чувствительных анаэробных/протозойных клетках и повреждает ДНК."
      ],
      "visual": {
        "title": "Основные антибактериальные мишени",
        "kind": "flow",
        "steps": [
          "cell wall synthesis",
          "50S ribosome",
          "30S ribosome",
          "DNA gyrase / topoisomerase",
          "DNA damage"
        ],
        "sourceIds": [
          "openstax-micro",
          "ncbi-pharm",
          "fda"
        ]
      },
      "sources": [
        "openstax-micro",
        "ncbi-pharm",
        "fda"
      ]
    },
    {
      "id": "infect-resistance",
      "title": "Антимикробная устойчивость: основные механизмы",
      "section": "pathophysiology",
      "status": "advanced-theory",
      "lastReviewed": "2026-09-07",
      "summary": "Устойчивость возникает через изменение мишени, инактивацию препарата, снижение внутриклеточной концентрации или обход блокированного пути.",
      "type": "note",
      "body": [
        "β-lactamases расщепляют β-lactam ring.",
        "Изменение мишени уменьшает сродство препарата.",
        "Efflux pumps и снижение проницаемости уменьшают внутриклеточную концентрацию антибиотика.",
        "Горизонтальный перенос генов ускоряет распространение устойчивости."
      ],
      "visual": {
        "title": "Антимикробная устойчивость: основные механизмы",
        "kind": "flow",
        "steps": [
          "drug inactivation",
          "target modification",
          "efflux / permeability",
          "gene transfer",
          "resistance"
        ],
        "sourceIds": [
          "openstax-micro",
          "pubmed",
          "idsa"
        ]
      },
      "sources": [
        "openstax-micro",
        "pubmed",
        "idsa"
      ]
    },
    {
      "id": "infect-antiviral-antifungal",
      "title": "Противовирусные и противогрибковые мишени из базы ProPharm",
      "section": "targets",
      "status": "advanced-theory",
      "lastReviewed": "2026-09-07",
      "summary": "Противовирусные и противогрибковые препараты используют различия вирусных ферментов и грибковой мембраны/метаболизма.",
      "type": "note",
      "body": [
        "Acyclovir после фосфорилирования в инфицированной клетке ингибирует viral DNA polymerase и прекращает удлинение цепи.",
        "Azole antifungals нарушают синтез ergosterol через inhibition of fungal CYP51/14α-demethylase.",
        "Terbinafine блокирует squalene epoxidase и нарушает синтез ergosterol на более раннем этапе."
      ],
      "visual": {
        "title": "Противовирусные и противогрибковые мишени из базы ProPharm",
        "kind": "flow",
        "steps": [
          "viral activation → DNA polymerase ⊣",
          "CYP51 ⊣ → ergosterol ↓",
          "squalene epoxidase ⊣"
        ],
        "sourceIds": [
          "openstax-micro",
          "ncbi-pharm",
          "fda",
          "israel-drugs"
        ]
      },
      "sources": [
        "openstax-micro",
        "ncbi-pharm",
        "fda",
        "israel-drugs"
      ]
    }
  ],
  "immune": [
    {
      "id": "immune-innate-adaptive",
      "title": "Врождённый и адаптивный иммунитет",
      "section": "physiology",
      "status": "advanced-theory",
      "lastReviewed": "2026-09-07",
      "summary": "Врождённый иммунитет обеспечивает быстрый неспецифический ответ, а адаптивный создаёт антиген-специфические T- и B-клеточные реакции и память.",
      "type": "note",
      "body": [
        "Innate cells распознают conserved molecular patterns и быстро продуцируют медиаторы воспаления.",
        "Antigen presentation связывает врождённый и адаптивный ответ.",
        "T lymphocytes обеспечивают клеточно-опосредованные реакции, B lymphocytes — продукцию антител."
      ],
      "visual": {
        "title": "Врождённый и адаптивный иммунитет",
        "kind": "flow",
        "steps": [
          "innate recognition",
          "antigen presentation",
          "T-cell response",
          "B-cell / antibody response",
          "memory"
        ],
        "sourceIds": [
          "openstax-ap",
          "reactome",
          "ncbi-books"
        ]
      },
      "sources": [
        "openstax-ap",
        "reactome",
        "ncbi-books"
      ]
    },
    {
      "id": "immune-cytokines",
      "title": "Цитокиновая сигнализация и TNF",
      "section": "biochemistry",
      "status": "advanced-theory",
      "lastReviewed": "2026-09-07",
      "summary": "Цитокины координируют активацию, миграцию и выживание иммунных клеток через специфические рецепторные пути.",
      "type": "note",
      "body": [
        "TNF участвует в поддержании воспалительного ответа и активации эндотелия.",
        "Разные cytokine receptors активируют distinct intracellular pathways, включая NF-κB и JAK/STAT-related signaling.",
        "Избыточная или хроническая активация может поддерживать аутоиммунное воспаление."
      ],
      "visual": {
        "title": "Цитокиновая сигнализация и TNF",
        "kind": "flow",
        "steps": [
          "cytokine receptor",
          "NF-κB / JAK-STAT signaling",
          "gene expression",
          "inflammation"
        ],
        "sourceIds": [
          "reactome",
          "openstax-ap",
          "pubmed"
        ]
      },
      "sources": [
        "reactome",
        "openstax-ap",
        "pubmed"
      ]
    },
    {
      "id": "immune-autoimmune",
      "title": "Хроническое аутоиммунное воспаление",
      "section": "pathophysiology",
      "status": "advanced-theory",
      "lastReviewed": "2026-09-07",
      "summary": "Потеря иммунологической толерантности позволяет адаптивному иммунитету повреждать собственные ткани и поддерживать хроническое воспаление.",
      "type": "note",
      "body": [
        "Аутоактивные лимфоциты и антитела участвуют в tissue-specific или systemic inflammation.",
        "Cytokines поддерживают рекрутирование и активацию иммунных клеток.",
        "Повторное повреждение и репарация могут приводить к ремоделированию ткани и потере функции."
      ],
      "visual": {
        "title": "Хроническое аутоиммунное воспаление",
        "kind": "flow",
        "steps": [
          "loss of tolerance",
          "autoreactive lymphocytes",
          "cytokine amplification",
          "tissue injury"
        ],
        "sourceIds": [
          "openstax-ap",
          "ncbi-books",
          "eular",
          "pubmed"
        ]
      },
      "sources": [
        "openstax-ap",
        "ncbi-books",
        "eular",
        "pubmed"
      ]
    },
    {
      "id": "immune-targets",
      "title": "Иммунологические мишени: TNF, calcineurin, folate metabolism и glucocorticoid receptor",
      "section": "targets",
      "status": "advanced-theory",
      "lastReviewed": "2026-09-07",
      "summary": "Иммунодепрессанты и противовоспалительные средства подавляют разные уровни иммунного ответа.",
      "type": "note",
      "body": [
        "Adalimumab нейтрализует TNF.",
        "Cyclosporine и tacrolimus через immunophilin-dependent complexes ингибируют calcineurin и уменьшают T-cell activation.",
        "Methotrexate при иммуновоспалительных заболеваниях действует через несколько метаболических/противовоспалительных механизмов.",
        "Glucocorticoids изменяют транскрипцию множества воспалительных генов."
      ],
      "visual": {
        "title": "Иммунологические мишени: TNF, calcineurin, folate metabolism и glucocorticoid receptor",
        "kind": "flow",
        "steps": [
          "TNF neutralization",
          "calcineurin ⊣",
          "methotrexate anti-inflammatory pathways",
          "GR-mediated transcription"
        ],
        "sourceIds": [
          "reactome",
          "ncbi-pharm",
          "eular",
          "fda"
        ]
      },
      "sources": [
        "reactome",
        "ncbi-pharm",
        "eular",
        "fda"
      ]
    }
  ],
  "pain": [
    {
      "id": "pain-nociception",
      "title": "Ноцицепция: периферическая трансдукция и центральная передача",
      "section": "physiology",
      "status": "advanced-theory",
      "lastReviewed": "2026-09-07",
      "summary": "Болевой сигнал формируется при активации ноцицепторов, проводится по первичным афферентам и обрабатывается в спинальных и супраспинальных сетях.",
      "type": "note",
      "body": [
        "Тканевое повреждение высвобождает медиаторы, повышающие чувствительность nociceptors.",
        "Потенциалы действия распространяются по первичным афферентам к заднему рогу спинного мозга.",
        "Центральные сети передают и модулируют болевой сигнал.",
        "Descending inhibitory pathways способны уменьшать передачу боли."
      ],
      "visual": {
        "title": "Ноцицепция: периферическая трансдукция и центральная передача",
        "kind": "flow",
        "steps": [
          "tissue injury",
          "nociceptor sensitization",
          "afferent conduction",
          "spinal transmission",
          "descending modulation"
        ],
        "sourceIds": [
          "openstax-ap",
          "ncbi-books"
        ]
      },
      "sources": [
        "openstax-ap",
        "ncbi-books"
      ]
    },
    {
      "id": "pain-inflammatory",
      "title": "Простагландины и воспалительная сенситизация",
      "section": "biochemistry",
      "status": "advanced-theory",
      "lastReviewed": "2026-09-07",
      "summary": "COX-зависимый синтез prostaglandins повышает чувствительность периферических ноцицепторов к воспалительным стимулам.",
      "type": "note",
      "body": [
        "Arachidonic acid метаболизируется cyclooxygenases.",
        "Prostaglandins усиливают nociceptor sensitization и участвуют в лихорадке/воспалении.",
        "NSAID уменьшают prostaglandin synthesis через COX inhibition."
      ],
      "visual": {
        "title": "Простагландины и воспалительная сенситизация",
        "kind": "flow",
        "steps": [
          "arachidonic acid",
          "COX-1 / COX-2",
          "prostaglandins",
          "nociceptor sensitization"
        ],
        "sourceIds": [
          "openstax-ap",
          "reactome",
          "ncbi-pharm"
        ]
      },
      "sources": [
        "openstax-ap",
        "reactome",
        "ncbi-pharm"
      ]
    },
    {
      "id": "pain-chronic-path",
      "title": "Сенситизация и переход боли в хроническое состояние",
      "section": "pathophysiology",
      "status": "advanced-theory",
      "lastReviewed": "2026-09-07",
      "summary": "Длительная ноцицептивная активность способна повышать чувствительность периферических и центральных нейронных сетей, из-за чего ответ на стимул становится непропорциональным его интенсивности.",
      "type": "note",
      "body": [
        "Периферическое воспаление снижает порог активации nociceptors.",
        "Повторная афферентная импульсация усиливает центральную обработку болевого сигнала.",
        "При нейропатической боли повреждение нервной системы формирует патологическую спонтанную и вызванную активность.",
        "Лечение выбирают по механизму: воспалительный, ноцицептивный, нейропатический или смешанный компонент."
      ],
      "visual": {
        "title": "Сенситизация и переход боли в хроническое состояние",
        "kind": "flow",
        "steps": [
          "peripheral sensitization",
          "repeated afferent input",
          "central sensitization",
          "persistent pain"
        ],
        "sourceIds": [
          "openstax-ap",
          "ncbi-books",
          "pubmed"
        ]
      },
      "sources": [
        "openstax-ap",
        "ncbi-books",
        "pubmed"
      ]
    },
    {
      "id": "pain-targets",
      "title": "Фармакологические мишени анальгетиков",
      "section": "targets",
      "status": "advanced-theory",
      "lastReviewed": "2026-09-07",
      "summary": "Экзаменационные препараты уменьшают боль через COX/prostaglandins, μ-opioid receptors, monoamine pathways и α₂δ-associated calcium-channel signaling.",
      "type": "note",
      "body": [
        "NSAID подавляют cyclooxygenase-dependent prostaglandin synthesis.",
        "Opioids активируют μ-receptors и уменьшают нейрональную передачу боли.",
        "Duloxetine усиливает descending monoaminergic inhibition.",
        "Gabapentin/pregabalin связываются с α₂δ-subunit voltage-gated Ca²⁺ channels и уменьшают excitatory transmitter release."
      ],
      "visual": {
        "title": "Фармакологические мишени анальгетиков",
        "kind": "flow",
        "steps": [
          "COX ⊣",
          "μ receptor agonism",
          "SNRI / descending inhibition",
          "α₂δ → transmitter release ↓"
        ],
        "sourceIds": [
          "ncbi-pharm",
          "ncbi-books",
          "fda"
        ]
      },
      "sources": [
        "ncbi-pharm",
        "ncbi-books",
        "fda"
      ]
    }
  ],
  "bone": [
    {
      "id": "bone-remodeling",
      "title": "Костное ремоделирование: osteoclast–osteoblast coupling",
      "section": "physiology",
      "status": "advanced-theory",
      "lastReviewed": "2026-09-07",
      "summary": "Кость постоянно обновляется через скоординированную резорбцию остеокластами и образование матрикса остеобластами.",
      "type": "note",
      "body": [
        "Osteoclasts резорбируют минерализованную кость.",
        "Osteoblasts формируют osteoid и участвуют в минерализации.",
        "RANKL/OPG signaling регулирует дифференцировку и активность osteoclasts.",
        "Механическая нагрузка и гормональные сигналы меняют баланс ремоделирования."
      ],
      "visual": {
        "title": "Костное ремоделирование: osteoclast–osteoblast coupling",
        "kind": "flow",
        "steps": [
          "osteoclast resorption",
          "RANKL / OPG",
          "osteoblast formation",
          "mineralization"
        ],
        "sourceIds": [
          "openstax-ap",
          "reactome",
          "who-bone"
        ]
      },
      "sources": [
        "openstax-ap",
        "reactome",
        "who-bone"
      ]
    },
    {
      "id": "bone-calcium-vitd",
      "title": "Кальций, витамин D и PTH",
      "section": "biochemistry",
      "status": "advanced-theory",
      "lastReviewed": "2026-09-07",
      "summary": "Кальциевый гомеостаз связывает кишечник, кость, почки и паращитовидные железы.",
      "type": "note",
      "body": [
        "Снижение ionized Ca²⁺ стимулирует secretion of PTH.",
        "PTH увеличивает почечную реабсорбцию Ca²⁺, уменьшает реабсорбцию phosphate и стимулирует образование активного vitamin D.",
        "Активный vitamin D повышает кишечное всасывание Ca²⁺ и phosphate."
      ],
      "visual": {
        "title": "Кальций, витамин D и PTH",
        "kind": "flow",
        "steps": [
          "Ca²⁺ ↓",
          "PTH ↑",
          "renal Ca²⁺ retention + phosphate excretion",
          "active vitamin D ↑",
          "intestinal absorption ↑"
        ],
        "sourceIds": [
          "openstax-ap",
          "ncbi-books"
        ]
      },
      "sources": [
        "openstax-ap",
        "ncbi-books"
      ]
    },
    {
      "id": "bone-osteoporosis",
      "title": "Остеопороз: дисбаланс ремоделирования",
      "section": "pathophysiology",
      "status": "advanced-theory",
      "lastReviewed": "2026-09-07",
      "summary": "Остеопороз развивается, когда костная резорбция хронически превышает формирование, что снижает прочность кости и повышает риск переломов.",
      "type": "note",
      "body": [
        "Возрастные и гормональные изменения могут усиливать osteoclast activity относительно bone formation.",
        "Снижается костная масса и ухудшается микроархитектура.",
        "Лечение направлено на снижение резорбции, поддержку минерального обмена и коррекцию факторов риска."
      ],
      "visual": {
        "title": "Остеопороз: дисбаланс ремоделирования",
        "kind": "flow",
        "steps": [
          "resorption > formation",
          "bone mass ↓",
          "microarchitecture deterioration",
          "fracture risk ↑"
        ],
        "sourceIds": [
          "openstax-ap",
          "who-bone",
          "pubmed"
        ]
      },
      "sources": [
        "openstax-ap",
        "who-bone",
        "pubmed"
      ]
    },
    {
      "id": "bone-targets",
      "title": "Мишени терапии кости и суставов",
      "section": "targets",
      "status": "advanced-theory",
      "lastReviewed": "2026-09-07",
      "summary": "Препараты из базы воздействуют на остеокласты, минеральный обмен и воспаление.",
      "type": "note",
      "body": [
        "Alendronate накапливается в кости и подавляет функцию osteoclasts.",
        "Calcium и vitamin D поддерживают субстрат и гормональную регуляцию минерализации.",
        "NSAID уменьшают prostaglandin-dependent inflammatory pain.",
        "Methotrexate и biologic therapy могут подавлять иммуновоспалительные механизмы ревматических заболеваний."
      ],
      "visual": {
        "title": "Мишени терапии кости и суставов",
        "kind": "flow",
        "steps": [
          "osteoclast function ↓",
          "Ca²⁺ / vitamin D support",
          "COX inhibition",
          "immune modulation"
        ],
        "sourceIds": [
          "ncbi-pharm",
          "eular",
          "fda",
          "israel-drugs"
        ]
      },
      "sources": [
        "ncbi-pharm",
        "eular",
        "fda",
        "israel-drugs"
      ]
    }
  ],
  "repro": [
    {
      "id": "repro-hpg-axis",
      "title": "Гипоталамо-гипофизарно-гонадная ось",
      "section": "physiology",
      "status": "advanced-theory",
      "lastReviewed": "2026-09-07",
      "summary": "Репродуктивная функция регулируется пульсирующим GnRH, гонадотропинами и половыми стероидами с обратной связью.",
      "type": "note",
      "body": [
        "GnRH стимулирует секрецию LH и FSH.",
        "LH и FSH регулируют функции гонад и steroidogenesis/gametogenesis.",
        "Estrogen, progesterone и testosterone участвуют в обратной связи на гипоталамус и гипофиз."
      ],
      "visual": {
        "title": "Гипоталамо-гипофизарно-гонадная ось",
        "kind": "flow",
        "steps": [
          "GnRH pulses",
          "LH / FSH",
          "gonadal function",
          "sex steroids",
          "feedback"
        ],
        "sourceIds": [
          "openstax-ap",
          "ncbi-books"
        ]
      },
      "sources": [
        "openstax-ap",
        "ncbi-books"
      ]
    },
    {
      "id": "repro-cycle",
      "title": "Овариальный цикл и овуляция",
      "section": "biochemistry",
      "status": "advanced-theory",
      "lastReviewed": "2026-09-07",
      "summary": "Овариальный цикл представляет координацию фолликулярного развития, овуляции и функции corpus luteum.",
      "type": "note",
      "body": [
        "FSH поддерживает рост фолликулов.",
        "Rising estradiol в поздней фолликулярной фазе связан с LH surge.",
        "LH surge запускает ovulation.",
        "После овуляции corpus luteum секретирует progesterone и estrogen."
      ],
      "visual": {
        "title": "Овариальный цикл и овуляция",
        "kind": "flow",
        "steps": [
          "follicular phase",
          "estradiol ↑",
          "LH surge",
          "ovulation",
          "luteal progesterone"
        ],
        "sourceIds": [
          "openstax-ap",
          "ncbi-books"
        ]
      },
      "sources": [
        "openstax-ap",
        "ncbi-books"
      ]
    },
    {
      "id": "repro-disorders",
      "title": "Нарушения овуляции, гиперпролактинемия и гормонозависимые состояния",
      "section": "pathophysiology",
      "status": "advanced-theory",
      "lastReviewed": "2026-09-07",
      "summary": "Нарушения оси HPG и prolactin signaling способны подавлять овуляцию и изменять репродуктивную функцию.",
      "type": "note",
      "body": [
        "Повышенный prolactin может подавлять GnRH signaling и нарушать гонадотропную функцию.",
        "Фармакологическое изменение estrogen signaling используется как в репродуктивной медицине, так и в гормонозависимой онкологии.",
        "Механизм терапии зависит от того, требуется ли стимулировать овуляцию, подавить пролактин или блокировать/снижать эстрогенный сигнал."
      ],
      "visual": {
        "title": "Нарушения овуляции, гиперпролактинемия и гормонозависимые состояния",
        "kind": "flow",
        "steps": [
          "prolactin ↑ → GnRH ↓",
          "ovulatory dysfunction",
          "estrogen signaling modulation"
        ],
        "sourceIds": [
          "openstax-ap",
          "ncbi-books",
          "pubmed"
        ]
      },
      "sources": [
        "openstax-ap",
        "ncbi-books",
        "pubmed"
      ]
    },
    {
      "id": "repro-targets",
      "title": "Репродуктивные и гормональные мишени препаратов из базы",
      "section": "targets",
      "status": "advanced-theory",
      "lastReviewed": "2026-09-07",
      "summary": "В экзаменационной базе представлены средства, влияющие на dopamine D₂, estrogen receptor signaling и estrogen synthesis.",
      "type": "note",
      "body": [
        "Bromocriptine/cabergoline активируют D₂ receptors и снижают prolactin secretion.",
        "Clomiphene модифицирует estrogen feedback на уровне hypothalamic-pituitary axis и используется для induction of ovulation.",
        "Anastrozole/letrozole ингибируют aromatase и снижают estrogen synthesis.",
        "Tamoxifen является selective estrogen receptor modulator с тканеспецифическими эффектами."
      ],
      "visual": {
        "title": "Репродуктивные и гормональные мишени препаратов из базы",
        "kind": "flow",
        "steps": [
          "D₂ agonism → prolactin ↓",
          "estrogen feedback modulation",
          "aromatase ⊣",
          "SERM"
        ],
        "sourceIds": [
          "ncbi-pharm",
          "fda",
          "israel-drugs"
        ]
      },
      "sources": [
        "ncbi-pharm",
        "fda",
        "israel-drugs"
      ]
    }
  ],
  "cardio": [
    {
      "id": "cardio-source-framework",
      "title": "ССС: академическая интеграция источников",
      "section": "physiology",
      "status": "advanced-theory",
      "lastReviewed": "2026-09-07",
      "summary": "Существующий продвинутый модуль ССС сохраняется; эта карточка фиксирует академическую иерархию источников для дальнейшей проверки и обновления.",
      "type": "note",
      "body": [
        "OpenStax используется для базовой анатомии и физиологии.",
        "Reactome/NCBI — для клеточных и сигнальных механизмов.",
        "ESC — для клинически изменяемой фармакотерапии и рекомендаций.",
        "FDA/Israeli Drug Registry/ГРЛС — для официальных свойств препаратов."
      ],
      "visual": {
        "title": "ССС: академическая интеграция источников",
        "kind": "flow",
        "steps": [
          "academic physiology",
          "molecular pathway validation",
          "clinical guideline",
          "regulatory drug source"
        ],
        "sourceIds": [
          "openstax-ap",
          "reactome",
          "ncbi-books",
          "esc",
          "fda",
          "israel-drugs",
          "grls"
        ]
      },
      "sources": [
        "openstax-ap",
        "reactome",
        "ncbi-books",
        "esc",
        "fda",
        "israel-drugs",
        "grls"
      ]
    }
  ],
  "oncology": [
    {
      "id": "oncology-hormone-dependence",
      "title": "Гормонозависимая опухолевая фармакология",
      "section": "pathophysiology",
      "status": "advanced-theory",
      "lastReviewed": "2026-09-07",
      "summary": "Некоторые опухоли используют estrogen receptor signaling или зависят от синтеза эстрогенов, что создаёт терапевтические мишени.",
      "type": "note",
      "body": [
        "Aromatase converts androgen precursors to estrogens in peripheral tissues.",
        "Aromatase inhibitors уменьшают estrogen synthesis.",
        "Tamoxifen модулирует estrogen receptor signaling в ткани-мишени."
      ],
      "visual": {
        "title": "Гормонозависимая опухолевая фармакология",
        "kind": "flow",
        "steps": [
          "aromatase",
          "estrogen synthesis",
          "estrogen receptor signaling",
          "tumor growth signaling"
        ],
        "sourceIds": [
          "ncbi-books",
          "pubmed",
          "fda"
        ]
      },
      "sources": [
        "ncbi-books",
        "pubmed",
        "fda"
      ]
    }
  ]
};
