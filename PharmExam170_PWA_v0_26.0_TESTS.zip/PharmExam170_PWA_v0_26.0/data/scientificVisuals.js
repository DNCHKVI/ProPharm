export const SCIENTIFIC_VISUALS = Object.freeze({
  'heart-anatomy': {
    type: 'external-source',
    title: 'Анатомия сердца и направление кровотока',
    imageUrl: 'https://thumb.wikimedia.org/wikipedia/commons/thumb/f/f5/Diagram_of_the_human_heart_%28no_text%29.svg/960px-Diagram_of_the_human_heart_%28no_text%29.svg.png',
    sourcePage: 'https://commons.wikimedia.org/wiki/File:Diagram_of_the_human_heart_(no_text).svg',
    sourceName: 'Wikimedia Commons',
    author: 'Wapcaplet, Yaddah, Wnauta; later validation by Jmarchn',
    license: 'CC BY-SA 3.0 / GFDL',
    note: 'Готовая анатомическая иллюстрация из открытого научного ресурса; ProPharm не меняет анатомические связи на изображении.'
  },
  'conduction': {
    type: 'external-source',
    title: 'Проводящая система сердца',
    imageUrl: 'https://thumb.wikimedia.org/wikipedia/commons/thumb/3/3c/Heart_and_electrical_conduction_system.svg/960px-Heart_and_electrical_conduction_system.svg.png',
    sourcePage: 'https://commons.wikimedia.org/wiki/File:Heart_and_electrical_conduction_system.svg',
    sourceName: 'Wikimedia Commons / CardioNetworks ECGpedia',
    author: 'Original Drj; modified by Wikimedia uploader',
    license: 'CC BY-SA 3.0',
    note: 'Проверенная схема проводящей системы без встроенных текстовых подписей; русские пояснения выводятся отдельно.'
  },
  'coronary': {
    type: 'external-source',
    title: 'Коронарные артерии и их ветви',
    imageUrl: 'https://thumb.wikimedia.org/wikipedia/commons/thumb/1/18/Coronary_arteries.svg/960px-Coronary_arteries.svg.png',
    sourcePage: 'https://commons.wikimedia.org/wiki/File:Coronary_arteries.svg',
    sourceName: 'Wikimedia Commons',
    author: 'Patrick J. Lynch; Fred the Oyster; Mikael Häggström, M.D.',
    license: 'CC BY-SA 3.0',
    note: 'Готовая медицинская схема коронарных артерий; английские подписи дополняются русской легендой в ProPharm.'
  },
  'cardiac-cycle': {
    type: 'external-source',
    title: 'Диаграмма Виггерса — сердечный цикл',
    imageUrl: 'https://thumb.wikimedia.org/wikipedia/commons/thumb/f/f4/Wiggers_Diagram.svg/960px-Wiggers_Diagram.svg.png',
    sourcePage: 'https://commons.wikimedia.org/wiki/File:Wiggers_Diagram.svg',
    sourceName: 'Wikimedia Commons',
    author: 'DanielChangMD / DestinyQx; SVG redraw by xavax',
    license: 'CC BY-SA 2.5',
    note: 'Связывает давление, объём желудочка, ЭКГ, клапанные события и тоны сердца.'
  },
  'ventricular-ap': {
    type: 'external-source',
    title: 'Потенциал действия кардиомиоцита и антиаритмические мишени',
    imageUrl: 'https://thumb.wikimedia.org/wikipedia/commons/thumb/6/6d/Cardiac_action_potential.svg/960px-Cardiac_action_potential.svg.png',
    sourcePage: 'https://commons.wikimedia.org/wiki/File:Cardiac_action_potential.svg',
    sourceName: 'Wikimedia Commons',
    author: 'Sertion; based on Cardiac action potential.png',
    license: 'CC BY-SA 4.0',
    note: 'Готовая схема фаз сердечного потенциала действия и классов антиаритмических препаратов.'
  },
  'ecc': {
    type: 'external-source',
    title: 'Кальциевый цикл и сопряжение возбуждения и сокращения сердца',
    imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/1/10/Cardiac_calcium_cycling_and_excitation-contraction_coupling.png',
    sourcePage: 'https://commons.wikimedia.org/wiki/File:Cardiac_calcium_cycling_and_excitation-contraction_coupling.png',
    sourceName: 'Wikimedia Commons',
    author: 'PeaBrainC',
    license: 'CC BY-SA 4.0',
    note: 'Готовая схема ключевых белков кальциевого цикла и excitation–contraction coupling; ProPharm добавляет русскую легенду и упрощённый Learning Whiteboard отдельно.'
  },
  'raas': {
    type: 'external-source',
    title: 'Ренин-ангиотензин-альдостероновая система',
    imageUrl: 'https://thumb.wikimedia.org/wikipedia/commons/thumb/3/36/Renin-angiotensin-aldosterone_system.svg/1280px-Renin-angiotensin-aldosterone_system.svg.png',
    sourcePage: 'https://commons.wikimedia.org/wiki/File:Renin-angiotensin-aldosterone_system.svg',
    sourceName: 'Wikimedia Commons',
    author: 'Soupvector',
    license: 'CC BY-SA 4.0',
    note: 'Открытая векторная схема RAAS. В ProPharm оригинал используется как научная иллюстрация, а экзаменационная цепочка показывается отдельным Learning Whiteboard.'
  },
  'atherosclerosis': {
    type: 'external-source',
    title: 'Нормальная артерия и атеросклеротическая бляшка',
    imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/b/b3/Atherosclerosis_diagram.png',
    sourcePage: 'https://commons.wikimedia.org/wiki/File:Atherosclerosis_diagram.png',
    sourceName: 'NHLBI / Wikimedia Commons',
    author: 'National Heart, Lung, and Blood Institute (NHLBI)',
    license: 'Public domain — U.S. federal government work',
    note: 'Показывает нормальный просвет и сужение артерии вследствие бляшки.'
  }
});

export const WHITEBOARD_SOURCE_MAP = Object.freeze({
  default: [
    {name:'Reactome',url:'https://reactome.org/',license:'Pathway illustrations CC BY 4.0; pathway data CC0'},
    {name:'WikiPathways',url:'https://www.wikipathways.org/',license:'CC0'}
  ],
  physiology: [
    {name:'OpenStax Anatomy & Physiology 2e',url:'https://openstax.org/details/books/anatomy-and-physiology-2e',license:'CC BY-NC-SA 4.0 — reference use only unless reuse conditions are satisfied'},
    {name:'NCBI Bookshelf',url:'https://www.ncbi.nlm.nih.gov/books/',license:'Per-title terms; used as academic reference'}
  ],
  biochemistry: [
    {name:'Reactome',url:'https://reactome.org/',license:'Pathway illustrations CC BY 4.0; pathway data CC0'},
    {name:'WikiPathways',url:'https://www.wikipathways.org/',license:'CC0'}
  ],
  pathophysiology: [
    {name:'Reactome',url:'https://reactome.org/',license:'Pathway illustrations CC BY 4.0; pathway data CC0'},
    {name:'WikiPathways',url:'https://www.wikipathways.org/',license:'CC0'},
    {name:'Servier Medical Art',url:'https://smart.servier.com/',license:'CC BY 4.0'}
  ],
  diagnostics: [
    {name:'OpenStax Anatomy & Physiology 2e',url:'https://openstax.org/details/books/anatomy-and-physiology-2e',license:'CC BY-NC-SA 4.0 — reference use only unless reuse conditions are satisfied'},
    {name:'NCBI Bookshelf',url:'https://www.ncbi.nlm.nih.gov/books/',license:'Per-title terms; used as academic reference'}
  ]
});
