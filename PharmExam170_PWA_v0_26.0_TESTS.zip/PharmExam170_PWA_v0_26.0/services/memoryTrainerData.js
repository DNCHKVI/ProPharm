import { allForUser,get,makeKey,put,randomId } from './localDb.js?v=0.24.1';
import { currentUserId } from './authService.js?v=0.25.9';
function uid(){const id=currentUserId();if(!id)throw new Error('Нет авторизованного пользователя');return id}
const intervals=[0,1,3,7,14,30];
function nextDate(days){const d=new Date();d.setDate(d.getDate()+days);return d.toISOString()}
export async function trainerProgress(nodeId){return await get('memory_progress',makeKey(uid(),nodeId))}
export async function recordTrainerAnswer(nodeId,{correct,usedHint=false,responseMs=0,sourceId=null,topic=null}={}){
 const user_id=uid(),key=makeKey(user_id,nodeId),old=await get('memory_progress',key)||{key,user_id,node_id:nodeId,seen:0,correct:0,wrong:0,streak:0,level:0,status:'new'};
 let level=old.level||0,streak=old.streak||0,wrong=old.wrong||0,ok=old.correct||0;
 if(correct){ok++;streak++;if(!usedHint&&responseMs<30000)level=Math.min(intervals.length-1,level+1)}else{wrong++;streak=0;level=Math.max(0,level-1)}
 const status=!correct?'error':level>=5?'mastered':level>=3?'consolidating':level>=1?'learning':'weak';
 const row={...old,key,user_id,node_id:nodeId,source_id:sourceId,topic,seen:(old.seen||0)+1,correct:ok,wrong,streak,level,status,last_answer:correct?'correct':'wrong',last_seen:new Date().toISOString(),next_review:correct?nextDate(intervals[level]):new Date(Date.now()+5*60*1000).toISOString(),last_response_ms:responseMs,last_used_hint:!!usedHint,updated_at:new Date().toISOString()};
 await put('memory_progress',row);
 await put('memory_events',{key:makeKey(user_id,randomId('memory')),user_id,node_id:nodeId,correct:!!correct,used_hint:!!usedHint,response_ms:responseMs,source_id:sourceId,topic,created_at:new Date().toISOString()});
 return row;
}
export async function trainerStats(){
 const user_id=uid(),rows=await allForUser('memory_progress',user_id),events=await allForUser('memory_events',user_id),now=Date.now();
 const due=rows.filter(x=>!x.next_review||Date.parse(x.next_review)<=now).length,mastered=rows.filter(x=>x.status==='mastered').length,weak=rows.filter(x=>['error','weak'].includes(x.status)).length;
 const today=new Date().toISOString().slice(0,10),todayEvents=events.filter(x=>String(x.created_at||'').slice(0,10)===today),avgMs=events.length?Math.round(events.reduce((a,b)=>a+(b.response_ms||0),0)/events.length):0;
 const activeDays=new Set(events.map(x=>String(x.created_at||'').slice(0,10)).filter(Boolean));let dayStreak=0;for(let i=0;i<365;i++){const d=new Date();d.setDate(d.getDate()-i);if(activeDays.has(d.toISOString().slice(0,10)))dayStreak++;else if(i>0)break;else if(i===0&&!activeDays.has(today))continue;}
 const nextReview=rows.map(x=>x.next_review).filter(Boolean).sort()[0]||null;
 const topicErrors={};for(const r of rows.filter(x=>x.wrong>0&&x.topic)){topicErrors[r.topic]=(topicErrors[r.topic]||0)+r.wrong}const weakTopics=Object.entries(topicErrors).sort((a,b)=>b[1]-a[1]).slice(0,5);
 return {rows,events,due,mastered,weak,total:rows.length,mastery:rows.length?Math.round(mastered/rows.length*100):0,today:todayEvents.length,dayStreak,avgMs,nextReview,weakTopics};
}
export async function trainerReset(){const rows=await allForUser('memory_progress',uid());for(const r of rows)await put('memory_progress',{...r,status:'new',level:0,seen:0,correct:0,wrong:0,streak:0,next_review:null,updated_at:new Date().toISOString()})}
