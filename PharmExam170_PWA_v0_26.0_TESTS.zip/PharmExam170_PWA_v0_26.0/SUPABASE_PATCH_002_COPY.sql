-- ProPharm v0.16 — reliable admin application list + notifications.
-- Run this AFTER 001_propharm_accounts.sql in Supabase SQL Editor.
-- Safe to re-run.

create extension if not exists pgcrypto;

-- 1) Admin-only event log for new access applications.
create table if not exists public.admin_notifications (
  id uuid primary key default gen_random_uuid(),
  kind text not null default 'new_application',
  target_user_id uuid references auth.users(id) on delete cascade,
  title text not null default 'Новая заявка ProPharm',
  message text,
  email text,
  created_at timestamptz not null default now(),
  read_at timestamptz
);

alter table public.admin_notifications enable row level security;

drop policy if exists admin_notifications_admin_select on public.admin_notifications;
create policy admin_notifications_admin_select
on public.admin_notifications for select
using (public.is_propharm_admin());

-- Only the bootstrap admin may mark notifications read from the client.
drop policy if exists admin_notifications_admin_update on public.admin_notifications;
create policy admin_notifications_admin_update
on public.admin_notifications for update
using (public.is_propharm_admin())
with check (public.is_propharm_admin());

grant select, update on public.admin_notifications to authenticated;

-- 2) Generate one admin event whenever a new profile is created.
create or replace function public.notify_admin_new_profile()
returns trigger
language plpgsql
security definer
set search_path=public
as $$
begin
  if new.role='user' and new.status='pending' then
    insert into public.admin_notifications(kind,target_user_id,title,message,email)
    values(
      'new_application',
      new.user_id,
      'Новая заявка ProPharm',
      coalesce(nullif(new.name,''),new.email,'Новый пользователь') || ' ожидает подтверждения доступа.',
      new.email
    );
  end if;
  return new;
end $$;

drop trigger if exists on_propharm_profile_application on public.profiles;
create trigger on_propharm_profile_application
after insert on public.profiles
for each row execute function public.notify_admin_new_profile();

-- Backfill notifications for applications that already existed before v0.16.
insert into public.admin_notifications(kind,target_user_id,title,message,email)
select 'new_application',p.user_id,'Новая заявка ProPharm',
       coalesce(nullif(p.name,''),p.email,'Новый пользователь') || ' ожидает подтверждения доступа.',
       p.email
from public.profiles p
where p.role='user' and p.status='pending'
  and not exists (select 1 from public.admin_notifications n where n.kind='new_application' and n.target_user_id=p.user_id);

-- 3) Reliable admin list. SECURITY DEFINER avoids problems caused by an older
-- profiles SELECT policy while still explicitly checking the one bootstrap admin.
create or replace function public.admin_list_users()
returns table(
  user_id uuid,
  name text,
  email text,
  provider text,
  role text,
  status text,
  created_at timestamptz,
  last_login timestamptz
)
language plpgsql
security definer
set search_path=public
as $$
begin
  if not public.is_propharm_admin() then
    raise exception 'admin required';
  end if;
  return query
  select p.user_id,p.name,p.email,p.provider,p.role::text,p.status::text,p.created_at,p.last_login
  from public.profiles p
  order by case when p.status='pending' then 0 else 1 end, p.created_at desc;
end $$;

create or replace function public.admin_pending_count()
returns integer
language plpgsql
security definer
set search_path=public
as $$
declare n integer;
begin
  if not public.is_propharm_admin() then raise exception 'admin required'; end if;
  select count(*)::integer into n from public.profiles where status='pending' and role='user';
  return coalesce(n,0);
end $$;

create or replace function public.admin_list_notifications(p_limit integer default 30)
returns table(
  id uuid,
  kind text,
  target_user_id uuid,
  title text,
  message text,
  email text,
  created_at timestamptz,
  read_at timestamptz
)
language plpgsql
security definer
set search_path=public
as $$
begin
  if not public.is_propharm_admin() then raise exception 'admin required'; end if;
  return query
  select n.id,n.kind,n.target_user_id,n.title,n.message,n.email,n.created_at,n.read_at
  from public.admin_notifications n
  order by n.created_at desc
  limit greatest(1,least(coalesce(p_limit,30),100));
end $$;

create or replace function public.admin_mark_notifications_read()
returns void
language plpgsql
security definer
set search_path=public
as $$
begin
  if not public.is_propharm_admin() then raise exception 'admin required'; end if;
  update public.admin_notifications set read_at=coalesce(read_at,now()) where read_at is null;
end $$;

revoke all on function public.admin_list_users() from public;
revoke all on function public.admin_pending_count() from public;
revoke all on function public.admin_list_notifications(integer) from public;
revoke all on function public.admin_mark_notifications_read() from public;
grant execute on function public.admin_list_users() to authenticated;
grant execute on function public.admin_pending_count() to authenticated;
grant execute on function public.admin_list_notifications(integer) to authenticated;
grant execute on function public.admin_mark_notifications_read() to authenticated;

-- 4) Realtime for immediate in-app/system notifications while ProPharm is running.
alter table public.admin_notifications replica identity full;
do $$
begin
  if not exists (
    select 1 from pg_publication_tables
    where pubname='supabase_realtime' and schemaname='public' and tablename='admin_notifications'
  ) then
    alter publication supabase_realtime add table public.admin_notifications;
  end if;
exception when undefined_object then
  -- Some projects may not have the publication enabled yet; enable it in
  -- Database > Publications > supabase_realtime and add admin_notifications.
  null;
end $$;

-- 5) Optional Web Push subscriptions for notifications when an installed PWA is closed.
create table if not exists public.push_subscriptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  endpoint text not null unique,
  p256dh text not null,
  auth text not null,
  user_agent text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.push_subscriptions enable row level security;
drop policy if exists push_subscriptions_own on public.push_subscriptions;
create policy push_subscriptions_own
on public.push_subscriptions for all
using (user_id=auth.uid())
with check (user_id=auth.uid());
grant select,insert,update,delete on public.push_subscriptions to authenticated;

-- NOTE: receiving a real push while the PWA is completely closed additionally requires:
-- 1) a VAPID key pair,
-- 2) the PUBLIC key in config/supabase-config.js,
-- 3) the PRIVATE key only in Supabase Edge Function secrets,
-- 4) a Database Webhook on admin_notifications INSERT to the Edge Function.
