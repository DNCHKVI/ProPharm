// ProPharm v0.15 — public Supabase configuration (email/password only).
// Public/publishable key is intended for browser use with RLS enabled.
// NEVER put service_role, secret keys, database passwords or OAuth client secrets here.
export const SUPABASE_CONFIG = Object.freeze({
  enabled: true,
  url: "https://jrdpjatspvatpqongcon.supabase.co",
  publishableKey: "sb_publishable_KHMVppAR9HZq-93DCPmc5w_jiTQuEjm",
  siteUrl: "https://dnchkvi.github.io/ProPharm/",
  auth: {
    requireApproval: true,
    allowLocalPreviewWhenDisabled: false,
    google: false,
    apple: false,
    manualIdentityLinking: false
  }
});
