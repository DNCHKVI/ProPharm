export const MECHANISMS = {
  "cardio": [
    {
      "title": "β₁ → Gs → cAMP → PKA",
      "chain": [
        "β₁",
        "Gs",
        "Adenylyl cyclase ↑",
        "cAMP ↑",
        "PKA ↑",
        "If/ICaL ↑",
        "ЧСС/проводимость/Ca²⁺-цикл ↑"
      ],
      "examples": [
        "Atenolol",
        "Metoprolol",
        "Propranolol",
        "Timolol"
      ]
    },
    {
      "title": "M₂ → Gi + GIRK",
      "chain": [
        "M₂",
        "Gi",
        "cAMP ↓",
        "If/ICaL ↓",
        "GIRK K⁺ ↑",
        "гиперполяризация",
        "ЧСС и АВ-проведение ↓"
      ],
      "examples": [
        "Donepezil — косвенно через ACh ↑"
      ]
    },
    {
      "title": "L-type Ca²⁺ → RyR2 → CICR",
      "chain": [
        "Cav1.2",
        "Ca²⁺ входит",
        "RyR2",
        "Ca²⁺ из СПР",
        "TnC",
        "actin–myosin",
        "сокращение"
      ],
      "examples": [
        "Verapamil",
        "Diltiazem",
        "Amlodipine",
        "Nifedipine"
      ]
    },
    {
      "title": "Na⁺/K⁺-АТФаза → NCX → Ca²⁺",
      "chain": [
        "Na⁺/K⁺-АТФаза",
        "Na⁺-градиент",
        "NCX",
        "Ca²⁺-выведение",
        "Ca²⁺ в СПР",
        "инотропия"
      ],
      "examples": [
        "Digoxin"
      ]
    },
    {
      "title": "Fast Na⁺ → фаза 0 → QRS",
      "chain": [
        "Nav1.5",
        "INa",
        "крутизна фазы 0",
        "скорость проведения",
        "QRS"
      ],
      "examples": [
        "Propafenone",
        "Amitriptyline",
        "Nortriptyline",
        "Phenytoin"
      ]
    },
    {
      "title": "IKr/hERG → QT → TdP",
      "chain": [
        "IKr ↓",
        "фаза 3 дольше",
        "APD ↑",
        "QT/QTc ↑",
        "EAD",
        "TdP"
      ],
      "examples": [
        "Amiodarone",
        "Haloperidol",
        "Domperidone",
        "Azithromycin",
        "Escitalopram"
      ]
    },
    {
      "title": "NO → sGC → cGMP",
      "chain": [
        "NO",
        "sGC",
        "cGMP ↑",
        "Ca²⁺ гладкой мышцы ↓",
        "вазодилатация"
      ],
      "examples": [
        "Isosorbide mono/dinitrate",
        "Sildenafil — downstream PDE5"
      ]
    },
    {
      "title": "RAAS",
      "chain": [
        "Renin",
        "Angiotensin I",
        "ACE",
        "Angiotensin II",
        "AT₁",
        "вазоконстрикция/aldosterone"
      ],
      "examples": [
        "Enalapril",
        "Losartan",
        "Spironolactone"
      ]
    }
  ]
};
