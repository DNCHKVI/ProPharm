export const SOURCE_SECTIONS = [
  {
    "id": "heart-failure",
    "title": "I. СЕРДЕЧНАЯ НЕДОСТАТОЧНОСТЬ",
    "count": 7,
    "topic": "cardio"
  },
  {
    "id": "hypertension",
    "title": "II. АРТЕРИАЛЬНАЯ ГИПЕРТЕНЗИЯ, β-БЛОКАТОРЫ, ДИУРЕТИКИ И CCB",
    "count": 21,
    "topic": "cardio"
  },
  {
    "id": "ihd-acs",
    "title": "III. ИШЕМИЧЕСКАЯ БОЛЕЗНЬ СЕРДЦА, НИТРАТЫ И ОСТРЫЙ КОРОНАРНЫЙ СИНДРОМ",
    "count": 11,
    "topic": "cardio"
  },
  {
    "id": "antiarrhythmics",
    "title": "IV. АНТИАРИТМИЧЕСКИЕ ПРЕПАРАТЫ И ЭЛЕКТРОФИЗИОЛОГИЯ СЕРДЦА",
    "count": 11,
    "topic": "cardio"
  },
  {
    "id": "af",
    "title": "IV. АНТИАРИТМИЧЕСКИЕ ПРЕПАРАТЫ И ФИБРИЛЛЯЦИЯ ПРЕДСЕРДИЙ",
    "count": 9,
    "topic": "cardio"
  },
  {
    "id": "hemostasis",
    "title": "V. АНТИАГРЕГАНТЫ И АНТИКОАГУЛЯНТЫ",
    "count": 11,
    "topic": "hemostasis"
  },
  {
    "id": "cardiac-basics",
    "title": "VI. БАЗОВАЯ АНАТОМИЯ И ЭЛЕКТРОФИЗИОЛОГИЯ СЕРДЦА",
    "count": 6,
    "topic": "cardio"
  }
];
