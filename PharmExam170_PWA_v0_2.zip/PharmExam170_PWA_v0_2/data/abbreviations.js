export const ABBREVIATIONS = {
  "cardio": [
    {
      "abbr": "AP",
      "full": "Action Potential",
      "ru": "потенциал действия",
      "subtopic": "Электрофизиология"
    },
    {
      "abbr": "SA",
      "full": "Sinoatrial node",
      "ru": "синоатриальный узел",
      "subtopic": "Проводящая система"
    },
    {
      "abbr": "AV",
      "full": "Atrioventricular node",
      "ru": "атриовентрикулярный узел",
      "subtopic": "Проводящая система"
    },
    {
      "abbr": "ECG / ЭКГ",
      "full": "Electrocardiogram",
      "ru": "электрокардиограмма",
      "subtopic": "ЭКГ"
    },
    {
      "abbr": "ERP",
      "full": "Effective Refractory Period",
      "ru": "эффективный рефрактерный период",
      "subtopic": "Электрофизиология"
    },
    {
      "abbr": "If",
      "full": "Funny current",
      "ru": "пейсмекерный ток через HCN-каналы",
      "subtopic": "СА-узел"
    },
    {
      "abbr": "HCN",
      "full": "Hyperpolarization-activated cyclic nucleotide-gated channel",
      "ru": "каналы, формирующие If",
      "subtopic": "СА-узел"
    },
    {
      "abbr": "Nav1.5",
      "full": "Cardiac voltage-gated sodium channel",
      "ru": "быстрый Na⁺-канал рабочего миокарда",
      "subtopic": "Фаза 0"
    },
    {
      "abbr": "Cav1.2",
      "full": "L-type calcium channel",
      "ru": "L-type Ca²⁺-канал",
      "subtopic": "Фаза 2 / узловая ткань"
    },
    {
      "abbr": "IK1",
      "full": "Inward rectifier K⁺ current",
      "ru": "K⁺-ток потенциала покоя",
      "subtopic": "Фаза 4"
    },
    {
      "abbr": "Ito",
      "full": "Transient outward K⁺ current",
      "ru": "кратковременный выходящий K⁺-ток",
      "subtopic": "Фаза 1"
    },
    {
      "abbr": "IKr",
      "full": "Rapid delayed rectifier K⁺ current",
      "ru": "K⁺-ток реполяризации",
      "subtopic": "Фаза 3"
    },
    {
      "abbr": "hERG",
      "full": "Human Ether-à-go-go-Related Gene channel",
      "ru": "канал, формирующий IKr; важен для лекарственного QT",
      "subtopic": "QT"
    },
    {
      "abbr": "QTc",
      "full": "Corrected QT interval",
      "ru": "корригированный интервал QT",
      "subtopic": "ЭКГ"
    },
    {
      "abbr": "TdP",
      "full": "Torsades de pointes",
      "ru": "полиморфная желудочковая тахикардия типа «пируэт»",
      "subtopic": "QT"
    },
    {
      "abbr": "CICR",
      "full": "Calcium-Induced Calcium Release",
      "ru": "кальций-индуцированное высвобождение кальция",
      "subtopic": "Сокращение"
    },
    {
      "abbr": "RyR2",
      "full": "Ryanodine Receptor type 2",
      "ru": "рианодиновый рецептор 2",
      "subtopic": "Ca²⁺"
    },
    {
      "abbr": "SR / СПР",
      "full": "Sarcoplasmic Reticulum",
      "ru": "саркоплазматический ретикулум",
      "subtopic": "Ca²⁺"
    },
    {
      "abbr": "SERCA2a",
      "full": "Sarcoplasmic/Endoplasmic Reticulum Ca²⁺-ATPase 2a",
      "ru": "насос возврата Ca²⁺ в СПР",
      "subtopic": "Расслабление"
    },
    {
      "abbr": "PLB",
      "full": "Phospholamban",
      "ru": "фосфоламбан",
      "subtopic": "Расслабление"
    },
    {
      "abbr": "NCX",
      "full": "Na⁺/Ca²⁺ Exchanger",
      "ru": "Na⁺/Ca²⁺-обменник",
      "subtopic": "Ca²⁺"
    },
    {
      "abbr": "PMCA",
      "full": "Plasma Membrane Ca²⁺-ATPase",
      "ru": "плазматическая Ca²⁺-АТФаза",
      "subtopic": "Ca²⁺"
    },
    {
      "abbr": "MCU",
      "full": "Mitochondrial Calcium Uniporter",
      "ru": "митохондриальный унипортер Ca²⁺",
      "subtopic": "Ca²⁺"
    },
    {
      "abbr": "TnC",
      "full": "Troponin C",
      "ru": "Ca²⁺-связывающий компонент тропонина",
      "subtopic": "Саркомер"
    },
    {
      "abbr": "RAAS",
      "full": "Renin–Angiotensin–Aldosterone System",
      "ru": "ренин-ангиотензин-альдостероновая система",
      "subtopic": "Давление / HF"
    },
    {
      "abbr": "ACE",
      "full": "Angiotensin-Converting Enzyme",
      "ru": "ангиотензинпревращающий фермент",
      "subtopic": "RAAS"
    },
    {
      "abbr": "ARB",
      "full": "Angiotensin Receptor Blocker",
      "ru": "блокатор рецепторов ангиотензина II",
      "subtopic": "RAAS"
    },
    {
      "abbr": "AT₁",
      "full": "Angiotensin II type 1 receptor",
      "ru": "рецептор ангиотензина II типа 1",
      "subtopic": "RAAS"
    },
    {
      "abbr": "NO",
      "full": "Nitric Oxide",
      "ru": "оксид азота",
      "subtopic": "Сосуды"
    },
    {
      "abbr": "sGC",
      "full": "Soluble Guanylate Cyclase",
      "ru": "растворимая гуанилатциклаза",
      "subtopic": "NO/cGMP"
    },
    {
      "abbr": "cGMP",
      "full": "Cyclic Guanosine Monophosphate",
      "ru": "циклический гуанозинмонофосфат",
      "subtopic": "NO/cGMP"
    },
    {
      "abbr": "CO",
      "full": "Cardiac Output",
      "ru": "сердечный выброс",
      "subtopic": "Гемодинамика"
    },
    {
      "abbr": "SV",
      "full": "Stroke Volume",
      "ru": "ударный объём",
      "subtopic": "Гемодинамика"
    },
    {
      "abbr": "EF",
      "full": "Ejection Fraction",
      "ru": "фракция выброса",
      "subtopic": "Сердечная недостаточность"
    },
    {
      "abbr": "SVR",
      "full": "Systemic Vascular Resistance",
      "ru": "системное сосудистое сопротивление",
      "subtopic": "Гемодинамика"
    }
  ],
  "hemostasis": [
    {
      "abbr": "INR",
      "full": "International Normalized Ratio",
      "ru": "международное нормализованное отношение",
      "subtopic": "Warfarin"
    },
    {
      "abbr": "PT",
      "full": "Prothrombin Time",
      "ru": "протромбиновое время",
      "subtopic": "Коагуляция"
    },
    {
      "abbr": "aPTT",
      "full": "Activated Partial Thromboplastin Time",
      "ru": "активированное частичное тромбопластиновое время",
      "subtopic": "Коагуляция"
    },
    {
      "abbr": "LMWH",
      "full": "Low-Molecular-Weight Heparin",
      "ru": "низкомолекулярный гепарин",
      "subtopic": "Enoxaparin"
    },
    {
      "abbr": "DOAC",
      "full": "Direct Oral Anticoagulant",
      "ru": "прямой пероральный антикоагулянт",
      "subtopic": "Dabigatran/Rivaroxaban"
    },
    {
      "abbr": "P2Y12",
      "full": "P2Y12 ADP receptor",
      "ru": "рецептор тромбоцитов — мишень clopidogrel",
      "subtopic": "Антиагреганты"
    }
  ],
  "endocrine": [
    {
      "abbr": "SGLT2",
      "full": "Sodium-Glucose Cotransporter 2",
      "ru": "натрий-глюкозный котранспортер 2",
      "subtopic": "Диабет"
    },
    {
      "abbr": "GLP-1",
      "full": "Glucagon-Like Peptide-1",
      "ru": "глюкагоноподобный пептид-1",
      "subtopic": "Диабет"
    },
    {
      "abbr": "DPP-4",
      "full": "Dipeptidyl Peptidase-4",
      "ru": "дипептидилпептидаза-4",
      "subtopic": "Диабет"
    },
    {
      "abbr": "PPARγ",
      "full": "Peroxisome Proliferator-Activated Receptor gamma",
      "ru": "мишень pioglitazone",
      "subtopic": "Диабет"
    },
    {
      "abbr": "T4",
      "full": "Thyroxine",
      "ru": "тироксин",
      "subtopic": "Щитовидная железа"
    },
    {
      "abbr": "T3",
      "full": "Triiodothyronine",
      "ru": "трийодтиронин",
      "subtopic": "Щитовидная железа"
    },
    {
      "abbr": "TSH",
      "full": "Thyroid-Stimulating Hormone",
      "ru": "тиреотропный гормон",
      "subtopic": "Щитовидная железа"
    }
  ],
  "psych": [
    {
      "abbr": "SSRI / СИОЗС",
      "full": "Selective Serotonin Reuptake Inhibitor",
      "ru": "селективный ингибитор обратного захвата серотонина",
      "subtopic": "Антидепрессанты"
    },
    {
      "abbr": "SNRI / СИОЗСН",
      "full": "Serotonin–Norepinephrine Reuptake Inhibitor",
      "ru": "ингибитор обратного захвата серотонина и норадреналина",
      "subtopic": "Антидепрессанты"
    },
    {
      "abbr": "TCA / ТЦА",
      "full": "Tricyclic Antidepressant",
      "ru": "трициклический антидепрессант",
      "subtopic": "Антидепрессанты"
    },
    {
      "abbr": "5-HT",
      "full": "5-Hydroxytryptamine",
      "ru": "серотонин",
      "subtopic": "Серотонинергическая система"
    },
    {
      "abbr": "D₂",
      "full": "Dopamine D2 receptor",
      "ru": "дофаминовый D₂-рецептор",
      "subtopic": "Антипсихотики"
    },
    {
      "abbr": "GABA-A",
      "full": "Gamma-Aminobutyric Acid type A receptor",
      "ru": "ГАМК-A-рецептор",
      "subtopic": "Бензодиазепины / Z-drugs"
    }
  ],
  "neuro": [
    {
      "abbr": "AChE",
      "full": "Acetylcholinesterase",
      "ru": "ацетилхолинэстераза",
      "subtopic": "Деменция"
    },
    {
      "abbr": "NMDA",
      "full": "N-Methyl-D-Aspartate receptor",
      "ru": "NMDA-рецептор глутамата",
      "subtopic": "Memantine"
    },
    {
      "abbr": "COMT",
      "full": "Catechol-O-Methyltransferase",
      "ru": "катехол-O-метилтрансфераза",
      "subtopic": "Паркинсон"
    },
    {
      "abbr": "MAO-B",
      "full": "Monoamine Oxidase B",
      "ru": "моноаминоксидаза B",
      "subtopic": "Паркинсон"
    },
    {
      "abbr": "SV2A",
      "full": "Synaptic Vesicle Glycoprotein 2A",
      "ru": "синаптический белок — мишень levetiracetam",
      "subtopic": "Эпилепсия"
    }
  ],
  "resp": [
    {
      "abbr": "SABA",
      "full": "Short-Acting Beta2-Agonist",
      "ru": "короткодействующий β₂-агонист",
      "subtopic": "Астма"
    },
    {
      "abbr": "LAMA",
      "full": "Long-Acting Muscarinic Antagonist",
      "ru": "длительно действующий М-холиноблокатор",
      "subtopic": "ХОБЛ"
    },
    {
      "abbr": "ICS",
      "full": "Inhaled Corticosteroid",
      "ru": "ингаляционный глюкокортикостероид",
      "subtopic": "Астма"
    },
    {
      "abbr": "CysLT1",
      "full": "Cysteinyl Leukotriene receptor 1",
      "ru": "мишень montelukast",
      "subtopic": "Астма"
    },
    {
      "abbr": "H1",
      "full": "Histamine H1 receptor",
      "ru": "гистаминовый H1-рецептор",
      "subtopic": "Аллергология"
    }
  ],
  "gi": [
    {
      "abbr": "PPI / ИПП",
      "full": "Proton Pump Inhibitor",
      "ru": "ингибитор протонной помпы",
      "subtopic": "Кислотность"
    },
    {
      "abbr": "H2",
      "full": "Histamine H2 receptor",
      "ru": "H2-рецептор париетальной клетки",
      "subtopic": "Кислотность"
    },
    {
      "abbr": "D₂",
      "full": "Dopamine D2 receptor",
      "ru": "мишень domperidone/metoclopramide",
      "subtopic": "Тошнота / моторика"
    }
  ]
};
