export const THEORY = {
  "cardio": [
    {
      "id": "cardio-electrophysiology",
      "title": "Электрофизиология сердца, Ca²⁺ и ЭКГ",
      "summary": "Проводящая система, потенциалы действия, excitation–contraction coupling, ЭКГ и влияние 49 препаратов.",
      "type": "interactive",
      "url": "modules/cardio/index.html"
    },
    {
      "id": "cardio-core-chain",
      "title": "Главная интеграционная цепочка",
      "summary": "СА-узел → проведение → QRS → L-type Ca²⁺ → RyR2/CICR → TnC → actin/myosin → SERCA/NCX → расслабление.",
      "type": "note",
      "body": [
        "ЭКГ регистрирует электрическую активность, а не механическое сокращение.",
        "Фаза 0 рабочего миокарда зависит от быстрых Na⁺-каналов; фаза 0 СА/АВ-узлов — от L-type Ca²⁺-каналов.",
        "Ca²⁺, вошедший через L-type канал, активирует RyR2 и запускает CICR.",
        "SERCA2a возвращает Ca²⁺ в СПР; NCX в обычном диастолическом режиме выводит Ca²⁺ из клетки."
      ]
    }
  ]
};
