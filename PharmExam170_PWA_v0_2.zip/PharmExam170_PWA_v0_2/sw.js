const CACHE="pharmexam170-v0.2.0";
const CORE=["./", "./index.html", "./styles.css", "./app.js", "./manifest.webmanifest", "./data/topics.js", "./data/drugs.js", "./data/abbreviations.js", "./data/theory.js", "./data/mechanisms.js", "./data/highYield.js", "./data/tests.js", "./data/testAnalyses.js", "./data/sourceSections.js", "./data/cardio49.js", "./source/cardio_tests_webarchive_full_text.txt", "./modules/cardio/index.html", "./modules/cardio/app.js", "./icons/icon-180.png", "./icons/icon-192.png", "./icons/icon-512.png"];
self.addEventListener("install",e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(CORE))));
self.addEventListener("activate",e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k))))));
self.addEventListener("fetch",e=>{
  if(e.request.method!=="GET")return;
  e.respondWith(caches.match(e.request).then(hit=>hit||fetch(e.request).then(r=>{
    const copy=r.clone(); caches.open(CACHE).then(c=>c.put(e.request,copy)); return r;
  }).catch(()=>caches.match("./index.html"))));
});
