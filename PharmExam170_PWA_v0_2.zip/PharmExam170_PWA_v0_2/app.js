import { TOPICS } from "./data/topics.js";
import { DRUGS } from "./data/drugs.js";
import { ABBREVIATIONS } from "./data/abbreviations.js";
import { THEORY } from "./data/theory.js";
import { MECHANISMS } from "./data/mechanisms.js";
import { HIGH_YIELD } from "./data/highYield.js";
import { TESTS } from "./data/tests.js";
import { TEST_ANALYSES } from "./data/testAnalyses.js";
import { SOURCE_SECTIONS } from "./data/sourceSections.js";
import { CARDIO49 } from "./data/cardio49.js";

const app = document.getElementById("app");
const topicMap = Object.fromEntries(TOPICS.map(t => [t.id,t]));
const drugMap = Object.fromEntries(DRUGS.map(d => [String(d.n),d]));
const esc = s => String(s ?? "").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));

function header(){return `<div class="topbar"><div class="brand"><div class="brandIcon">💊</div><div><h1>PharmExam 170</h1><div class="sub">теория · препараты · тесты · разборы</div></div></div></div>`;}
function bottomNav(active){
 const items=[["home","🏠","Главная"],["topics","🗂️","Темы"],["drugs","💊","170"],["tests","📝","Тесты"],["search","🔎","Поиск"]];
 return `<nav class="bottomNav">${items.map(([id,ic,t])=>`<button class="navBtn ${active===id?"active":""}" data-nav="${id}"><span class="iconFrame">${ic}</span><span>${t}</span></button>`).join("")}</nav>`;
}
function bindNav(){
 document.querySelectorAll("[data-nav]").forEach(b=>b.addEventListener("click",()=>location.hash=b.dataset.nav==="home"?"#home":`#${b.dataset.nav}`));
 document.querySelectorAll("[data-route]").forEach(el=>el.addEventListener("click",()=>location.hash=el.dataset.route));
}
function countsForTopic(id){return {drugs:DRUGS.filter(d=>d.topics.includes(id)).length,abbr:(ABBREVIATIONS[id]||[]).length,theory:(THEORY[id]||[]).length,mechanisms:(MECHANISMS[id]||[]).length,tests:TESTS.filter(q=>q.topic===id).length,analyses:TEST_ANALYSES.filter(q=>q.topic===id).length};}

function renderHome(){
 app.innerHTML=header()+`<div class="page"><section class="hero"><h2>Единая база подготовки по 170 препаратам</h2><p>В каждой теме отдельно хранятся теория, механизмы, препараты, аббревиатуры, тесты и разборы. Первый полноценно заполненный модуль — ССС.</p><div class="stats"><div class="stat"><b>170</b><span>препаратов</span></div><div class="stat"><b>${TOPICS.length}</b><span>тем</span></div><div class="stat"><b>${Object.values(ABBREVIATIONS).flat().length}</b><span>аббревиатур</span></div><div class="stat"><b>${TESTS.length}</b><span>тестов загружено</span></div></div></section>
 <div class="sectionTitle"><h2>Продолжить изучение</h2></div><div class="card clickCard" data-route="#topic/cardio/theory"><div class="cardHead"><div class="iconFrame">🫀</div><div><h3>ССС → Электрофизиология и ЭКГ</h3><p>Потенциалы действия, Ca²⁺, ЭКГ и интерактивная фармакология 49 препаратов.</p><span class="badge blue">интерактивный модуль</span></div></div></div>
 <div class="sectionTitle"><h2>Основные разделы</h2></div><div class="sectionGrid"><div class="card clickCard" data-route="#topics"><div class="cardHead"><div class="iconFrame">🗂️</div><div><h3>Темы</h3><p>17 системных разделов с вложенной структурой.</p></div></div></div><div class="card clickCard" data-route="#drugs"><div class="cardHead"><div class="iconFrame">💊</div><div><h3>170 препаратов</h3><p>Единая база без дублирования карточек.</p></div></div></div><div class="card clickCard" data-route="#tests"><div class="cardHead"><div class="iconFrame">📝</div><div><h3>Тесты и разборы</h3><p>Структура готова; реальные вопросы добавим из твоих тестов.</p></div></div></div><div class="card clickCard" data-route="#search"><div class="cardHead"><div class="iconFrame">🔎</div><div><h3>Глобальный поиск</h3><p>По препаратам, аббревиатурам и теории.</p></div></div></div></div></div>`+bottomNav("home");bindNav();
}

function renderTopics(){
 app.innerHTML=header()+`<div class="page"><div class="sectionTitle"><h2>Темы</h2><span class="muted">${TOPICS.length} разделов</span></div><div class="topicGrid">${TOPICS.map(t=>{const c=countsForTopic(t.id);return `<div class="card clickCard" data-route="#topic/${t.id}"><div class="cardHead"><div class="iconFrame">${t.icon}</div><div><h3>${esc(t.title)}</h3><p>${esc(t.description)}</p><span class="badge">${c.drugs} препаратов</span>${c.abbr?`<span class="badge">${c.abbr} аббр.</span>`:""}${c.theory?`<span class="badge blue">${c.theory} теория</span>`:""}</div></div></div>`;}).join("")}</div></div>`+bottomNav("topics");bindNav();
}
function topicSections(t){const c=countsForTopic(t.id);const defs=[["theory","📘","Теория",c.theory,"Конспекты и интерактивные учебные модули."],["mechanisms","🧬","Механизмы",c.mechanisms,"Сигнальные пути и причинно-следственные цепочки."],["drugs","💊","Препараты",c.drugs,"Препараты, связанные с этой темой."],["abbr","🔤","Аббревиатуры",c.abbr,"Только словарь этой темы — без смешивания."],["tests","📝","Тесты",c.tests,"Вопросы только по выбранной теме."],["analysis","✅","Разбор тестов",c.analyses,"Почему правильный ответ верен и почему остальные неверны."],["high","⚡","High-yield",(HIGH_YIELD[t.id]||[]).length,"Короткий экзаменационный повтор."]];return defs.map(([id,ic,title,count,desc])=>`<div class="card clickCard" data-route="#topic/${t.id}/${id}"><div class="cardHead"><div class="iconFrame">${ic}</div><div><h3>${title}</h3><p>${desc}</p><span class="badge">${count}</span></div></div></div>`).join("");}
function renderTopic(id){const t=topicMap[id];if(!t){location.hash="#topics";return;}app.innerHTML=header()+`<div class="page"><div class="breadcrumb"><button data-route="#topics">Темы</button><span>›</span><span>${esc(t.short)}</span></div><div class="topicHeader"><div class="iconFrame">${t.icon}</div><div><h2>${esc(t.title)}</h2><p>${esc(t.description)}</p></div></div><div class="sectionGrid">${topicSections(t)}</div></div>`+bottomNav("topics");bindNav();}
function sectionShell(t,title,content){return header()+`<div class="page"><div class="breadcrumb"><button data-route="#topics">Темы</button><span>›</span><button data-route="#topic/${t.id}">${esc(t.short)}</button><span>›</span><span>${esc(title)}</span></div><div class="topicHeader"><div class="iconFrame">${t.icon}</div><div><h2>${esc(title)}</h2><p>${esc(t.title)}</p></div></div>${content}</div>`+bottomNav("topics");}

function renderTopicTheory(t){const items=THEORY[t.id]||[];if(!items.length)return `<div class="emptyState"><div class="big">📘</div><b>Теория пока не заполнена</b><p>Структура уже готова. Следующие конспекты добавим сюда по мере подготовки.</p></div>`;return `<div class="list">${items.map(x=>`<div class="theoryCard"><h3>${esc(x.title)}</h3><p>${esc(x.summary)}</p>${x.type==="interactive"?`<a class="moduleButton" href="${x.url}">📈 Открыть интерактивный модуль</a>`:""}${x.body?`<div class="chips">${x.body.map(v=>`<span class="chip">${esc(v)}</span>`).join("")}</div>`:""}</div>`).join("")}</div>`;}
function renderMechanisms(t){const arr=MECHANISMS[t.id]||[];if(!arr.length)return `<div class="emptyState"><div class="big">🧬</div><b>Механизмы пока не заполнены</b><p>Здесь будут схемы receptor → messenger → effect → drug.</p></div>`;return `<div class="list">${arr.map(m=>`<div class="mechanismCard"><h3>${esc(m.title)}</h3><div class="chain">${m.chain.map((v,i)=>`${i?'<div class="chainArrow">→</div>':""}<div class="chainNode">${esc(v)}</div>`).join("")}</div><div class="chips">${m.examples.map(v=>`<span class="chip">${esc(v)}</span>`).join("")}</div></div>`).join("")}</div>`;}
function drugRows(list){return `<div class="list">${list.map(d=>`<div class="drugRow"><div class="drugNum">#${d.n}</div><div class="drugMain" style="flex:1"><b>${esc(d.name)}</b><span>${esc(d.group)}</span><div>${d.topics.map(x=>`<span class="badge">${esc(topicMap[x]?.short||x)}</span>`).join("")}</div></div><button class="drugLink" data-route="#drug/${d.n}">Открыть</button></div>`).join("")}</div>`;}
function renderTopicDrugs(t){const list=DRUGS.filter(d=>d.topics.includes(t.id));return `<div class="toolbar"><input id="topicDrugSearch" placeholder="Поиск в ${esc(t.short)}…"><span class="badge blue">${list.length} препаратов</span></div><div id="topicDrugList">${drugRows(list)}</div>`;}
function abbrRow(a){return `<div class="abbrRow"><b>${esc(a.abbr)}</b><div class="full">${esc(a.full)}</div><div class="ru">${esc(a.ru)}</div><div class="subtopic">${esc(a.subtopic)}</div></div>`;}
function renderAbbr(t){const arr=ABBREVIATIONS[t.id]||[];if(!arr.length)return `<div class="emptyState"><div class="big">🔤</div><b>Словарь этой темы пока не заполнен</b><p>Аббревиатуры будут добавляться внутри темы, а не в один смешанный список.</p></div>`;return `<div class="toolbar"><input id="abbrSearch" placeholder="Поиск по аббревиатурам ${esc(t.short)}…"><span class="badge">${arr.length}</span></div><div id="abbrList" class="list">${arr.map(abbrRow).join("")}</div>`;}
function renderTestsSection(t, analysis=false){
  const arr=(analysis?TEST_ANALYSES:TESTS).filter(x=>x.topic===t.id);
  if(!arr.length) return `<div class="emptyState"><div class="big">${analysis?"✅":"📝"}</div><b>${analysis?"Разборов":"Тестов"} пока нет</b></div>`;
  if(!analysis){
    const sections=SOURCE_SECTIONS.filter(s=>s.topic===t.id);
    return `<div class="card"><h3>Интерактивный тест</h3><p>${arr.length} вопросов из загруженного материала. Результаты сессии нигде не сохраняются.</p>
      <button class="moduleButton" data-start-test="topic:${t.id}">▶ Начать тест по теме (${arr.length})</button></div>
      <div class="sectionTitle"><h2>Блоки источника</h2></div>
      <div class="list">${sections.map(s=>`<div class="theoryCard"><h3>${esc(s.title)}</h3><p>${s.count} вопросов</p><button class="drugLink" data-start-test="section:${s.id}">Начать</button></div>`).join("")}</div>`;
  }
  const qmap=Object.fromEntries(TESTS.map(q=>[q.id,q]));
  return `<div class="list">${arr.map(a=>{
    const q=qmap[a.questionId]; if(!q)return "";
    return `<div class="theoryCard"><div class="resultType">${esc(q.sectionTitle)} · вопрос ${q.number}</div><h3>${esc(q.question)}</h3>
      <div class="answerReview"><b>Правильный ответ: ${esc(q.correct)}. ${esc(q.options.find(o=>o.id===q.correct)?.text||q.correctText||"")}</b></div>
      ${a.explanation?.length?`<div class="reviewText">${a.explanation.map(x=>`<p>${esc(x)}</p>`).join("")}</div>`:""}
      ${q.options.map(o=>`<div class="reviewOption ${o.id===q.correct?"isCorrect":""}"><b>${o.id}. ${esc(o.text)}</b><div>${o.id===q.correct?"Правильный вариант.":esc(a.optionExplanations?.[o.id]||"В исходном материале отдельный комментарий к этому варианту не сохранён.")}</div></div>`).join("")}
      ${a.sourceNotes?.length?`<div class="sourceNote">${a.sourceNotes.map(x=>`<div>⚠ ${esc(x)}</div>`).join("")}</div>`:""}
    </div>`;
  }).join("")}</div>`;
}
function renderHigh(t){const arr=HIGH_YIELD[t.id]||[];if(!arr.length)return `<div class="emptyState"><div class="big">⚡</div><b>High-yield пока не заполнен</b></div>`;return `<div class="list">${arr.map((x,i)=>`<div class="highYieldItem"><b>${i+1}.</b> ${esc(x)}</div>`).join("")}</div>`;}

function renderTopicSection(id,section){const t=topicMap[id];if(!t){location.hash="#topics";return;}const titles={theory:"Теория",mechanisms:"Механизмы",drugs:"Препараты",abbr:"Аббревиатуры",tests:"Тесты",analysis:"Разбор тестов",high:"High-yield"};let content="";if(section==="theory")content=renderTopicTheory(t);if(section==="mechanisms")content=renderMechanisms(t);if(section==="drugs")content=renderTopicDrugs(t);if(section==="abbr")content=renderAbbr(t);if(section==="tests")content=renderTestsSection(t,false);if(section==="analysis")content=renderTestsSection(t,true);if(section==="high")content=renderHigh(t);app.innerHTML=sectionShell(t,titles[section]||section,content);bindNav();bindTestStarters();if(section==="drugs"){const input=document.getElementById("topicDrugSearch"),target=document.getElementById("topicDrugList"),base=DRUGS.filter(d=>d.topics.includes(t.id));input?.addEventListener("input",()=>{const q=input.value.toLowerCase();target.innerHTML=drugRows(base.filter(d=>(d.name+" "+d.group).toLowerCase().includes(q)));bindNav();});}if(section==="abbr"){const input=document.getElementById("abbrSearch"),target=document.getElementById("abbrList"),base=ABBREVIATIONS[t.id]||[];input?.addEventListener("input",()=>{const q=input.value.toLowerCase();target.innerHTML=base.filter(a=>(a.abbr+" "+a.full+" "+a.ru+" "+a.subtopic).toLowerCase().includes(q)).map(abbrRow).join("");});}}

function renderAllDrugs(){const options=TOPICS.map(t=>`<option value="${t.id}">${esc(t.short)}</option>`).join("");app.innerHTML=header()+`<div class="page"><div class="sectionTitle"><h2>170 препаратов</h2><span class="muted">единая база</span></div><div class="toolbar"><input id="drugSearch" placeholder="Название или фармгруппа…"><select id="drugTopic"><option value="">Все темы</option>${options}</select></div><div id="allDrugList">${drugRows(DRUGS)}</div></div>`+bottomNav("drugs");bindNav();const s=document.getElementById("drugSearch"),f=document.getElementById("drugTopic"),out=document.getElementById("allDrugList");const apply=()=>{const q=s.value.toLowerCase(),topic=f.value;const rows=DRUGS.filter(d=>(!q||(d.name+" "+d.group).toLowerCase().includes(q))&&(!topic||d.topics.includes(topic)));out.innerHTML=drugRows(rows);bindNav();};s.addEventListener("input",apply);f.addEventListener("change",apply);}
function renderDrug(n){const d=drugMap[String(n)];if(!d){location.hash="#drugs";return;}const cardio=CARDIO49[d.name];app.innerHTML=header()+`<div class="page drugDetail"><div class="breadcrumb"><button data-route="#drugs">170 препаратов</button><span>›</span><span>#${d.n}</span></div><div class="topicHeader"><div class="iconFrame">💊</div><div><h2>${esc(d.name)}</h2><p>${esc(d.group)}</p></div></div><div class="detailBox"><h3>Связанные темы</h3><div class="chips">${d.topics.map(x=>`<button class="chip" data-route="#topic/${x}">${esc(topicMap[x]?.title||x)}</button>`).join("")}</div></div>${cardio?`<div class="detailBox noteCardio"><h3>Связь с электрофизиологией ССС</h3><p>${esc(cardio.note)}</p><a class="moduleButton" href="modules/cardio/index.html">🫀 Открыть Cardio-модуль</a></div>`:""}<div class="detailBox"><h3>Карточка препарата — структура для расширения</h3><div class="chips"><span class="chip">Механизм действия</span><span class="chip">Показания</span><span class="chip">Побочные эффекты</span><span class="chip">Противопоказания</span><span class="chip">Взаимодействия</span><span class="chip">Фармакокинетика</span><span class="chip">Экзаменационные ловушки</span><span class="chip">Связанные тесты</span></div><p class="smallMuted" style="margin-top:9px">Пока заполнены исходная фармгруппа, тематические связи и ранее подготовленная кардиальная информация для 49 препаратов.</p></div></div>`+bottomNav("drugs");bindNav();}
function renderTests(){
  const cardio=TESTS.filter(q=>q.topic==="cardio").length;
  const hem=TESTS.filter(q=>q.topic==="hemostasis").length;
  app.innerHTML=header()+`<div class="page">
    <section class="hero"><h2>Тесты из загруженного конспекта</h2><p>76 вопросов. Неправильный ответ → подсказка → повторная попытка до правильного ответа. После правильного ответа открывается полный разбор.</p>
      <div class="stats"><div class="stat"><b>${TESTS.length}</b><span>вопросов</span></div><div class="stat"><b>${SOURCE_SECTIONS.length}</b><span>блоков</span></div><div class="stat"><b>${cardio}</b><span>ССС</span></div><div class="stat"><b>${hem}</b><span>гемостаз</span></div></div>
      <div class="warn">История ответов не записывается в localStorage, cookies или базу. Статистика существует только до закрытия/перезагрузки текущей тестовой сессии.</div>
    </section>
    <div class="sectionTitle"><h2>Начать</h2></div>
    <div class="sectionGrid">
      <div class="card clickCard"><div class="cardHead"><div class="iconFrame">🎯</div><div><h3>Все вопросы</h3><p>${TESTS.length} вопросов подряд.</p><button class="moduleButton" data-start-test="all">Начать</button></div></div></div>
      <div class="card clickCard"><div class="cardHead"><div class="iconFrame">🫀</div><div><h3>Только ССС</h3><p>${cardio} вопросов.</p><button class="moduleButton" data-start-test="topic:cardio">Начать</button></div></div></div>
      <div class="card clickCard"><div class="cardHead"><div class="iconFrame">🩸</div><div><h3>Гемостаз</h3><p>${hem} вопросов.</p><button class="moduleButton" data-start-test="topic:hemostasis">Начать</button></div></div></div>
    </div>
    <div class="sectionTitle"><h2>По блокам источника</h2></div>
    <div class="list">${SOURCE_SECTIONS.map(s=>`<div class="theoryCard"><h3>${esc(s.title)}</h3><p>${s.count} вопросов</p><button class="drugLink" data-start-test="section:${s.id}">Начать тест</button></div>`).join("")}</div>
  </div>`+bottomNav("tests");
  bindNav(); bindTestStarters();
}
function renderSearch(){app.innerHTML=header()+`<div class="page"><div class="sectionTitle"><h2>Глобальный поиск</h2></div><input id="globalSearch" placeholder="Например: SERCA, metoprolol, QT, SGLT2…"><div id="globalResults" class="globalResults" style="margin-top:10px"><div class="emptyState"><div class="big">🔎</div><b>Начни вводить запрос</b><p>Поиск идёт по препаратам, аббревиатурам и теоретическим модулям.</p></div></div></div>`+bottomNav("search");bindNav();const input=document.getElementById("globalSearch"),out=document.getElementById("globalResults");input.addEventListener("input",()=>{const q=input.value.trim().toLowerCase();if(!q){out.innerHTML=`<div class="emptyState"><div class="big">🔎</div><b>Начни вводить запрос</b></div>`;return;}const dr=DRUGS.filter(d=>(d.name+" "+d.group).toLowerCase().includes(q)).slice(0,20);const ab=Object.entries(ABBREVIATIONS).flatMap(([topic,arr])=>arr.map(a=>({...a,topic}))).filter(a=>(a.abbr+" "+a.full+" "+a.ru+" "+a.subtopic).toLowerCase().includes(q)).slice(0,20);const th=Object.entries(THEORY).flatMap(([topic,arr])=>arr.map(x=>({...x,topic}))).filter(x=>(x.title+" "+x.summary).toLowerCase().includes(q)).slice(0,20);const html=[...dr.map(d=>`<div class="drugRow"><div><div class="resultType">Препарат</div><b>${esc(d.name)}</b><div class="smallMuted">${esc(d.group)}</div></div><button class="drugLink" data-route="#drug/${d.n}">Открыть</button></div>`),...ab.map(a=>`<div class="abbrRow"><div class="resultType">Аббревиатура · ${esc(topicMap[a.topic]?.short||a.topic)}</div><b>${esc(a.abbr)}</b><div class="ru">${esc(a.ru)}</div></div>`),...th.map(x=>`<div class="theoryCard"><div class="resultType">Теория · ${esc(topicMap[x.topic]?.short||x.topic)}</div><h3>${esc(x.title)}</h3><p>${esc(x.summary)}</p></div>`)].join("");out.innerHTML=html||`<div class="emptyState"><b>Ничего не найдено</b></div>`;bindNav();});}

let testSession=null;

function bindTestStarters(){
  document.querySelectorAll("[data-start-test]").forEach(b=>b.addEventListener("click",()=>startTestSession(b.dataset.startTest)));
}

function startTestSession(spec){
  let questions=[...TESTS];
  if(spec?.startsWith("topic:")) questions=questions.filter(q=>q.topic===spec.split(":")[1]);
  if(spec?.startsWith("section:")) questions=questions.filter(q=>q.sectionId===spec.split(":")[1]);
  testSession={
    questions, index:0, firstTryCorrect:0, retriedQuestions:0, extraWrongAttempts:0,
    currentWrong:[], errors:[], answered:0
  };
  location.hash="#quiz";
}

function currentQuestion(){return testSession?.questions?.[testSession.index]}

function renderQuiz(){
  if(!testSession){location.hash="#tests";return;}
  if(testSession.index>=testSession.questions.length){renderQuizResults();return;}
  const q=currentQuestion();
  const progress=Math.round((testSession.index/testSession.questions.length)*100);
  app.innerHTML=header()+`<div class="page quizPage">
    <div class="quizTop"><button class="quizExit" id="quizExit">✕ Закрыть</button><div class="quizCount">${testSession.index+1} / ${testSession.questions.length}</div></div>
    <div class="progressTrack"><div class="progressFill" style="width:${progress}%"></div></div>
    <div class="card quizCard">
      <div class="resultType">${esc(q.sectionTitle)} · вопрос ${q.number}</div>
      <h2>${esc(q.question)}</h2>
      ${q.disputed?`<div class="sourceNote">⚠ В исходном материале этот вопрос отмечен как спорный/исправленный. После ответа покажу примечание.</div>`:""}
      <div class="quizOptions">${q.options.map(o=>`<button class="quizOption" data-option="${o.id}"><span class="optionLetter">${o.id}</span><span>${esc(o.text)}</span></button>`).join("")}</div>
      <div class="smallMuted" style="margin-top:10px">Если ошибёшься, получишь подсказку и сможешь отвечать снова до правильного варианта.</div>
    </div>
  </div>`;
  document.getElementById("quizExit").addEventListener("click",()=>{testSession=null;location.hash="#tests";});
  document.querySelectorAll(".quizOption").forEach(b=>b.addEventListener("click",()=>handleQuizAnswer(b.dataset.option,b)));
}

function handleQuizAnswer(optionId,button){
  const q=currentQuestion();
  if(!q||button.disabled)return;
  if(optionId===q.correct){
    button.classList.add("correctAnswer");
    document.querySelectorAll(".quizOption").forEach(x=>x.disabled=true);
    if(testSession.currentWrong.length===0)testSession.firstTryCorrect++;
    else testSession.retriedQuestions++;
    testSession.answered++;
    showExplanationModal(q);
  }else{
    button.classList.add("wrongAnswer"); button.disabled=true;
    testSession.currentWrong.push(optionId);
    testSession.extraWrongAttempts++;
    let err=testSession.errors.find(e=>e.questionId===q.id);
    if(!err){err={questionId:q.id,sectionTitle:q.sectionTitle,number:q.number,question:q.question,wrong:[],correct:q.correct,correctText:q.options.find(o=>o.id===q.correct)?.text||q.correctText};testSession.errors.push(err);}
    err.wrong.push({id:optionId,text:q.options.find(o=>o.id===optionId)?.text||""});
    showHintModal(q,optionId);
  }
}

function modalShell(inner){
  const el=document.createElement("div"); el.className="modalBackdrop"; el.innerHTML=`<div class="modalSheet">${inner}</div>`; document.body.appendChild(el); return el;
}

function showHintModal(q,optionId){
  const wrong=q.options.find(o=>o.id===optionId);
  const modal=modalShell(`<div class="modalHandle"></div><div class="modalIcon bad">✕</div><h2>Пока неверно</h2><p class="modalWrong"><b>${esc(optionId)}. ${esc(wrong?.text||"")}</b></p><div class="hintBox"><b>Подсказка</b><p>${esc(q.hint)}</p></div><button class="modalPrimary" id="hintClose">Попробовать ещё раз</button>`);
  modal.querySelector("#hintClose").addEventListener("click",()=>modal.remove());
}

function showExplanationModal(q){
  const main=q.explanation?.length?q.explanation.map(x=>`<p>${esc(x)}</p>`).join(""):`<p>Правильный ответ указан в исходном материале.</p>`;
  const opts=q.options.map(o=>{
    const isCorrect=o.id===q.correct;
    const exp=isCorrect?"Правильный вариант. "+(q.correctText&&normText(q.correctText)!==normText(o.text)?esc(q.correctText):""):esc(q.optionExplanations?.[o.id]||"В исходном материале отдельный комментарий к этому варианту не сохранён.");
    return `<div class="explainOption ${isCorrect?"good":"badLine"}"><b>${o.id}. ${esc(o.text)}</b><div>${exp}</div></div>`;
  }).join("");
  const notes=q.sourceNotes?.length?`<div class="sourceNote">${q.sourceNotes.map(x=>`<div>⚠ ${esc(x)}</div>`).join("")}</div>`:"";
  const modal=modalShell(`<div class="modalHandle"></div><div class="modalIcon good">✓</div><h2>Правильно</h2><div class="correctBanner"><b>${esc(q.correct)}. ${esc(q.options.find(o=>o.id===q.correct)?.text||q.correctText||"")}</b></div><div class="explanationText">${main}</div><h3>Разбор всех вариантов</h3>${opts}${notes}<button class="modalPrimary" id="nextQuestion">${testSession.index+1>=testSession.questions.length?"Показать результат":"Следующий вопрос"}</button>`);
  modal.querySelector("#nextQuestion").addEventListener("click",()=>{
    modal.remove(); testSession.index++; testSession.currentWrong=[]; renderQuiz();
  });
}

function normText(s){return String(s||"").toLowerCase().replace(/[^a-zа-я0-9]+/g," ").trim()}

function renderQuizResults(){
  const s=testSession;if(!s){location.hash="#tests";return;}
  const total=s.questions.length;
  app.innerHTML=header()+`<div class="page">
    <section class="hero"><h2>Результат сессии</h2><p>Эта статистика не сохраняется. После закрытия страницы/сессии она исчезнет.</p>
      <div class="stats"><div class="stat"><b>${total}</b><span>вопросов</span></div><div class="stat"><b>${s.firstTryCorrect}</b><span>с 1-й попытки</span></div><div class="stat"><b>${s.retriedQuestions}</b><span>потребовалась ещё попытка</span></div><div class="stat"><b>${s.extraWrongAttempts}</b><span>лишних неверных выборов</span></div></div>
    </section>
    <div class="sectionTitle"><h2>Где были ошибки</h2><span class="muted">${s.errors.length} вопросов</span></div>
    ${s.errors.length?`<div class="list">${s.errors.map(e=>`<div class="theoryCard"><div class="resultType">${esc(e.sectionTitle)} · вопрос ${e.number}</div><h3>${esc(e.question)}</h3><div class="errorChoices"><b>Неверные попытки:</b>${e.wrong.map(w=>`<div class="wrongMini">✕ ${esc(w.id)}. ${esc(w.text)}</div>`).join("")}</div><div class="rightMini">✓ Правильно: ${esc(e.correct)}. ${esc(e.correctText)}</div></div>`).join("")}</div>`:`<div class="emptyState"><div class="big">🏆</div><b>Ни одной ошибки</b><p>Все вопросы были отвечены правильно с первой попытки.</p></div>`}
    <button class="moduleButton" id="closeResults">Закрыть результаты</button>
  </div>`;
  document.getElementById("closeResults").addEventListener("click",()=>{testSession=null;location.hash="#tests";});
}
function router(){const h=(location.hash||"#home").slice(1),parts=h.split("/");if(parts[0]==="home"||!parts[0])return renderHome();if(parts[0]==="topics")return renderTopics();if(parts[0]==="topic"&&parts.length===2)return renderTopic(parts[1]);if(parts[0]==="topic"&&parts.length>=3)return renderTopicSection(parts[1],parts[2]);if(parts[0]==="drugs")return renderAllDrugs();if(parts[0]==="drug")return renderDrug(parts[1]);if(parts[0]==="tests")return renderTests();if(parts[0]==="quiz")return renderQuiz();if(parts[0]==="search")return renderSearch();renderHome();}
window.addEventListener("hashchange",router);router();
