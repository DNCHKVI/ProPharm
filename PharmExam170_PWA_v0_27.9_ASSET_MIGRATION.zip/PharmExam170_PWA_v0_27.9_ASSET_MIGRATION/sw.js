const CACHE="propharm-v0.27.9";
const CORE=["./","./index.html","./styles.css","./app.js","./manifest.webmanifest","./config/supabase-config.js","./services/authService.js","./services/localDb.js","./services/userData.js","./services/memoryTrainerData.js","./data/topics.js","./data/drugs.js","./data/abbreviations.js","./data/theory.js","./data/advancedTheory.js","./data/academicSources.js","./data/advancedTables.js","./data/mechanisms.js","./data/highYield.js","./data/tests.js","./data/chemistryExamTest.js","./data/pharmacokineticsExamTest.js","./data/testAnalyses.js","./data/cardio49.js","./data/sourceSections.js","./data/interactions.js","./data/drugKnowledge.js","./data/drugProfiles.js","./data/sectionVisuals.js","./data/studyTables.js","./data/systems.js","./data/foundationalSections.js","./data/chemistryContent.js","./data/foundationAdvancedContent.js","./data/generalChemistryV242.js","./data/pharmacologyFoundations.js","./data/chemistryTools.js","./data/testNav.js","./data/diseases.js","./data/glossaryExtras.js","./data/cardioIntegrated.js","./data/visualSources.js","./data/scientificVisuals.js","./data/pastExamQuestions.js","./modules/cardio/index.html","./modules/cardio/app.js","./icons/icon-180.png","./icons/icon-192.png","./icons/icon-512.png","./assets/chemistry-test/chem-01-stereochemistry.png","./assets/chemistry-test/chem-11-functional-groups.png","./assets/chemistry-test/chem-12-aromaticity-r0279.png","./assets/chemistry-test/chem-16-functional-groups.png","./assets/chemistry-test/chem-17-vanillin-r0279.png","./assets/chemistry-test/chem-19-acetaminophen-r0279.png","./assets/chemistry-test/chem-20-capsaicin-r0279.png","./assets/chemistry-test/chem-21-citalopram-r0279.png","./assets/chemistry-test/chem-22-morphine-r0279.png","./assets/chemistry-test/chem-24-lactic-acid-enantiomers-r0279.png","./assets/chemistry-test/chem-25-weak-base-strong-acid-titration-r0279.png","./assets/chemistry-test/chem-27-simvastatin-lactone-r0279.png","./assets/chemistry-test/chem-28-sulfasalazine-r0279.png","./assets/chemistry-test/chem-25-titration-comment-r0279.jpeg","./assets/pharmacokinetics-test/pk-hysteresis-q9.png","./assets/pharmacokinetics-test/pk-absorption-order-q6.png","./assets/pharmacokinetics-test/pk-route-curve-b-q7.png","./assets/pharmacokinetics-test/pk-naproxen-curves-q4.png"];
CORE.push("./data/biochemistryExamTest.js","./data/analyticalMethodsExamTest.js","./data/pharmTechExamTest.js","./data/endocrinologyExamTest.js","./assets/chemistry-test/chem-carbocations-A-D-r0279.png","./assets/chemistry-test/chem-dopamine-r0279.png","./assets/chemistry-test/chem-doxazosin-r0279.png","./assets/chemistry-test/chem-doxazosin-comment-r0279.png","./assets/analytical-test/tlc-polarity.svg","./assets/analytical-test/c18-compounds-r0279.png","./assets/pharm-tech-test/curve-b-route.png","./i18n/admin-runtime-i18n.js","./i18n/locales/ui-dictionary.js","./i18n/admin-language-switcher.css");
self.addEventListener("install",e=>{self.skipWaiting();e.waitUntil(caches.open(CACHE).then(c=>c.addAll(CORE)))});
self.addEventListener("activate",e=>{e.waitUntil((async()=>{const keys=await caches.keys();await Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)));await self.clients.claim()})())});
async function cached(req,{allowVersionFallback=true}={}){
  const cache=await caches.open(CACHE);
  return (await cache.match(req))||(allowVersionFallback?await cache.match(req,{ignoreSearch:true}):null);
}
async function remember(req,response){if(response&&response.ok){const copy=response.clone();caches.open(CACHE).then(c=>c.put(req,copy)).catch(()=>{})}return response}
self.addEventListener("fetch",e=>{
  if(e.request.method!=="GET")return;
  const u=new URL(e.request.url);

  // Translation and other external API calls must NEVER be served from the PWA cache.
  // v0.27.3 used ignoreSearch fallback for generic GETs; for Google Translate this
  // collapsed different q/tl query strings onto the first cached /translate_a/single
  // response and caused unrelated UI labels to receive the same translation.
  if(u.hostname==="translate.googleapis.com"){
    e.respondWith(fetch(e.request,{cache:"no-store"}));
    return;
  }
  const isSdk=u.hostname==="cdn.jsdelivr.net"&&u.pathname.includes("@supabase/supabase-js");
  if(isSdk){e.respondWith((async()=>{const hit=await cached(e.request);if(hit)return hit;return remember(e.request,await fetch(e.request))})());return}
  const isScientificImage=e.request.destination==="image"&&(u.hostname.endsWith("wikimedia.org")||u.hostname.endsWith("wikipedia.org"));
  if(isScientificImage){e.respondWith((async()=>{const hit=await cached(e.request);if(hit)return hit;try{const res=await fetch(e.request,{mode:"no-cors"});const cache=await caches.open(CACHE);await cache.put(e.request,res.clone());return res}catch{return hit||Response.error()}})());return}
  // Do not let generic cross-origin requests fall into the same-origin cache logic.
  // Explicitly handled CDN/images above are the only cross-origin resources cached.
  if(u.origin!==self.location.origin){
    e.respondWith(fetch(e.request,{cache:"no-store"}));
    return;
  }
  const sameOriginImage=e.request.destination==="image";
  if(sameOriginImage){
    e.respondWith((async()=>{
      try{return remember(e.request,await fetch(e.request,{cache:"no-store"}))}
      catch{
        const hit=await cached(e.request,{allowVersionFallback:false});
        return hit||Response.error();
      }
    })());
    return;
  }
  const code=/\.(?:js|json)$/.test(u.pathname)||u.pathname.endsWith("/index.html")||u.pathname.endsWith("/");
  if(code){e.respondWith((async()=>{
    try{return remember(e.request,await fetch(e.request,{cache:"no-store"}))}
    catch{
      // Fallback is restricted to THIS release cache. Old release caches are never searched.
      const hit=await cached(e.request,{allowVersionFallback:true});
      if(hit)return hit;
      const cache=await caches.open(CACHE);
      return (await cache.match("./index.html"))||Response.error();
    }
  })());return}
  e.respondWith((async()=>{const hit=await cached(e.request);if(hit)return hit;try{return remember(e.request,await fetch(e.request))}catch{return Response.error()}})());
});

// v0.18 Web Push support. A push payload should be JSON:
// {"title":"Новая заявка ProPharm","body":"...","url":"#admin"}
self.addEventListener('push',event=>{
  let data={};
  try{data=event.data?event.data.json():{}}catch{data={body:event.data?.text?.()||''}}
  const title=data.title||'Новая заявка ProPharm';
  const options={
    body:data.body||'Новый пользователь ожидает подтверждения.',
    icon:'./icons/icon-192.png',
    badge:'./icons/icon-192.png',
    tag:data.tag||'propharm-admin-application',
    data:{url:data.url||'#admin'}
  };
  event.waitUntil(self.registration.showNotification(title,options));
});
self.addEventListener('notificationclick',event=>{
  event.notification.close();
  const target=event.notification.data?.url||'#admin';
  event.waitUntil((async()=>{
    const all=await clients.matchAll({type:'window',includeUncontrolled:true});
    for(const c of all){
      try{await c.focus();c.postMessage({type:'PROPHARM_NOTIFICATION_OPEN',url:target});return;}catch{}
    }
    await clients.openWindow(`./${target}`);
  })());
});
