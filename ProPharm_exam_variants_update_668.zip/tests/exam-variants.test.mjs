import test from 'node:test';
import assert from 'node:assert/strict';
import {keys,validateVariants,createRun,choose,finish,retry,summary,restore,storageKey,activeAttempt} from '../src/questions/exam-variants.js';
const q=(id,k)=>({id,question:id,options:['a','b','c'].map(id=>({id,text:id})),correctOptionIds:k});
const v={id:'one',questions:[q('wrong',['b']),q('multi',['a','c']),q('missing',[]),q('skipped',['a'])]};
test('first mistake survives correction, duplicate clicks and reload; retry is separate',()=>{
 let r=createRun(v,'one');r=choose(r,v,'wrong','a');r=choose(r,v,'wrong','a');r=choose(r,v,'wrong','b');r=choose(r,v,'multi','c');r=choose(r,v,'missing','a');
 r=restore(JSON.stringify(r),v);assert.deepEqual(summary(r.original,v),{correct:1,wrong:1,skipped:1,unscored:1,wrongIds:['wrong']});
 r=finish(r);const original=JSON.stringify(r.original);assert.deepEqual(choose(r,v,'wrong','c'),r);
 r=retry(r,v,'retry');assert.deepEqual(activeAttempt(r).ids,['wrong']);assert.deepEqual(retry(r,v,'duplicate'),r);
 r=choose(r,v,'wrong','b');r=finish(r);assert.equal(summary(activeAttempt(r),v).correct,1);assert.equal(JSON.stringify(r.original),original);
 assert.deepEqual(restore(JSON.stringify(r),v),r);assert.equal(createRun(v,'new').retries.length,0);
});
test('variants/users isolated, changed keys invalidate drafts and empty array is authoritative',()=>{
 const w={...v,id:'two'};assert.notEqual(storageKey('u',v),storageKey('u',w));assert.notEqual(storageKey('u',v),storageKey('z',v));
 const r=createRun(v,'x');assert.throws(()=>restore(JSON.stringify(r),w));assert.throws(()=>restore(JSON.stringify(r),{...v,questions:[q('wrong',['a'])]}));
 assert.deepEqual(keys({correctOptionIds:[],correctOptionId:'a'}),[]);
 assert.throws(()=>validateVariants({variants:[{id:'x',questions:[q('x',['bad'])]}]}));
});
import fs from 'node:fs';
test('six imported variants validate; all asset bytes and protected build data exist',()=>{
 const data=JSON.parse(fs.readFileSync('content/catalog.json')).EXAM_VARIANTS;validateVariants(data);
 assert.deepEqual(data.variants.map(v=>v.questions.length),[141,109,120,120,120,58]);
 assert.equal(data.variants.flatMap(v=>v.questions).reduce((n,q)=>n+q.options.length,0),3276);
 for(const v of data.variants)for(const q of v.questions)for(const a of q.assets||[])assert.ok(fs.existsSync(a.path));
});
import crypto from 'node:crypto';
test('reviewed keys: 606 graded, 62 excluded, all 23 multi-key questions accept every alternative',()=>{
 const data=JSON.parse(fs.readFileSync('content/catalog.json')).EXAM_VARIANTS;
 assert.equal(data.status,'verified');const all=data.variants.flatMap(v=>v.questions);
 assert.equal(all.filter(q=>keys(q).length).length,606);assert.equal(all.filter(q=>!keys(q).length).length,62);
 assert.equal(all.filter(q=>keys(q).length>1).length,23);
 for(const v of data.variants)for(const q of v.questions){
  for(const key of keys(q)){const run=choose(createRun(v,'key-check'),v,q.id,key);assert.equal(summary(run.original,v).correct,1,q.id+':'+key);assert.equal(summary(run.original,v).wrong,0);}
  if(!keys(q).length)assert.ok(q.unscoredReason.length>20,q.id);
  for(const asset of q.assets||[])assert.equal(crypto.createHash('sha256').update(fs.readFileSync(asset.path)).digest('hex'),asset.sha256);
 }
 const blank=all.find(q=>q.id==='test-14-q071');assert.deepEqual(blank.options,[]);assert.deepEqual(keys(blank),[]);assert.match(blank.unscoredReason,/вариантов ответа нет/);
 const notices=all.filter(q=>q.notices?.includes('Перевод уточнён по оригиналу'));assert.deepEqual(notices.map(q=>q.id),['test-15-q017','test-15-q105']);
 for(const q of notices)assert.ok(q.source.translationRepair.changes.length);
});
