#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
node scripts/build.mjs
node scripts/verify-build.mjs
node scripts/preview-test.mjs
cd ../qa-preview
printf 'Локальная проверка: http://127.0.0.1:8767/#tests/exam-variants\n'
exec python3 -m http.server 8767 --bind 127.0.0.1
