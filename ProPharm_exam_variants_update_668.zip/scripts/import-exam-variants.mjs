// Import a locally materialized, reviewed archive directory. No network or backend writes.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {validateVariants} from '../src/questions/exam-variants.js';
const source=path.resolve(process.argv[2]||'');
if(!process.argv[2])throw new Error('Usage: node scripts/import-exam-variants.mjs /absolute/unpacked-directory [intermediate|verified]');
const status=process.argv[3]||'intermediate';
if(!['intermediate','verified'].includes(status))throw new Error('Unknown status');
const data=JSON.parse(fs.readFileSync(path.join(source,'exam-data.json'),'utf8'));
if(!Array.isArray(data.exams)||data.exams.length!==6)throw new Error('Expected six exams');
const pending=[];
const variants=data.exams.map(exam=>({...exam,questions:exam.questions.map(q=>{
 const assets=(q.assets||[]).map(a=>{
  if(path.isAbsolute(a.path)||a.path.split(/[\\/]/).includes('..'))throw new Error('Unsafe asset path');
  const file=path.resolve(source,a.path),bytes=fs.readFileSync(file);
  if(a.sha256&&crypto.createHash('sha256').update(bytes).digest('hex')!==a.sha256)throw new Error('Asset checksum mismatch: '+a.path);
  const destination='assets/exam-variants/'+path.basename(file);pending.push({destination,bytes});return {...a,path:destination};
 });
 return {...q,question:q.stem??q.question,correctOptionIds:Object.hasOwn(q,'correctOptionIds')?(q.correctOptionIds||[]):(q.correctOptionId?[q.correctOptionId]:[]),unscoredReason:q.unscoredReason||q.gradingExplanation||q.source?.gradingEvidence?.reason||'Ключ этого вопроса пока не подтверждён; вопрос исключён из оценки.',assets};
})}));
validateVariants({variants});
if(variants[0].questions.length!==141)throw new Error('Expected 141 questions in first exam');
const cat=JSON.parse(fs.readFileSync('content/catalog.json','utf8'));cat.EXAM_VARIANTS={status,variants};
fs.mkdirSync('assets/exam-variants',{recursive:true});for(const a of pending)fs.writeFileSync(a.destination,a.bytes);
fs.writeFileSync('content/catalog.json',JSON.stringify(cat,null,2));
console.log(JSON.stringify({status,variants:variants.length,questions:variants.reduce((n,v)=>n+v.questions.length,0),unscored:variants.flatMap(v=>v.questions).filter(q=>!q.correctOptionIds.length).length,assets:pending.length}));
