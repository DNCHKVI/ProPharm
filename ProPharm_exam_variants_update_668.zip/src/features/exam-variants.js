import {resolveAsset} from '../core/content-service.js';
import {app,esc} from '../core/shared.js';
import {header,bottomNav,bindNav} from '../ui/shell.js';
import {authState} from '../../services/authService.js';
import {EXAM_VARIANTS} from '../core/content.js';
import {keys,createRun,activeAttempt,choose,summary,finish,retry,storageKey,restore} from '../questions/exam-variants.js';
export function renderExamVariants(id){
 const uid=authState.user?.id,route=location.hash,v=EXAM_VARIANTS.variants.find(v=>v.id===id);
 const allowed=()=>uid&&uid===authState.user?.id&&authState.profile?.status==='approved'&&location.hash===route;
 if(!allowed())return;
 let drawEpoch=0;
 const wrap=body=>{app.innerHTML=header()+'<div class="page testsPage">'+body+'</div>'+bottomNav('study');bindNav();};
 const back='<a class="moduleButton secondary" href="#tests/exam-variants">Все варианты</a>';
 if(!v){wrap('<h1>Экзаменационные варианты</h1><p>Первая попытка определяет результат. Исправление ответа не отменяет первоначальную ошибку.</p>'+ (EXAM_VARIANTS.status==='intermediate'?'<p class="sourceNote">Промежуточные данные: проверка полного ключа продолжается.</p>':EXAM_VARIANTS.status==='pending'?'<p class="sourceNote">Импорт ожидается. Вопросы и подтверждённые ключи ещё не загружены.</p>':'')+'<div class="sectionGrid">'+EXAM_VARIANTS.variants.map(x=>`<a class="card" href="#tests/exam-variants/${esc(x.id)}"><h2>${esc(x.title)}</h2><p>${x.questions.length?x.questions.length+' вопросов':'Ожидается импорт'}</p></a>`).join('')+'</div><a href="#tests">Все тесты</a>');return;}
 if(!v.questions.length){wrap(back+`<h1>${esc(v.title)}</h1><p>Вопросы ожидают проверенного импорта.</p>`);return;}
 const key=storageKey(uid,v);let run,error='',savedRaw=null;
 try{const raw=localStorage.getItem(key);savedRaw=raw;run=raw?restore(raw,v):createRun(v,crypto.randomUUID());}catch(e){error=e.message;}
 const persist=next=>{if(!allowed())return false;try{if(localStorage.getItem(key)!==savedRaw)throw new Error('Прохождение изменено в другой вкладке. Перезагрузите страницу.');const serialized=JSON.stringify(next);localStorage.setItem(key,serialized);savedRaw=serialized;run=next;return true;}catch(e){const el=document.getElementById('examStatus');if(el)el.textContent='Изменение не сохранено. '+e.message;return false;}};
 const counts=a=>{const s=summary(a,v);return `<p>Правильных: <b>${s.correct}</b> · Неправильных: <b>${s.wrong}</b> · Пропущенных с ключом: <b>${s.skipped}</b> · Без подтверждённого ключа: <b>${s.unscored}</b></p>`;};
 function draw(){
  if(!allowed())return;
  const drawing=++drawEpoch;
  if(!run){wrap(back+`<h1>${esc(v.title)}</h1><p role="alert">${esc(error)}. Прежнее сохранение не изменено.</p><button class="moduleButton" id="examNew">Начать новое прохождение</button><p id="examStatus" role="alert"></p>`);}
  else{const a=activeAttempt(run);wrap(back+`<h1>${esc(v.title)}</h1><p>${run.active?'Повтор ошибок № '+run.active:'Первоначальное прохождение'}. Оценивается первый выбор. Вопросы без ключа не считаются ошибками.</p><p id="examStatus" role="status" aria-live="polite"></p>`+(run.active?'<section class="card"><h2>Первоначальный результат</h2>'+counts(run.original)+'</section>':'')+(a.finished?'<section class="card"><h2>Результат '+(run.active?'повтора':'прохождения')+'</h2>'+counts(a)+'</section>':'')+a.ids.map((qid,i)=>{const q=v.questions.find(q=>q.id===qid),x=a.answers[qid];return `<article class="card" data-exam-question="${esc(qid)}"><h2 style="white-space:pre-wrap">${q.number||i+1}. ${esc(q.question)}</h2>${(q.notices||[]).map(notice=>`<p class="sourceNote">${esc(notice)}</p>`).join('')}${(q.assets||[]).map(asset=>`<figure><img data-exam-image="${esc(asset.path)}" alt="${esc(asset.alt||'Рисунок к вопросу')}" style="background:#fff;max-width:100%;height:auto;padding:12px;border-radius:12px"><figcaption>${esc(asset.alt||'Рисунок к вопросу')}</figcaption></figure>`).join('')}${q.options.map(o=>{const selected=x?.current===o.id;const cls=selected?(keys(q).length?(keys(q).includes(o.id)?'correctAnswer':'wrongAnswer'):'selectedAnswer'):'';return `<button class="quizOption ${cls}" style="display:block;width:100%;text-align:left;margin:8px 0" data-exam-answer="${esc(o.id)}" aria-pressed="${selected}" ${a.finished?'disabled':''}>${esc(o.label||o.id)}. ${esc(o.text)}${selected?' · '+(keys(q).length?(keys(q).includes(o.id)?'Верно':'Неверно'):'Без оценки'):''}</button>`}).join('')}<p role="status" aria-live="polite">${x?'Первый ответ: '+esc(q.options.find(o=>o.id===x.first)?.label||x.first)+(keys(q).length?(keys(q).includes(x.first)?' — верно':' — ошибка сохранена'):' — без оценки'):''}</p>${!keys(q).length?'<p class="sourceNote">Нет подтверждённого ключа. '+esc(q.unscoredReason||'Вопрос не оценивается.')+'</p>':''}</article>`}).join('')+`<div class="quizActions">${!a.finished?'<button class="moduleButton" id="examFinish">Завершить прохождение</button>':summary(run.original,v).wrong?' <button class="moduleButton" id="examRetry">Повторить первоначальные ошибки</button>':''}<button class="moduleButton secondary" id="examNew">Начать новое прохождение</button></div>`);
  app.querySelectorAll('[data-exam-image]').forEach(async img=>{try{const url=await resolveAsset(img.dataset.examImage);if(allowed()&&drawEpoch===drawing&&img.isConnected)img.src=url;}catch{if(img.isConnected)img.alt+=' — не удалось загрузить изображение';}});
  app.querySelectorAll('[data-exam-answer]').forEach(b=>b.onclick=()=>{const y=scrollY,qid=b.closest('[data-exam-question]').dataset.examQuestion,oid=b.dataset.examAnswer;if(persist(choose(run,v,qid,oid))){draw();const card=[...app.querySelectorAll('[data-exam-question]')].find(el=>el.dataset.examQuestion===qid);const button=[...(card?.querySelectorAll('[data-exam-answer]')||[])].find(el=>el.dataset.examAnswer===oid);button?.focus({preventScroll:true});scrollTo(0,y);}});
  document.getElementById('examFinish')?.addEventListener('click',()=>{if(persist(finish(run))){draw();scrollTo(0,0);}});
  document.getElementById('examRetry')?.addEventListener('click',()=>{if(persist(retry(run,v,crypto.randomUUID()))){draw();scrollTo(0,0);}});
  }
  document.getElementById('examNew').onclick=()=>{if(confirm('Начать заново? Сохранённое прохождение и его повторы будут заменены.'))if(persist(createRun(v,crypto.randomUUID()))){draw();scrollTo(0,0);}};
 }
 draw();
}
