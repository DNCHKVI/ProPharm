// Awaiting verified archive. Never substitute fixture questions for real exam content.
export const EXAM_VARIANTS={status:'pending',variants:[
 {id:'first-141',title:'Первый тест — 141 вопрос',expectedCount:141,questions:[]},
 ...[13,14,15,16,17].map(n=>({id:'test-'+n,title:'Тест '+n,questions:[]}))
]};
