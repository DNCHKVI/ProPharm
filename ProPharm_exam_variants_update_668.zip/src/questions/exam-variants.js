// Independent local attempts; no writes to the existing progress/backend.
export function keys(q) {
 const value=q.correctOptionIds;
 return Object.hasOwn(q,'correctOptionIds')?(Array.isArray(value)?value:[]):(q.correctOptionId?[q.correctOptionId]:[]);
}
export function validateVariants(data){
 if(!Array.isArray(data.variants))throw new Error('Нет массива variants');
 const ids=new Set();
 for(const v of data.variants){
  if(!v.id||ids.has(v.id)||!Array.isArray(v.questions))throw new Error('Некорректный вариант');ids.add(v.id);
  const qs=new Set();for(const q of v.questions){
   if(!q.id||qs.has(q.id)||typeof q.question!=='string'||!q.question.trim()||!Array.isArray(q.options)||(q.options.length<2&&keys(q).length>0)||(q.correctOptionIds!=null&&!Array.isArray(q.correctOptionIds)))throw new Error('Некорректный вопрос');qs.add(q.id);
   const os=q.options.map(o=>o.id);if(new Set(os).size!==os.length||os.some(id=>typeof id!=='string'||!id)||q.options.some(o=>typeof o.text!=='string'||!o.text.trim())||keys(q).some(id=>!os.includes(id)))throw new Error('Некорректные варианты или ключ');
  }
 }
 return data;
}
export function fingerprint(v){return JSON.stringify(v.questions.map(q=>[q.id,q.question,q.options,keys(q)]));}
export function createAttempt(ids,id){return {id,ids:[...ids],answers:{},finished:false};}
export function createRun(v,id){return {version:1,variantId:v.id,fingerprint:fingerprint(v),original:createAttempt(v.questions.map(q=>q.id),id),retries:[],active:0};}
export function activeAttempt(run){return run.active===0?run.original:run.retries[run.active-1];}
export function choose(run,v,qid,optionId){
 const next=JSON.parse(JSON.stringify(run)),a=activeAttempt(next),q=v.questions.find(q=>q.id===qid);
 if(!q||!a.ids.includes(qid)||!q.options.some(o=>o.id===optionId))throw new Error('Неизвестный ответ');
 if(a.finished)return run;
 const old=a.answers[qid];a.answers[qid]={first:old?old.first:optionId,current:optionId};return next;
}
export function summary(a,v){
 const r={correct:0,wrong:0,skipped:0,unscored:0,wrongIds:[]};
 for(const id of a.ids){const q=v.questions.find(q=>q.id===id),answer=a.answers[id];
  if(!keys(q).length){r.unscored++;continue;}
  if(!answer){r.skipped++;continue;}
  if(keys(q).includes(answer.first))r.correct++;else{r.wrong++;r.wrongIds.push(id);}
 }return r;
}
export function finish(run){const n=JSON.parse(JSON.stringify(run));activeAttempt(n).finished=true;return n;}
export function retry(run,v,id){
 if(!activeAttempt(run).finished)return run;
 const ids=summary(run.original,v).wrongIds;if(!ids.length)return run;
 const n=JSON.parse(JSON.stringify(run));n.retries.push(createAttempt(ids,id));n.active=n.retries.length;return n;
}
export function storageKey(uid,v){return 'propharm:exam-variants:v1:'+encodeURIComponent(uid)+':'+encodeURIComponent(v.id);}
export function restore(raw,v){
 const r=JSON.parse(raw);if(r.version!==1||r.variantId!==v.id||r.fingerprint!==fingerprint(v)||!Array.isArray(r.retries)||!Number.isInteger(r.active)||r.active<0||r.active>r.retries.length)throw new Error('Состав варианта изменился или сохранение повреждено');
 const all=v.questions.map(q=>q.id);
 for(const a of [r.original,...r.retries]){
  if(!a||!Array.isArray(a.ids)||new Set(a.ids).size!==a.ids.length||a.ids.some(id=>!all.includes(id))||typeof a.finished!=='boolean'||!a.answers)throw new Error('Повреждённая попытка');
  for(const [id,x] of Object.entries(a.answers)){const q=v.questions.find(q=>q.id===id);if(!a.ids.includes(id)||!q.options.some(o=>o.id===x.first)||!q.options.some(o=>o.id===x.current))throw new Error('Повреждённый ответ');}
 }
 if(JSON.stringify(r.original.ids)!==JSON.stringify(all)||r.retries.some(a=>JSON.stringify(a.ids)!==JSON.stringify(summary(r.original,v).wrongIds)))throw new Error('Повреждённый состав попытки');
 return r;
}
