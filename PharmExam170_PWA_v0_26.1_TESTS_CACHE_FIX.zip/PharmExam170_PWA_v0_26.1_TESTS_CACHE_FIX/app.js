import { SUPABASE_CONFIG } from "./config/supabase-config.js?v=0.24.2";
import { TOPICS } from "./data/topics.js?v=0.24.2";
import { DRUGS } from "./data/drugs.js?v=0.24.2";
import { ABBREVIATIONS } from "./data/abbreviations.js?v=0.24.2";
import { THEORY } from "./data/theory.js?v=0.24.2";
import { ACADEMIC_SOURCES } from "./data/academicSources.js?v=0.24.2";
import { MECHANISMS } from "./data/mechanisms.js?v=0.24.2";
import { HIGH_YIELD } from "./data/highYield.js?v=0.24.2";
import { TESTS as BASE_TESTS } from "./data/tests.js?v=0.24.2";
import { CHEMISTRY_EXAM_TESTS } from "./data/chemistryExamTest.js?v=0.25.0";
import { BIOCHEMISTRY_EXAM_TESTS } from "./data/biochemistryExamTest.js?v=0.25.7";
import { ANALYTICAL_METHODS_EXAM_TESTS } from "./data/analyticalMethodsExamTest.js?v=0.25.8";
import { PHARM_TECH_EXAM_TESTS } from "./data/pharmTechExamTest.js?v=0.26.1";
import { ENDOCRINOLOGY_EXAM_TESTS } from "./data/endocrinologyExamTest.js?v=0.26.1";
import { TEST_ANALYSES as BASE_TEST_ANALYSES } from "./data/testAnalyses.js?v=0.24.2";
import { SOURCE_SECTIONS } from "./data/sourceSections.js?v=0.24.2";
import { INTERACTIONS } from "./data/interactions.js?v=0.24.2";
import { DRUG_KNOWLEDGE } from "./data/drugKnowledge.js?v=0.24.2";
import { DRUG_PROFILES } from "./data/drugProfiles.js?v=0.24.2";
import { SECTION_VISUALS } from "./data/sectionVisuals.js?v=0.24.2";
import { CARDIO49 } from "./data/cardio49.js?v=0.24.2";
import { STUDY_TABLES } from "./data/studyTables.js?v=0.24.2";
import { SYSTEMS, SYSTEM_SECTION_ORDER } from "./data/systems.js?v=0.24.2";
import { FOUNDATIONAL_SECTIONS } from "./data/foundationalSections.js?v=0.24.2";
import { CHEMISTRY_CONTENT } from "./data/chemistryContent.js?v=0.24.2";
import { ADVANCED_FOUNDATION_CONTENT } from "./data/foundationAdvancedContent.js?v=0.24.2";
import { GENERAL_CHEMISTRY_V242 } from "./data/generalChemistryV242.js?v=0.24.2";
import { PHARMACOLOGY_FOUNDATIONS, DIURETIC_GROUPS } from "./data/pharmacologyFoundations.js?v=0.24.2";
import { PERIODIC_ELEMENTS, LANTHANIDES, ACTINIDES, AB_GROUP_LABELS, SOLUBILITY_CATIONS, SOLUBILITY_ANIONS, SOLUBILITY_MATRIX, QUALITATIVE_REACTIONS, FLAME_TESTS, ORGANIC_QUALITATIVE } from "./data/chemistryTools.js?v=0.24.2";
import { TEST_NAV_STRUCTURE } from "./data/testNav.js?v=0.26.1";
import { DISEASES } from "./data/diseases.js?v=0.24.2";
import { GLOSSARY_EXTRAS } from "./data/glossaryExtras.js?v=0.24.2";
import { CARDIO_GLOSSARY, CARDIO_PHYSIOLOGY, CARDIO_BIOCHEMISTRY, CARDIO_PATHOLOGIES, CARDIO_TARGETS, CARDIO_DIAGNOSTICS, CARDIO_FLASHCARDS, CARDIO_EXTRA_TESTS, CARDIO_EXTRA_ANALYSES } from "./data/cardioIntegrated.js?v=0.24.2";
import { VISUAL_SOURCES, VISUAL_SOURCE_GROUPS } from "./data/visualSources.js?v=0.24.2";
import { SCIENTIFIC_VISUALS, WHITEBOARD_SOURCE_MAP } from "./data/scientificVisuals.js?v=0.24.2";
import { PAST_EXAM_QUESTIONS, PAST_EXAM_SECTIONS, PAST_EXAM_SOURCES } from "./data/pastExamQuestions.js?v=0.24.2";
import { trainerStats, trainerProgress, recordTrainerAnswer } from "./services/memoryTrainerData.js?v=0.24.2";
import { authState, initAuth, onAuthState, isAuthConfigured, isAdmin, signInWithPassword, signUpWithPassword, signOut, resetPassword, updatePassword, updateOwnProfile, listUsersForAdmin, adminPendingCount, listAdminNotifications, markAdminNotificationsRead, subscribeAdminApplications, savePushSubscription, deletePushSubscription, adminSetStatus, refreshProfile } from "./services/authService.js?v=0.25.9";
import { saveTestSession, recordQuestionResult, toggleFavorite, isFavorite, listFavorites, setReview, removeReview, listReview, getLearningStats, lastStudyRoute, recordStudyPosition, saveUserSettings, loadUserSettings, hydrateFromCloud, syncPending } from "./services/userData.js?v=0.24.2";

const TESTS=[...BASE_TESTS,...CHEMISTRY_EXAM_TESTS,...BIOCHEMISTRY_EXAM_TESTS,...ANALYTICAL_METHODS_EXAM_TESTS,...PHARM_TECH_EXAM_TESTS,...ENDOCRINOLOGY_EXAM_TESTS,...CARDIO_EXTRA_TESTS,...PAST_EXAM_QUESTIONS];
const TEST_ANALYSES=[...BASE_TEST_ANALYSES,...CARDIO_EXTRA_ANALYSES];
const ALL_SOURCE_SECTIONS=[...SOURCE_SECTIONS,...PAST_EXAM_SECTIONS];
const foundationContent = (id)=> id==='general-chemistry' ? GENERAL_CHEMISTRY_V242 : (ADVANCED_FOUNDATION_CONTENT[id]||[]);

const app = document.getElementById("app");
const topicMap = Object.fromEntries(TOPICS.map(t => [t.id,t]));
const drugMap = Object.fromEntries(DRUGS.map(d => [String(d.n),d]));
const systemMap = Object.fromEntries(SYSTEMS.map(s=>[s.id,s]));
const diseaseMap = Object.fromEntries(DISEASES.map(d=>[d.id,d]));
const foundationalMap = Object.fromEntries(FOUNDATIONAL_SECTIONS.map(x=>[x.id,x]));
const esc = s => String(s ?? "").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));
const UI_SETTINGS_KEY="propharm_ui_settings_v1";
let uiSettings=Object.assign({largeText:false,reducedMotion:false},JSON.parse(localStorage.getItem(UI_SETTINGS_KEY)||"{}"));
function applyUiSettings(){document.documentElement.classList.toggle("largeText",!!uiSettings.largeText);document.documentElement.classList.toggle("reducedMotion",!!uiSettings.reducedMotion);}
applyUiSettings();

// ----- Admin applications & notifications -----
let adminPendingTotal=0;
let stopAdminApplications=null;
const ADMIN_NOTIFICATION_KEY="propharm_admin_notifications_enabled_v1";
function notificationPermission(){return typeof Notification!=="undefined"?Notification.permission:"unsupported"}
function canUseWebPush(){return !!(navigator.serviceWorker&&window.PushManager&&typeof Notification!=="undefined")}
function urlBase64ToUint8Array(base64String){
  const padding='='.repeat((4-base64String.length%4)%4),base64=(base64String+padding).replace(/-/g,'+').replace(/_/g,'/');
  const raw=atob(base64),arr=new Uint8Array(raw.length);for(let i=0;i<raw.length;i++)arr[i]=raw.charCodeAt(i);return arr;
}
async function setAdminAppBadge(count=adminPendingTotal){
  try{if('setAppBadge' in navigator){if(count>0)await navigator.setAppBadge(count);else if('clearAppBadge' in navigator)await navigator.clearAppBadge();}}catch{}
}
async function showAdminApplicationNotification(row={}){
  if(notificationPermission()!=="granted")return;
  const title="Новая заявка ProPharm";
  const body=row.title||row.message||"Новый пользователь ожидает подтверждения.";
  const options={body,icon:"./icons/icon-192.png",badge:"./icons/icon-192.png",tag:`propharm-application-${row.target_user_id||row.id||Date.now()}`,data:{url:"#admin"}};
  try{
    const reg=await navigator.serviceWorker?.ready;
    if(reg?.showNotification)await reg.showNotification(title,options);
    else if(typeof Notification!=="undefined")new Notification(title,options);
  }catch(e){console.warn("Notification failed",e)}
}
async function requestAdminNotifications(){
  if(!isAdmin())throw new Error("Уведомления доступны только администратору");
  if(typeof Notification==="undefined")throw new Error("Этот браузер не поддерживает системные уведомления");
  const permission=await Notification.requestPermission();
  if(permission!=="granted")throw new Error("Разрешение на уведомления не предоставлено");
  localStorage.setItem(ADMIN_NOTIFICATION_KEY,"1");
  // Real Web Push when the PWA is completely closed is optional and requires a VAPID public key.
  const vapid=SUPABASE_CONFIG.notifications?.vapidPublicKey?.trim();
  if(vapid&&canUseWebPush()){
    const reg=await navigator.serviceWorker.ready;
    let sub=await reg.pushManager.getSubscription();
    if(!sub)sub=await reg.pushManager.subscribe({userVisibleOnly:true,applicationServerKey:urlBase64ToUint8Array(vapid)});
    await savePushSubscription(sub);
  }
  return permission;
}
async function disableAdminNotifications(){
  localStorage.removeItem(ADMIN_NOTIFICATION_KEY);
  try{const reg=await navigator.serviceWorker?.ready,sub=await reg?.pushManager?.getSubscription();if(sub){await deletePushSubscription(sub.endpoint);await sub.unsubscribe();}}catch{}
}
async function refreshAdminPendingCount(){
  if(!isAdmin()){adminPendingTotal=0;await setAdminAppBadge(0);return 0;}
  try{adminPendingTotal=await adminPendingCount();await setAdminAppBadge(adminPendingTotal);return adminPendingTotal}catch(e){console.warn("pending count",e);return adminPendingTotal}
}
async function startAdminApplicationWatcher(){
  if(stopAdminApplications){try{await stopAdminApplications()}catch{} stopAdminApplications=null;}
  if(!isAdmin())return;
  await refreshAdminPendingCount();
  stopAdminApplications=await subscribeAdminApplications(async row=>{
    await refreshAdminPendingCount();
    toast(`Новая заявка${row.email?`: ${row.email}`:""}`);
    if(localStorage.getItem(ADMIN_NOTIFICATION_KEY)==="1")await showAdminApplicationNotification(row);
    if(location.hash==="#admin")renderAdmin();
  });
}

function authBadge(){
  if(!isAuthConfigured())return `<span class="modeBadge">Аккаунты не настроены</span>`;
  const p=authState.profile;if(!p)return "";
  return `<span class="modeBadge ${p.role==='admin'?'admin':'user'}">${p.role==='admin'?'Администратор':'Профиль'}</span>`;
}
function toast(message,type="ok"){
  const old=document.querySelector('.toastMessage');if(old)old.remove();
  const el=document.createElement('div');el.className=`toastMessage ${type}`;el.textContent=message;document.body.appendChild(el);setTimeout(()=>el.classList.add('show'),20);setTimeout(()=>{el.classList.remove('show');setTimeout(()=>el.remove(),250)},2200);
}
function favoriteButton(type,id,label="Избранное"){
  return `<button class="miniAction favoriteAction" data-favorite-type="${esc(type)}" data-favorite-id="${esc(id)}" aria-label="${esc(label)}"><span>♡</span><small>${esc(label)}</small></button>`;
}
function reviewButton(type,id,label="Повторить"){
  return `<button class="miniAction reviewAction" data-review-type="${esc(type)}" data-review-id="${esc(id)}" aria-label="${esc(label)}"><span>↻</span><small>${esc(label)}</small></button>`;
}
async function bindPersonalActions(root=document){
  root.querySelectorAll('[data-favorite-type]').forEach(async b=>{
    const type=b.dataset.favoriteType,id=b.dataset.favoriteId;
    try{if(await isFavorite(type,id)){b.classList.add('active');const s=b.querySelector('span');if(s)s.textContent='♥'}}catch{}
    b.onclick=async e=>{e.preventDefault();e.stopPropagation();try{const on=await toggleFavorite(type,id);b.classList.toggle('active',on);const sp=b.querySelector('span');if(sp)sp.textContent=on?'♥':'♡';toast(on?'Добавлено в избранное':'Удалено из избранного')}catch(err){toast(err.message||String(err),'bad')}};
  });
  root.querySelectorAll('[data-review-type]').forEach(b=>{
    b.onclick=async e=>{e.preventDefault();e.stopPropagation();try{await setReview(b.dataset.reviewType,b.dataset.reviewId,{reason:'manual',priority:2});b.classList.add('active');toast('Добавлено в «Повторить»')}catch(err){toast(err.message||String(err),'bad')}};
  });
}
function inferProgressFromRoute(parts){
  if(parts[0]==='system')return {system_id:parts[1]||null,section_id:parts[2]||'overview',entity_id:null,route:location.hash};
  if(parts[0]==='drug')return {system_id:null,section_id:'drug',entity_id:parts[1],route:location.hash};
  if(parts[0]==='disease'||parts[0]==='cardio-pathology')return {system_id:parts[0]==='cardio-pathology'?'cardiovascular':null,section_id:'disease',entity_id:parts[1],route:location.hash};
  if(parts[0]==='mechanism')return {system_id:null,section_id:'mechanism',entity_id:parts[1],route:location.hash};
  return {system_id:null,section_id:parts[0]||'home',entity_id:null,route:location.hash};
}
function resolvePersonalEntity(type,id){
  if(type==='drug'){const d=drugMap[String(id)];return d?{title:d.name,subtitle:d.group,route:`#drug/${d.n}`}:null}
  if(type==='disease'){const d=diseaseMap[id];return d?{title:d.title,subtitle:systemMap[d.systemId]?.title||'Заболевание',route:`#disease/${id}`}:null}
  if(type==='cardio-pathology'){const d=CARDIO_PATHOLOGIES.find(x=>x.id===id);return d?{title:d.title,subtitle:'Сердечно-сосудистая система',route:`#cardio-pathology/${id}`}:null}
  if(type==='mechanism'){const m=allCanonicalMechanisms().find(x=>x.id===id);return m?{title:m.title,subtitle:systemMap[m.systemId]?.title||'Механизм',route:`#mechanism/${id}`}:null}
  if(type==='question'){const q=TESTS.find(x=>x.id===id);return q?{title:q.question,subtitle:q.sectionTitle||'Тестовый вопрос',route:'#tests'}:null}
  if(type==='system'){const x=systemMap[id];return x?{title:x.title,subtitle:'Система',route:`#system/${id}`}:null}
  if(type==='card'){const c=buildFlashCards().find(x=>x.id===id);return c?{title:c.title,subtitle:c.front,route:'#cards'}:null}
  return {title:`${type}: ${id}`,subtitle:'Сохранённый материал',route:'#study'};
}

function doodleIcon(type){
 const common=`viewBox="0 0 64 64" aria-hidden="true" focusable="false"`;
 const svg=(body)=>`<svg ${common} class="chalkSvg"><g fill="none" stroke="currentColor" stroke-width="3.4" stroke-linecap="round" stroke-linejoin="round">${body}</g></svg>`;
 const map={
  tests:svg(`<path d="M19 12h28a5 5 0 0 1 5 5v36H14V17a5 5 0 0 1 5-5Z"/><path d="M24 9h18v9H24z"/><path d="m21 28 3 3 6-7M21 40l3 3 6-7M35 28h10M35 40h10"/>`),
  theory:svg(`<path d="M8 17c9-5 18-4 25 1v35c-7-5-16-6-25-1V17Z"/><path d="M56 17c-9-5-18-4-23 1v35c7-5 14-6 23-1V17Z"/><path d="M15 27h11M15 35h11M40 27h10M40 35h10"/>`),
  tables:svg(`<rect x="9" y="11" width="46" height="42" rx="6"/><path d="M9 25h46M9 39h46M24 11v42M40 11v42"/>`),
  schemes:svg(`<rect x="25" y="8" width="14" height="12" rx="3"/><rect x="8" y="43" width="18" height="13" rx="4"/><rect x="38" y="43" width="18" height="13" rx="4"/><path d="M32 20v11M17 43v-8h30v8"/>`),
  cards:svg(`<path d="m16 17 31-5 5 30-31 5-5-30Z"/><rect x="11" y="24" width="38" height="28" rx="5"/><circle cx="28" cy="37" r="4"/><path d="M36 34h8M36 41h7"/>`),
  drugs:svg(`<path d="M15 41 39 17a10 10 0 0 1 14 14L29 55a10 10 0 0 1-14-14Z"/><path d="m27 29 15 15"/><path d="M18 45h8M38 19h8"/>`),
  abbr:svg(`<rect x="9" y="10" width="46" height="44" rx="8"/><path d="M17 44 25 21l8 23M20 36h10M40 23h8M40 33h8M40 43h6"/>`),
  settings:svg(`<circle cx="32" cy="32" r="9"/><path d="M32 8v7M32 49v7M8 32h7M49 32h7M15 15l5 5M44 44l5 5M49 15l-5 5M20 44l-5 5"/>`),
  search:svg(`<circle cx="27" cy="27" r="15"/><path d="m38 38 14 14"/>`),
  home:svg(`<path d="m10 30 22-18 22 18v24H39V40H25v14H10V30Z"/>`),
  study:svg(`<path d="M8 17c9-5 18-4 25 1v35c-7-5-16-6-25-1V17ZM56 17c-9-5-18-4-23 1v35c7-5 14-6 23-1V17Z"/>`),
  profile:svg(`<circle cx="32" cy="22" r="9"/><path d="M15 54c2-13 10-19 17-19s15 6 17 19"/>`),
  memory:svg(`<path d="M21 15c-7 2-10 10-6 16-4 5-1 12 6 13 3 6 10 5 12 0 7 2 13-5 9-11 5-6 1-15-7-15-2-6-10-7-14-3"/><path d="M31 18v29M22 27h9M31 37h9"/><path d="M47 13v9M43 17h9"/>`),
  interactions:svg(`<circle cx="20" cy="32" r="9"/><circle cx="44" cy="32" r="9"/><path d="M29 32h6M32 22v20"/>`),
  chemistry:svg(`<path d="M24 8v17L11 48a6 6 0 0 0 5 8h32a6 6 0 0 0 5-8L40 25V8"/><path d="M20 38h24M26 8h12"/>`),
  analytics:svg(`<circle cx="27" cy="26" r="13"/><path d="m37 36 14 14M18 26h18M27 17v18"/>`),
  kinetics:svg(`<path d="M9 51h46M13 47c8-26 16-34 24-22 7 10 9 16 15 4"/><path d="M17 14v10M12 19h10"/>`),
  law:svg(`<path d="M32 9v46M17 18h30M14 18l-8 16h16L14 18ZM50 18l-8 16h16L50 18ZM22 55h20"/>`),
  biology:svg(`<path d="M23 10c18 7 23 18 18 44M41 10C23 17 18 28 23 54"/><path d="M23 25h18M22 40h19"/>`),
  systems:svg(`<path d="M32 10c-5 0-8 5-8 10 0 4 2 7 4 9l-6 24M32 10c5 0 8 5 8 10 0 4-2 7-4 9l6 24M20 31h24M26 53h12"/>`)
 };
 return map[type]||map.study;
}
function homeDoodleIcon(type){
 const common=`viewBox="0 0 88 88" aria-hidden="true" focusable="false"`;
 const svg=(body)=>`<svg ${common} class="homeChalkSvg"><g class="homeChalkMain" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round">${body}</g><g class="homeChalkGhost" fill="none" stroke="currentColor" stroke-width="1.25" stroke-linecap="round" stroke-linejoin="round" opacity=".34" transform="translate(.8 -.6)">${body}</g></svg>`;
 const rays=`<path class="chalkRay" d="M11 44H4M18 19l-5-5M70 19l5-5M77 44h7"/>`;
 const map={
  theory:svg(`<path d="M44 12c-5 0-8 4-8 9 0 4 2 7 5 9l-3 9-7 7-5 18M44 12c5 0 8 4 8 9 0 4-2 7-5 9l3 9 7 7 5 18"/><path d="M37 37c4 3 10 3 14 0M32 45l-12 7M56 45l12 7M38 63l-5 13M50 63l5 13"/>${rays}`),
  drugs:svg(`<path d="M17 55 47 25a12 12 0 0 1 17 17L34 72a12 12 0 0 1-17-17Z"/><path d="m31 41 17 17"/><circle cx="66" cy="65" r="11"/><path d="M59 65h14"/>${rays}`),
  tests:svg(`<path d="M27 18h38a6 6 0 0 1 6 6v48H20V24a6 6 0 0 1 7-6Z"/><path d="M34 13h23v12H34z"/><path d="m30 37 4 4 8-9M30 51l4 4 8-9M48 37h13M48 52h13"/>${rays}`),
  memory:svg(`<path d="M31 18c-10 2-14 13-8 21-6 6-2 17 8 18 4 8 16 6 18-2 10 2 17-9 11-17 6-9 0-20-11-20-4-7-15-7-18 0Z"/><path d="M43 20v37M31 31h12M43 44h12"/><path d="M66 18c8 4 12 11 12 20M78 38l-5-5M78 38l5-5"/>`),
  cards:svg(`<path d="m25 19 39-5 5 43-39 5-5-43Z"/><path d="m19 26 41-3 4 43-41 3-4-43Z"/><rect x="14" y="31" width="45" height="39" rx="7"/><path d="M32 44c2-5 13-6 15 0 2 6-7 7-7 13M40 64v.5"/>${rays}`),
  schemes:svg(`<circle cx="43" cy="44" r="11"/><circle cx="18" cy="60" r="8"/><circle cx="68" cy="61" r="8"/><circle cx="48" cy="16" r="8"/><path d="m35 50-10 7M51 51l10 7M45 33l2-9"/>${rays}`),
  tables:svg(`<rect x="14" y="16" width="48" height="49" rx="5"/><path d="M14 31h48M14 47h48M30 16v49M46 16v49"/><circle cx="62" cy="59" r="13"/><path d="m71 68 10 10"/>${rays}`),
  abbr:svg(`<path d="M20 18h49a6 6 0 0 1 6 6v46H14V24a6 6 0 0 1 6-6Z"/><path d="M27 59 36 32l9 27M30 50h12M52 35h13M52 47h13M52 59h9"/>${rays}`),
  interactions:svg(`<path d="M14 55 36 33a10 10 0 0 1 14 14L28 69a10 10 0 0 1-14-14Z"/><path d="M49 25 60 14a8 8 0 0 1 12 12L61 37"/><path d="m47 50 7 7M24 45l11 11"/><path d="M67 48v13M67 68v1"/>${rays}`)
 };
 return map[type]||doodleIcon(type);
}

function topicIcon(type){
 const common=`viewBox="0 0 64 64" aria-hidden="true" focusable="false"`;
 const wrap=(body)=>`<svg ${common} class="chalkSvg"><g fill="none" stroke="currentColor" stroke-width="3.2" stroke-linecap="round" stroke-linejoin="round">${body}</g></svg>`;
 const m={
  cardio:`<path d="M32 53S11 41 11 25c0-10 13-14 21-4 8-10 21-6 21 4 0 16-21 28-21 28Z"/>`,
  hemostasis:`<path d="M32 8s15 18 15 31a15 15 0 1 1-30 0C17 26 32 8 32 8Z"/>`,
  endocrine:`<circle cx="32" cy="32" r="6"/><path d="M32 9v12M32 43v12M9 32h12M43 32h12M16 16l8 8M40 40l8 8M48 16l-8 8M24 40l-8 8"/>`,
  psych:`<path d="M24 16c-8 2-11 12-6 18-5 5-2 14 6 15 3 6 13 5 15-1 8 1 13-8 8-14 5-7 0-17-8-17-3-6-12-6-15-1Z"/><path d="M32 17v31M24 27h8M32 37h8"/>`,
  neuro:`<path d="m35 7-17 29h13l-2 21 17-31H33l2-19Z"/>`,
  pain:`<path d="M32 8v16M32 40v16M8 32h16M40 32h16M15 15l11 11M38 38l11 11M49 15 38 26M26 38 15 49"/>`,
  infectious:`<circle cx="32" cy="32" r="12"/><path d="M32 8v12M32 44v12M8 32h12M44 32h12M15 15l9 9M40 40l9 9M49 15l-9 9M24 40l-9 9"/>`,
  resp:`<path d="M30 14v19c-8-14-17-10-18 5-1 13 8 17 18 11V33M34 14v19c8-14 17-10 18 5 1 13-8 17-18 11V33"/>`,
  gi:`<path d="M29 10c0 11 8 10 8 18 0 4-4 6-7 4-9-5-17 1-16 11 1 10 9 14 19 11 11-3 17-14 14-24-3-11-13-10-18-20Z"/>`,
  uro:`<path d="M25 13c-9 0-14 9-12 18 2 9 9 13 16 8V18c-1-3-2-5-4-5ZM39 13c9 0 14 9 12 18-2 9-9 13-16 8V18c1-3 2-5 4-5Z"/><path d="M29 39v14M35 39v14"/>`,
  repro:`<circle cx="32" cy="24" r="12"/><path d="M32 36v20M24 48h16"/>`,
  immune:`<path d="M32 8 50 15v14c0 13-8 21-18 27-10-6-18-14-18-27V15L32 8Z"/>`,
  oncology:`<path d="M22 11c17 6 23 18 20 42M42 11C25 17 19 29 22 53"/><path d="M22 26h20M23 40h18"/>`,
  bone:`<path d="M17 22c-7-7-13 2-7 7l20 20c7 7 16-2 9-9L20 21c-1-1-2-1-3 1ZM47 42c7 7 13-2 7-7L34 15c-7-7-16 2-9 9l19 19c1 1 2 1 3-1Z"/>`,
  ophth:`<path d="M7 32s10-15 25-15 25 15 25 15-10 15-25 15S7 32 7 32Z"/><circle cx="32" cy="32" r="7"/>`,
  local:`<path d="M16 46 42 20l8 8-26 26H16v-8Z"/><path d="m37 25 8 8"/>`,
  toxicology:`<path d="M32 8 56 52H8L32 8Z"/><path d="M32 23v14M32 45v1"/>`
 };
 return wrap(m[type]||m.study||`<circle cx="32" cy="32" r="20"/>`);
}

function capsuleLogo(cls="brandCapsuleLogo"){
 return `<svg class="${cls}" viewBox="0 0 120 82" aria-hidden="true" focusable="false">
   <g fill="none" stroke="currentColor" stroke-width="6.2" stroke-linecap="round" stroke-linejoin="round">
     <path d="M13 29c8-13 21-17 32-8l18 15-25 27-18-15c-9-7-10-13-7-19Z"/>
     <path d="M107 29c-8-13-21-17-32-8L57 36l25 27 18-15c9-7 10-13 7-19Z"/>
     <path d="M38 23c4 0 8 2 11 5M82 23c-4 0-8 2-11 5" stroke-width="4.4"/>
   </g>
   <g fill="currentColor">
     <circle cx="56" cy="48" r="3.8"/><circle cx="65" cy="53" r="4.7"/><circle cx="52" cy="58" r="3.3"/>
     <circle cx="62" cy="64" r="3.8"/><circle cx="54" cy="69" r="2.4"/><circle cx="67" cy="73" r="2.4"/>
   </g>
 </svg>`;
}
function header(){return `<div class="topbar innerTopbar chalkTop"><button class="backMini" onclick="history.length>1?history.back():location.hash='#home'">‹</button><div class="brandCompact brandWithLogo">${capsuleLogo("miniCapsuleLogo")}<span><b>ProPharm</b><small>экзаменационная база</small></span></div><div class="topDoodle">•••</div></div>`;}
function bottomNav(active){
 const items=[["home","#home","home","Главная"],["search","#search","search","Поиск"],["study","#study","study","Учёба"],["settings","#settings","settings","Настройки"]];
 return `<nav class="bottomNav">${items.map(([id,route,ic,t])=>`<button class="navBtn ${active===id?"active":""}" data-route="${route}"><span class="navSketch">${doodleIcon(ic)}</span><span>${t}</span></button>`).join("")}</nav>`;
}
function bindNav(root=document){
 root.querySelectorAll("[data-nav]").forEach(b=>b.addEventListener("click",()=>location.hash=b.dataset.nav==="home"?"#home":`#${b.dataset.nav}`));
 root.querySelectorAll("[data-route]").forEach(el=>el.addEventListener("click",()=>location.hash=el.dataset.route));
 bindPersonalActions(root);
 bindAccordions(root);
 bindScientificImages(root);
}
const ACCORDION_SESSION_KEY="propharm_accordion_v014";
function readAccordionState(){try{return JSON.parse(sessionStorage.getItem(ACCORDION_SESSION_KEY)||"{}")}catch{return {}}}
function rememberAccordion(id,open){if(!id)return;const state=readAccordionState();state[id]=!!open;sessionStorage.setItem(ACCORDION_SESSION_KEY,JSON.stringify(state));}
function accordionOpen(id,defaultOpen=false){const state=readAccordionState();return Object.prototype.hasOwnProperty.call(state,id)?!!state[id]:!!defaultOpen}
function accordion({id,title,body,badge="",count="",subtitle="",level=1,open=false,className="",icon=""}){
 const shouldOpen=accordionOpen(id,open),shownBadge=badge!==""?badge:count;
 return `<details class="learningAccordion level-${level} ${className}" data-accordion-id="${esc(id)}" ${shouldOpen?"open":""}><summary><span class="accordionChevron" aria-hidden="true">›</span>${icon?`<span class="accordionPencilIcon">${icon}</span>`:""}<span class="accordionHeading"><span class="accordionTitle">${esc(title)}</span>${subtitle?`<small>${esc(subtitle)}</small>`:""}</span>${shownBadge!==""?`<span class="accordionBadge">${esc(shownBadge)}</span>`:""}</summary><div class="learningAccordionBody">${body}</div></details>`;
}
function bindAccordions(root=document){root.querySelectorAll('details[data-accordion-id]').forEach(d=>{if(d.dataset.accordionBound)return;d.dataset.accordionBound='1';d.addEventListener('toggle',()=>rememberAccordion(d.dataset.accordionId,d.open))})}
function bindScientificImages(root=document){root.querySelectorAll('[data-scientific-image]').forEach(btn=>{if(btn.dataset.imageBound)return;btn.dataset.imageBound='1';btn.addEventListener('click',()=>openScientificLightbox(btn.dataset.imageUrl,btn.dataset.imageTitle,btn.dataset.sourceUrl))})}
function openScientificLightbox(url,title,sourceUrl){
 const modal=document.createElement('div');modal.className='scientificLightbox';modal.innerHTML=`<div class="scientificLightboxBar"><b>${esc(title||'Схема')}</b><button aria-label="Закрыть">×</button></div><div class="scientificLightboxViewport"><img src="${esc(url)}" alt="${esc(title||'Научная иллюстрация')}" draggable="false"></div>${sourceUrl?`<a class="scientificSourceLink" href="${esc(sourceUrl)}" target="_blank" rel="noopener noreferrer">Открыть оригинальный источник ↗</a>`:""}`;document.body.appendChild(modal);
 const img=modal.querySelector('img'),view=modal.querySelector('.scientificLightboxViewport');let scale=1,tx=0,ty=0,lastDist=0,lastX=0,lastY=0,dragging=false;
 const apply=()=>img.style.transform=`translate(${tx}px,${ty}px) scale(${scale})`;
 modal.querySelector('button').onclick=()=>modal.remove();modal.addEventListener('click',e=>{if(e.target===modal)modal.remove()});
 view.addEventListener('wheel',e=>{e.preventDefault();scale=Math.min(5,Math.max(1,scale+(e.deltaY<0?.2:-.2)));apply()},{passive:false});
 view.addEventListener('pointerdown',e=>{dragging=true;lastX=e.clientX;lastY=e.clientY;view.setPointerCapture?.(e.pointerId)});
 view.addEventListener('pointermove',e=>{if(!dragging||scale<=1)return;tx+=e.clientX-lastX;ty+=e.clientY-lastY;lastX=e.clientX;lastY=e.clientY;apply()});
 view.addEventListener('pointerup',()=>dragging=false);view.addEventListener('pointercancel',()=>dragging=false);
 let touches=[];view.addEventListener('touchstart',e=>{touches=[...e.touches];if(touches.length===2)lastDist=Math.hypot(touches[0].clientX-touches[1].clientX,touches[0].clientY-touches[1].clientY)},{passive:true});
 view.addEventListener('touchmove',e=>{if(e.touches.length===2){const d=Math.hypot(e.touches[0].clientX-e.touches[1].clientX,e.touches[0].clientY-e.touches[1].clientY);if(lastDist){scale=Math.min(5,Math.max(1,scale*d/lastDist));apply()}lastDist=d}},{passive:true});
}

function countsForTopic(id){return {drugs:DRUGS.filter(d=>d.topics.includes(id)).length,abbr:(ABBREVIATIONS[id]||[]).length,theory:(THEORY[id]||[]).length,mechanisms:(MECHANISMS[id]||[]).length,tests:TESTS.filter(q=>q.topic===id).length,analyses:TEST_ANALYSES.filter(q=>q.topic===id).length,interactions:(INTERACTIONS[id]||[]).length};}



const ALL_ABBREVIATIONS=(()=>{
 const seen=new Set(),out=[];
 const push=(x)=>{
   if(!x?.abbr)return;
   const key=(x.abbr+"|"+(x.full||"")).toLowerCase();
   if(seen.has(key))return;seen.add(key);out.push(x);
 };
 Object.values(ABBREVIATIONS).flat().forEach(push);
 GLOSSARY_EXTRAS.forEach(push);
 CARDIO_GLOSSARY.forEach(push);
 return out;
})();
function abbreviationAliases(abbr){
 return String(abbr||"").split(/\s*\/\s*/).map(x=>x.trim()).filter(Boolean);
}
function textHasAbbreviation(text,abbr){
 const hay=String(text||"");
 return abbreviationAliases(abbr).some(alias=>{
   const escaped=alias.replace(/[.*+?^${}()|[\]\\]/g,"\\$&");
   return new RegExp(`(^|[^A-Za-zА-Яа-я0-9])${escaped}([^A-Za-zА-Яа-я0-9]|$)`,"i").test(hay);
 });
}
function abbreviationsInText(text){
 if(!text)return [];
 return ALL_ABBREVIATIONS.filter(a=>textHasAbbreviation(text,a.abbr));
}
function renderAbbreviationLead(text){
 const found=abbreviationsInText(text);
 if(!found.length)return "";
 return `<div class="abbrLead"><div class="abbrLeadTitle">Используемые термины и сокращения</div>${found.map(a=>`<div class="abbrLeadRow"><b>${esc(a.abbr)}</b><span>${esc(a.full||"")}${a.ru?` — ${esc(a.ru)}`:""}</span></div>`).join("")}</div>`;
}
function renderTextWithAbbreviations(text){
 if(!text)return "";
 return `${renderAbbreviationLead(text)}${String(text).split("\\n").filter(Boolean).map(x=>`<p>${esc(x)}</p>`).join("")}`;
}

// Helpers for the full 170-drug profile database.
// These are deliberately kept close to the router/UI helpers because the
// drug page, schemes hub, flashcards and full-text search all depend on them.
function profileFor(drugOrNumber){
  const n=typeof drugOrNumber==="object" ? drugOrNumber?.n : drugOrNumber;
  return n==null ? null : (DRUG_PROFILES[String(n)] || null);
}
function profileSection(title,text,icon="•"){
  if(!text)return "";
  return `<details class="drugProfileSection"><summary><span><span class="profileSectionIcon">${esc(icon)}</span>${esc(title)}</span><span class="schemePlus">＋</span></summary><div class="drugProfileBody">${renderAbbreviationLead(text)}${String(text).split("\\n").filter(Boolean).map(x=>`<p>${esc(x)}</p>`).join("")}</div></details>`;
}
function interactionRiskClass(level=""){
  const l=String(level).toUpperCase();
  if(l.includes("КРАСН"))return "riskRed";
  if(l.includes("ОРАНЖ"))return "riskOrange";
  if(l.includes("ЖЁЛТ")||l.includes("ЖЕЛТ"))return "riskYellow";
  if(l.includes("ЗЕЛЁН")||l.includes("ЗЕЛЕН"))return "riskGreen";
  return "riskGray";
}
function renderProfileInteractions(profile){
  if(!profile)return "";
  const arr=Array.isArray(profile.interactions)?profile.interactions:[];
  if(arr.length){
    return `<details class="drugProfileSection"><summary><span><span class="profileSectionIcon">↔</span>Лекарственные взаимодействия</span><span class="schemePlus">＋</span></summary><div class="drugProfileBody"><div class="interactionProfileList">${arr.map(x=>`<div class="profileInteraction">${renderAbbreviationLead(x.text||"")}<span class="riskBadge ${interactionRiskClass(x.level)}">${esc(x.level||"СЕРЫЙ")}</span><p>${esc(x.text||"")}</p></div>`).join("")}</div></div></details>`;
  }
  return profileSection("Лекарственные взаимодействия",profile.interactionsText,"↔");
}
function drugSearchText(d){
  const p=profileFor(d);
  return [
    d?.name,d?.group,
    ...(d?.topics||[]).map(x=>topicMap[x]?.title||x),
    p?.sourceTitle,p?.mnn,p?.groupSource,p?.basic,p?.indications,p?.contraindications,
    p?.mechanismText,p?.scheme,p?.routes,p?.pharmacodynamics,p?.pharmacokinetics,
    p?.adverseEffects,p?.interactionsText,p?.specialSituations,
    ...(p?.interactions||[]).flatMap(x=>[x.level,x.text])
  ].filter(Boolean).join(" ").toLowerCase();
}

function accountDisplayName(){
 const p=authState.profile||{};return String(p.name||p.email||'Профиль').trim();
}
function chemistryWhiteboard(w){if(!w)return '';
 const nodes=(w.nodes||[]).map(([label,tone])=>`<span class="chemNode chem-${esc(tone||'neutral')}">${esc(label)}</span>`).join('<span class="chemArrow">→</span>');
 const arrows=(w.arrows||[]).map(x=>`<div class="chemFlowLine">${esc(x)}</div>`).join('');
 return `<div class="chemWhiteboard"><div class="chemNodeFlow">${nodes}</div>${arrows}</div>`;
}
function chemistryTable(t){if(!t)return '';
 return `<div class="tableWrap chemTableWrap"><table class="studyTable chemTable"><thead><tr>${t.headers.map(x=>`<th>${esc(x)}</th>`).join('')}</tr></thead><tbody>${t.rows.map(r=>`<tr>${r.map((x,i)=>`<td>${esc(x)}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`;
}
function chemistryCards(cards){if(!cards)return '';
 return `<div class="chemClassGrid">${cards.map(([a,b,c])=>`<div class="chemClassCard chem-${esc(c)}"><b>${esc(a)}</b><span>${esc(b)}</span></div>`).join('')}</div>`;
}
function chemistryScale(items){if(!items)return '';
 return `<div class="chemScale" aria-label="Ряд активности металлов">${items.map((x,i)=>`<span class="${i<8?'activeMetal':'lessMetal'}">${esc(x)}</span>`).join('<b>›</b>')}</div>`;
}
function renderChemistryTopic(sectionId,item){
 const terms=accordion({id:`chem-${item.id}-terms`,title:'Термины и обозначения',level:3,open:true,body:`<div class="theoryBody">${(item.terms||[]).map(x=>`<p>• ${esc(x)}</p>`).join('')}</div>`});
 const visual=(item.whiteboard?accordion({id:`chem-${item.id}-visual`,title:'Learning Whiteboard',level:3,open:true,body:chemistryWhiteboard(item.whiteboard)}):'')+(item.cards?accordion({id:`chem-${item.id}-classes`,title:'Классификация',level:3,body:chemistryCards(item.cards)}):'')+(item.scale?accordion({id:`chem-${item.id}-scale`,title:'Интерактивная шкала',level:3,body:chemistryScale(item.scale)}):'');
 const theory=accordion({id:`chem-${item.id}-theory`,title:'Теория',level:3,body:`<div class="theoryBody">${(item.theory||[]).map(x=>`<p>${esc(x)}</p>`).join('')}</div>`});
 const table=item.table?accordion({id:`chem-${item.id}-table`,title:'Таблица',level:3,body:chemistryTable(item.table)}):'';
 const reactions=item.reactions?.length?accordion({id:`chem-${item.id}-rx`,title:'Примеры реакций',level:3,body:`<div class="reactionList">${item.reactions.map(x=>`<code>${esc(x)}</code>`).join('')}</div>`}):'';
 const expert=accordion({id:`chem-${item.id}-expert`,title:'Совет эксперта',level:3,body:`<div class="expertTip">${esc(item.expert||'Связывай структуру, условия реакции и наблюдаемый результат.')}</div>`});
 const self=accordion({id:`chem-${item.id}-self`,title:'Проверь себя',level:3,body:`<ol class="selfCheck">${(item.self||[]).map(x=>`<li>${esc(x)}</li>`).join('')}</ol><div class="sourceNote"><b>Важно:</b> это блок самопроверки, а не новая запись в экзаменационной базе тестов.</div>`});
 return accordion({id:`chem-topic-${item.id}`,title:item.title,subtitle:item.subtitle||'',level:2,icon:doodleIcon('chemistry'),body:`<div class="accordionStack">${terms}${visual}${theory}${table}${reactions}${expert}${self}</div>`});
}

function renderFoundationSources(ids=[],sourceText=''){
 const rows=(ids||[]).map(id=>ACADEMIC_SOURCES[id]).filter(Boolean);
 const academic=rows.length?`<div class="sourceMeta">${rows.map(x=>`<p><b>${esc(x.name)}</b> · ${esc(x.institution||'')}<br><span>${esc(x.use||'')}</span><br><a href="${esc(x.url)}" target="_blank" rel="noopener noreferrer">Открыть источник ↗</a></p>`).join('')}</div>`:'';
 const booklet=sourceText?`<div class="sourceNote"><b>Источник структуры/реакций:</b> ${esc(sourceText)}</div>`:'';
 return academic+booklet||'<p class="smallMuted">Источник будет добавлен после научной сверки.</p>';
}
function renderFormulaList(xs=[]){return xs?.length?`<div class="formulaStack">${xs.map(x=>`<div class="formulaCard">${esc(x)}</div>`).join('')}</div>`:''}
function renderSelfCheckCards(cards=[]){
 if(!cards?.length)return '';
 return `<div class="selfCardGrid">${cards.map((x,i)=>{const q=Array.isArray(x)?x[0]:x.question;const a=Array.isArray(x)?x[1]:x.answer;return `<details class="selfStudyCard"><summary><span class="selfCardNo">${i+1}</span><span>${esc(q||'Вопрос')}</span></summary><div class="selfStudyAnswer"><b>Ответ</b><p>${esc(a||'Открой теоретический блок выше и сформулируй ответ самостоятельно.')}</p></div></details>`}).join('')}</div><div class="sourceNote"><b>Проверь себя:</b> карточки относятся только к теоретическому разделу и не добавляются в глобальную экзаменационную базу «Тесты».</div>`;
}
function renderNamedReactions(items=[]){
 if(!items?.length)return '';
 return `<div class="accordionStack">${items.map((r,i)=>accordion({id:`named-rxn-${i}`,title:r.name,level:4,body:`${r.chain?.length?renderLearningWhiteboard({title:r.name,steps:r.chain,area:'default',showSources:false}):''}${r.equation?`<div class="formulaCard">${esc(r.equation)}</div>`:''}<div class="theoryBody"><p><b>Что происходит.</b> ${esc(r.explanation||'')}</p></div>`})).join('')}</div>`;
}
function renderExternalVisuals(items=[]){
 if(!items?.length)return '';
 return `<div class="externalVisualGrid">${items.map(x=>`<a class="externalVisualCard" href="${esc(x.url)}" target="_blank" rel="noopener noreferrer"><span class="externalVisualIcon">↗</span><div><b>${esc(x.title)}</b><p>${esc(x.note||'Открыть исходную визуализацию')}</p><small>${esc(x.url)}</small></div></a>`).join('')}</div>`;
}
function renderAdvancedFoundationTopic(sectionId,item){
 const terms=item.terms?.length?accordion({id:`adv-${item.id}-terms`,title:'Термины и сокращения',level:3,open:true,body:`<div class="theoryBody">${item.terms.map(x=>`<p>• ${esc(x)}</p>`).join('')}</div>`}):'';
 const theory=accordion({id:`adv-${item.id}-theory`,title:'Теоретическая база',level:3,open:true,body:`<div class="theoryBody">${(item.theory||[]).map(x=>`<p>${esc(x)}</p>`).join('')}</div>${renderFormulaList(item.formulas||[])}`});
 const wb=item.steps?.length?accordion({id:`adv-${item.id}-wb`,title:'Learning Whiteboard: процесс',level:3,open:true,body:renderLearningWhiteboard({title:item.title,steps:item.steps,area:sectionId==='biochemistry-biology'?'biochemistry':'default',showSources:false})}):'';
 const tbl=item.table?accordion({id:`adv-${item.id}-table`,title:'Таблица',level:3,body:chemistryTable(item.table)}):'';
 const named=item.namedReactions?.length?accordion({id:`adv-${item.id}-named`,title:'Именные реакции / пробы',level:3,open:true,body:renderNamedReactions(item.namedReactions)}):'';
 const ext=item.externalVisuals?.length?accordion({id:`adv-${item.id}-external`,title:'Внешние визуальные справочники',level:3,open:true,body:renderExternalVisuals(item.externalVisuals)}):'';
 const cards=item.selfCards?.length?accordion({id:`adv-${item.id}-selfcards`,title:'Проверь себя — карточки',level:3,body:renderSelfCheckCards(item.selfCards)}):'';
 let extra='';
 if(sectionId==='general-chemistry'&&(item.id==='gc-periodicity'||item.id==='gc-periodic-tables'))extra+=renderPeriodicTables();
 if(sectionId==='general-chemistry'&&item.id==='gc-solubility')extra+=renderSolubilityTable();
 if(sectionId==='general-chemistry'&&item.id==='gc-qualitative')extra+=renderQualitativeReactions()+renderFlameTests();
 if(sectionId==='organic-chemistry'&&item.id==='oc-qualitative')extra+=renderOrganicQualitative();
 if(sectionId==='pharmacokinetics'&&item.chart)extra+=renderPkMiniChart(item.chart);
 const src=accordion({id:`adv-${item.id}-sources`,title:'Источники',level:3,body:renderFoundationSources(item.sourceIds||[],item.sourceText||'')});
 return accordion({id:`adv-topic-${item.id}`,title:item.title,subtitle:item.subtitle||'',level:2,icon:foundationIcon(sectionId),body:`<div class="accordionStack">${terms}${theory}${wb}${tbl}${named}${ext}${extra}${cards}${src}</div>`});
}
function renderPkMiniChart(type){
 if(type==='steadyState')return accordion({id:'pk-chart-steady',title:'График: накопление до steady state',level:3,body:`<div class="pkChart"><div class="pkAxis y">Css %</div><svg viewBox="0 0 420 220" role="img" aria-label="Накопление до steady state"><path class="pkGrid" d="M40 20V190H400M40 190H400"/><polyline class="pkCurve" points="40,190 100,105 160,62.5 220,41.3 280,30.6 340,25.3 400,22.7"/><g class="pkDots"><circle cx="100" cy="105" r="5"/><circle cx="160" cy="62.5" r="5"/><circle cx="220" cy="41.3" r="5"/><circle cx="280" cy="30.6" r="5"/><circle cx="340" cy="25.3" r="5"/></g><text x="90" y="210">1</text><text x="150" y="210">2</text><text x="210" y="210">3</text><text x="270" y="210">4</text><text x="330" y="210">5 t½</text></svg><div class="pkLegend">1 t½ ≈ 50% · 2 ≈ 75% · 3 ≈ 87.5% · 4 ≈ 93.75% · 5 ≈ 96.9%</div></div>`});
 return accordion({id:'pk-chart-ct',title:'График концентрация–время',level:3,body:`<div class="pkChart"><svg viewBox="0 0 420 220" role="img" aria-label="Концентрация во времени"><path class="pkGrid" d="M40 20V190H400M40 190H400"/><path class="pkCurve" d="M45 188 C80 60 135 30 180 45 C235 65 285 105 395 175"/><circle class="pkPeak" cx="150" cy="40" r="6"/><text x="158" y="35">Cmax</text><text x="138" y="210">Tmax</text><path class="pkArea" d="M45 188 C80 60 135 30 180 45 C235 65 285 105 395 175 L395 190 L45 190Z"/></svg><div class="pkLegend">Высота пика = Cmax · положение пика по времени = Tmax · площадь под кривой = AUC</div></div>`});
}
function renderPeriodicTables(){
 const make=(mode)=>{const heads=mode==='iupac'?Array.from({length:18},(_,i)=>String(i+1)):AB_GROUP_LABELS;const cells=[];for(let p=1;p<=7;p++){for(let g=1;g<=18;g++){const e=PERIODIC_ELEMENTS.find(x=>x[2]===p&&x[3]===g);cells.push(e?`<button class="periodicCell" data-el-title="${esc(e[4])}" title="${esc(e[4])}"><small>${e[1]}</small><b>${esc(e[0])}</b><span>${esc(e[4])}</span></button>`:`<span class="periodicEmpty"></span>`)} }return `<div class="periodicWrap"><div class="periodicHead">${heads.map(x=>`<span>${esc(x)}</span>`).join('')}</div><div class="periodicGrid">${cells.join('')}</div><div class="fBlock"><b>Лантаноиды</b>${LANTHANIDES.map(x=>`<span title="${esc(x[2])}"><small>${x[1]}</small><b>${x[0]}</b></span>`).join('')}</div><div class="fBlock"><b>Актиноиды</b>${ACTINIDES.map(x=>`<span title="${esc(x[2])}"><small>${x[1]}</small><b>${x[0]}</b></span>`).join('')}</div></div>`};
 return accordion({id:'gc-periodic-tools',title:'Две таблицы Менделеева',level:3,body:`<div class="periodicTabs"><details open><summary>Вариант 1 · современная / свойства (по референсу Ptable)</summary>${make('iupac')}<a class="sourceOpenBtn" href="https://ptable.com/?lang=ru#Свойства" target="_blank" rel="noopener noreferrer">Открыть интерактивный Ptable ↗</a></details><details><summary>Вариант 2 · традиционная русская A/B</summary>${make('ab')}<a class="sourceOpenBtn" href="https://disk.yandex.ru/i/Ea2epWQkDbD4tA" target="_blank" rel="noopener noreferrer">Открыть пользовательский оригинал ↗</a></details></div><div class="sourceNote">В приложении обе таблицы остаются локально читаемыми; внешние ссылки используются как указанные пользователем визуальные референсы.</div>`});
}
function renderSolubilityTable(){
 return accordion({id:'gc-solubility-full',title:'Интерактивная таблица растворимости',level:3,body:`<div class="solLegend"><span class="sol-R">Р — растворимо</span><span class="sol-M">М — малорастворимо</span><span class="sol-N">Н — нерастворимо</span><span class="sol-D">—</span></div><div class="solTableWrap"><table class="solTable"><thead><tr><th>Катион ↓ / Анион →</th>${SOLUBILITY_ANIONS.map(a=>`<th>${esc(a)}</th>`).join('')}</tr></thead><tbody>${SOLUBILITY_CATIONS.map(c=>`<tr><th>${esc(c)}</th>${(SOLUBILITY_MATRIX[c]||[]).map(v=>`<td class="sol-${v==='Р'?'R':v==='М'?'M':v==='Н'?'N':'D'}">${esc(v)}</td>`).join('')}</tr>`).join('')}</tbody></table></div><div class="sourceNote">Используй таблицу как учебный ориентир для реакций в водных растворах; конкретные условия, комплексообразование и кислотность среды могут менять наблюдаемую систему.</div><a class="sourceOpenBtn" href="https://disk.yandex.ru/i/q68gv2fz8rCM7Q" target="_blank" rel="noopener noreferrer">Открыть указанную цветную таблицу растворимости ↗</a>`});
}
function reactionIcon(kind=''){const map={gas:'↑', 'precip-white':'↓ ◻','precip-blue':'↓ 🟦','precip-green':'↓ 🟩','precip-brown':'↓ 🟫','precip-cream':'↓ ◽','precip-yellow':'↓ 🟨'};return map[kind]||'→'}
function renderQualitativeReactions(){return accordion({id:'gc-qualitative-table',title:'Качественные реакции: ион → реактив → визуальный признак',level:3,body:`<div class="qualGrid">${QUALITATIVE_REACTIONS.map(x=>`<div class="qualCard"><span class="qualSign">${reactionIcon(x.kind)}</span><div><b>${esc(x.ion)}</b><small>Реактив: ${esc(x.reagent)}</small><code>${esc(x.equation)}</code><p>${esc(x.sign)}</p></div></div>`).join('')}</div>`})}
function renderFlameTests(){return accordion({id:'gc-flame-table',title:'Окрашивание пламени',level:3,body:`<div class="flameGrid">${FLAME_TESTS.map(x=>`<div class="flameCard"><span class="flame" style="--flame:${esc(x[2])}"></span><b>${esc(x[0])}</b><small>${esc(x[1])}</small></div>`).join('')}</div>`})}
function renderOrganicQualitative(){return accordion({id:'oc-qual-table',title:'Справочник качественных реакций',level:3,body:`<div class="tableWrap"><table class="studyTable"><thead><tr><th>Фрагмент / класс</th><th>Реактив</th><th>Признак</th></tr></thead><tbody>${ORGANIC_QUALITATIVE.map(r=>`<tr>${r.map(x=>`<td>${esc(x)}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`})}
function foundationDrugsForCategory(cat){return DRUGS.filter(d=>cat.match.test(d.name||''))}
function renderDiureticNephron(){
 const rows=DIURETIC_GROUPS.map(g=>`<button class="nephronDrugBtn" data-diuretic="${g.id}"><b>${esc(g.title)}</b><small>${esc(g.segment)}</small></button>`).join('');
 const cards=DIURETIC_GROUPS.map(g=>`<div class="diureticDetail" data-diuretic-detail="${g.id}" hidden><div class="nephronMap"><div class="nephSeg pct ${g.segment.includes('Проксим')?'active':''}">Проксимальный каналец</div><div class="nephArrow">↓</div><div class="nephSeg loop ${g.segment.includes('восход')?'active':''}">Петля Генле / TAL</div><div class="nephArrow">↓</div><div class="nephSeg dct ${g.segment.includes('дисталь')?'active':''}">Дистальный каналец</div><div class="nephArrow">↓</div><div class="nephSeg cd ${g.segment.includes('Собират')?'active':''}">Собирательная трубочка</div></div><div class="diureticTarget"><b>Мишень</b><p>${esc(g.target)}</p><b>Примеры</b><p>${g.examples.map(esc).join(', ')}</p><b>Кислотно-основный эффект</b><p>${esc(g.acidBase)}</p></div>${renderLearningWhiteboard({title:`${g.title}: механизм`,steps:g.steps,area:'default',showSources:false})}<div class="ionPanel">${Object.entries(g.effects).map(([ion,val])=>`<div><b>${ion}</b><span>${esc(val)}</span></div>`).join('')}</div></div>`).join('');
 return `<div class="diureticModule"><div class="sourceNote"><b>Интерактивная карта:</b> выбери класс — подсветится место действия, мишень и направление изменения экскреции ионов. Для K⁺ подпись «сохраняется» означает уменьшение его потери с мочой.</div><div class="nephronDrugList">${rows}</div>${cards}</div>`;
}
function bindDiureticModule(root=document){const btns=[...root.querySelectorAll('[data-diuretic]')],cards=[...root.querySelectorAll('[data-diuretic-detail]')];if(!btns.length)return;const show=id=>{btns.forEach(b=>b.classList.toggle('active',b.dataset.diuretic===id));cards.forEach(c=>c.hidden=c.dataset.diureticDetail!==id)};btns.forEach(b=>b.onclick=()=>show(b.dataset.diuretic));show(btns[0].dataset.diuretic)}
function renderPharmacologyFoundation(){
 const intro=accordion({id:'pharm-found-intro',title:PHARMACOLOGY_FOUNDATIONS.intro.title,subtitle:PHARMACOLOGY_FOUNDATIONS.intro.summary,level:1,open:true,icon:doodleIcon('drugs'),body:`${renderLearningWhiteboard({title:'Как лекарство превращает молекулярное действие в клинический эффект',steps:PHARMACOLOGY_FOUNDATIONS.intro.steps,showSources:false})}<div class="sourceNote">Каждая фармгруппа использует те же препараты, что и глобальная база «170 препаратов»; карточки не дублируются.</div>`});
 const groups=PHARMACOLOGY_FOUNDATIONS.categories.map(cat=>{
  const drugs=foundationDrugsForCategory(cat);let body='';
  if(cat.id==='diuretics')body+=renderDiureticNephron();
  body+=`<div class="pharmGroupSummary"><h4>Препараты из базы 170</h4><div class="chips">${drugs.map(d=>`<button class="chip drugChipButton" data-route="#drug/${d.n}">${esc(d.name)}</button>`).join('')}</div></div>`;
  if(drugs.length){
   const mechRows=drugs.slice(0,10).map((d,i)=>{const p=profileFor(d);return accordion({id:`pharm-${cat.id}-drug-${d.n}`,title:d.name,subtitle:d.group,level:3,body:`${renderAbbreviationLead((p?.mechanismText||'')+' '+(p?.pharmacokinetics||''))}<p><b>Механизм / мишень.</b> ${esc(p?.mechanismText||'Смотри полную карточку препарата.')}</p>${p?.schemeSteps?.length?renderLearningWhiteboard({title:`${d.name}: где и как действует`,steps:p.schemeSteps,showSources:false}):''}<p><b>Распределение, метаболизм и выведение.</b> ${esc(p?.pharmacokinetics||'Точные PK-особенности приведены в полной карточке и требуют сверки с регуляторными источниками.')}</p><button class="drugLink" data-route="#drug/${d.n}">Открыть полную карточку</button>`})}).join('');
   body+=accordion({id:`pharm-${cat.id}-mechanisms`,title:'Механизмы, мишени и фармакокинетика представителей',level:2,body:`<div class="accordionStack">${mechRows}</div>`});
  }
  return accordion({id:`pharm-found-${cat.id}`,title:cat.title,level:1,badge:String(drugs.length),icon:doodleIcon('drugs'),body});
 }).join('');
 return `<div class="accordionStack">${intro}${groups}</div>`;
}

function renderHome(){
 const tiles=[
  ["theory","Базовые дисциплины","Системы организма, фармакокинетика, химия, биохимия и НД Израиля","#foundations","paper"],
  ["drugs","170 препаратов","Полная экзаменационная база","#drugs","blue"],
  ["tests","Тесты","Экзаменационная база + вопросы прошлых лет","#tests","lavender"],
  ["memory","Тренажёр памяти","Циклическое обучение и интервальное повторение","#memory-trainer","blue"],
  ["cards","Карточки","Повторение по препаратам и тестам","#cards","lavender"],
  ["schemes","Схемы","Механизмы и процессы","#schemes","paper"],
  ["tables","Таблицы","Сравнения и диагностические ориентиры","#tables","blue"],
  ["abbr","Аббревиатуры","Расшифровки по системам","#abbr-hub","lavender"],
  ["interactions","Взаимодействия","Поиск опасных взаимодействий по препарату","#interactions-hub","paper"]
 ];
 app.innerHTML=`<div class="homePage page chalkHome">
   <section class="chalkMasthead"><div class="chalkBrand">${capsuleLogo("homeBrandLogo")}<div><div class="chalkBrandName">ProPharm</div><div class="chalkBrandTag">знания лечат ♡</div></div></div><button class="chalkMenu" aria-label="Настройки" data-route="#settings">•••</button></section><button class="homeAccountCapsule" data-route="#profile" aria-label="Открыть профиль"><span class="homeAccountDot">${esc(accountDisplayName().slice(0,1).toUpperCase())}</span><span>${esc(accountDisplayName())}</span></button>
   <section class="chalkIntro"><h1>Главная</h1><p>Начни с системного изучения</p><span class="handNote">норма → механизм → патология → препарат ♡</span></section>
   <section class="dashboardGrid chalkGrid">${tiles.map(([ic,title,desc,route,tone])=>`<button class="dashTile chalkTile tone-${tone}" data-route="${route}"><span class="dashIcon">${homeDoodleIcon(ic)}</span><span class="dashText"><b>${title}</b><small>${desc}</small></span></button>`).join("")}</section>
   <div class="chalkFooterNote">понимай связи · не учи изолированные факты</div>
 </div>`+bottomNav("home");bindNav();
}
function renderTopics(){
 app.innerHTML=header()+`<div class="page"><div class="sectionTitle"><h2>Темы</h2><span class="muted">${TOPICS.length} разделов</span></div><div class="topicGrid">${TOPICS.map(t=>{const c=countsForTopic(t.id);return `<div class="card clickCard" data-route="#topic/${t.id}"><div class="cardHead"><div class="iconFrame topicLineIcon">${topicIcon(t.id)}</div><div><h3>${esc(t.title)}</h3><p>${esc(t.description)}</p><span class="badge">${c.drugs} препаратов</span>${c.abbr?`<span class="badge">${c.abbr} аббр.</span>`:""}${c.theory?`<span class="badge blue">${c.theory} теория</span>`:""}</div></div></div>`;}).join("")}</div></div>`+bottomNav("study");bindNav();
}
function topicSections(t){const c=countsForTopic(t.id);const defs=[["theory","📘","Теория",c.theory,"Конспекты и интерактивные учебные модули."],["mechanisms","🧬","Механизмы",c.mechanisms,"Сигнальные пути и причинно-следственные цепочки."],["drugs","💊","Препараты",c.drugs,"Препараты, связанные с этой темой."],["abbr","🔤","Аббревиатуры",c.abbr,"Только словарь этой темы — без смешивания."],["interactions","🔗","Взаимодействия",c.interactions,"Лекарственные взаимодействия с механизмом и клиническим следствием."],["tests","📝","Тесты",c.tests,"Вопросы только по выбранной теме."],["analysis","✅","Разбор тестов",c.analyses,"Почему правильный ответ верен и почему остальные неверны."],["high","⚡","High-yield",(HIGH_YIELD[t.id]||[]).length,"Короткий экзаменационный повтор."]];return defs.map(([id,ic,title,count,desc])=>`<div class="card clickCard" data-route="#topic/${t.id}/${id}"><div class="cardHead"><div class="iconFrame">${ic}</div><div><h3>${title}</h3><p>${desc}</p><span class="badge">${count}</span></div></div></div>`).join("");}
function renderTopic(id){const t=topicMap[id];if(!t){location.hash="#topics";return;}app.innerHTML=header()+`<div class="page"><div class="breadcrumb"><button data-route="#topics">Темы</button><span>›</span><span>${esc(t.short)}</span></div><div class="topicHeader"><div class="iconFrame topicLineIcon">${topicIcon(t.id)}</div><div><h2>${esc(t.title)}</h2><p>${esc(t.description)}</p></div></div><div class="sectionGrid">${topicSections(t)}</div></div>`+bottomNav("study");bindNav();}
function sectionShell(t,title,content){return header()+`<div class="page"><div class="breadcrumb"><button data-route="#topics">Темы</button><span>›</span><button data-route="#topic/${t.id}">${esc(t.short)}</button><span>›</span><span>${esc(title)}</span></div><div class="topicHeader"><div class="iconFrame topicLineIcon">${topicIcon(t.id)}</div><div><h2>${esc(title)}</h2><p>${esc(t.title)}</p></div></div>${content}</div>`+bottomNav("study");}

function renderScientificVisual(key){
  const v=SCIENTIFIC_VISUALS[key];if(!v)return "";
  return `<figure class="scientificFigure"><button class="scientificImageButton" type="button" data-scientific-image data-image-url="${esc(v.imageUrl)}" data-image-title="${esc(v.title)}" data-source-url="${esc(v.sourcePage)}"><img src="${esc(v.imageUrl)}" alt="${esc(v.title)}" loading="lazy" referrerpolicy="no-referrer"><span class="scientificZoomHint">Открыть схему · увеличить</span></button><figcaption><b>${esc(v.title)}</b><p>${esc(v.note||"")}</p></figcaption>${accordion({id:`source-${key}`,title:'Источник и лицензия',level:3,body:`<div class="sourceMeta"><p><b>Источник:</b> ${esc(v.sourceName)}</p><p><b>Автор:</b> ${esc(v.author)}</p><p><b>Лицензия:</b> ${esc(v.license)}</p><a href="${esc(v.sourcePage)}" target="_blank" rel="noopener noreferrer">Открыть страницу оригинала ↗</a></div>`})}</figure>`;
}
function renderWhiteboardSources(area='default'){
  const rows=WHITEBOARD_SOURCE_MAP[area]||WHITEBOARD_SOURCE_MAP.default||[];
  if(!rows.length)return '';
  return accordion({id:`wb-sources-${area}-${rows.map(x=>x.name).join('-')}`,title:'Научные источники для проверки механизма',level:3,body:`<div class="sourceMeta">${rows.map(x=>`<p><b>${esc(x.name)}</b> · ${esc(x.license)}<br><a href="${esc(x.url)}" target="_blank" rel="noopener noreferrer">Открыть источник ↗</a></p>`).join('')}</div>`});
}
function renderLearningWhiteboard({title='',steps=[],area='default',showSources=false}={}){
  const clean=(steps||[]).map(x=>String(x||'').trim()).filter(Boolean);if(!clean.length)return '';
  const nodes=clean.map((x,i)=>`<div class="whiteboardStep"><span class="whiteboardIndex">${i+1}</span><span class="whiteboardNodeText">${esc(x)}</span></div>${i<clean.length-1?'<div class="whiteboardArrow" aria-hidden="true">↓</div>':''}`).join('');
  return `<div class="learningWhiteboard"><div class="whiteboardHeader"><span class="whiteboardTag">Learning Whiteboard</span>${title?`<b>${esc(title)}</b>`:''}</div><div class="whiteboardCanvas">${nodes}</div><p class="whiteboardNote">Схема построена как структурированная HTML-визуализация: без генерации медицинской картинки и без текста, нарисованного image-generation моделью.</p>${showSources?renderWhiteboardSources(area):''}</div>`;
}
function renderVisual(v){
  if(!v)return "";
  if(v.imageUrl){
    const title=esc(v.title||'Схема к вопросу'),alt=esc(v.alt||v.title||'Схема к вопросу'),note=v.note?`<p>${esc(v.note)}</p>`:'';
    return `<figure class="scientificFigure chemistryQuestionFigure"><button class="scientificImageButton" type="button" data-scientific-image data-image-url="${esc(v.imageUrl)}" data-image-title="${title}" data-source-url=""><img src="${esc(v.imageUrl)}" alt="${alt}" loading="lazy"><span class="scientificZoomHint">Открыть схему · увеличить</span></button><figcaption><b>${title}</b>${note}</figcaption></figure>`;
  }
  if(!v.steps?.length)return "";
  const raw=[v.title||"",...(v.steps||[])].join(" ");
  return `${v.skipAbbr?"":renderAbbreviationLead(raw)}${renderLearningWhiteboard({title:v.title||'Процесс',steps:v.steps,area:v.area||'default',showSources:v.showSources!==false})}`;
}
function renderInteractions(t){
  const arr=INTERACTIONS[t.id]||[];
  if(!arr.length)return `<div class="emptyState"><div class="big">🔗</div><b>Взаимодействия пока не заполнены</b><p>Они будут добавляться из комментариев к тестам и теории.</p></div>`;
  return `<div class="list">${arr.map(x=>`<div class="theoryCard"><div class="resultType">${esc(x.type||"Взаимодействие")}</div><h3>${esc(x.title)}</h3><p>${esc(x.summary||"")}</p>${renderVisual({title:"Механизм взаимодействия",kind:"flow",steps:x.chain||[],skipAbbr:true})}${x.note?`<div class="sourceNote">${esc(x.note)}</div>`:""}</div>`).join("")}</div>`;
}
function renderTopicTheory(t){const items=THEORY[t.id]||[];if(!items.length)return `<div class="emptyState"><div class="big">📘</div><b>Теория пока не заполнена</b><p>Структура уже готова. Следующие конспекты добавим сюда по мере подготовки.</p></div>`;return `<div class="list">${items.map(x=>`<div class="theoryCard"><h3>${esc(x.title)}</h3><p>${esc(x.summary)}</p>${x.type==="interactive"?`<a class="moduleButton" href="${x.url}">📈 Открыть интерактивный модуль</a>`:""}${x.body?.length?`<div class="theoryBody">${x.body.map(v=>`<p>• ${esc(v)}</p>`).join("")}</div>`:""}${renderVisual(x.visual?{...x.visual,skipAbbr:true}:x.visual)}</div>`).join("")}</div>`;}
function renderMechanisms(t){const arr=MECHANISMS[t.id]||[];if(!arr.length)return `<div class="emptyState"><div class="big">🧬</div><b>Механизмы пока не заполнены</b><p>Здесь будут схемы receptor → messenger → effect → drug.</p></div>`;return `<div class="list">${arr.map(m=>`<div class="mechanismCard"><h3>${esc(m.title)}</h3><div class="chain">${m.chain.map((v,i)=>`${i?'<div class="chainArrow">→</div>':""}<div class="chainNode">${esc(v)}</div>`).join("")}</div><div class="chips">${m.examples.map(v=>`<span class="chip">${esc(v)}</span>`).join("")}</div></div>`).join("")}</div>`;}
function drugRows(list){return `<div class="list">${list.map(d=>`<div class="drugRow"><div class="drugNum">#${d.n}</div><div class="drugMain" style="flex:1"><b>${esc(d.name)}</b><span>${esc(d.group)}</span><div>${d.topics.map(x=>`<span class="badge">${esc(topicMap[x]?.short||x)}</span>`).join("")}</div></div><div class="rowActions">${favoriteButton("drug",d.n,"Сохранить")}<button class="drugLink" data-route="#drug/${d.n}">Открыть</button></div></div>`).join("")}</div>`;}
function renderTopicDrugs(t){const list=DRUGS.filter(d=>d.topics.includes(t.id));return `<div class="toolbar"><input id="topicDrugSearch" placeholder="Поиск в ${esc(t.short)}…"><span class="badge blue">${list.length} препаратов</span></div><div id="topicDrugList">${drugRows(list)}</div>`;}
function abbrRow(a){return `<div class="abbrRow"><b>${esc(a.abbr)}</b><div class="full">${esc(a.full)}</div><div class="ru">${esc(a.ru)}</div><div class="subtopic">${esc(a.subtopic)}</div></div>`;}
function renderAbbr(t){const arr=ABBREVIATIONS[t.id]||[];if(!arr.length)return `<div class="emptyState"><div class="big">🔤</div><b>Словарь этой темы пока не заполнен</b><p>Аббревиатуры будут добавляться внутри темы, а не в один смешанный список.</p></div>`;return `<div class="toolbar"><input id="abbrSearch" placeholder="Поиск по аббревиатурам ${esc(t.short)}…"><span class="badge">${arr.length}</span></div><div id="abbrList" class="list">${arr.map(abbrRow).join("")}</div>`;}
function renderTestsSection(t, analysis=false){
  const arr=(analysis?TEST_ANALYSES:TESTS).filter(x=>x.topic===t.id);
  if(!arr.length) return `<div class="emptyState"><div class="big">${analysis?"✅":"📝"}</div><b>${analysis?"Разборов":"Тестов"} пока нет</b></div>`;
  if(!analysis){
    const sections=ALL_SOURCE_SECTIONS.filter(s=>s.topic===t.id);
    return `<div class="card"><h3>Интерактивный тест</h3><p>${arr.length} вопросов из загруженного материала. Результаты сохраняются в личной истории обучения и синхронизируются при подключённом аккаунте.</p>
      <button class="moduleButton" data-start-test="topic:${t.id}">▶ Начать тест по теме (${arr.length})</button></div>
      <div class="sectionTitle"><h2>Блоки источника</h2></div>
      <div class="list">${sections.map(s=>`<div class="theoryCard"><h3>${esc(s.title)}</h3><p>${s.count} вопросов</p><button class="drugLink" data-start-test="section:${s.id}">Начать</button></div>`).join("")}</div>`;
  }
  const qmap=Object.fromEntries(TESTS.map(q=>[q.id,q]));
  return `<div class="list">${arr.map(a=>{
    const q=qmap[a.questionId]; if(!q)return "";
    return `<div class="theoryCard"><div class="resultType">${esc(q.sectionTitle)} · вопрос ${q.number}</div><h3>${esc(q.question)}</h3>
      <div class="answerReview"><b>Правильный ответ: ${esc(q.correct)}. ${esc(q.options.find(o=>o.id===q.correct)?.text||q.correctText||"")}</b></div>
      ${a.explanation?.length?`<div class="reviewText">${a.explanation.map(x=>`<p>${esc(x)}</p>`).join("")}</div>`:""}
      ${q.options.map(o=>`<div class="reviewOption ${o.id===q.correct?"isCorrect":""}"><b>${o.id}. ${esc(o.text)}</b><div>${o.id===q.correct?"Правильный вариант.":esc(a.optionExplanations?.[o.id]||"В исходном материале отдельный комментарий к этому варианту не сохранён.")}</div></div>`).join("")}
      ${renderVisual(q.visual||a.visual||SECTION_VISUALS[q.sectionId])}${a.sourceNotes?.length?`<div class="sourceNote">${a.sourceNotes.map(x=>`<div>⚠ ${esc(x)}</div>`).join("")}</div>`:""}
    </div>`;
  }).join("")}</div>`;
}
function renderHigh(t){const arr=HIGH_YIELD[t.id]||[];if(!arr.length)return `<div class="emptyState"><div class="big">⚡</div><b>High-yield пока не заполнен</b></div>`;return `<div class="list">${arr.map((x,i)=>`<div class="highYieldItem"><b>${i+1}.</b> ${esc(x)}</div>`).join("")}</div>`;}

function renderTopicSection(id,section){const t=topicMap[id];if(!t){location.hash="#topics";return;}const titles={theory:"Теория",mechanisms:"Механизмы",drugs:"Препараты",abbr:"Аббревиатуры",interactions:"Взаимодействия",tests:"Тесты",analysis:"Разбор тестов",high:"High-yield"};let content="";if(section==="theory")content=renderTopicTheory(t);if(section==="mechanisms")content=renderMechanisms(t);if(section==="drugs")content=renderTopicDrugs(t);if(section==="abbr")content=renderAbbr(t);if(section==="interactions")content=renderInteractions(t);if(section==="tests")content=renderTestsSection(t,false);if(section==="analysis")content=renderTestsSection(t,true);if(section==="high")content=renderHigh(t);app.innerHTML=sectionShell(t,titles[section]||section,content);bindNav();bindTestStarters();if(section==="drugs"){const input=document.getElementById("topicDrugSearch"),target=document.getElementById("topicDrugList"),base=DRUGS.filter(d=>d.topics.includes(t.id));input?.addEventListener("input",()=>{const q=input.value.toLowerCase();target.innerHTML=drugRows(base.filter(d=>drugSearchText(d).includes(q)));bindNav();});}if(section==="abbr"){const input=document.getElementById("abbrSearch"),target=document.getElementById("abbrList"),base=ABBREVIATIONS[t.id]||[];input?.addEventListener("input",()=>{const q=input.value.toLowerCase();target.innerHTML=base.filter(a=>(a.abbr+" "+a.full+" "+a.ru+" "+a.subtopic).toLowerCase().includes(q)).map(abbrRow).join("");});}}

function renderAllDrugs(){const options=TOPICS.map(t=>`<option value="${t.id}">${esc(t.short)}</option>`).join("");app.innerHTML=header()+`<div class="page"><div class="sectionTitle"><h2>170 препаратов</h2><span class="muted">единая база</span></div><div class="toolbar"><input id="drugSearch" placeholder="Название или фармгруппа…"><select id="drugTopic"><option value="">Все темы</option>${options}</select></div><div id="allDrugList">${drugRows(DRUGS)}</div></div>`+bottomNav("study");bindNav();const s=document.getElementById("drugSearch"),f=document.getElementById("drugTopic"),out=document.getElementById("allDrugList");const apply=()=>{const q=s.value.toLowerCase(),topic=f.value;const rows=DRUGS.filter(d=>(!q||drugSearchText(d).includes(q))&&(!topic||d.topics.includes(topic)));out.innerHTML=drugRows(rows);bindNav();};s.addEventListener("input",apply);f.addEventListener("change",apply);}

function testCommentForDrug(q,d){
  const a=TEST_ANALYSES.find(x=>x.questionId===q.id);
  const all=[];
  const generic=(a?.explanation||q.explanation||[]).filter(Boolean);
  if(generic.length) all.push(...generic);
  const name=(d.name||"").toLowerCase();
  const comments=Object.entries(a?.optionExplanations||q.optionExplanations||{}).filter(([key,text])=>{
    const opt=q.options?.find(o=>o.id===key)?.text||"";
    const hay=(opt+" "+text).toLowerCase();
    return hay.includes(name) || q.drugIds?.length===1;
  }).map(([key,text])=>`${key}: ${text}`);
  if(comments.length) all.push(...comments);
  return [...new Set(all)].slice(0,6);
}
function renderRelatedTestComments(d,relatedTests){
  if(!relatedTests.length)return `<p class="smallMuted">Пока комментариев из тестов по этому препарату нет.</p>`;
  return `<div class="testCommentList">${relatedTests.slice(0,40).map(q=>{
    const comments=testCommentForDrug(q,d);
    return `<div class="testCommentCard"><div class="resultType">${esc(q.sectionTitle)} · №${q.number}</div>${comments.length?comments.map(x=>`<p>Комментарий: ${esc(x)}</p>`).join(""):`<p>Комментарий: ${esc((q.explanation||[]).join(" ")||"Вопрос связан с препаратом, но отдельный текстовый комментарий в источнике не сохранён.")}</p>`}</div>`;
  }).join("")}</div>`;
}
function renderDrug(n){
  const d=drugMap[String(n)];if(!d){location.hash="#drugs";return;}
  const p=profileFor(d),cardio=CARDIO49[d.name],k=DRUG_KNOWLEDGE[String(d.n)],relatedTests=TESTS.filter(q=>q.drugIds?.includes(d.n));
  const relatedInteractions=Object.entries(INTERACTIONS).flatMap(([topic,arr])=>arr.map(x=>({...x,topic}))).filter(x=>x.drugIds?.includes(d.n));
  const sourceScheme=p?.schemeSteps?.length?`${renderVisual({title:"Схема механизма",kind:"flow",steps:p.schemeSteps,skipAbbr:true})}${renderProcessCommentary({commentary:p.schemeSteps.map((step,i)=>`${i+1}. ${step}`)})}`:"";
  app.innerHTML=header()+`<div class="page drugDetail">
    <div class="breadcrumb"><button data-route="#drugs">170 препаратов</button><span>›</span><span>#${d.n}</span></div>
    <div class="topicHeader"><div class="iconFrame">Rx</div><div><h2>${esc(p?.mnn||d.name)}</h2><p>${esc(p?.groupSource||d.group)}</p><div class="chips"><span class="badge blue">№ ${d.n}</span>${d.topics.map(x=>`<span class="badge">${esc(topicMap[x]?.short||x)}</span>`).join("")}</div><div class="entityActions">${favoriteButton("drug",d.n,"Избранное")}${reviewButton("drug",d.n,"Повторить")}</div></div></div>

    <div class="sourceNote profileSourceWarning"><b>Учебная карточка ProPharm v1.0.</b> Данные перенесены из загруженной базы. Точные регуляторные формулировки и PK-числа в исходнике отмечены как требующие второго прохода сверки по Israeli Drug Registry, FDA/Drugs@FDA и ГРЛС.</div>

    <div class="drugProfileAccordion">
      ${profileSection("Основная информация",p?.basic,"i")}
      ${profileSection("Показания к применению",p?.indications,"+")}
      ${profileSection("Противопоказания и ограничения",p?.contraindications,"!")}
      ${p?.mechanismText?`<details class="drugProfileSection" open><summary><span><span class="profileSectionIcon">→</span>Механизм действия</span><span class="schemePlus">＋</span></summary><div class="drugProfileBody">${renderAbbreviationLead((p.mechanismText||"")+" "+(p.scheme||""))}<p>${esc(p.mechanismText)}</p>${sourceScheme}</div></details>`:""}
      ${profileSection("Способы применения",p?.routes,"↗")}
      ${profileSection("Фармакодинамика",p?.pharmacodynamics,"PD")}
      ${profileSection("Фармакокинетика",p?.pharmacokinetics,"PK")}
      ${profileSection("Побочные эффекты",p?.adverseEffects,"⚠")}
      ${renderProfileInteractions(p)}
      ${profileSection("Особые ситуации",p?.specialSituations,"★")}
      ${profileSection("Источники для верификации",p?.sources,"≡")}
    </div>

    ${k?`<div class="detailBox"><h3>Дополнительные экзаменационные комментарии</h3>${k.pearls?.map(x=>`<p>• ${esc(x)}</p>`).join("")||""}${k.visual?renderVisual(k.visual):""}</div>`:""}
    ${cardio?`<div class="detailBox noteCardio"><h3>Связь с электрофизиологией ССС</h3><p>${esc(cardio.note)}</p><a class="moduleButton" href="modules/cardio/index.html">Открыть Cardio-модуль</a></div>`:""}
    ${relatedInteractions.length?`<div class="detailBox"><h3>Дополнительные взаимодействия из тестовой базы</h3>${relatedInteractions.map(x=>`<div class="interactionMini"><b>${esc(x.title)}</b><div>${esc(x.summary)}</div>${renderVisual({title:"Механизм",kind:"flow",steps:x.chain||[]})}</div>`).join("")}</div>`:""}
    <div class="detailBox"><h3>Комментарии из связанных тестов</h3><p class="smallMuted">Сам вопрос здесь не дублируется — показаны только учебные комментарии.</p>${renderRelatedTestComments(d,relatedTests)}</div>
  </div>`+bottomNav("study");bindNav();
}
function testCountForSections(ids=[]){const set=new Set(ids);return TESTS.filter(q=>set.has(q.sectionId)).length}
function renderTestLeaf(id,title,sections=[]){const count=testCountForSections(sections);return accordion({id:`test-nav-${id}`,title,level:2,badge:String(count),icon:doodleIcon('tests'),body:count?`<p>${count} вопросов в текущей импортированной базе.</p><button class="moduleButton" data-start-test="sections:${sections.join(',')}">Начать раздел</button>`:`<div class="emptyState compactEmpty"><b>Раздел зафиксирован</b><p>Вопросы будут добавлены только после подтверждённого импорта соответствующего исходного тестового блока.</p></div>`})}
function renderTestNavNode(node){
 if(node.children){const body=node.children.map(([id,title,sections])=>renderTestLeaf(id,title,sections||[])).join('');return accordion({id:`test-nav-${node.id}`,title:node.title,level:1,icon:doodleIcon('tests'),body:`<div class="accordionStack">${body}</div>`});}
 const count=testCountForSections(node.sections||[]);return accordion({id:`test-nav-${node.id}`,title:node.title,level:1,badge:String(count),icon:doodleIcon('tests'),body:count?`<p>${count} вопросов.</p><button class="moduleButton" data-start-test="sections:${(node.sections||[]).join(',')}">Начать</button>`:`<div class="emptyState compactEmpty"><b>Раздел зафиксирован</b><p>Ожидает подтверждённого импорта исходных экзаменационных вопросов.</p></div>`});
}
function renderTests(){
 const mappedIds=new Set(TEST_NAV_STRUCTURE.flatMap(n=>n.children?n.children.flatMap(x=>x[2]||[]):n.sections||[]));const mapped=TESTS.filter(q=>mappedIds.has(q.sectionId)).length;
 app.innerHTML=header()+`<div class="page"><section class="hero"><h2>Экзаменационные тесты</h2><p>Навигация зафиксирована строго по исходной структуре Success Pharm. Вопросы не перераспределяются по самостоятельно придуманным рубрикам.</p><div class="stats"><div class="stat"><b>${TESTS.length}</b><span>вопросов в базе</span></div><div class="stat"><b>${mapped}</b><span>распределено по подтверждённым блокам</span></div><div class="stat"><b>${TEST_NAV_STRUCTURE.length}</b><span>верхних разделов</span></div></div><div class="warn">Пустой раздел означает, что его исходный пакет вопросов ещё не импортирован/не подтверждён. Он не заполняется автоматически вопросами из соседней темы.</div></section><div class="accordionStack">${TEST_NAV_STRUCTURE.map(renderTestNavNode).join('')}</div></div>`+bottomNav('study');bindNav();bindTestStarters();
}

let memoryLesson=null;
function memoryNodeFromQuestion(q){return {id:q.id,question:q.question,correct:q.correct,correctText:q.options?.find(o=>o.id===q.correct)?.text||q.correctText||'',options:q.options||[],topic:q.topic,source:q.source||q.sectionTitle||'База ProPharm',sourceFile:q.sourceFile||null,number:q.number,sectionTitle:q.sectionTitle,drugIds:q.drugIds||[],disputed:!!q.disputed};}
function shuffled(xs){const a=[...xs];for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]]}return a}
function buildMemoryVariant(node,index=0){
 const q=TESTS.find(x=>x.id===node.id)||node;const correctText=q.options?.find(o=>o.id===q.correct)?.text||q.correctText||'';
 const variants=['source','shuffle','reverse','drug-mechanism','drug-group','negative','source','shuffle','clinical','source'];const type=variants[index%variants.length];
 if(type==='drug-mechanism'&&q.drugIds?.length){const d=drugMap[String(q.drugIds[0])],p=d&&profileFor(d);if(d&&p?.mechanismText){const distract=shuffled(DRUGS.filter(x=>x.n!==d.n).slice(0,30)).slice(0,3).map(x=>profileFor(x)?.mechanismText).filter(Boolean);if(distract.length>=3)return {type,title:'Препарат → механизм',prompt:`Какой механизм соответствует препарату ${d.name}?`,answers:shuffled([{id:'ok',text:p.mechanismText,correct:true},...distract.map((x,i)=>({id:`d${i}`,text:x,correct:false}))]),source:q};}}
 if(type==='drug-group'&&q.drugIds?.length){const d=drugMap[String(q.drugIds[0])];if(d){const distract=shuffled(DRUGS.filter(x=>x.n!==d.n&&x.group!==d.group)).slice(0,3);return {type,title:'Препарат → фармгруппа',prompt:`К какой фармакологической группе относится ${d.name}?`,answers:shuffled([{id:'ok',text:d.group,correct:true},...distract.map((x,i)=>({id:`d${i}`,text:x.group,correct:false}))]),source:q};}}
 if(type==='reverse'&&correctText){return {type,title:'Обратная проверка',prompt:`Какой исходный вопрос связан с ответом «${correctText}»?`,answers:shuffled([{id:'ok',text:q.question,correct:true},...shuffled(TESTS.filter(x=>x.id!==q.id)).slice(0,3).map((x,i)=>({id:`d${i}`,text:x.question,correct:false}))]),source:q};}
 const answers=(q.options||[]).map(o=>({id:o.id,text:o.text,correct:o.id===q.correct}));return {type:type==='shuffle'?'Исходный вопрос · варианты перемешаны':'Экзаменационный вопрос',title:type==='shuffle'?'Варианты перемешаны':'Экзаменационный вопрос',prompt:q.question,answers:type==='shuffle'?shuffled(answers):answers,source:q};
}
function memoryPool(mode='continue',weakIds=[]){
 let qs=TESTS.filter(q=>q.correct&&q.options?.length&&!q.disputed);
 if(mode==='past'||mode==='frequent')qs=qs.filter(q=>q.id.startsWith('past'));
 else if(mode==='errors'&&weakIds.length)qs=qs.filter(q=>weakIds.includes(q.id));
 else if(mode==='mechanisms')qs=qs.filter(q=>q.drugIds?.length);
 else if(mode==='interactions')qs=qs.filter(q=>(q.drugIds||[]).some(id=>interactionCandidatesForDrug(drugMap[String(id)]||{}).length));
 else if(mode==='clinical')qs=qs.filter(q=>/пациент|больн|рецепт|фармацевт|клинич/i.test(q.question||''));
 else if(mode.startsWith('topic:'))qs=qs.filter(q=>q.topic===mode.slice(6));
 return qs.map(memoryNodeFromQuestion);
}
async function renderMemoryTrainer(){
 const st=await trainerStats();const past=PAST_EXAM_QUESTIONS.length,sourceCount=PAST_EXAM_SOURCES.length;
 app.innerHTML=header()+`<div class="page memoryPage"><div class="paperTitle"><span class="handMini">Duolingo × интервальное повторение</span><h2>Тренажёр памяти</h2><p>Отдельный модуль: прогресс здесь не изменяет «Тесты» и «Карточки».</p></div><div class="memoryStats"><div><b>${st.mastery}%</b><span>освоено</span></div><div><b>${st.due}</b><span>к повторению</span></div><div><b>${st.weak}</b><span>слабых узлов</span></div><div><b>${past}</b><span>вопросов прошлых лет</span></div></div><div class="memoryDaily"><span>Серия: <b>${st.dayStreak}</b> дн.</span><span>Сегодня: <b>${st.today}</b> ответов</span><span>Среднее: <b>${st.avgMs?Math.round(st.avgMs/1000):0}</b> с</span><span>Ближайшее повторение: <b>${st.nextReview?new Date(st.nextReview).toLocaleDateString('ru-RU'):'после первого урока'}</b></span></div><button class="memoryContinue" data-memory-mode="continue">▶ Продолжить обучение</button><div class="sectionTitle"><h2>Режимы</h2></div><div class="memoryModeGrid"><button data-memory-mode="new">${doodleIcon('memory')}<b>Новый материал</b><small>Новые учебные узлы</small></button><button data-memory-mode="errors">${doodleIcon('tests')}<b>Повторить ошибки</b><small>Возврат слабых фактов</small></button><button data-memory-mode="past">${doodleIcon('tests')}<b>Экзамены прошлых лет</b><small>${past} подтверждённых вопросов</small></button><button data-memory-mode="frequent">${doodleIcon('cards')}<b>Часто повторяющиеся</b><small>Приоритет экзаменационных источников</small></button><button data-memory-mode="mechanisms">${doodleIcon('schemes')}<b>Механизмы действия</b><small>Препарат ↔ механизм</small></button><button data-memory-mode="interactions">${doodleIcon('interactions')}<b>Взаимодействия</b><small>Риск и клиническое следствие</small></button><button data-memory-mode="clinical">${doodleIcon('profile')}<b>Клинические задачи</b><small>Пациент → решение</small></button><button data-memory-mode="quick">${doodleIcon('kinetics')}<b>Быстрый круг</b><small>5 минут</small></button><button data-memory-mode="mixed">${doodleIcon('systems')}<b>Смешанный марафон</b><small>Разные темы и формы</small></button><button data-memory-mode="control">${doodleIcon('analytics')}<b>Контрольный раунд</b><small>Без приоритета ошибок</small></button></div><div class="sectionTitle"><h2>Источники экзаменов</h2></div><div class="accordionStack">${PAST_EXAM_SOURCES.map(x=>accordion({id:`memory-source-${x.id}`,title:x.title,subtitle:x.note,level:2,badge:x.importStatus,icon:doodleIcon('tests'),body:`<p><b>Год:</b> ${x.year||'не указан в доступном файле'} · <b>Сессия:</b> ${x.session||'не указана'}</p><p>${esc(x.note)}</p>`})).join('')}</div></div>`+bottomNav('study');bindNav();document.querySelectorAll('[data-memory-mode]').forEach(b=>b.onclick=()=>startMemoryLesson(b.dataset.memoryMode));
}
async function startMemoryLesson(mode='continue'){
 const stats=await trainerStats(),weakIds=stats.rows.filter(x=>['error','weak'].includes(x.status)).map(x=>x.node_id);let pool=memoryPool(mode,weakIds);if(mode==='continue'&&weakIds.length){const weak=new Set(weakIds);pool.sort((a,b)=>(weak.has(b.id)?1:0)-(weak.has(a.id)?1:0));}
 pool=shuffled(pool);const size=mode==='quick'?10:mode==='control'?25:20;const selected=pool.slice(0,Math.min(size,pool.length));memoryLesson={mode,index:0,score:0,wrong:0,usedHint:false,startedAt:Date.now(),weakIds,queue:selected.map((n,i)=>buildMemoryVariant(n,i)),errors:[]};location.hash='#memory-lesson';
}
function showMemoryOriginal(src){const q=src;const modal=modalShell(`<div class="modalHandle"></div><h2>Оригинальный экзаменационный узел</h2><div class="sourceNote"><b>${esc(q.sourceFile||q.source||q.sectionTitle||'Источник ProPharm')}</b>${q.number?` · вопрос №${q.number}`:''}</div><h3>${esc(q.question||'')}</h3><div class="explanationText">${(q.options||[]).map(o=>`<p><b>${esc(o.id)}.</b> ${esc(o.text)}</p>`).join('')}</div><div class="correctBanner"><b>Подтверждённый ответ: ${esc(q.correct||'—')}. ${esc(q.options?.find(o=>o.id===q.correct)?.text||q.correctText||'')}</b></div><div class="modalPersonalActions">${favoriteButton("question",q.id,"В избранное")}${reviewButton("question",q.id,"Повторить позже")}</div><button class="modalPrimary" id="memoryOriginalClose">Закрыть</button>`);bindPersonalActions(modal);modal.querySelector('#memoryOriginalClose').onclick=()=>modal.remove();}
function renderMemoryLesson(){const s=memoryLesson;if(!s||!s.queue.length){location.hash='#memory-trainer';return}if(s.index>=s.queue.length)return renderMemoryResults();const task=s.queue[s.index],src=task.source;const progress=Math.round(s.index/s.queue.length*100);app.innerHTML=header()+`<div class="page memoryLesson"><div class="memoryLessonTop"><span>${esc(task.title)}</span><b>${s.index+1}/${s.queue.length}</b></div><div class="memoryProgress"><i style="width:${progress}%"></i></div><div class="memorySource">${esc(src.sectionTitle||src.source||'ProPharm')}${src.number?` · вопрос №${src.number}`:''}</div><div class="memoryQuestion"><h2>${esc(task.prompt)}</h2><div class="memoryAnswers">${task.answers.map(a=>`<button data-memory-answer="${esc(a.id)}" class="memoryAnswer">${esc(a.text)}</button>`).join('')}</div><div class="questionPersonalActions memoryPersonalActions">${favoriteButton("question",src.id,"В избранное")}${reviewButton("question",src.id,"Повторить позже")}</div><div id="memoryFeedback"></div><div class="memoryControls"><button id="memoryHint" class="moduleButton secondary">Подсказка</button></div></div></div>`+bottomNav('study');bindNav();bindPersonalActions();const started=Date.now();document.getElementById('memoryHint').onclick=()=>{s.usedHint=true;document.getElementById('memoryFeedback').innerHTML=`<div class="hintBox"><b>Подсказка:</b> Определи тему и исключи варианты, относящиеся к другой фармгруппе/механизму. Правильный ответ пока не показывается.</div>`};document.querySelectorAll('[data-memory-answer]').forEach(btn=>btn.onclick=async()=>{const a=task.answers.find(x=>x.id===btn.dataset.memoryAnswer),correct=!!a?.correct;document.querySelectorAll('[data-memory-answer]').forEach(x=>x.disabled=true);btn.classList.add(correct?'good':'bad');if(correct){s.score++;}else{s.wrong++;s.errors.push(src.id);const c=task.answers.find(x=>x.correct);document.querySelectorAll('[data-memory-answer]').forEach(x=>{if(x.dataset.memoryAnswer===c?.id)x.classList.add('good')});const node=memoryNodeFromQuestion(src);const retry=buildMemoryVariant(node,s.index+3);s.queue.splice(Math.min(s.queue.length,s.index+3),0,retry);s.queue.push(buildMemoryVariant(node,s.queue.length+1));}await recordTrainerAnswer(src.id,{correct,usedHint:s.usedHint,responseMs:Date.now()-started,sourceId:src.sectionId,topic:src.topic});document.getElementById('memoryFeedback').innerHTML=`<div class="memoryFeedback ${correct?'goodBox':'badBox'}"><b>${correct?'✓ Правильно':'✕ Ошибка'}</b><p>${correct?'Этот факт вернётся позже в другой форме.':`Правильно: ${esc(task.answers.find(x=>x.correct)?.text||'')}. Вопрос вернётся через несколько заданий.`}</p><div class="memoryOriginLine">Источник: ${esc(src.sourceFile||src.source||src.sectionTitle||'ProPharm')}${src.number?` · №${src.number}`:''}</div><div class="memoryFeedbackActions"><button id="memoryOriginal" class="moduleButton secondary">Открыть оригинальный вопрос</button><button id="memoryNext" class="moduleButton">Продолжить</button></div></div>`;document.getElementById('memoryOriginal').onclick=()=>showMemoryOriginal(src);document.getElementById('memoryNext').onclick=()=>{s.index++;s.usedHint=false;renderMemoryLesson()};});}
function renderMemoryResults(){const s=memoryLesson,acc=s.queue.length?Math.round(s.score/s.queue.length*100):0;app.innerHTML=header()+`<div class="page"><div class="paperTitle"><span class="handMini">Раунд завершён</span><h2>Тренажёр памяти</h2><p>Ошибки уже поставлены в отдельный цикл повторения.</p></div><div class="memoryStats"><div><b>${s.score}</b><span>правильно</span></div><div><b>${s.wrong}</b><span>ошибок</span></div><div><b>${acc}%</b><span>точность</span></div></div><button class="moduleButton" data-route="#memory-trainer">Вернуться в тренажёр</button></div>`+bottomNav('study');bindNav();memoryLesson=null;}
function renderSearch(){app.innerHTML=header()+`<div class="page"><div class="sectionTitle"><h2>Глобальный поиск</h2></div><input id="globalSearch" placeholder="Например: SERCA, metoprolol, QT, SGLT2…"><div id="globalResults" class="globalResults" style="margin-top:10px"><div class="emptyState"><div class="big">🔎</div><b>Начни вводить запрос</b><p>Поиск идёт по препаратам, аббревиатурам и теоретическим модулям.</p></div></div></div>`+bottomNav("search");bindNav();const input=document.getElementById("globalSearch"),out=document.getElementById("globalResults");input.addEventListener("input",()=>{const q=input.value.trim().toLowerCase();if(!q){out.innerHTML=`<div class="emptyState"><div class="big">🔎</div><b>Начни вводить запрос</b></div>`;return;}const dr=DRUGS.filter(d=>drugSearchText(d).includes(q)).slice(0,20);const ab=ALL_ABBREVIATIONS.map(a=>({...a,topic:a.subtopic?.startsWith("ССС")?"cardio":""})).filter(a=>(a.abbr+" "+a.full+" "+a.ru+" "+a.subtopic).toLowerCase().includes(q)).slice(0,30);const integrated=[...CARDIO_PHYSIOLOGY.map(x=>({...x,kind:"Анатомия / физиология"})),...CARDIO_BIOCHEMISTRY.map(x=>({...x,kind:"Биохимия"})),...CARDIO_PATHOLOGIES.map(x=>({...x,summary:x.definition,kind:"Патофизиология"})),...CARDIO_DIAGNOSTICS.map(x=>({...x,kind:"Диагностика"}))].filter(x=>cardioBlockText(x).toLowerCase().includes(q)).slice(0,20);const th=Object.entries(THEORY).flatMap(([topic,arr])=>arr.map(x=>({...x,topic}))).filter(x=>(x.title+" "+x.summary).toLowerCase().includes(q)).slice(0,20);const html=[...dr.map(d=>`<div class="drugRow"><div><div class="resultType">Препарат</div><b>${esc(d.name)}</b><div class="smallMuted">${esc(d.group)}</div></div><button class="drugLink" data-route="#drug/${d.n}">Открыть</button></div>`),...ab.map(a=>`<div class="abbrRow"><div class="resultType">Термин / сокращение ${a.topic?`· ${esc(topicMap[a.topic]?.short||a.topic)}`:""}</div><b>${esc(a.abbr)}</b><div class="full">${esc(a.full||"")}</div><div class="ru">${esc(a.ru)}</div></div>`),...integrated.map(x=>`<div class="theoryCard"><div class="resultType">ССС · ${esc(x.kind)}</div><h3>${esc(x.title)}</h3><p>${esc(x.summary||"")}</p><button class="drugLink" data-route="#system/cardiovascular/${x.kind==="Биохимия"?"biochemistry":x.kind==="Патофизиология"?"pathophysiology":x.kind==="Диагностика"?"diagnostics":"physiology"}">Открыть раздел</button></div>`),...th.map(x=>`<div class="theoryCard"><div class="resultType">Теория · ${esc(topicMap[x.topic]?.short||x.topic)}</div><h3>${esc(x.title)}</h3><p>${esc(x.summary)}</p></div>`)].join("");out.innerHTML=html||`<div class="emptyState"><b>Ничего не найдено</b></div>`;bindNav();});}

function renderTheoryHub(){
 const groups=TOPICS.map(t=>({t,items:THEORY[t.id]||[]})).filter(x=>x.items.length);
 app.innerHTML=header()+`<div class="page"><div class="paperTitle"><span class="handMini">Учёба</span><h2>Теория</h2><p>Конспекты по темам, без смешивания разделов.</p></div><div class="topicGrid">${groups.map(({t,items})=>`<div class="card clickCard softPaper" data-route="#topic/${t.id}/theory"><div class="cardHead"><div class="iconFrame topicLineIcon">${topicIcon(t.id)}</div><div><h3>${esc(t.title)}</h3><p>${items.length} материалов</p><span class="badge blue">открыть теорию</span></div></div></div>`).join("")}</div></div>`+bottomNav("study");bindNav();
}
function renderTablesHub(){
 const topics=TOPICS.map(t=>({t,tables:STUDY_TABLES[t.id]||[]})).filter(x=>x.tables.length);
 const tableHtml=(tbl,topicId,i)=>accordion({id:`table-${topicId}-${i}`,title:tbl.title,level:2,body:`${renderAbbreviationLead([tbl.title,...tbl.columns,...tbl.rows.flat(),tbl.note||""] .join(" "))}<div class="tableScroll"><table><thead><tr>${tbl.columns.map(c=>`<th>${esc(c)}</th>`).join("")}</tr></thead><tbody>${tbl.rows.map(r=>`<tr>${r.map(c=>`<td>${esc(c)}</td>`).join("")}</tr>`).join("")}</tbody></table></div>${tbl.note?`<div class="tableNote">${esc(tbl.note)}</div>`:""}`});
 app.innerHTML=header()+`<div class="page"><div class="paperTitle"><span class="handMini">Быстрый повтор</span><h2>Таблицы</h2><p>Разделы и таблицы свёрнуты по умолчанию. Открой систему/тему, затем конкретную таблицу.</p></div><div class="accordionStack">${topics.map(({t,tables})=>accordion({id:`tables-topic-${t.id}`,title:t.title,count:tables.length,level:1,body:tables.map((x,i)=>tableHtml(x,t.id,i)).join("")})).join("")}</div></div>`+bottomNav("study");bindNav();
}
function schemeGroups(){
 const out={};
 const add=(topic,item)=>{if(!out[topic])out[topic]=[];const key=(item.title+"|"+(item.steps||[]).join("|")).toLowerCase();if(!out[topic].some(x=>x._key===key))out[topic].push({...item,_key:key});};
 TOPICS.forEach(t=>{
   (THEORY[t.id]||[]).forEach(x=>{if(x.visual?.steps?.length)add(t.id,{title:x.visual.title||x.title,kind:x.visual.kind||"flow",steps:x.visual.steps,explanation:x.summary,details:x.body||[],examples:[]});});
   (MECHANISMS[t.id]||[]).forEach(m=>add(t.id,{title:m.title,kind:"flow",steps:m.chain||[],explanation:`Механизм: ${(m.chain||[]).join(" → ")}.`,details:[],examples:m.examples||[]}));
   (INTERACTIONS[t.id]||[]).forEach(x=>add(t.id,{title:`Взаимодействие: ${x.title}`,kind:"flow",steps:x.chain||[],explanation:x.summary||"Лекарственное взаимодействие из тестовой/теоретической базы.",details:x.note?[x.note]:[],examples:[]}));
 });
 ALL_SOURCE_SECTIONS.forEach(sec=>{const v=SECTION_VISUALS[sec.id];if(v?.steps?.length)add(sec.topic,{title:`${sec.title}: ${v.title}`,kind:v.kind||"flow",steps:v.steps,explanation:`Схема к экзаменационному блоку «${sec.title}».`,details:[],examples:[]});});
 DRUGS.forEach(d=>{const p=profileFor(d);if(p?.schemeSteps?.length)add(d.primaryTopic||d.topics?.[0]||"",{title:`${d.name}: механизм действия`,kind:"flow",steps:p.schemeSteps,explanation:p.mechanismText||p.scheme,details:p.pharmacodynamics?[`Фармакодинамика: ${p.pharmacodynamics}`]:[],examples:[d.name]});});
 CARDIO_BIOCHEMISTRY.forEach(x=>add("cardio",{title:`ССС · ${x.title}`,kind:"integrated-cardio",steps:x.steps||[],explanation:x.summary,details:x.commentary||[],examples:(x.drugIds||[]).map(id=>drugMap[String(id)]?.name).filter(Boolean),integrated:x}));
 CARDIO_PHYSIOLOGY.forEach(x=>add("cardio",{title:`ССС · ${x.title}`,kind:"integrated-cardio",steps:x.points||[],explanation:x.summary,details:x.commentary||[],examples:[],integrated:x}));
 return out;
}
function schemeHumanTitle(x){
 const raw=String(x.title||''),hay=(raw+' '+(x.steps||[]).join(' ')).toLowerCase();
 const rules=[
  [/β.?1|beta.?1|gs.*camp|camp.*pka/,'Как β₁-адренорецептор усиливает работу сердца'],
  [/α.?1|alpha.?1|gq.*plc|ip3.*dag/,'Как α₁-адренорецептор вызывает сокращение сосудов'],
  [/m.?2|gi.*adenyl|парасимпат/,'Как парасимпатическая система замедляет работу сердца'],
  [/raas|renin|angiotensin|aldosterone/,'Как RAAS повышает давление и объём циркулирующей крови'],
  [/nitric|no.*cgmp|guanylate/,'Как оксид азота расслабляет сосуды'],
  [/na.?\/k|atpase.*ncx|digoxin/,'Как дигоксин повышает внутриклеточный Ca²⁺ и сократимость сердца'],
  [/herg|ikr|qt|torsad/,'Почему некоторые препараты удлиняют QT и повышают риск torsades de pointes'],
  [/nav1|fast na|qrs|натриев.*канал/,'Почему блокада быстрых Na⁺-каналов расширяет QRS'],
  [/action potential|потенциал действия.*кардио/,'Как возникает потенциал действия рабочего кардиомиоцита'],
  [/pacemaker|sa node|синус.*уз|funny current|hcn/,'Как клетки синусового узла самостоятельно создают сердечный ритм'],
  [/excitation|contraction|ryr2|troponin.*ca/,'Как электрический импульс превращается в сокращение кардиомиоцита'],
  [/frank|starling/,'Почему увеличение наполнения сердца усиливает сокращение'],
  [/wiggers|сердечный цикл/,'Что происходит во время одного сердечного цикла'],
  [/coronar/,'Как миокард получает кровь и кислород'],
  [/conduct|his|purkinje|проводящ/,'Как электрический импульс проходит через сердце'],
  [/hmg.?coa|mevalonate|statin/,'Как синтезируется холестерин и где действуют статины'],
  [/gaba.?a|chloride.*gaba/,'Как GABA снижает возбудимость нейрона'],
  [/insulin.*rtk|irs.*pi3k|akt.*glut4/,'Как инсулин увеличивает поступление глюкозы в клетку'],
  [/coag|factor xa|thrombin|fibrin/,'Как формируется фибриновый тромб и где действуют антикоагулянты'],
  [/platelet|p2y12|cox.?1.*txa/,'Как активируются тромбоциты и где действуют антиагреганты'],
  [/nephron|nkcc2|ncc|enac|diure/,'Где диуретики действуют в нефроне и какие ионы изменяют'],
  [/glycolysis|гликолиз/,'Как глюкоза превращается в пируват и образует ATP'],
  [/electron transport|complex i|cytochrome c|atp synthase/,'Как дыхательная цепь создаёт протонный градиент и ATP'],
  [/dna.*rna.*protein|central dogma/,'Как генетическая информация превращается из DNA в RNA и белок'],
  [/replication|helicase|dna polymerase/,'Как клетка копирует DNA перед делением'],
  [/transcription|rna polymerase/,'Как информация DNA переписывается в RNA'],
  [/translation|ribosome|trna/,'Как рибосома синтезирует белок по mRNA'],
  [/apopt|caspase|cytochrome c/,'Как клетка запускает программируемую гибель — апоптоз']
 ];
 for(const [re,title] of rules)if(re.test(hay))return title;
 const clean=raw.replace(/^ССС\s*[·:—-]\s*/,'').replace(/^Взаимодействие:\s*/,'').trim();
 if(/^(Как|Почему|Что|Где|Когда|Путь|Механизм|Сердечный|Потенциал|Коронар|Проводящ|Генетическ|Качественн|Классификац|Метаболизм|Синтез|Распределение|Всасывание|Выведение|Клиренс|Период|Клет)/i.test(clean))return clean;
 if(raw.startsWith('Взаимодействие:'))return `Как развивается лекарственное взаимодействие: ${clean}`;
 return `Как работает процесс: ${clean}`;
}
function renderSchemeItem(x,topicId,i){
 const humanTitle=schemeHumanTitle(x);
 const terms=x.integrated?renderAbbreviationLead(cardioBlockText(x.integrated)):renderAbbreviationLead([x.title,...(x.steps||[])].join(" "));
 const area=x.integrated?(CARDIO_PHYSIOLOGY.some(z=>z.id===x.integrated.id)?'physiology':'biochemistry'):'default';
 const visual=x.integrated?renderMedicalVisual(x.integrated,area):renderLearningWhiteboard({title:humanTitle,steps:x.steps||[],area,showSources:true});
 const explanation=`<div class="schemeExplanation"><div class="sourceNote"><b>Молекулярная/процессная цепочка:</b> ${esc(x.title||'')}</div><h4>Что показывает схема</h4><p>${esc(x.explanation||"")}</p>${x.details?.length?x.details.map((d,n)=>`<p><b>${n+1}.</b> ${esc(d)}</p>`).join(""):""}${x.examples?.length?`<div class="chips"><span class="smallMuted">Связанные препараты / примеры:</span>${x.examples.map(v=>`<span class="chip">${esc(v)}</span>`).join("")}</div>`:""}</div>`;
 return accordion({id:`scheme-${topicId}-${i}`,title:humanTitle,subtitle:x.title!==humanTitle?x.title:'',level:2,body:`${accordion({id:`scheme-${topicId}-${i}-terms`,title:'Термины и сокращения',level:3,body:terms||'<p class="smallMuted">Отдельных сокращений нет.</p>'})}${accordion({id:`scheme-${topicId}-${i}-visual`,title:'Learning Whiteboard / научная иллюстрация',level:3,body:visual})}${accordion({id:`scheme-${topicId}-${i}-comment`,title:'Что происходит на схеме',level:3,body:x.integrated?renderProcessCommentary(x.integrated):explanation})}${accordion({id:`scheme-${topicId}-${i}-sources`,title:'Источники',level:3,body:x.integrated?renderVisualSources(area)||renderWhiteboardSources(area):renderWhiteboardSources(area)})}`});
}
function renderSchemesHub(){
 const groups=schemeGroups(),topics=TOPICS.map(t=>({t,items:groups[t.id]||[]})).filter(x=>x.items.length);
 const systemRows=topics.map(({t,items})=>accordion({id:`schemes-topic-${t.id}`,title:t.title,count:items.length,level:1,body:items.map((x,i)=>renderSchemeItem(x,t.id,i)).join("")})).join("");
 const foundationRows=FOUNDATIONAL_SECTIONS.map(sec=>{const items=foundationContent(sec.id).filter(x=>x.steps?.length).map(x=>({title:x.title,steps:x.steps,explanation:(x.theory||[])[0]||x.subtitle||'',details:(x.theory||[]).slice(1),examples:[]}));if(!items.length)return '';return accordion({id:`schemes-found-${sec.id}`,title:`Базовые дисциплины · ${sec.title}`,count:items.length,level:1,icon:foundationIcon(sec.id),body:items.map((x,i)=>renderSchemeItem(x,`foundation-${sec.id}`,i)).join('')})}).join('');
 app.innerHTML=header()+`<div class="page"><div class="paperTitle"><span class="handMini">Наглядно</span><h2>Схемы</h2><p>Каждая схема теперь названа по смыслу процесса. Внутри: расшифровка терминов → Learning Whiteboard/научная иллюстрация → пошаговое объяснение → источники.</p></div><div class="accordionStack">${systemRows}${foundationRows}</div></div>`+bottomNav("study");bindNav();
}
function renderSchemesTopic(topicId){
 const t=topicMap[topicId];if(!t){location.hash="#schemes";return;}const items=schemeGroups()[topicId]||[];
 app.innerHTML=header()+`<div class="page"><div class="breadcrumb"><button data-route="#schemes">Схемы</button><span>›</span><span>${esc(t.short)}</span></div><div class="topicHeader"><div class="iconFrame topicLineIcon">${topicIcon(t.id)}</div><div><h2>Схемы: ${esc(t.title)}</h2><p>Открой конкретную схему. Медицинские изображения берутся из проверенных источников; процессные схемы — Learning Whiteboard.</p></div></div><div class="accordionStack">${items.map((x,i)=>renderSchemeItem(x,t.id,i)).join("")}</div></div>`+bottomNav("study");bindNav();
}
let flashIndex=0,flashRevealed=false,flashFilter="all",flashQuery="";
function stableFlashId(card){
 let h=2166136261,s=[card.type,card.drugId||'',card.topic||'',card.front||''].join('|');
 for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619)}
 return `fc-${card.type}-${(h>>>0).toString(36)}`;
}
function buildFlashCards(){
 const cards=[];
 DRUGS.forEach(d=>{
   const p=profileFor(d);
   cards.push({type:"drug",topic:d.primaryTopic||d.topics?.[0]||"",drugId:d.n,title:d.name,front:`К какой фармакологической группе относится ${d.name}?`,back:[p?.groupSource||d.group,`Темы: ${d.topics.map(x=>topicMap[x]?.short||x).join(", ")}`]});
   if(p?.mechanismText)cards.push({type:"profileMechanism",topic:d.primaryTopic||d.topics?.[0]||"",drugId:d.n,title:d.name,front:`Механизм действия ${d.name}`,back:[p.mechanismText]});
   if(p?.indications)cards.push({type:"indications",topic:d.primaryTopic||d.topics?.[0]||"",drugId:d.n,title:d.name,front:`Основные показания ${d.name}`,back:[p.indications]});
   if(p?.pharmacokinetics)cards.push({type:"pk",topic:d.primaryTopic||d.topics?.[0]||"",drugId:d.n,title:d.name,front:`Что важно помнить о фармакокинетике ${d.name}?`,back:[p.pharmacokinetics]});
   if(p?.adverseEffects)cards.push({type:"adverse",topic:d.primaryTopic||d.topics?.[0]||"",drugId:d.n,title:d.name,front:`Основные побочные эффекты ${d.name}`,back:[p.adverseEffects]});
   if(p?.interactionsText)cards.push({type:"profileInteraction",topic:d.primaryTopic||d.topics?.[0]||"",drugId:d.n,title:d.name,front:`Ключевые взаимодействия ${d.name}`,back:[p.interactionsText]});
   const k=DRUG_KNOWLEDGE[String(d.n)];
   if(k?.mechanism?.length)cards.push({type:"mechanism",topic:d.primaryTopic||d.topics?.[0]||"",drugId:d.n,title:d.name,front:`Каков механизм действия ${d.name}?`,back:k.mechanism});
   if(k?.pearls?.length)k.pearls.forEach((p,i)=>cards.push({type:"pearl",topic:d.primaryTopic||d.topics?.[0]||"",drugId:d.n,title:d.name,front:`Что важно помнить о ${d.name}? · карточка ${i+1}`,back:[p]}));
 });
 TESTS.forEach(q=>{
   (q.drugIds||[]).forEach(drugId=>{
     const d=drugMap[String(drugId)];if(!d)return;
     const correct=q.options?.find(o=>o.id===q.correct);
     cards.push({type:"test",topic:q.topic||d.primaryTopic,drugId,title:d.name,front:q.question,back:[`Правильный ответ: ${q.correct}. ${correct?.text||q.correctText||""}`,...(q.explanation||[])]});
     Object.entries(q.optionExplanations||{}).forEach(([oid,comment])=>{
       const opt=q.options?.find(o=>o.id===oid);
       if(!comment||!opt)return;
       cards.push({type:"comment",topic:q.topic||d.primaryTopic,drugId,title:d.name,front:`Комментарий к варианту ${oid} в вопросе про ${d.name}: «${opt.text}»`,back:[comment]});
     });
   });
 });
 CARDIO_FLASHCARDS.forEach(c=>cards.push({type:"cardioIntegrated",topic:"cardio",drugId:"",title:c.title,front:c.front,back:[c.back],cardioArea:c.area}));
 return cards.map(c=>({...c,id:stableFlashId(c)}));
}
function filteredFlashCards(){
 const all=buildFlashCards();
 return all.filter(c=>(flashFilter==="all"||c.type===flashFilter)&&(!flashQuery||(c.title+" "+c.front+" "+c.back.join(" ")).toLowerCase().includes(flashQuery.toLowerCase())));
}
function renderCardsHub(){
 const cards=filteredFlashCards();
 if(flashIndex>=cards.length)flashIndex=0;
 const d=cards[flashIndex];
 const typeNames={drug:"Фармгруппа",profileMechanism:"Механизм из базы 170",indications:"Показания",pk:"Фармакокинетика",adverse:"Побочные эффекты",profileInteraction:"Взаимодействия",mechanism:"Механизм из тестов",pearl:"Экзаменационный комментарий",test:"Вопрос из теста",comment:"Комментарий к варианту",cardioIntegrated:"ССС · интегрированная карточка"};
 app.innerHTML=header()+`<div class="page"><div class="paperTitle"><span class="handMini">Повторение</span><h2>Карточки</h2><p>Карточки формируются из 170 препаратов, механизмов, тестовых вопросов и комментариев к вариантам.</p></div>
 <div class="flashToolbar"><input id="flashSearch" value="${esc(flashQuery)}" placeholder="Поиск препарата или текста…"><select id="flashType"><option value="all">Все типы</option>${Object.entries(typeNames).map(([k,v])=>`<option value="${k}" ${flashFilter===k?"selected":""}>${v}</option>`).join("")}</select></div>
 <div class="flashStats"><span class="badge blue">${cards.length} карточек</span><span class="badge">прогресс сохраняется</span></div>
 ${d?`<div class="flashWrap"><button class="flashCard ${flashRevealed?"revealed":""}" id="flashCard"><span class="flashNum">${esc(typeNames[d.type]||d.type)} · #${d.drugId||""}</span><h2>${esc(d.title)}</h2>${renderAbbreviationLead([d.front,...d.back].join(" "))}${flashRevealed?`<div class="flashAnswer">${d.back.map(x=>`<p>${esc(x)}</p>`).join("")}</div>`:`<p>${esc(d.front)}</p><span class="handMini">нажми, чтобы перевернуть ↻</span>`}</button><div class="flashPersonal">${favoriteButton("card",d.id,"Избранное")}${reviewButton("card",d.id,"Повторить")}<button class="miniAction" id="knowCard">✓ Знаю</button></div><div class="flashControls"><button id="prevCard">← Назад</button><span>${flashIndex+1} / ${cards.length}</span><button id="nextCard">Дальше →</button></div></div>`:`<div class="emptyState"><div class="big">🗂️</div><b>Нет карточек по выбранному фильтру</b></div>`}</div>`+bottomNav("study");bindNav();
 const search=document.getElementById("flashSearch"),type=document.getElementById("flashType");
 search.oninput=e=>{flashQuery=e.target.value;flashIndex=0;flashRevealed=false;clearTimeout(window.__flashTimer);window.__flashTimer=setTimeout(renderCardsHub,180)};
 type.onchange=e=>{flashFilter=e.target.value;flashIndex=0;flashRevealed=false;renderCardsHub()};
 if(d){document.getElementById("flashCard").onclick=()=>{flashRevealed=!flashRevealed;renderCardsHub()};document.getElementById("prevCard").onclick=()=>{flashIndex=(flashIndex-1+cards.length)%cards.length;flashRevealed=false;renderCardsHub()};document.getElementById("nextCard").onclick=()=>{flashIndex=(flashIndex+1)%cards.length;flashRevealed=false;renderCardsHub()};document.getElementById("knowCard")?.addEventListener("click",async()=>{await recordStudyPosition({system_id:d.topic||"global",section_id:"cards",entity_id:d.id,route:"#cards",completed:true});toast("Карточка отмечена как изученная");flashIndex=(flashIndex+1)%cards.length;flashRevealed=false;renderCardsHub()});}
}
function renderSettingsHub(){
 const profile=authState.profile;
 app.innerHTML=header()+`<div class="page"><div class="paperTitle"><span class="handMini">Под себя</span><h2>Настройки</h2><p>Интерфейс, аккаунт и синхронизация.</p>${authBadge()}</div>
 <div class="settingsList"><label class="settingRow"><span><b>Крупный текст</b><small>Увеличить шрифт интерфейса</small></span><input type="checkbox" id="largeText" ${uiSettings.largeText?"checked":""}></label><label class="settingRow"><span><b>Меньше анимаций</b><small>Уменьшить движение элементов</small></span><input type="checkbox" id="reducedMotion" ${uiSettings.reducedMotion?"checked":""}></label></div>
 <div class="sectionTitle"><h2>Аккаунт и учёба</h2></div><div class="sectionGrid profileGrid">
 <div class="card clickCard" data-route="#profile"><h3>Профиль</h3><p>${esc(profile?.name||profile?.email||'Профиль')}</p></div>
 <div class="card clickCard" data-route="#my-study"><h3>Моя учёба</h3><p>История тестов и успешность</p></div>
 <div class="card clickCard" data-route="#favorites"><h3>Избранное</h3><p>Сохранённые материалы</p></div>
 <div class="card clickCard" data-route="#review"><h3>Повторить</h3><p>Очередь слабых тем</p></div>
 ${isAdmin()?`<div class="card clickCard adminCard" data-route="#admin"><h3>Администрирование <span id="settingsPendingBadge" class="pendingDot" hidden>0</span></h3><p>Заявки, одобрение и уведомления</p></div>`:""}
 </div><button class="moduleButton secondary" id="syncNow">Синхронизировать сейчас</button><button class="moduleButton dangerSoft" id="logoutBtn">Выйти из аккаунта</button></div>`+bottomNav("settings");bindNav();
 document.getElementById("largeText").onchange=e=>{uiSettings.largeText=e.target.checked;localStorage.setItem(UI_SETTINGS_KEY,JSON.stringify(uiSettings));saveUserSettings(uiSettings).catch(()=>{});applyUiSettings()};
 document.getElementById("reducedMotion").onchange=e=>{uiSettings.reducedMotion=e.target.checked;localStorage.setItem(UI_SETTINGS_KEY,JSON.stringify(uiSettings));saveUserSettings(uiSettings).catch(()=>{});applyUiSettings()};
 document.getElementById('syncNow')?.addEventListener('click',async()=>{try{await syncPending();await hydrateFromCloud();toast('Синхронизация завершена')}catch(e){toast(e.message||String(e),'bad')}});
 document.getElementById('logoutBtn')?.addEventListener('click',async()=>{await signOut();location.hash='#home';router()});
 if(isAdmin())refreshAdminPendingCount().then(n=>{const b=document.getElementById('settingsPendingBadge');if(b){b.textContent=String(n);b.hidden=!n}}).catch(()=>{});
}
function renderAbbrHub(){return renderSystemAbbrHub();}
async function renderProfile(){
 const p=authState.profile||{};
 app.innerHTML=header()+`<div class="page"><div class="paperTitle"><span class="handMini">Мой ProPharm</span><h2>Профиль</h2><p>Данные аккаунта и способы входа.</p>${authBadge()}</div>
 <div class="profileHero"><div class="profileAvatar">${esc((p.name||p.email||'P').slice(0,1).toUpperCase())}</div><div><h3>${esc(p.name||'Пользователь')}</h3><p>${esc(p.email||'')}</p><div class="chips"><span class="chip">${esc(p.provider||'email')}</span><span class="chip">${esc(p.status||'pending')}</span><span class="chip">${esc(p.role||'user')}</span></div></div></div>
 ${isAuthConfigured()?`<div class="card"><h3>Имя профиля</h3><div class="inlineForm"><input id="profileName" value="${esc(p.name||'')}" placeholder="Имя"><button class="drugLink" id="saveProfile">Сохранить</button></div></div><div class="card"><h3>Способ входа</h3><p>Авторизация ProPharm настроена только через подтверждённый e-mail и пароль.</p></div>`:''}
 <div class="sectionGrid"><div class="card clickCard" data-route="#my-study"><h3>Моя учёба</h3><p>Статистика и история тестов</p></div><div class="card clickCard" data-route="#favorites"><h3>Избранное</h3><p>Сохранённые сущности</p></div><div class="card clickCard" data-route="#review"><h3>Повторить</h3><p>Материал для повторения</p></div><div class="card clickCard" data-route="${esc(lastStudyRoute())}"><h3>Продолжить обучение</h3><p>${esc(lastStudyRoute())}</p></div></div></div>`+bottomNav('settings');bindNav();
 document.getElementById('saveProfile')?.addEventListener('click',async()=>{try{await updateOwnProfile({name:document.getElementById('profileName').value});toast('Профиль сохранён');renderProfile()}catch(e){toast(e.message||String(e),'bad')}});
}
async function renderMyStudy(){
 app.innerHTML=header()+`<div class="page"><div class="paperTitle"><span class="handMini">Персональная статистика</span><h2>Моя учёба</h2><p>Загружаю локальную историю…</p></div></div>`+bottomNav('settings');bindNav();
 const st=await getLearningStats();
 const recent=[...st.sessions].sort((a,b)=>String(b.completed_at||b.created_at).localeCompare(String(a.completed_at||a.created_at))).slice(0,12);
 const weak=[...st.questions].filter(x=>(x.wrong_count||0)>0).sort((a,b)=>(b.wrong_count||0)-(a.wrong_count||0)).slice(0,10);
 const systemStats=SYSTEMS.map(system=>{
   const source=new Set(systemSourceTopics(system));
   const rows=st.questions.filter(r=>{const q=TESTS.find(x=>x.id===r.question_id);return q&&source.has(q.topic)});
   const correct=rows.reduce((n,r)=>n+(r.correct_count||0),0),wrong=rows.reduce((n,r)=>n+(r.wrong_count||0),0),attempts=rows.reduce((n,r)=>n+(r.attempts||0),0),first=rows.reduce((n,r)=>n+(r.first_try_correct_count||0),0);
   return {system,rows:rows.length,attempts,wrong,accuracy:(correct+wrong)?Math.round(correct/(correct+wrong)*100):0,firstTry:attempts?Math.round(first/attempts*100):0};
 }).filter(x=>x.attempts>0);
 app.innerHTML=header()+`<div class="page"><div class="paperTitle"><span class="handMini">Персональная статистика</span><h2>Моя учёба</h2><p>История хранится локально и при настроенном аккаунте синхронизируется между устройствами.</p></div>
 <div class="stats learningStats"><div class="stat"><b>${st.sessions.length}</b><span>тестовых сессий</span></div><div class="stat"><b>${st.accuracy}%</b><span>точность выборов</span></div><div class="stat"><b>${st.firstTryRate}%</b><span>с 1-й попытки</span></div><div class="stat"><b>${st.wrong}</b><span>ошибочных выборов</span></div></div>
 <div class="quickStudy"><button class="moduleButton" data-route="${esc(lastStudyRoute())}">Продолжить обучение</button><button class="moduleButton secondary" data-route="#review">Повторить слабые темы (${st.review.length})</button></div>
 <div class="sectionTitle"><h2>По системам</h2><span class="muted">${systemStats.length}</span></div>${systemStats.length?`<div class="list systemProgressList">${systemStats.map(x=>`<div class="theoryCard"><div class="resultType">${esc(x.system.short||x.system.title)}</div><h3>${x.accuracy}% точность</h3><p>С первой попытки: ${x.firstTry}% · прохождений вопросов: ${x.attempts} · ошибочных выборов: ${x.wrong}</p><button class="drugLink" data-route="#system/${x.system.id}">Открыть систему</button></div>`).join('')}</div>`:`<div class="emptyState"><b>Статистики по системам пока нет</b><p>Она появится после прохождения тематических тестов.</p></div>`}
 <div class="sectionTitle"><h2>Последние тесты</h2><span class="muted">${recent.length}</span></div>${recent.length?`<div class="list">${recent.map(x=>`<div class="theoryCard"><div class="resultType">${esc(x.test_id||'Тест')}</div><h3>${Number(x.score||0).toFixed(0)}% с первой попытки</h3><p>${x.first_try_correct||0}/${x.questions_total||0} с первой попытки · ошибок выбора: ${x.wrong_selections||0}</p><div class="smallMuted">${esc((x.completed_at||x.created_at||'').replace('T',' ').slice(0,16))}</div></div>`).join('')}</div>`:`<div class="emptyState"><b>Истории пока нет</b><p>Пройди первый тест — результат появится здесь.</p></div>`}
 <div class="sectionTitle"><h2>Слабые вопросы</h2></div>${weak.length?`<div class="list">${weak.map(x=>{const q=TESTS.find(q=>q.id===x.question_id);return `<div class="theoryCard"><h3>${esc(q?.question||x.question_id)}</h3><p>Ошибочных выборов: ${x.wrong_count||0} · прохождений: ${x.attempts||0}</p>${reviewButton('question',x.question_id,'Повторить')}</div>`}).join('')}</div>`:`<div class="emptyState"><b>Слабых вопросов пока не выявлено</b></div>`}</div>`+bottomNav('settings');bindNav();
}
async function renderFavorites(){
 const rows=await listFavorites();const resolved=rows.map(x=>({...x,info:resolvePersonalEntity(x.entity_type,x.entity_id)})).filter(x=>x.info);
 app.innerHTML=header()+`<div class="page"><div class="paperTitle"><span class="handMini">Сохранённое</span><h2>Избранное</h2><p>Препараты, заболевания, механизмы, карточки и вопросы привязаны к твоему профилю.</p></div>${resolved.length?`<div class="list">${resolved.map(x=>`<div class="card personalRow"><div><div class="resultType">${esc(x.entity_type)}</div><h3>${esc(x.info.title)}</h3><p>${esc(x.info.subtitle||'')}</p></div><div class="rowActions">${favoriteButton(x.entity_type,x.entity_id,'Удалить')}<button class="drugLink" data-route="${esc(x.info.route)}">Открыть</button></div></div>`).join('')}</div>`:`<div class="emptyState"><div class="big">♡</div><b>Избранное пока пусто</b><p>Нажимай ♡ возле препаратов и других учебных сущностей.</p></div>`}</div>`+bottomNav('settings');bindNav();
}
async function renderReview(){
 const rows=await listReview();const resolved=rows.map(x=>({...x,info:resolvePersonalEntity(x.entity_type,x.entity_id)}));
 app.innerHTML=header()+`<div class="page"><div class="paperTitle"><span class="handMini">Активное повторение</span><h2>Повторить</h2><p>Отдельно от избранного: сюда попадает материал, который нужно закрепить.</p></div>${resolved.length?`<div class="list">${resolved.map(x=>`<div class="card personalRow"><div><div class="resultType">${esc(x.reason||'manual')}</div><h3>${esc(x.info?.title||x.entity_id)}</h3><p>${esc(x.info?.subtitle||'')}</p></div><div class="rowActions"><button class="miniAction" data-remove-review="${esc(x.entity_type)}|${esc(x.entity_id)}">✓ Готово</button>${x.info?.route?`<button class="drugLink" data-route="${esc(x.info.route)}">Открыть</button>`:''}</div></div>`).join('')}</div>`:`<div class="emptyState"><div class="big">↻</div><b>Очередь повторения пуста</b></div>`}</div>`+bottomNav('settings');bindNav();
 document.querySelectorAll('[data-remove-review]').forEach(b=>b.addEventListener('click',async()=>{const [t,id]=b.dataset.removeReview.split('|');await removeReview(t,id);renderReview()}));
}
function renderAuthLoading(){app.innerHTML=`<div class="authPage"><div class="authCard"><div class="authLogo">${capsuleLogo('authCapsuleLogo')}</div><h1>ProPharm</h1><p>Проверяем аккаунт…</p><div class="authSpinner"></div></div></div>`}
function renderAuthProfileError(){
 const raw=authState.error?.message||String(authState.error||'');
 const detail=raw?`Техническая причина: ${raw}`:'Сервер не вернул данные профиля.';
 app.innerHTML=`<div class="authPage"><div class="authCard authUnavailable"><div class="authLogo">${capsuleLogo('authCapsuleLogo')}</div><h1>Не удалось загрузить профиль</h1><p>Сессия входа сохранена, но Supabase не подтвердил статус профиля.</p><div class="sourceNote">${esc(detail)}</div><button class="moduleButton" id="retryProfile">Повторить загрузку</button><button class="moduleButton secondary" id="profileErrorLogout">Выйти из аккаунта</button></div></div>`;
 document.getElementById('retryProfile').onclick=async e=>{e.currentTarget.disabled=true;e.currentTarget.textContent='Проверяем…';await refreshProfile();router()};
 document.getElementById('profileErrorLogout').onclick=async()=>{await signOut();location.hash='#login';router()};
}
function renderAuthUnconfigured(){app.innerHTML=`<div class="authPage"><div class="authCard authUnavailable"><div class="authLogo">${capsuleLogo('authCapsuleLogo')}</div><h1>ProPharm ещё не подключён</h1><p>Система пользовательских аккаунтов ещё не настроена владельцем приложения. Учебные материалы временно недоступны.</p><div class="sourceNote"><b>Для владельца:</b> настрой Supabase согласно <code>docs/SUPABASE_SETUP_RU.md</code>, затем укажи публичные URL и publishable/anon key в конфигурации.</div></div></div>`}
function renderLogin(){
 app.innerHTML=`<div class="authPage"><div class="authCard"><div class="authLogo">${capsuleLogo('authCapsuleLogo')}</div><h1>ProPharm</h1><p>Войди в учебный профиль</p><form id="loginForm"><label>E-mail<input type="email" id="loginEmail" autocomplete="email" required></label><label>Пароль<input type="password" id="loginPassword" autocomplete="current-password" required></label><button class="moduleButton" type="submit">Войти</button></form><div class="authLinks"><button data-route="#register">Создать аккаунт</button><button id="forgotPassword">Забыли пароль?</button></div><p class="authPrivacyNote">Учебные материалы доступны только авторизованным и одобренным пользователям ProPharm.</p><div id="authMessage" class="authMessage"></div></div></div>`;bindNav();
 document.getElementById('loginForm').onsubmit=async e=>{e.preventDefault();try{await signInWithPassword(document.getElementById('loginEmail').value,document.getElementById('loginPassword').value);router()}catch(err){showAuthError(err)}};
 document.getElementById('forgotPassword').onclick=async()=>{const email=document.getElementById('loginEmail').value;if(!email)return showAuthError(new Error('Сначала введи e-mail'));try{await resetPassword(email);document.getElementById('authMessage').textContent='Ссылка для восстановления отправлена.'}catch(e){showAuthError(e)}};
}
function renderRegister(){
 app.innerHTML=`<div class="authPage"><div class="authCard"><div class="authLogo">${capsuleLogo('authCapsuleLogo')}</div><h1>Создание аккаунта</h1><p>Для доступа к материалам создай учебный профиль. После подтверждения e-mail аккаунт получает <b>user + pending</b> и ждёт одобрения администратора.</p><form id="registerForm"><label>Имя<input id="registerName" autocomplete="name" required></label><label>E-mail<input type="email" id="registerEmail" autocomplete="email" required></label><label>Пароль<input type="password" id="registerPassword" minlength="8" autocomplete="new-password" required></label><label>Повторите пароль<input type="password" id="registerPassword2" minlength="8" autocomplete="new-password" required></label><button class="moduleButton" type="submit">Создать учебный аккаунт</button></form><div class="authLinks"><button data-route="#login">Уже есть аккаунт? Войти</button></div><p class="authPrivacyNote">После подтверждения почты доступ останется закрытым до одобрения администратора.</p><div id="authMessage" class="authMessage"></div></div></div>`;
 bindNav();
 document.getElementById('registerForm').onsubmit=async e=>{e.preventDefault();const a=document.getElementById('registerPassword').value,b=document.getElementById('registerPassword2').value;if(a!==b)return showAuthError(new Error('Пароли не совпадают'));try{await signUpWithPassword(document.getElementById('registerName').value,document.getElementById('registerEmail').value,a);document.getElementById('authMessage').textContent='Проверь e-mail и подтверди регистрацию. После подтверждения аккаунт будет ожидать одобрения администратора.'}catch(err){showAuthError(err)}};
}
function showAuthError(err){const x=document.getElementById('authMessage');if(x){x.textContent=err?.message||String(err);x.classList.add('error')}else toast(err?.message||String(err),'bad')}
function renderResetPassword(){app.innerHTML=`<div class="authPage"><div class="authCard"><div class="authLogo">${capsuleLogo('authCapsuleLogo')}</div><h1>Новый пароль</h1><p>Установи новый пароль для текущей recovery-сессии.</p><form id="resetPasswordForm"><label>Новый пароль<input type="password" id="newPassword" minlength="8" required autocomplete="new-password"></label><label>Повтори пароль<input type="password" id="newPassword2" minlength="8" required autocomplete="new-password"></label><button class="moduleButton" type="submit">Сохранить пароль</button></form><div id="authMessage" class="authMessage"></div></div></div>`;document.getElementById('resetPasswordForm').onsubmit=async e=>{e.preventDefault();const a=document.getElementById('newPassword').value,b=document.getElementById('newPassword2').value;if(a!==b)return showAuthError(new Error('Пароли не совпадают'));try{await updatePassword(a);document.getElementById('authMessage').textContent='Пароль обновлён.';setTimeout(()=>{location.hash='#settings'},700)}catch(err){showAuthError(err)}}}
function renderAccessState(status){
 const map={pending:['Аккаунт создан','Ваш профиль ожидает подтверждения администратора ProPharm. До подтверждения учебные материалы недоступны.'],blocked:['Доступ ограничен','Доступ к аккаунту ограничен администратором.'],rejected:['Заявка отклонена','Администратор отклонил запрос на доступ.']},[title,text]=map[status]||['Доступ недоступен','Проверь статус аккаунта.'];
 const p=authState.profile||{},provider=p.provider||authState.user?.app_metadata?.provider||'email';
 app.innerHTML=`<div class="authPage"><div class="authCard"><div class="authLogo">${capsuleLogo('authCapsuleLogo')}</div><h1>${esc(title)}</h1><p>${esc(text)}</p><div class="pendingIdentity"><b>${esc(p.name||authState.user?.email||'Пользователь')}</b><span>${esc(p.email||authState.user?.email||'')}</span><span>${esc(provider)} · ${esc(status||'pending')}</span></div><button class="moduleButton" id="refreshAccess">Обновить статус</button><button class="moduleButton secondary" id="accessLogout">Выйти</button></div></div>`;
 document.getElementById('refreshAccess').onclick=async()=>{await refreshProfile();router()};
 document.getElementById('accessLogout').onclick=async()=>{await signOut();location.hash='#login';router()};
}
async function renderAdmin(){
 if(!isAdmin()){location.hash='#settings';return}
 app.innerHTML=header()+`<div class="page"><div class="paperTitle"><span class="handMini">Только владелец</span><h2>Администрирование</h2><p>Загружаю заявки…</p></div></div>`+bottomNav('settings');bindNav();
 try{
   const [users,notifications]=await Promise.all([listUsersForAdmin(),listAdminNotifications(30).catch(()=>[])]);
   adminPendingTotal=users.filter(u=>u.status==='pending').length;await setAdminAppBadge(adminPendingTotal);
   const notifEnabled=localStorage.getItem(ADMIN_NOTIFICATION_KEY)==='1'&&notificationPermission()==='granted';
   const pushConfigured=!!SUPABASE_CONFIG.notifications?.vapidPublicKey?.trim();
   const pending=users.filter(u=>u.status==='pending'),others=users.filter(u=>u.status!=='pending');
   const renderUser=u=>`<div class="card adminUser ${u.status==='pending'?'pendingUser':''}"><div><div class="resultType">${esc(u.provider||'email')} · ${esc(u.role)}</div><h3>${esc(u.name||u.email||u.user_id)}</h3><p>${esc(u.email||'')}</p><div class="chips"><span class="chip">${esc(u.status)}</span><span class="smallMuted">${esc((u.created_at||'').replace('T',' ').slice(0,16))}</span></div></div>${u.role==='admin'?`<span class="badge">bootstrap admin</span>`:`<div class="adminActions"><button class="approveBtn" data-admin-status="approved" data-user-id="${esc(u.user_id)}">Одобрить</button><button data-admin-status="rejected" data-user-id="${esc(u.user_id)}">Отклонить</button><button data-admin-status="blocked" data-user-id="${esc(u.user_id)}">Блокировать</button><button data-admin-status="pending" data-user-id="${esc(u.user_id)}">В pending</button></div>`}</div>`;
   app.innerHTML=header()+`<div class="page"><div class="paperTitle"><span class="handMini">Только владелец</span><h2>Администрирование</h2><p>Заявки теперь загружаются через защищённую admin-функцию Supabase, а новые регистрации приходят в реальном времени.</p></div>
   <div class="adminSummary"><span class="badge blue">${users.length} пользователей</span><span class="badge ${pending.length?'attentionBadge':''}">${pending.length} ожидают</span></div>
   <div class="card adminNotificationCard"><div><h3>Уведомления о новых заявках</h3><p>${notifEnabled?'Системные уведомления включены.':'Нажми кнопку, чтобы разрешить уведомления на этом устройстве.'}</p><p class="smallMuted">${pushConfigured?'Web Push настроен: уведомления могут приходить через установленное PWA даже когда интерфейс не открыт.':'Сейчас работают realtime + системные уведомления, пока ProPharm запущен. Для уведомлений при полностью закрытом PWA добавь VAPID public key и Edge Function по инструкции.'}</p></div><div class="adminNotifyActions"><button class="moduleButton" id="enableAdminNotifications">${notifEnabled?'Уведомления включены':'Включить уведомления'}</button>${notifEnabled?`<button class="moduleButton secondary" id="disableAdminNotifications">Выключить</button>`:''}<button class="moduleButton secondary" id="refreshApplications">Обновить заявки</button></div></div>
   <div class="sectionTitle"><h2>Новые заявки</h2><span class="muted">${pending.length}</span></div>${pending.length?`<div class="list">${pending.map(renderUser).join('')}</div>`:`<div class="emptyState"><b>Новых заявок нет</b><p>При новой регистрации список обновится автоматически.</p></div>`}
   <details class="sourceAccordion"><summary>Все пользователи (${others.length})</summary><div class="sourceAccordionBody"><div class="list">${others.map(renderUser).join('')}</div></div></details>
   ${notifications.length?`<details class="sourceAccordion"><summary>Журнал заявок (${notifications.length})</summary><div class="sourceAccordionBody"><div class="list">${notifications.map(n=>`<div class="adminNotificationRow"><b>${esc(n.title||'Новая заявка')}</b><p>${esc(n.message||'')}</p><span class="smallMuted">${esc((n.created_at||'').replace('T',' ').slice(0,16))}</span></div>`).join('')}</div></div></details>`:''}
   </div>`+bottomNav('settings');bindNav();
   document.querySelectorAll('[data-admin-status]').forEach(b=>b.addEventListener('click',async()=>{try{await adminSetStatus(b.dataset.userId,b.dataset.adminStatus);toast('Статус обновлён');await renderAdmin()}catch(e){toast(e.message||String(e),'bad')}}));
   document.getElementById('enableAdminNotifications')?.addEventListener('click',async()=>{try{await requestAdminNotifications();toast('Уведомления включены');await renderAdmin()}catch(e){toast(e.message||String(e),'bad')}});
   document.getElementById('disableAdminNotifications')?.addEventListener('click',async()=>{await disableAdminNotifications();toast('Уведомления выключены');await renderAdmin()});
   document.getElementById('refreshApplications')?.addEventListener('click',()=>renderAdmin());
   markAdminNotificationsRead().catch(()=>{});
 }catch(e){
   app.innerHTML=header()+`<div class="page"><div class="emptyState"><b>Не удалось загрузить пользователей</b><p>${esc(e.message||String(e))}</p><p class="smallMuted">Если в Supabase заявки видны, но здесь список пуст или появляется ошибка, выполни SQL-патч <b>002_admin_applications_notifications.sql</b>.</p></div></div>`+bottomNav('settings');bindNav();
 }
}


const CARDIO_SECTION_ORDER=[
 ['abbr','Аббревиатуры и обозначения','Словарь сокращений, белков, ферментов, каналов, транспортёров и соединений.'],
 ['physiology','Анатомия и физиология','Анатомия сердца, кровоток, проводящая система, сердечный цикл и гемодинамика.'],
 ['biochemistry','Биохимия и клеточные процессы','Рецепторы, вторичные посредники, ионные токи, Ca²⁺-handling и нейрогуморальные каскады.'],
 ['pathophysiology','Патофизиология','Перечень патологий: формирование → изменения → диагностика → фармакотерапия.'],
 ['diseases','Заболевания','Клиническая навигация по тем же патофизиологическим сущностям.'],
 ['targets','Фармакологические мишени','Мишень → процесс → связанные препараты → ожидаемый эффект.'],
 ['drugs','Препараты','Препараты ССС из глобальной базы 170. Взаимодействия — внутри карточки каждого препарата.'],
 ['diagnostics','Диагностика / ЭКГ / лаборатория','ЭКГ, объёмы и EF, электролиты, troponin, BNP/NT-proBNP.'],
 ['cards','Карточки','Карточки из анатомии, физиологии, биохимии, патофизиологии, мишеней и диагностики.'],
 ['tests','Тесты','Существующие экзаменационные вопросы + созданные учебные вопросы по материалу ССС.'],
 ['analysis','Разбор тестов','Почему правильный вариант верен, почему остальные неверны и с каким механизмом это связано.']
];
function systemSectionOrder(system){return system?.id==='cardiovascular'?CARDIO_SECTION_ORDER:SYSTEM_SECTION_ORDER;}
function cardioSectionMeta(key){return CARDIO_SECTION_ORDER.find(x=>x[0]===key)||systemSectionMeta(key);}
function cardioBlockText(item){return [item.title,item.summary,...(item.points||[]),...(item.steps||[]),item.physiology,item.pathology,...(item.commentary||[])].filter(Boolean).join(' ');}
function renderVisualSources(area){const ids=VISUAL_SOURCE_GROUPS[area]||[];if(!ids.length)return '';return `<details class="sourceAccordion"><summary>Источники и научные референсы схемы</summary><div class="sourceAccordionBody">${ids.map(id=>{const x=VISUAL_SOURCES[id];return `<div class="visualSourceRow"><b>${esc(x.name)}</b><span>${esc(x.license)}</span><p>${esc(x.use)}</p><a href="${esc(x.url)}" target="_blank" rel="noopener noreferrer">Открыть источник ↗</a></div>`}).join('')}<p class="smallMuted">Готовые медицинские иллюстрации используются только из источников с понятным происхождением и лицензией. Если подходящего оригинала нет, процесс отображается как Learning Whiteboard с отдельными научными референсами.</p></div></details>`;}
function cardioVisualSteps(item){return (item.steps?.length?item.steps:item.commentary?.length?item.commentary:item.formation?.length?item.formation:item.points?.length?item.points:[]).map(x=>String(x).trim()).filter(Boolean)}
function renderMedicalVisual(item,area='default'){
 const exactKey=SCIENTIFIC_VISUALS[item?.illustration]?item.illustration:(SCIENTIFIC_VISUALS[item?.id]?item.id:null);
 if(exactKey)return `${renderScientificVisual(exactKey)}${cardioVisualSteps(item).length?renderLearningWhiteboard({title:`Упрощённая учебная цепочка: ${item.title||''}`,steps:cardioVisualSteps(item),area,showSources:true}):''}`;
 const steps=cardioVisualSteps(item);return steps.length?renderLearningWhiteboard({title:item.title||'Механизм',steps,area,showSources:true}):'';
}
function accordionTextList(lines=[]){return `<div class="theoryBody">${lines.map(x=>`<p>• ${esc(x)}</p>`).join('')}</div>`}
function renderProcessCommentary(item){const rows=item.commentary||item.steps||item.formation||[];return rows.length?`<ol class="processStepsText">${rows.map(x=>`<li>${esc(x)}</li>`).join('')}</ol>`:'';}
function cardioDrugChips(ids=[],label='Связанные препараты'){return ids.length?`<div class="linkedDrugs"><b>${esc(label)}</b><div class="chips">${ids.map(id=>{const d=drugMap[String(id)];return d?`<button class="chip drugChip" data-route="#drug/${d.n}">${esc(d.name)}</button>`:''}).join('')}</div></div>`:'';}
function renderPathologyTherapy(p){const linked=cardioDrugChips(p.drugIds||[],'Фармакотерапия · препараты из базы ProPharm');return `<div class="therapyMap">${linked||`<p>В экзаменационном списке 170 нет специфического препарата, который устраняет первичный дефект этой патологии. Основная стратегия: ${esc((p.targets||[]).join('; '))}.</p>`}<p><b>Логика:</b> ${esc(p.why||'')}</p></div>`;}
function renderContextCards(cards,title=''){if(!cards.length)return '';return `<div class="miniFlashGrid">${cards.map(c=>`<details class="miniFlash"><summary>${esc(c[0])}</summary><p>${esc(c[1])}</p></details>`).join('')}</div>`;}
function cardioTestSections(area){const map={physiology:['cardiac-basics','cardio-v012-physiology'],biochemistry:['cardio-v012-biochemistry'],pathophysiology:['heart-failure','hypertension','ihd-acs','antiarrhythmics','af','cardio-v012-pathophysiology'],diseases:['heart-failure','hypertension','ihd-acs','antiarrhythmics','af','cardio-v012-pathophysiology'],targets:['heart-failure','hypertension','antiarrhythmics','cardio-v012-targets'],diagnostics:['cardiac-basics','antiarrhythmics','af','cardio-v012-diagnostics']};return map[area]||[];}
function cardioTests(area){const set=new Set(cardioTestSections(area));return TESTS.filter(q=>set.has(q.sectionId));}
function renderContextTests(area){const qs=cardioTests(area);if(!qs.length)return '';return `<div class="contextStudy"><div><span class="handMini">Проверить себя</span><h3>Тесты по этому разделу</h3><p>${qs.length} вопросов: существующая экзаменационная база + учебные вопросы.</p></div><button class="moduleButton" data-start-test="cardio-section:${area}">Начать</button></div>`;}
function renderCardioKnowledge(items,area){
 return `<div class="cardioKnowledge accordionStack">${items.map(item=>{
   const raw=cardioBlockText(item),terms=renderAbbreviationLead(raw)||'<p class="smallMuted">Специальных сокращений в этом блоке не обнаружено.</p>';
   const intro=`<p class="leadText">${esc(item.summary||item.definition||'')}</p>${item.points?.length?accordionTextList(item.points):''}`;
   const physiology=item.physiology?`<div class="dualExplain"><div><b>Связь с физиологией</b><p>${esc(item.physiology)}</p></div><div><b>Связь с патологией</b><p>${esc(item.pathology||'')}</p></div></div>`:'';
   const body=[
     accordion({id:`cv-${area}-${item.id}-terms`,title:'Термины и сокращения',level:3,body:terms}),
     accordion({id:`cv-${area}-${item.id}-intro`,title:'Краткое объяснение',level:3,body:intro}),
     accordion({id:`cv-${area}-${item.id}-visual`,title:'Иллюстрация процесса',level:3,body:renderMedicalVisual(item,area)}),
     accordion({id:`cv-${area}-${item.id}-comment`,title:'Что происходит на схеме',level:3,body:renderProcessCommentary(item)||'<p class="smallMuted">Пошаговый комментарий будет добавлен после проверки источника.</p>'}),
     physiology?accordion({id:`cv-${area}-${item.id}-links`,title:'Физиология и патология',level:3,body:physiology}):'',
     (item.drugIds||[]).length?accordion({id:`cv-${area}-${item.id}-drugs`,title:'Связанные препараты',level:3,body:cardioDrugChips(item.drugIds||[])}):'',
     (item.cards||[]).length?accordion({id:`cv-${area}-${item.id}-cards`,title:'Карточки по теме',level:3,body:renderContextCards(item.cards||[],item.title)}):'',
     accordion({id:`cv-${area}-${item.id}-sources`,title:'Источники и научные референсы',level:3,body:renderVisualSources(area)||renderWhiteboardSources(area)})
   ].filter(Boolean).join('');
   return accordion({id:`cv-${area}-${item.id}`,title:item.title,level:2,body});
 }).join('')}</div>${renderContextTests(area)}`;
}
function renderCardioPhysiology(){return `<div class="integratedIntro">Раздел построен как раскрывающийся учебный атлас. Готовые анатомические/физиологические изображения берутся из открытых научных ресурсов; объясняющие цепочки отображаются как Learning Whiteboard.</div>${renderCardioKnowledge(CARDIO_PHYSIOLOGY,'physiology')}`;}
function renderCardioBiochemistry(){return `<div class="integratedIntro">Биохимические механизмы больше не выводятся как AI-сгенерированные картинки. Используется Learning Whiteboard из проверенной последовательности, а где есть подходящая открытая научная схема — она показывается отдельно.</div>${renderCardioKnowledge(CARDIO_BIOCHEMISTRY,'biochemistry')}`;}
function renderCardioPathologyCard(p,detail=false){
 const allText=[p.title,p.definition,p.normal,p.abnormal,...p.formation,p.biochem,...p.consequences,...p.clinical,...p.diagnostics,...p.targets,p.why].join(' ');
 const body=[
   accordion({id:`path-${p.id}-terms`,title:'Термины и сокращения',level:3,body:renderAbbreviationLead(allText)||'<p class="smallMuted">Нет дополнительных сокращений.</p>'}),
   accordion({id:`path-${p.id}-definition`,title:'Определение',level:3,body:`<p>${esc(p.definition)}</p>`}),
   accordion({id:`path-${p.id}-normal`,title:'Что происходит в норме',level:3,body:`<p>${esc(p.normal)}</p>`}),
   accordion({id:`path-${p.id}-abnormal`,title:'Что нарушается',level:3,body:`<p>${esc(p.abnormal)}</p>`}),
   accordion({id:`path-${p.id}-formation`,title:'Механизм формирования и схема патогенеза',level:3,body:`${renderMedicalVisual({...p,steps:p.formation},'pathophysiology')}${renderProcessCommentary({...p,commentary:p.formation})}`}),
   accordion({id:`path-${p.id}-biochem`,title:'Биохимические изменения',level:3,body:`<p>${esc(p.biochem)}</p>`}),
   accordion({id:`path-${p.id}-consequences`,title:'Физиологические и гемодинамические изменения',level:3,body:accordionTextList(p.consequences||[])}),
   accordion({id:`path-${p.id}-clinical`,title:'Клинические проявления',level:3,body:accordionTextList(p.clinical||[])}),
   accordion({id:`path-${p.id}-diagnostics`,title:'Диагностика',level:3,body:accordionTextList(p.diagnostics||[])}),
   accordion({id:`path-${p.id}-targets`,title:'Фармакологические мишени',level:3,body:`<div class="chips">${(p.targets||[]).map(x=>`<span class="chip">${esc(x)}</span>`).join('')}</div>`}),
   accordion({id:`path-${p.id}-therapy`,title:'Фармакотерапия и почему она работает',level:3,body:renderPathologyTherapy(p)}),
   (p.cards||[]).length?accordion({id:`path-${p.id}-cards`,title:'Карточки',level:3,body:renderContextCards(p.cards,p.title)}):'',
   accordion({id:`path-${p.id}-sources`,title:'Источники',level:3,body:renderVisualSources('pathophysiology')||renderWhiteboardSources('pathophysiology')}),
   detail?accordion({id:`path-${p.id}-tests`,title:'Тесты',level:3,body:renderContextTests('pathophysiology')}):''
 ].filter(Boolean).join('');
 return accordion({id:`path-${p.id}`,title:p.title,level:2,badge:'патогенез · диагностика · терапия',body});
}
function renderCardioPathophysiology(){return `<div class="integratedIntro">Каждая патология теперь является отдельным раскрывающимся блоком: норма → нарушение → механизм → диагностика → мишень → фармакотерапия.</div><div class="accordionStack">${CARDIO_PATHOLOGIES.map(p=>renderCardioPathologyCard(p,false)).join('')}</div>${renderContextTests('pathophysiology')}`;}
function renderCardioDiseases(){return `<div class="accordionStack">${CARDIO_PATHOLOGIES.map(p=>accordion({id:`disease-cv-${p.id}`,title:p.title,level:2,body:`<p>${esc(p.definition)}</p><button class="moduleButton secondary" data-route="#cardio-pathology/${p.id}">Открыть полный разбор</button>${(p.cards||[]).length?renderContextCards((p.cards||[]).slice(0,1),p.title):''}`})).join('')}</div>${renderContextTests('diseases')}`;}
function renderCardioPathologyDetail(id){const p=CARDIO_PATHOLOGIES.find(x=>x.id===id);if(!p){location.hash='#system/cardiovascular/pathophysiology';return;}app.innerHTML=header()+`<div class="page"><div class="breadcrumb"><button data-route="#system/cardiovascular">ССС</button><span>›</span><button data-route="#system/cardiovascular/pathophysiology">Патофизиология</button><span>›</span><span>${esc(p.title)}</span></div>${renderCardioPathologyCard(p,true)}</div>`+bottomNav('study');bindNav();bindTestStarters();}
function renderCardioTargets(){return `<div class="accordionStack">${CARDIO_TARGETS.map(t=>accordion({id:`target-${t.id}`,title:t.title,level:2,body:[accordion({id:`target-${t.id}-terms`,title:'Термины',level:3,body:renderAbbreviationLead([t.title,t.mechanism,t.effect].join(' '))||'<p class="smallMuted">Нет дополнительных сокращений.</p>'}),accordion({id:`target-${t.id}-mechanism`,title:'Механизм',level:3,body:renderLearningWhiteboard({title:t.title,steps:t.mechanism.split('→').map(x=>x.trim()),area:'biochemistry',showSources:true})}),accordion({id:`target-${t.id}-effect`,title:'Фармакологический эффект',level:3,body:`<p>${esc(t.effect)}</p>`}),accordion({id:`target-${t.id}-drugs`,title:'Связанные препараты',level:3,body:cardioDrugChips(t.drugIds)}),accordion({id:`target-${t.id}-cards`,title:'Карточки',level:3,body:renderContextCards([[`Назови ключевой эффект воздействия на ${t.title}`,t.effect]],t.title)})].join('')})).join('')}</div>${renderContextTests('targets')}`;}
function renderCardioDiagnostics(){return renderCardioKnowledge(CARDIO_DIAGNOSTICS,'diagnostics');}
function renderCardioCards(){const groups=['physiology','biochemistry','pathophysiology','diagnostics','targets'];return `<div class="flashStats"><span class="badge blue">${CARDIO_FLASHCARDS.length} карточек ССС</span></div><div class="accordionStack">${groups.map(area=>{const arr=CARDIO_FLASHCARDS.filter(c=>c.area===area),title={physiology:'Анатомия и физиология',biochemistry:'Биохимия',pathophysiology:'Патофизиология',diagnostics:'Диагностика',targets:'Фармакологические мишени'}[area];return accordion({id:`cards-${area}`,title,level:2,badge:String(arr.length),body:`<div class="miniFlashGrid">${arr.map(c=>`<details class="miniFlash"><summary>${esc(c.front)}</summary>${renderAbbreviationLead(c.front+' '+c.back)}<p>${esc(c.back)}</p></details>`).join('')}</div>`})}).join('')}</div>`;}

function systemIcon(s){return topicIcon(s?.iconSource||"cardio");}
function systemSourceTopics(system){return system?.sourceTopics||[];}
function systemDrugs(system){
 const topics=systemSourceTopics(system),extra=new Set(system?.extraDrugIds||[]);
 return DRUGS.filter(d=>d.topics?.some(t=>topics.includes(t))||extra.has(d.n));
}
function systemAbbreviations(system){
 const seen=new Set(),arr=[];
 const add=a=>{if(!a?.abbr)return;const k=a.abbr.toLowerCase();if(!seen.has(k)){seen.add(k);arr.push(a)}};
 systemSourceTopics(system).forEach(t=>(ABBREVIATIONS[t]||[]).forEach(add));
 if(system?.id==="cardiovascular")CARDIO_GLOSSARY.forEach(add);
 return arr;
}
function systemTheory(system){return systemSourceTopics(system).flatMap(t=>(THEORY[t]||[]).map(x=>({...x,topic:t})));}
function systemMechanisms(system){
 const out=[];systemSourceTopics(system).forEach(t=>(MECHANISMS[t]||[]).forEach((m,i)=>out.push({...m,topic:t,id:`${t}-m${i+1}`})));return out;
}
function systemDiseases(system){return DISEASES.filter(d=>d.systemId===system.id);}
function systemTests(system){const topics=systemSourceTopics(system);return TESTS.filter(q=>topics.includes(q.topic));}
function systemAnalyses(system){const qids=new Set(systemTests(system).map(q=>q.id));return TEST_ANALYSES.filter(a=>qids.has(a.questionId));}
function systemInteractions(system){
 const topics=systemSourceTopics(system),out=[];
 topics.forEach(t=>(INTERACTIONS[t]||[]).forEach(x=>out.push({...x,topic:t})));
 return out;
}
function systemTables(system){return systemSourceTopics(system).flatMap(t=>(STUDY_TABLES[t]||[]).map(x=>({...x,topic:t})));}
function systemHighYield(system){return systemSourceTopics(system).flatMap(t=>(HIGH_YIELD[t]||[]));}
function countSystemData(system){return {drugs:systemDrugs(system).length,abbr:systemAbbreviations(system).length,tests:systemTests(system).length,mechanisms:systemMechanisms(system).length,diseases:systemDiseases(system).length};}
function systemSectionMeta(key){return SYSTEM_SECTION_ORDER.find(x=>x[0]===key)||[key,key,""];}
function renderSystemsHub(){
 app.innerHTML=header()+`<div class="page"><div class="paperTitle"><span class="handMini">Интегрированное обучение</span><h2>Системы</h2><p>В каждой системе физиология, биохимия, патофизиология и фармакология связаны одной причинно-следственной цепочкой.</p></div><div class="topicGrid">${SYSTEMS.map(s=>{const c=countSystemData(s);return `<div class="card clickCard softPaper" data-route="#system/${s.id}"><div class="cardTopActions">${favoriteButton("system",s.id,"Сохранить")}</div><div class="cardHead"><div class="iconFrame topicLineIcon">${systemIcon(s)}</div><div><h3>${esc(s.title)}</h3><p>${esc(s.description)}</p><span class="badge">${c.drugs} препаратов</span><span class="badge blue">${c.tests} тестов</span></div></div></div>`}).join("")}</div></div>`+bottomNav("study");bindNav();
}
function systemSectionCount(s,key){
 const c=countSystemData(s);
 if(key==="abbr")return systemAbbreviations(s).length;
 if(key==="diseases")return s.id==="cardiovascular"?CARDIO_PATHOLOGIES.length:c.diseases;
 if(key==="targets")return s.id==="cardiovascular"?CARDIO_TARGETS.length:c.mechanisms;
 if(key==="biochemistry")return s.id==="cardiovascular"?CARDIO_BIOCHEMISTRY.length:c.mechanisms;
 if(key==="physiology")return s.id==="cardiovascular"?CARDIO_PHYSIOLOGY.length:systemTheory(s).length;
 if(key==="drugs")return c.drugs;
 if(key==="diagnostics")return s.id==="cardiovascular"?CARDIO_DIAGNOSTICS.length:systemTables(s).length;
 if(key==="cards")return s.id==="cardiovascular"?CARDIO_FLASHCARDS.length:buildFlashCards().filter(x=>systemSourceTopics(s).includes(x.topic)).length;
 if(key==="tests"||key==="analysis")return systemTests(s).length;
 return "";
}
function renderGenericSystemCards(s){
 const cards=buildFlashCards().filter(x=>systemSourceTopics(s).includes(x.topic)).slice(0,160);
 if(!cards.length)return renderSystemTheoryCards([]);
 return `<div class="accordionStack">${cards.map((c,i)=>accordion({id:`sys-${s.id}-card-${c.id||i}`,title:c.front,level:2,body:`<p>${(c.back||[]).map(esc).join('</p><p>')}</p>${c.drugId?`<button class="drugLink" data-route="#drug/${c.drugId}">Открыть препарат</button>`:''}`})).join('')}</div>`;
}
function getSystemSectionContent(s,key){
 let content="";
 if(s.id==="cardiovascular"){
   if(key==="abbr"){const a=systemAbbreviations(s);content=`<div class="integratedIntro">Словарь ССС включает не только аббревиатуры, но и белки, ферменты, рецепторы, каналы, транспортёры, ионные токи и биохимические соединения.</div><div class="list">${a.map(abbrRow).join("")}</div>`}
   if(key==="physiology")content=renderCardioPhysiology();
   if(key==="biochemistry")content=renderCardioBiochemistry();
   if(key==="pathophysiology")content=renderCardioPathophysiology();
   if(key==="diseases")content=renderCardioDiseases();
   if(key==="targets")content=renderCardioTargets();
   if(key==="drugs"){const list=systemDrugs(s);content=`<div class="sourceNote">Лекарственные взаимодействия находятся внутри полной карточки каждого препарата.</div><div class="toolbar"><input class="systemDrugSearch" data-system-drug-search="${s.id}" placeholder="Поиск препарата…"><span class="badge blue">${list.length}</span></div><div class="systemDrugList" data-system-drug-list="${s.id}">${drugRows(list)}</div>`}
   if(key==="diagnostics")content=renderCardioDiagnostics();
   if(key==="cards")content=renderCardioCards();
   if(key==="tests")content=`${renderContextTests("physiology")}${renderContextTests("biochemistry")}${renderContextTests("pathophysiology")}${renderContextTests("targets")}${renderContextTests("diagnostics")}<div class="sectionTitle"><h2>Весь тест по ССС</h2></div>${renderSystemTests(s,false)}`;
   if(key==="analysis")content=renderSystemTests(s,true);
 }else{
   if(key==="abbr"){const a=systemAbbreviations(s);content=a.length?`<div class="list">${a.map(abbrRow).join("")}</div>`:renderSystemTheoryCards([])}
   if(key==="physiology"){const all=systemTheory(s),tagged=all.filter(x=>x.section==="physiology"),legacy=all.filter(x=>!x.section&&/electrophysi|электрофизи|базов|кислотност|диабет|физиол|анатом/i.test((x.id||"")+" "+(x.title||"")+" "+(x.summary||"")));content=renderSystemTheoryCards([...tagged,...legacy])}
   if(key==="biochemistry"){const tagged=systemTheory(s).filter(x=>x.section==="biochemistry");content=`${renderSystemTheoryCards(tagged)}${renderBiochemistry(s)}`}
   if(key==="pathophysiology"){const tagged=systemTheory(s).filter(x=>x.section==="pathophysiology");content=`${renderSystemTheoryCards(tagged)}${renderPathophysiology(s)}`}
   if(key==="diseases")content=renderDiseaseCards(s);
   if(key==="targets"){const tagged=systemTheory(s).filter(x=>x.section==="targets");content=`${renderSystemTheoryCards(tagged)}${renderBiochemistry(s)}`}
   if(key==="drugs"){const list=systemDrugs(s);content=`<div class="toolbar"><input class="systemDrugSearch" data-system-drug-search="${s.id}" placeholder="Поиск препарата…"><span class="badge blue">${list.length}</span></div><div class="systemDrugList" data-system-drug-list="${s.id}">${drugRows(list)}</div>`}
   if(key==="diagnostics"){const tagged=systemTheory(s).filter(x=>x.section==="diagnostics");content=`${renderSystemTheoryCards(tagged)}${renderSystemDiagnostics(s)}`}
   if(key==="cards")content=renderGenericSystemCards(s);
   if(key==="tests")content=renderSystemTests(s,false);
   if(key==="analysis")content=renderSystemTests(s,true);
 }
 return content||renderSystemTheoryCards([]);
}
function bindSystemInlineUI(s,root=document){
 root.querySelectorAll(`[data-system-drug-search="${s.id}"]`).forEach(inp=>{const out=root.querySelector(`[data-system-drug-list="${s.id}"]`),base=systemDrugs(s);inp.oninput=()=>{const q=inp.value.toLowerCase();out.innerHTML=drugRows(base.filter(d=>drugSearchText(d).includes(q)));bindNav(out)}});
 bindTestStarters(root);bindNav(root);
}
function renderSystem(systemId){
 const s=systemMap[systemId];if(!s){location.hash="#systems";return;}const order=systemSectionOrder(s);
 const sections=order.map(([key,title,desc])=>accordion({id:`system-${s.id}-${key}`,title,subtitle:desc,count:systemSectionCount(s,key),level:1,body:getSystemSectionContent(s,key)})).join("");
 app.innerHTML=header()+`<div class="page"><div class="breadcrumb"><button data-route="#systems">Системы</button><span>›</span><span>${esc(s.short)}</span></div><div class="topicHeader"><div class="iconFrame topicLineIcon">${systemIcon(s)}</div><div><h2>${esc(s.title)}</h2><p>${esc(s.description)}</p></div></div><div class="causalRibbon"><span>Норма</span><b>→</b><span>Биохимия</span><b>→</b><span>Нарушение</span><b>→</b><span>Заболевание</span><b>→</b><span>Мишень</span><b>→</b><span>Препарат</span></div><div class="sourceNote"><b>Навигация:</b> открой нужный раздел, затем тему и её внутренние блоки. По умолчанию большие разделы свёрнуты.</div><div class="accordionStack systemAccordion">${sections}</div></div>`+bottomNav("study");
 bindNav();bindSystemInlineUI(s);
}
function renderAcademicSourceList(ids=[]){
 const rows=[...new Set(ids)].map(id=>ACADEMIC_SOURCES[id]).filter(Boolean);
 if(!rows.length)return `<p class="smallMuted">Для этого блока отдельные академические источники ещё не привязаны.</p>`;
 return `<div class="academicSources">${rows.map(x=>`<div class="academicSourceRow"><div><b>${esc(x.name)}</b><span class="sourcePriority">${esc(x.priority||"")}</span></div><p>${esc(x.institution||"")}</p><p>${esc(x.use||"")}</p><a href="${esc(x.url)}" target="_blank" rel="noopener noreferrer">Открыть источник ↗</a></div>`).join("")}</div>`;
}
function renderSystemTheoryCards(items){
 if(!items.length)return `<div class="emptyState"><b>В текущей базе отдельный материал для этого блока ещё не выделен.</b><p>Структура готова; данные будут появляться здесь без дублирования по мере расширения источников.</p></div>`;
 return `<div class="accordionStack">${items.map((x,i)=>{
   const allText=[x.title,x.summary,...(x.body||[]),...(x.visual?.steps||[])].join(" ");
   const sourceIds=x.sources||x.visual?.sourceIds||[];
   const status=x.status==='advanced-theory'?'Продвинуто · теория':'';
   const reviewed=x.lastReviewed?`Проверено: ${x.lastReviewed}`:'';
   const body=[
     accordion({id:`theory-${x.id||i}-terms`,title:'Термины и сокращения',level:3,body:renderAbbreviationLead(allText)||'<p class="smallMuted">Отдельных специальных сокращений нет.</p>'}),
     accordion({id:`theory-${x.id||i}-explain`,title:'Краткое объяснение',level:3,body:`<p>${esc(x.summary||"")}</p>${x.body?.length?`<div class="theoryBody">${x.body.map(v=>`<p>• ${esc(v)}</p>`).join("")}</div>`:""}`}),
     x.visual?.steps?.length?accordion({id:`theory-${x.id||i}-visual`,title:'Схема / Learning Whiteboard',level:3,body:renderLearningWhiteboard({title:x.visual.title||x.title,steps:x.visual.steps,area:x.section==='biochemistry'?'biochemistry':x.section==='pathophysiology'?'pathophysiology':x.section==='diagnostics'?'diagnostics':'physiology',showSources:false})}):'',
     x.visual?.steps?.length?accordion({id:`theory-${x.id||i}-comment`,title:'Что происходит на схеме',level:3,body:`<ol class="processStepsText">${x.visual.steps.map(v=>`<li>${esc(v)}</li>`).join("")}</ol>`}):'',
     accordion({id:`theory-${x.id||i}-sources`,title:'Академические источники',level:3,body:renderAcademicSourceList(sourceIds)}),
     x.type==="interactive"?`<a class="moduleButton" href="${esc(x.url)}">Открыть интерактивный модуль</a>`:''
   ].filter(Boolean).join('');
   return accordion({id:`theory-${x.id||i}`,title:x.title,subtitle:reviewed,count:status,level:2,body});
 }).join("")}</div>`;
}
function renderBiochemistry(system){
 const ms=systemMechanisms(system);if(!ms.length)return renderSystemTheoryCards([]);
 return `<div class="integratedIntro">Каждый механизм хранится как единая сущность. Процессная визуализация выполняется как Learning Whiteboard с указанием научных источников.</div><div class="accordionStack">${ms.map((m,i)=>accordion({id:`mechanism-${system.id}-${m.id||i}`,title:m.title,level:2,body:`${accordion({id:`mechanism-${system.id}-${m.id||i}-terms`,title:'Термины и сокращения',level:3,body:renderAbbreviationLead([m.title,...(m.chain||[])].join(" "))||'<p class="smallMuted">Нет отдельных сокращений.</p>'})}${accordion({id:`mechanism-${system.id}-${m.id||i}-visual`,title:'Learning Whiteboard',level:3,body:renderLearningWhiteboard({title:m.title,steps:m.chain||[],area:'biochemistry',showSources:true})})}${accordion({id:`mechanism-${system.id}-${m.id||i}-examples`,title:'Связанные препараты / примеры',level:3,body:`<div class="chips">${(m.examples||[]).map(x=>`<span class="chip">${esc(x)}</span>`).join("")}</div><button class="drugLink" data-route="#mechanism/${m.id}">Открыть механизм отдельно</button>`})}`})).join("")}</div>`;
}
function renderPathophysiology(system){
 const ds=systemDiseases(system),theory=systemTheory(system).filter(x=>ds.some(d=>(d.theoryIds||[]).includes(x.id)));
 return `<div class="integratedIntro">Патофизиология здесь строится из уже имеющихся разборов заболеваний: нормальный механизм → его нарушение → клинический блок → точка приложения терапии.</div>${renderSystemTheoryCards(theory)}`;
}
function renderDiseaseCards(system){const ds=systemDiseases(system);if(!ds.length)return renderSystemTheoryCards([]);return `<div class="accordionStack">${ds.map((d,i)=>{const cnt=TESTS.filter(q=>(d.sectionIds||[]).includes(q.sectionId)).length;return accordion({id:`disease-${system.id}-${d.id||i}`,title:d.title,count:cnt?`${cnt} тестов`:"",level:2,body:`<p>Связанные теоретические разборы, препараты, механизмы и тесты.</p>${favoriteButton("disease",d.id,"Сохранить")}<button class="drugLink" data-route="#disease/${d.id}">Открыть полный разбор</button>`})}).join("")}</div>`;}
function renderSystemDiagnostics(system){
 const tables=systemTables(system),diag=(system.diagnostics||[]).map((x,i)=>accordion({id:`diag-${system.id}-${i}`,title:`Диагностический ориентир ${i+1}`,level:2,body:`${renderAbbreviationLead(x)}<p>${esc(x)}</p>`})).join("");
 const tableBlocks=tables.map((tbl,i)=>accordion({id:`diag-table-${system.id}-${i}`,title:tbl.title,level:2,body:`${renderAbbreviationLead([tbl.title,...tbl.columns,...tbl.rows.flat(),tbl.note||""] .join(" "))}<div class="tableScroll"><table><thead><tr>${tbl.columns.map(c=>`<th>${esc(c)}</th>`).join("")}</tr></thead><tbody>${tbl.rows.map(r=>`<tr>${r.map(c=>`<td>${esc(c)}</td>`).join("")}</tr>`).join("")}</tbody></table></div>${tbl.note?`<div class="tableNote">${esc(tbl.note)}</div>`:""}`})).join("");
 return (diag||tableBlocks)?`<div class="accordionStack">${diag}${tableBlocks}</div>`:renderSystemTheoryCards([]);
}
function renderSystemInteractions(system){const arr=systemInteractions(system);if(!arr.length)return renderSystemTheoryCards([]);return `<div class="list">${arr.map(x=>`<div class="interactionCard"><div class="resultType">${esc(x.type||"Взаимодействие")}</div><h3>${esc(x.title)}</h3>${renderAbbreviationLead([x.title,x.summary,...(x.chain||[])].join(" "))}<p>${esc(x.summary||"")}</p>${renderVisual({title:"Механизм взаимодействия",kind:"flow",steps:x.chain||[],skipAbbr:true})}</div>`).join("")}</div>`;}
function renderSystemTests(system,analysis=false){
 const q=systemTests(system);if(!q.length)return renderSystemTheoryCards([]);
 if(!analysis)return `<div class="card"><h3>Тест по системе</h3><p>${q.length} вопросов. История сохраняется в личном профиле.</p><button class="moduleButton" data-start-test="system:${system.id}">Начать тест</button></div><div class="sectionTitle"><h2>Клинические блоки</h2></div>${renderDiseaseCards(system)}`;
 const qids=new Set(q.map(x=>x.id));const arr=TEST_ANALYSES.filter(a=>qids.has(a.questionId));const qmap=Object.fromEntries(TESTS.map(x=>[x.id,x]));return `<div class="list">${arr.map(a=>{const x=qmap[a.questionId];if(!x)return "";const raw=[x.question,...(x.options||[]).map(o=>o.text),...(a.explanation||[]),...Object.values(a.optionExplanations||{})].join(" ");return `<div class="theoryCard">${renderAbbreviationLead(raw)}<div class="resultType">${esc(x.sectionTitle)} · вопрос ${x.number}</div><h3>${esc(x.question)}</h3><div class="answerReview"><b>Правильный ответ: ${esc(x.correct)}. ${esc(x.options.find(o=>o.id===x.correct)?.text||"")}</b></div>${(a.explanation||[]).map(z=>`<p>${esc(z)}</p>`).join("")}${x.options.map(o=>`<div class="reviewOption ${o.id===x.correct?"isCorrect":""}"><b>${o.id}. ${esc(o.text)}</b><div>${esc(a.optionExplanations?.[o.id]|| (o.id===x.correct?"Правильный вариант.":"Отдельный комментарий в источнике не сохранён."))}</div></div>`).join("")}${renderVisual(x.visual||a.visual||SECTION_VISUALS[x.sectionId])}</div>`}).join("")}</div>`;
}
function renderSystemSection(systemId,key){
 const s=systemMap[systemId];if(!s){location.hash="#systems";return;}
 if(key==="interactions"||key==="high"){location.hash=`#system/${s.id}`;return;}
 const [,title]=(s.id==="cardiovascular"?cardioSectionMeta(key):systemSectionMeta(key));
 const content=getSystemSectionContent(s,key);
 app.innerHTML=header()+`<div class="page"><div class="breadcrumb"><button data-route="#systems">Системы</button><span>›</span><button data-route="#system/${s.id}">${esc(s.short)}</button><span>›</span><span>${esc(title)}</span></div><div class="topicHeader"><div class="iconFrame topicLineIcon">${systemIcon(s)}</div><div><h2>${esc(title)}</h2><p>${esc(s.title)}</p></div></div><div class="accordionStack sectionStandalone">${accordion({id:`standalone-${s.id}-${key}`,title,level:1,open:true,body:content})}</div></div>`+bottomNav("study");
 bindNav();bindSystemInlineUI(s);
}
function allCanonicalMechanisms(){
 const base=SYSTEMS.flatMap(s=>systemMechanisms(s).map(m=>({...m,systemId:s.id})));
 const cv=CARDIO_BIOCHEMISTRY.map(m=>({id:`cv12-${m.id}`,title:m.title,chain:m.steps||[],examples:(m.drugIds||[]).map(id=>drugMap[String(id)]?.name).filter(Boolean),systemId:"cardiovascular",integrated:true,illustration:m.illustration,commentary:m.commentary}));
 return [...cv,...base.filter(m=>!cv.some(x=>x.title===m.title))];
}
function renderMechanismsHub(){const arr=allCanonicalMechanisms();app.innerHTML=header()+`<div class="page"><div class="paperTitle"><span class="handMini">Единые сущности</span><h2>Механизмы</h2><p>Один механизм используется повторно в физиологии, патологии, препаратах и тестах.</p></div><div class="list">${arr.map(m=>`<div class="mechanismCard clickCard" data-route="#mechanism/${m.id}"><div class="cardTopActions">${favoriteButton("mechanism",m.id,"Сохранить")}</div><div class="resultType">${esc(systemMap[m.systemId]?.short||"")}</div><h3>${esc(m.title)}</h3>${renderAbbreviationLead([m.title,...(m.chain||[])].join(" "))}<p>${esc((m.chain||[]).join(" → "))}</p></div>`).join("")}</div></div>`+bottomNav("study");bindNav();}
function renderMechanismDetail(id){const m=allCanonicalMechanisms().find(x=>x.id===id);if(!m){location.hash="#mechanisms";return;}const names=new Set((m.examples||[]).map(x=>String(x).split(" — ")[0].trim().toLowerCase()));const ds=DRUGS.filter(d=>names.has(d.name.toLowerCase()));const tests=TESTS.filter(q=>(q.drugIds||[]).some(n=>ds.some(d=>d.n===n))||systemMap[m.systemId]?.sourceTopics?.includes(q.topic));app.innerHTML=header()+`<div class="page"><div class="breadcrumb"><button data-route="#mechanisms">Механизмы</button><span>›</span><span>${esc(m.title)}</span></div><div class="paperTitle"><h2>${esc(m.title)}</h2><p>${esc(systemMap[m.systemId]?.title||"")}</p></div>${renderAbbreviationLead([m.title,...(m.chain||[])].join(" "))}${renderVisual({title:"Процесс",kind:"process",steps:m.chain||[],skipAbbr:true})}<div class="detailBox"><h3>Связанные препараты</h3>${ds.length?drugRows(ds):`<div class="chips">${(m.examples||[]).map(x=>`<span class="chip">${esc(x)}</span>`).join("")}</div>`}</div><div class="detailBox"><h3>Связанные тесты</h3><p>${tests.length} вопросов связаны через систему/препараты. Вопросы физически не копируются.</p><button class="moduleButton" data-route="#system/${m.systemId}/tests">Открыть тесты системы</button></div></div>`+bottomNav("study");bindNav();}
function renderDiseasesHub(){const legacy=DISEASES.filter(d=>d.systemId!=="cardiovascular");app.innerHTML=header()+`<div class="page"><div class="paperTitle"><span class="handMini">Клиническая навигация</span><h2>По заболеваниям</h2><p>Это альтернативный вход в те же связанные данные. Патологии ССС используют тот же интегрированный слой, что и раздел системы.</p></div><div class="list">${CARDIO_PATHOLOGIES.map(p=>`<div class="card clickCard" data-route="#cardio-pathology/${p.id}"><div class="cardTopActions">${favoriteButton("cardio-pathology",p.id,"Сохранить")}</div><div class="cardHead"><div class="iconFrame topicLineIcon">${systemIcon(systemMap.cardiovascular)}</div><div><h3>${esc(p.title)}</h3><p>Сердечно-сосудистая система</p><span class="badge blue">механизм + терапия + диагностика</span></div></div></div>`).join("")}${legacy.map(d=>{const s=systemMap[d.systemId],cnt=TESTS.filter(q=>(d.sectionIds||[]).includes(q.sectionId)).length;return `<div class="card clickCard" data-route="#disease/${d.id}"><div class="cardTopActions">${favoriteButton("disease",d.id,"Сохранить")}</div><div class="cardHead"><div class="iconFrame topicLineIcon">${systemIcon(s)}</div><div><h3>${esc(d.title)}</h3><p>${esc(s?.title||"")}</p><span class="badge blue">${cnt} тестов</span></div></div></div>`}).join("")}</div></div>`+bottomNav("study");bindNav();}
function renderDisease(id){const d=diseaseMap[id];if(!d){location.hash="#diseases";return;}const s=systemMap[d.systemId],theory=systemTheory(s).filter(x=>(d.theoryIds||[]).includes(x.id)),qs=TESTS.filter(q=>(d.sectionIds||[]).includes(q.sectionId)),drugIds=new Set(qs.flatMap(q=>q.drugIds||[])),drugs=DRUGS.filter(x=>drugIds.has(x.n));app.innerHTML=header()+`<div class="page"><div class="breadcrumb"><button data-route="#diseases">Заболевания</button><span>›</span><span>${esc(d.title)}</span></div><div class="topicHeader"><div class="iconFrame topicLineIcon">${systemIcon(s)}</div><div><h2>${esc(d.title)}</h2><p>${esc(s.title)}</p></div></div><div class="causalRibbon"><span>Норма</span><b>→</b><span>Нарушение</span><b>→</b><span>${esc(d.title)}</span><b>→</b><span>Мишени</span><b>→</b><span>Препараты</span></div><div class="sectionTitle"><h2>Теория и патофизиология</h2></div>${renderSystemTheoryCards(theory)}<div class="sectionTitle"><h2>Связанные препараты</h2></div>${drugs.length?drugRows(drugs):renderSystemTheoryCards([])}<div class="sectionTitle"><h2>Тесты</h2></div><div class="card"><p>${qs.length} вопросов из существующей базы.</p>${qs.length?`<button class="moduleButton" data-start-test="disease:${d.id}">Начать тест</button>`:""}</div></div>`+bottomNav("study");bindNav();bindTestStarters();}
function renderStudyHub(){const items=[["Базовые дисциплины","Системы организма, фармакокинетика, химия, аналитика, биохимия/биология и НД Израиля","#foundations"],["Заболевания","Клинический вход в связанные материалы","#diseases"],["Механизмы","Рецепторы, каналы, ферменты и сигнальные пути","#mechanisms"],["Препараты","170 полных карточек","#drugs"],["Тесты","Интерактивная экзаменационная база","#tests"],["Тренажёр памяти","Интервальное повторение экзаменационного материала","#memory-trainer"],["Схемы","Все визуальные процессы","#schemes"],["Таблицы","Сравнения и диагностические ориентиры","#tables"]];app.innerHTML=header()+`<div class="page"><div class="paperTitle"><span class="handMini">Навигация по знаниям</span><h2>Учёба</h2><p>Разные входы открывают одну и ту же связанную базу — без дублирования сущностей.</p></div><div class="sectionGrid">${items.map(([a,b,c])=>`<div class="card clickCard" data-route="${c}"><h3>${a}</h3><p>${b}</p></div>`).join("")}</div></div>`+bottomNav("study");bindNav();}
function foundationIcon(id){const map={
  pharmacokinetics:'kinetics','general-chemistry':'chemistry','organic-chemistry':'chemistry','analytical-chemistry':'analytics','biochemistry-biology':'biology','pharmacology':'drugs','israel-regulatory':'law'
 };return doodleIcon(map[id]||'theory');}
function renderFoundationsHub(){
  const systemsRow=accordion({id:'foundation-hub-systems',title:'Системы организма',subtitle:'Интегрированное изучение: физиология → биохимия → патофизиология → препараты',level:1,icon:doodleIcon('systems'),body:`<div class="sourceNote"><b>Главный системный путь:</b> все 12 систем организма находятся внутри базовых дисциплин.</div><button class="moduleButton" data-route="#systems">Открыть системы</button>`});
  const rows=FOUNDATIONAL_SECTIONS.map(x=>accordion({
    id:`foundation-hub-${x.id}`,title:x.title,subtitle:x.description,level:1,badge:(x.id==='pharmacology'||foundationContent(x.id)?.length||CHEMISTRY_CONTENT[x.id]?.length)?'материалы добавлены':'раздел создан',icon:foundationIcon(x.id),
    body:`<div class="chips">${(x.plannedTopics||[]).slice(0,5).map(t=>`<span class="chip">${esc(t)}</span>`).join('')}</div><button class="moduleButton" data-route="#foundation/${x.id}">Открыть раздел</button>`
  })).join('');
  app.innerHTML=header()+`<div class="page"><div class="paperTitle"><span class="handMini">Общие учебные направления</span><h2>Базовые дисциплины</h2><p>Системы организма теперь являются частью этого раздела вместе с фармакокинетикой, химией, биохимией/биологией и нормативными документами Израиля.</p></div><div class="accordionStack">${systemsRow}${rows}</div></div>`+bottomNav('study');
  bindNav();
}
function renderFoundationDetail(id){
  const x=foundationalMap[id];if(!x){location.hash='#foundations';return;}
  const advanced=foundationContent(id);
  const legacy=CHEMISTRY_CONTENT[id]||[];
  let topicHtml='';
  if(id==='pharmacology') topicHtml=renderPharmacologyFoundation();
  else if(advanced.length) topicHtml=advanced.map(item=>renderAdvancedFoundationTopic(id,item)).join('');
  else if(legacy.length) topicHtml=legacy.map(item=>renderChemistryTopic(id,item)).join('');
  else topicHtml=(x.plannedTopics||[]).map((t,i)=>accordion({id:`foundation-${x.id}-topic-${i}`,title:t,level:2,icon:foundationIcon(x.id),badge:'будет заполнено позже',body:`<div class="emptyState compactEmpty"><b>Раздел подготовлен</b><p>Материалы по теме «${esc(t)}» будут добавлены на следующем этапе наполнения.</p></div>`})).join('');
  const hasMaterial=id==='pharmacology'||advanced.length||legacy.length;
  const status=hasMaterial?'расширенная учебная база добавлена; материал структурирован как теория → формулы/таблицы → Learning Whiteboard → источники.':'архитектура создана; содержимое ожидает наполнения.';
  const content=[
    accordion({id:`foundation-${x.id}-about`,title:'О разделе',level:1,open:true,body:`<p>${esc(x.description)}</p><div class="sourceNote"><b>Текущий статус:</b> ${esc(status)}</div>`}),
    accordion({id:`foundation-${x.id}-planned`,title:hasMaterial?'Учебные темы':'Планируемая структура',level:1,open:hasMaterial,body:`<div class="accordionStack">${topicHtml}</div>`}),
    accordion({id:`foundation-${x.id}-sources`,title:'Принцип источников и визуализации',level:1,body:`<p><b>Теория:</b> приоритет университетских учебников и академических ресурсов. <b>Химия:</b> реакционные схемы и организация материала дополнительно опираются на предоставленные минисправочники Н.Е. Дерябиной. <b>Визуализация:</b> Learning Whiteboard/HTML/SVG с читаемыми подписями; генеративные научные картинки не используются.</p>`})
  ].join('');
  app.innerHTML=header()+`<div class="page"><div class="breadcrumb"><button data-route="#foundations">Базовые дисциплины</button><span>›</span><span>${esc(x.short)}</span></div><div class="paperTitle"><span class="handMini">${hasMaterial?'Расширенная учебная база':'Раздел создан'}</span><h2>${esc(x.title)}</h2><p>${esc(x.description)}</p></div><div class="accordionStack">${content}</div></div>`+bottomNav('study');
  bindNav();bindDiureticModule();
}
function interactionSeverity(level=''){const x=String(level).toUpperCase();if(x.includes('КРАС')||x.includes('RED'))return 3;if(x.includes('ОРАНЖ')||x.includes('ORANGE'))return 2;return 1;}
function interactionCandidatesForDrug(d){
 const p=profileFor(d)||{},base=(p.interactions||[]).map((x,i)=>({id:`profile-${d.n}-${i}`,level:x.level||'ЖЁЛТЫЙ',title:x.text?.split(':')[0]||'Взаимодействие',text:x.text||'',source:'Карточка препарата'}));
 const linked=Object.values(INTERACTIONS).flat().filter(x=>(x.drugIds||[]).includes(d.n)).map(x=>({id:x.id,level:/risk|токс|кровотеч|аритм|SJS|AKI/i.test((x.summary||'')+' '+(x.note||''))?'ОРАНЖЕВЫЙ':'ЖЁЛТЫЙ',title:x.title,text:x.summary||'',chain:x.chain||[],source:'Структурированная база взаимодействий'}));
 const seen=new Set();return [...base,...linked].filter(x=>{const k=(x.title+'|'+x.text).toLowerCase();if(seen.has(k))return false;seen.add(k);return true}).sort((a,b)=>interactionSeverity(b.level)-interactionSeverity(a.level));
}
function renderInteractionResults(d){const arr=interactionCandidatesForDrug(d);if(!arr.length)return `<div class="emptyState"><b>Структурированные взаимодействия не найдены</b><p>Открой карточку препарата для полной монографии.</p></div>`;
 return `<div class="interactionDrugHeader"><div class="iconFrame">${doodleIcon('interactions')}</div><div><h3>${esc(d.name)}</h3><p>${esc(d.group)}</p></div></div><div class="interactionDangerList">${arr.map(x=>accordion({id:`interaction-search-${d.n}-${x.id}`,title:x.title,subtitle:x.source,level:2,badge:x.level,body:`<div class="interactionSeverity severity-${interactionSeverity(x.level)}"><b>${esc(x.level)}</b></div><p>${esc(x.text)}</p>${x.chain?.length?renderLearningWhiteboard({title:'Механизм взаимодействия',steps:x.chain,showSources:false}):''}`})).join('')}</div>`;}
function renderInteractionsHub(){
 app.innerHTML=header()+`<div class="page"><div class="paperTitle"><span class="handMini">Поиск по препарату</span><h2>Взаимодействия</h2><p>Начни вводить название препарата. Опасные взаимодействия выводятся первыми и раскрываются по нажатию.</p></div><div class="interactionSearchBox"><label for="interactionDrugSearch">Препарат</label><input id="interactionDrugSearch" autocomplete="off" placeholder="Например: amiodarone, warfarin, tramadol…"><div id="interactionSuggest" class="interactionSuggest"></div></div><div id="interactionResult"><div class="emptyState"><div class="big">${doodleIcon('interactions')}</div><b>Выбери препарат</b><p>Красные и оранжевые взаимодействия будут показаны вверху списка.</p></div></div></div>`+bottomNav('study');bindNav();
 const input=document.getElementById('interactionDrugSearch'),suggest=document.getElementById('interactionSuggest'),out=document.getElementById('interactionResult');
 const choose=d=>{input.value=d.name;suggest.innerHTML='';out.innerHTML=renderInteractionResults(d);bindAccordions(out)};
 input.addEventListener('input',()=>{const q=input.value.trim().toLowerCase();if(!q){suggest.innerHTML='';return}const found=DRUGS.filter(d=>drugSearchText(d).includes(q)).slice(0,10);suggest.innerHTML=found.map(d=>`<button type="button" data-drug-pick="${d.n}"><b>${esc(d.name)}</b><small>${esc(d.group)}</small></button>`).join('');suggest.querySelectorAll('[data-drug-pick]').forEach(b=>b.onclick=()=>choose(drugMap[String(b.dataset.drugPick)]));});
}
function renderSystemAbbrHub(){app.innerHTML=header()+`<div class="page"><div class="paperTitle"><span class="handMini">Сначала расшифровка</span><h2>Аббревиатуры</h2><p>Словарь организован по новым системам.</p></div><div class="topicGrid">${SYSTEMS.map(s=>{const n=systemAbbreviations(s).length;return `<div class="card clickCard" data-route="#system/${s.id}/abbr"><div class="cardHead"><div class="iconFrame topicLineIcon">${systemIcon(s)}</div><div><h3>${esc(s.title)}</h3><p>${n} сокращений из текущего словаря</p></div></div></div>`}).join("")}</div></div>`+bottomNav("study");bindNav();}


let testSession=null;

function bindTestStarters(root=document){
  root.querySelectorAll("[data-start-test]").forEach(b=>{if(b.dataset.testBound)return;b.dataset.testBound="1";b.addEventListener("click",()=>startTestSession(b.dataset.startTest))});
}

function startTestSession(spec){
  let questions=[...TESTS];
  if(spec?.startsWith("topic:")) {
    const topicId=spec.slice("topic:".length);
    questions=questions.filter(q=>q.topic===topicId);
  }
  if(spec?.startsWith("section:")) {
    const sectionId=spec.slice("section:".length);
    questions=questions.filter(q=>q.sectionId===sectionId);
  }
  if(spec?.startsWith("sections:")) {
    const ids=new Set(spec.slice("sections:".length).split(',').filter(Boolean));
    questions=questions.filter(q=>ids.has(q.sectionId));
  }
  if(spec?.startsWith("system:")) {
    const systemId=spec.slice("system:".length),s=systemMap[systemId];
    questions=questions.filter(q=>s?.sourceTopics?.includes(q.topic));
  }
  if(spec?.startsWith("cardio-section:")) {
    const area=spec.slice("cardio-section:".length),sections=new Set(cardioTestSections(area));
    questions=questions.filter(q=>sections.has(q.sectionId));
  }
  if(spec?.startsWith("disease:")) {
    const diseaseId=spec.slice("disease:".length),d=diseaseMap[diseaseId];
    questions=questions.filter(q=>(d?.sectionIds||[]).includes(q.sectionId));
  }
  if(!questions.length){
    const knownSections=[...new Set(TESTS.map(q=>q.sectionId))].filter(Boolean);
    console.error("ProPharm: test selection returned 0 questions", {spec,total:TESTS.length,knownSections});
    alert(`Не удалось загрузить вопросы для этого блока. Всего в базе сейчас: ${TESTS.length}. Обнови страницу — если ошибка повторится, это проблема кэша.`);
    return;
  }
  testSession={
    id:`session-${Date.now()}-${Math.random().toString(36).slice(2)}`,spec:spec||"all",startedAt:new Date().toISOString(),
    questions, index:0, firstTryCorrect:0, retriedQuestions:0, extraWrongAttempts:0,
    currentWrong:[], errors:[], answered:0
  };
  if(location.hash==="#quiz") renderQuiz();
  else location.hash="#quiz";
}

function currentQuestion(){return testSession?.questions?.[testSession.index]}

function renderQuiz(){
  if(!testSession){location.hash="#tests";return;}
  if(!testSession.questions?.length){
    console.error("ProPharm: attempted to render an empty test session");
    testSession=null;
    location.hash="#tests";
    return;
  }
  if(testSession.index>=testSession.questions.length){renderQuizResults();return;}
  const q=currentQuestion();
  const progress=Math.round((testSession.index/testSession.questions.length)*100);
  app.innerHTML=header()+`<div class="page quizPage">
    <div class="quizTop"><button class="quizExit" id="quizExit">✕ Закрыть</button><div class="quizCount">${testSession.index+1} / ${testSession.questions.length}</div></div>
    <div class="progressTrack"><div class="progressFill" style="width:${progress}%"></div></div>
    <div class="card quizCard">
      <div class="resultType">${esc(q.sectionTitle)} · вопрос ${q.number}</div>
      ${renderAbbreviationLead([q.question,...q.options.map(o=>o.text)].join(" "))}
      <h2>${esc(q.question)}</h2>
      ${renderVisual(q.visual||SECTION_VISUALS[q.sectionId])}
      ${q.disputed?`<div class="sourceNote">⚠ В исходном материале этот вопрос отмечен как спорный/исправленный. После ответа покажу примечание.</div>`:""}
      <div class="quizOptions">${q.options.map(o=>`<button class="quizOption" data-option="${o.id}"><span class="optionLetter">${o.id}</span><span>${esc(o.text)}</span></button>`).join("")}</div>
      <div class="questionPersonalActions">${favoriteButton("question",q.id,"В избранное")}${reviewButton("question",q.id,"Повторить позже")}</div>
      <div class="smallMuted" style="margin-top:10px">Если ошибёшься, получишь подсказку и сможешь отвечать снова до правильного варианта.</div>
    </div>
  </div>`;
  document.getElementById("quizExit").addEventListener("click",()=>{testSession=null;location.hash="#tests";});
  document.querySelectorAll(".quizOption").forEach(b=>b.addEventListener("click",()=>handleQuizAnswer(b.dataset.option,b)));
  bindScientificImages(app);
  bindPersonalActions();
}

function handleQuizAnswer(optionId,button){
  const q=currentQuestion();
  if(!q||button.disabled)return;
  if(optionId===q.correct){
    button.classList.add("correctAnswer");
    document.querySelectorAll(".quizOption").forEach(x=>x.disabled=true);
    if(testSession.currentWrong.length===0)testSession.firstTryCorrect++;
    else testSession.retriedQuestions++;
    testSession.answered++;
    recordQuestionResult({question_id:q.id,system_id:q.topic||null,section_id:q.sectionId||null,correct:true,first_try:testSession.currentWrong.length===0,wrong_count:testSession.currentWrong.length}).catch(console.warn);
    if(testSession.currentWrong.length>=2)setReview("question",q.id,{reason:"repeated_wrong_answer",priority:3}).catch(console.warn);
    showExplanationModal(q);
  }else{
    button.classList.add("wrongAnswer"); button.disabled=true;
    testSession.currentWrong.push(optionId);
    testSession.extraWrongAttempts++;
    let err=testSession.errors.find(e=>e.questionId===q.id);
    if(!err){err={questionId:q.id,sectionTitle:q.sectionTitle,number:q.number,question:q.question,wrong:[],correct:q.correct,correctText:q.options.find(o=>o.id===q.correct)?.text||q.correctText};testSession.errors.push(err);}
    err.wrong.push({id:optionId,text:q.options.find(o=>o.id===optionId)?.text||""});
    showHintModal(q,optionId);
  }
}

function modalShell(inner){
  const el=document.createElement("div"); el.className="modalBackdrop"; el.innerHTML=`<div class="modalSheet">${inner}</div>`; document.body.appendChild(el); return el;
}

function showHintModal(q,optionId){
  const wrong=q.options.find(o=>o.id===optionId);
  const modal=modalShell(`<div class="modalHandle"></div><div class="modalIcon bad">✕</div><h2>Пока неверно</h2><p class="modalWrong"><b>${esc(optionId)}. ${esc(wrong?.text||"")}</b></p><div class="hintBox"><b>Подсказка</b><p>${esc(q.hint)}</p></div><button class="modalPrimary" id="hintClose">Попробовать ещё раз</button>`);
  modal.querySelector("#hintClose").addEventListener("click",()=>modal.remove());
}

function showExplanationModal(q){
  const main=q.explanation?.length?q.explanation.map(x=>`<p>${esc(x)}</p>`).join(""):`<p>Правильный ответ указан в исходном материале.</p>`;
  const opts=q.options.map(o=>{
    const isCorrect=o.id===q.correct;
    const exp=isCorrect?esc(q.optionExplanations?.[o.id]||q.explanation?.join(" ")||"Правильный вариант."):esc(q.optionExplanations?.[o.id]||"В исходном материале отдельный комментарий к этому варианту не сохранён.");
    return `<div class="explainOption ${isCorrect?"good":"badLine"}"><b>${o.id}. ${esc(o.text)}</b><div>${exp}</div></div>`;
  }).join("");
  const notes=q.sourceNotes?.length?`<div class="sourceNote">${q.sourceNotes.map(x=>`<div>⚠ ${esc(x)}</div>`).join("")}</div>`:"";
  const abbreviationBlock=renderAbbreviationLead([q.question,...q.options.map(o=>o.text),...(q.explanation||[]),...Object.values(q.optionExplanations||{})].join(" "));
  const modal=modalShell(`<div class="modalHandle"></div><div class="modalIcon good">✓</div><h2>Правильно</h2>${abbreviationBlock}<div class="correctBanner"><b>${esc(q.correct)}. ${esc(q.options.find(o=>o.id===q.correct)?.text||q.correctText||"")}</b></div><div class="explanationText">${main}</div><h3>Разбор всех вариантов</h3>${opts}${renderVisual(q.visual||SECTION_VISUALS[q.sectionId])}${notes}<div class="modalPersonalActions">${favoriteButton("question",q.id,"Избранное")}${reviewButton("question",q.id,"Повторить")}</div><button class="modalPrimary" id="nextQuestion">${testSession.index+1>=testSession.questions.length?"Показать результат":"Следующий вопрос"}</button>`);
  bindPersonalActions();
  bindScientificImages(modal);
  modal.querySelector("#nextQuestion").addEventListener("click",()=>{
    modal.remove(); testSession.index++; testSession.currentWrong=[]; renderQuiz();
  });
}

function normText(s){return String(s||"").toLowerCase().replace(/[^a-zа-я0-9]+/g," ").trim()}

async function renderQuizResults(){
  const s=testSession;if(!s){location.hash="#tests";return;}
  const total=s.questions.length,score=total?Math.round(s.firstTryCorrect/total*100):0,completedAt=new Date().toISOString();
  const firstQ=s.questions[0]||{};
  const payload={id:s.id,test_id:s.spec,system_id:firstQ.topic||null,section_id:s.spec?.startsWith('section:')?s.spec.slice(8):(firstQ.sectionId||null),started_at:s.startedAt,completed_at:completedAt,questions_total:total,first_try_correct:s.firstTryCorrect,questions_with_retries:s.retriedQuestions,wrong_selections:s.extraWrongAttempts,score,duration_seconds:Math.max(0,Math.round((Date.parse(completedAt)-Date.parse(s.startedAt))/1000))};
  if(!s.saved){s.saved=true;saveTestSession(payload).then(()=>syncPending()).catch(console.warn)}
  app.innerHTML=header()+`<div class="page">
    <section class="hero"><h2>Результат сессии</h2><p>Результат сохранён в личной истории. При подключённом Supabase он синхронизируется между устройствами.</p>
      <div class="stats"><div class="stat"><b>${total}</b><span>вопросов</span></div><div class="stat"><b>${s.firstTryCorrect}</b><span>с 1-й попытки</span></div><div class="stat"><b>${s.retriedQuestions}</b><span>потребовалась ещё попытка</span></div><div class="stat"><b>${s.extraWrongAttempts}</b><span>неверных выборов</span></div></div>
    </section>
    <div class="sectionTitle"><h2>Где были ошибки</h2><span class="muted">${s.errors.length} вопросов</span></div>
    ${s.errors.length?`<div class="list">${s.errors.map(e=>`<div class="theoryCard"><div class="resultType">${esc(e.sectionTitle)} · вопрос ${e.number}</div><h3>${esc(e.question)}</h3><div class="errorChoices"><b>Неверные попытки:</b>${e.wrong.map(w=>`<div class="wrongMini">✕ ${esc(w.id)}. ${esc(w.text)}</div>`).join("")}</div><div class="rightMini">✓ Правильно: ${esc(e.correct)}. ${esc(e.correctText)}</div>${reviewButton('question',e.questionId,'Повторить')}</div>`).join("")}</div>`:`<div class="emptyState"><div class="big">🏆</div><b>Ни одной ошибки</b><p>Все вопросы были отвечены правильно с первой попытки.</p></div>`}
    <div class="quickStudy"><button class="moduleButton secondary" data-route="#my-study">Моя статистика</button><button class="moduleButton secondary" data-route="#review">Повторить слабое</button></div>
    <button class="moduleButton" id="closeResults">Закрыть результаты</button>
  </div>`;
  bindNav();
  document.getElementById("closeResults").addEventListener("click",()=>{testSession=null;location.hash="#tests";});
}

function routeNeedsGate(parts){return !['login','register','reset-password'].includes(parts[0]);}
function router(){
  try{
    const h=(location.hash||"#home").slice(1),parts=h.split("/");
    // Production access gate: no Supabase configuration means no study-content fallback.
    if(!isAuthConfigured())return renderAuthUnconfigured();
    if(authState.loading||authState.profileLoading||!authState.initialized)return renderAuthLoading();
    if(!authState.session){
      if(parts[0]==='register')return renderRegister();
      return renderLogin();
    }
    if(parts[0]==='reset-password')return renderResetPassword();
    if(!authState.profile){
      if(authState.error)return renderAuthProfileError();
      return renderAuthLoading();
    }
    const status=authState.profile.status||'pending';
    if(status!=='approved')return renderAccessState(status);
    // From this point on the session is real and the server-verified profile is approved.
    if(parts[0]==='login'||parts[0]==='register'){location.hash='#home';return;}
    if(parts[0]=="home"||!parts[0])renderHome();
    else if(parts[0]=="study")renderStudyHub();
    else if(parts[0]=="foundations")renderFoundationsHub();
    else if(parts[0]=="foundation"&&parts.length>=2)renderFoundationDetail(parts[1]);
    else if(parts[0]=="systems")renderSystemsHub();
    else if(parts[0]=="system"&&parts.length===2)renderSystem(parts[1]);
    else if(parts[0]=="system"&&parts.length>=3)renderSystemSection(parts[1],parts[2]);
    else if(parts[0]=="diseases")renderDiseasesHub();
    else if(parts[0]=="cardio-pathology")renderCardioPathologyDetail(parts[1]);
    else if(parts[0]=="disease")renderDisease(parts[1]);
    else if(parts[0]=="mechanisms")renderMechanismsHub();
    else if(parts[0]=="mechanism")renderMechanismDetail(parts[1]);
    else if(parts[0]=="interactions-hub")renderInteractionsHub();
    else if(parts[0]=="topics")renderSystemsHub();
    else if(parts[0]=="topic"&&parts.length===2)renderTopic(parts[1]);
    else if(parts[0]=="topic"&&parts.length>=3)renderTopicSection(parts[1],parts[2]);
    else if(parts[0]=="drugs")renderAllDrugs();
    else if(parts[0]=="drug")renderDrug(parts[1]);
    else if(parts[0]=="tests")renderTests();
    else if(parts[0]=="memory-trainer")renderMemoryTrainer();
    else if(parts[0]=="memory-lesson")renderMemoryLesson();
    else if(parts[0]=="quiz")renderQuiz();
    else if(parts[0]=="search")renderSearch();
    else if(parts[0]=="theory-hub")renderSystemsHub();
    else if(parts[0]=="tables")renderTablesHub();
    else if(parts[0]=="schemes"&&parts.length===1)renderSchemesHub();
    else if(parts[0]=="schemes"&&parts.length>=2)renderSchemesTopic(parts[1]);
    else if(parts[0]=="cards")renderCardsHub();
    else if(parts[0]=="abbr-hub")renderAbbrHub();
    else if(parts[0]=="settings")renderSettingsHub();
    else if(parts[0]=="profile")renderProfile();
    else if(parts[0]=="my-study")renderMyStudy();
    else if(parts[0]=="favorites")renderFavorites();
    else if(parts[0]=="review")renderReview();
    else if(parts[0]=="admin")renderAdmin();
    else renderHome();
    if(!['quiz','admin','settings','profile','my-study','favorites','review'].includes(parts[0]))recordStudyPosition(inferProgressFromRoute(parts)).catch(()=>{});
  }catch(err){
    console.error("ProPharm render error",err);
    if(!isAuthConfigured()||!authState.session||authState.profile?.status!=='approved')return renderAuthUnconfigured();
    app.innerHTML=header()+`<div class="page"><div class="emptyState routeError"><div class="big">!</div><b>Не удалось открыть раздел</b><p>${esc(err?.message||String(err))}</p><button class="moduleButton" data-route="#home">Вернуться на главную</button></div></div>`+bottomNav("home");bindNav();
  }
}
async function restoreSyncedSettings(){const row=await loadUserSettings().catch(()=>null);if(row?.settings_json){uiSettings=Object.assign({},uiSettings,row.settings_json);localStorage.setItem(UI_SETTINGS_KEY,JSON.stringify(uiSettings));applyUiSettings()}}
async function syncPersonalState(){if(authState.profile?.status!=='approved')return;await syncPending();await hydrateFromCloud();await restoreSyncedSettings()}
async function boot(){
  onAuthState(()=>{if(authState.initialized){router();if(authState.profile?.status==='approved')syncPersonalState().catch(()=>{});startAdminApplicationWatcher().catch(()=>{})}});
  window.addEventListener("hashchange",router);
  window.addEventListener("online",()=>{syncPersonalState().catch(()=>{});refreshAdminPendingCount().catch(()=>{})});
  navigator.serviceWorker?.addEventListener?.('message',event=>{if(event.data?.type==='PROPHARM_NOTIFICATION_OPEN'){location.hash=event.data.url||'#admin';router();}});
  await initAuth();
  if(authState.profile?.status==='approved')await syncPersonalState().catch(()=>{});
  await startAdminApplicationWatcher().catch(()=>{});
  router();
}
boot();
