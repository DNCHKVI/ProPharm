import { TOPICS } from "./data/topics.js?v=0.5.0";
import { DRUGS } from "./data/drugs.js?v=0.5.0";
import { ABBREVIATIONS } from "./data/abbreviations.js?v=0.5.0";
import { THEORY } from "./data/theory.js?v=0.5.0";
import { MECHANISMS } from "./data/mechanisms.js?v=0.5.0";
import { HIGH_YIELD } from "./data/highYield.js?v=0.5.0";
import { TESTS } from "./data/tests.js?v=0.5.0";
import { TEST_ANALYSES } from "./data/testAnalyses.js?v=0.5.0";
import { SOURCE_SECTIONS } from "./data/sourceSections.js?v=0.5.0";
import { INTERACTIONS } from "./data/interactions.js?v=0.5.0";
import { DRUG_KNOWLEDGE } from "./data/drugKnowledge.js?v=0.5.0";
import { SECTION_VISUALS } from "./data/sectionVisuals.js?v=0.5.0";
import { CARDIO49 } from "./data/cardio49.js?v=0.5.0";

const app = document.getElementById("app");
const topicMap = Object.fromEntries(TOPICS.map(t => [t.id,t]));
const drugMap = Object.fromEntries(DRUGS.map(d => [String(d.n),d]));
const esc = s => String(s ?? "").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));
const FAVORITES_KEY="propharm_favorite_drugs_v1";
const UI_SETTINGS_KEY="propharm_ui_settings_v1";
let favoriteDrugIds=new Set(JSON.parse(localStorage.getItem(FAVORITES_KEY)||"[]"));
let uiSettings=Object.assign({largeText:false,reducedMotion:false},JSON.parse(localStorage.getItem(UI_SETTINGS_KEY)||"{}"));
function saveFavorites(){localStorage.setItem(FAVORITES_KEY,JSON.stringify([...favoriteDrugIds]));}
function toggleFavoriteDrug(n){if(favoriteDrugIds.has(n))favoriteDrugIds.delete(n);else favoriteDrugIds.add(n);saveFavorites();const el=document.querySelector(`[data-favorite-drug="${n}"]`);if(el){el.classList.toggle("isFav",favoriteDrugIds.has(n));el.innerHTML=favoriteDrugIds.has(n)?"★ В избранном":"☆ В избранное";}}
function applyUiSettings(){document.documentElement.classList.toggle("largeText",!!uiSettings.largeText);document.documentElement.classList.toggle("reducedMotion",!!uiSettings.reducedMotion);}
applyUiSettings();


function doodleIcon(type){
 const common=`viewBox="0 0 64 64" aria-hidden="true" focusable="false"`;
 const map={
  tests:`<svg ${common}><path d="M20 10h26a6 6 0 0 1 6 6v38H14V16a6 6 0 0 1 6-6Z" fill="#fff" stroke="currentColor" stroke-width="3"/><path d="M24 8h18v8H24z" fill="#a9c6df" stroke="currentColor" stroke-width="3"/><path d="m21 27 3 3 5-6M21 38l3 3 5-6M21 49l3 3 5-6" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round"/><path d="M34 28h11M34 39h11M34 50h11" stroke="currentColor" stroke-width="3" stroke-linecap="round"/></svg>`,
  theory:`<svg ${common}><path d="M8 16c9-5 18-4 25 1v36c-7-5-16-6-25-1V16Zm48 0c-9-5-18-4-23 1v36c7-5 14-6 23-1V16Z" fill="#fff" stroke="currentColor" stroke-width="3" stroke-linejoin="round"/><path d="M15 25h11M15 33h11M40 25h10M40 33h10" stroke="#8faec7" stroke-width="2.5" stroke-linecap="round"/></svg>`,
  tables:`<svg ${common}><rect x="8" y="10" width="48" height="44" rx="5" fill="#fff" stroke="currentColor" stroke-width="3"/><path d="M8 24h48M8 38h48M24 10v44M40 10v44" stroke="#8faec7" stroke-width="2.5"/></svg>`,
  schemes:`<svg ${common}><rect x="25" y="7" width="14" height="12" rx="3" fill="#a9c6df" stroke="currentColor" stroke-width="3"/><rect x="7" y="43" width="18" height="14" rx="4" fill="#ecc4b5" stroke="currentColor" stroke-width="3"/><rect x="39" y="43" width="18" height="14" rx="4" fill="#a9c6df" stroke="currentColor" stroke-width="3"/><path d="M32 19v10M16 43V34h32v9" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round"/></svg>`,
  cards:`<svg ${common}><path d="m14 19 31-7 6 30-31 7-6-30Z" fill="#a9c6df" stroke="currentColor" stroke-width="3"/><rect x="10" y="22" width="39" height="29" rx="5" fill="#fff7e9" stroke="currentColor" stroke-width="3"/><path d="M27 33c3-5 10-3 10 2 0 5-8 9-8 9s-8-4-8-9c0-5 5-7 6-2Z" fill="#90a9c1"/></svg>`,
  progress:`<svg ${common}><path d="M10 52h46" stroke="currentColor" stroke-width="3" stroke-linecap="round"/><rect x="15" y="37" width="8" height="15" rx="2" fill="#a9c6df" stroke="currentColor" stroke-width="2.5"/><rect x="29" y="28" width="8" height="24" rx="2" fill="#a9c6df" stroke="currentColor" stroke-width="2.5"/><rect x="43" y="18" width="8" height="34" rx="2" fill="#a9c6df" stroke="currentColor" stroke-width="2.5"/><path d="m12 33 12-8 10 1 15-14M44 12h7v7" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
  favorites:`<svg ${common}><path d="m32 8 7 14 16 2-12 11 3 16-14-8-14 8 3-16L9 24l16-2 7-14Z" fill="#f4d59c" stroke="currentColor" stroke-width="3" stroke-linejoin="round"/></svg>`,
  settings:`<svg ${common}><path d="M25 9h14l2 7 7 4 7-2 7 12-5 5v8l5 5-7 12-7-2-7 4-2 7H25l-2-7-7-4-7 2-7-12 5-5v-8l-5-5 7-12 7 2 7-4 2-7Z" transform="scale(.78) translate(9 7)" fill="#a9c6df" stroke="currentColor" stroke-width="3"/><circle cx="32" cy="32" r="9" fill="#fff" stroke="currentColor" stroke-width="3"/></svg>`,
  search:`<svg ${common}><circle cx="28" cy="28" r="15" fill="#fff" stroke="currentColor" stroke-width="3"/><path d="m39 39 13 13" stroke="currentColor" stroke-width="4" stroke-linecap="round"/></svg>`,
  home:`<svg ${common}><path d="m10 29 22-18 22 18v26H38V39H26v16H10V29Z" fill="#a9c6df" stroke="currentColor" stroke-width="3" stroke-linejoin="round"/></svg>`,
  study:`<svg ${common}><path d="M8 16c9-5 18-4 25 1v36c-7-5-16-6-25-1V16Zm48 0c-9-5-18-4-23 1v36c7-5 14-6 23-1V16Z" fill="#fff" stroke="currentColor" stroke-width="3" stroke-linejoin="round"/></svg>`,
  profile:`<svg ${common}><circle cx="32" cy="22" r="9" fill="#fff" stroke="currentColor" stroke-width="3"/><path d="M15 54c2-13 10-19 17-19s15 6 17 19" fill="#fff" stroke="currentColor" stroke-width="3" stroke-linecap="round"/></svg>`
 };
 return map[type]||map.study;
}
function header(){return `<div class="topbar innerTopbar"><button class="backMini" onclick="history.length>1?history.back():location.hash='#home'">‹</button><div class="brandCompact"><span>ProPharm</span><small>экзаменационная база</small></div><div class="topDoodle">✦</div></div>`;}
function bottomNav(active){
 const items=[["home","#home","home","Главная"],["search","#search","search","Поиск"],["study","#topics","study","Учёба"],["profile","#profile","profile","Профиль"]];
 return `<nav class="bottomNav">${items.map(([id,route,ic,t])=>`<button class="navBtn ${active===id?"active":""}" data-route="${route}"><span class="navSketch">${doodleIcon(ic)}</span><span>${t}</span></button>`).join("")}</nav>`;
}
function bindNav(){
 document.querySelectorAll("[data-nav]").forEach(b=>b.addEventListener("click",()=>location.hash=b.dataset.nav==="home"?"#home":`#${b.dataset.nav}`));
 document.querySelectorAll("[data-route]").forEach(el=>el.addEventListener("click",()=>location.hash=el.dataset.route));
 document.querySelectorAll("[data-favorite-drug]").forEach(el=>el.addEventListener("click",()=>toggleFavoriteDrug(+el.dataset.favoriteDrug)));
}
function countsForTopic(id){return {drugs:DRUGS.filter(d=>d.topics.includes(id)).length,abbr:(ABBREVIATIONS[id]||[]).length,theory:(THEORY[id]||[]).length,mechanisms:(MECHANISMS[id]||[]).length,tests:TESTS.filter(q=>q.topic===id).length,analyses:TEST_ANALYSES.filter(q=>q.topic===id).length,interactions:(INTERACTIONS[id]||[]).length};}

function renderHome(){
 const tiles=[
  ["tests","Тесты","Проверь свои знания","#tests","blue"],
  ["theory","Теория","Изучай в удобном формате","#theory-hub","blue"],
  ["tables","Таблицы","Вся важная информация","#tables","blue"],
  ["schemes","Схемы","Наглядно и понятно","#schemes","rose"],
  ["cards","Карточки","Запоминай легко","#cards","rose"],
  ["progress","Прогресс","Следи за текущей сессией","#progress","blue"],
  ["favorites","Избранное","Сохраняй важное","#favorites","cream"],
  ["settings","Настройки","Сделай приложение своим","#settings","blue"]
 ];
 app.innerHTML=`<div class="homePage page">
   <section class="homeIntro">
     <div class="handQuote">Хорошие люди учатся<br>каждый день ♡</div>
     <div class="homeTitleWrap"><h1 class="homeTitle">Главная</h1><span class="paintStroke"></span></div>
     <p class="homeLead">Выбери раздел</p>
     <div class="studyStillLife" aria-hidden="true">
       <div class="book b1">Учёба</div><div class="book b2">Развитие</div><div class="book b3">Лучшая версия себя</div>
       <div class="mug">Больше<br>знаний<br>♡</div>
     </div>
   </section>
   <section class="dashboardGrid">${tiles.map(([ic,title,desc,route,tone])=>`<button class="dashTile tone-${tone}" data-route="${route}"><span class="dashIcon">${doodleIcon(ic)}</span><span class="dashText"><b>${title}</b><small>${desc}</small></span><span class="dashArrow">→</span></button>`).join("")}</section>
   <div class="homeFooterNote">Маленькие шаги тоже ведут к большим целям ♡</div>
   <div class="stickyNote">Ты<br>можешь<br>больше<br>♡</div>
 </div>`+bottomNav("home");bindNav();
}
function renderTopics(){
 app.innerHTML=header()+`<div class="page"><div class="sectionTitle"><h2>Темы</h2><span class="muted">${TOPICS.length} разделов</span></div><div class="topicGrid">${TOPICS.map(t=>{const c=countsForTopic(t.id);return `<div class="card clickCard" data-route="#topic/${t.id}"><div class="cardHead"><div class="iconFrame">${t.icon}</div><div><h3>${esc(t.title)}</h3><p>${esc(t.description)}</p><span class="badge">${c.drugs} препаратов</span>${c.abbr?`<span class="badge">${c.abbr} аббр.</span>`:""}${c.theory?`<span class="badge blue">${c.theory} теория</span>`:""}</div></div></div>`;}).join("")}</div></div>`+bottomNav("study");bindNav();
}
function topicSections(t){const c=countsForTopic(t.id);const defs=[["theory","📘","Теория",c.theory,"Конспекты и интерактивные учебные модули."],["mechanisms","🧬","Механизмы",c.mechanisms,"Сигнальные пути и причинно-следственные цепочки."],["drugs","💊","Препараты",c.drugs,"Препараты, связанные с этой темой."],["abbr","🔤","Аббревиатуры",c.abbr,"Только словарь этой темы — без смешивания."],["interactions","🔗","Взаимодействия",c.interactions,"Лекарственные взаимодействия с механизмом и клиническим следствием."],["tests","📝","Тесты",c.tests,"Вопросы только по выбранной теме."],["analysis","✅","Разбор тестов",c.analyses,"Почему правильный ответ верен и почему остальные неверны."],["high","⚡","High-yield",(HIGH_YIELD[t.id]||[]).length,"Короткий экзаменационный повтор."]];return defs.map(([id,ic,title,count,desc])=>`<div class="card clickCard" data-route="#topic/${t.id}/${id}"><div class="cardHead"><div class="iconFrame">${ic}</div><div><h3>${title}</h3><p>${desc}</p><span class="badge">${count}</span></div></div></div>`).join("");}
function renderTopic(id){const t=topicMap[id];if(!t){location.hash="#topics";return;}app.innerHTML=header()+`<div class="page"><div class="breadcrumb"><button data-route="#topics">Темы</button><span>›</span><span>${esc(t.short)}</span></div><div class="topicHeader"><div class="iconFrame">${t.icon}</div><div><h2>${esc(t.title)}</h2><p>${esc(t.description)}</p></div></div><div class="sectionGrid">${topicSections(t)}</div></div>`+bottomNav("study");bindNav();}
function sectionShell(t,title,content){return header()+`<div class="page"><div class="breadcrumb"><button data-route="#topics">Темы</button><span>›</span><button data-route="#topic/${t.id}">${esc(t.short)}</button><span>›</span><span>${esc(title)}</span></div><div class="topicHeader"><div class="iconFrame">${t.icon}</div><div><h2>${esc(title)}</h2><p>${esc(t.title)}</p></div></div>${content}</div>`+bottomNav("study");}

function renderVisual(v){
  if(!v||!v.steps?.length)return "";
  const title=v.title?`<div class="visualTitle">${esc(v.title)}</div>`:"";
  const steps=v.steps.map((x,i)=>`<div class="visualNode"><span class="visualIndex">${i+1}</span><span>${esc(x)}</span></div>${i<v.steps.length-1?'<div class="visualArrow">→</div>':''}`).join("");
  const special=v.kind?` visual-${esc(v.kind)}`:"";
  return `<div class="visualCard${special}">${title}<div class="visualFlow">${steps}</div></div>`;
}
function renderInteractions(t){
  const arr=INTERACTIONS[t.id]||[];
  if(!arr.length)return `<div class="emptyState"><div class="big">🔗</div><b>Взаимодействия пока не заполнены</b><p>Они будут добавляться из комментариев к тестам и теории.</p></div>`;
  return `<div class="list">${arr.map(x=>`<div class="theoryCard"><div class="resultType">${esc(x.type||"Взаимодействие")}</div><h3>${esc(x.title)}</h3><p>${esc(x.summary||"")}</p>${renderVisual({title:"Механизм взаимодействия",kind:"flow",steps:x.chain||[]})}${x.note?`<div class="sourceNote">${esc(x.note)}</div>`:""}</div>`).join("")}</div>`;
}
function renderTopicTheory(t){const items=THEORY[t.id]||[];if(!items.length)return `<div class="emptyState"><div class="big">📘</div><b>Теория пока не заполнена</b><p>Структура уже готова. Следующие конспекты добавим сюда по мере подготовки.</p></div>`;return `<div class="list">${items.map(x=>`<div class="theoryCard"><h3>${esc(x.title)}</h3><p>${esc(x.summary)}</p>${x.type==="interactive"?`<a class="moduleButton" href="${x.url}">📈 Открыть интерактивный модуль</a>`:""}${x.body?.length?`<div class="theoryBody">${x.body.map(v=>`<p>• ${esc(v)}</p>`).join("")}</div>`:""}${renderVisual(x.visual)}</div>`).join("")}</div>`;}
function renderMechanisms(t){const arr=MECHANISMS[t.id]||[];if(!arr.length)return `<div class="emptyState"><div class="big">🧬</div><b>Механизмы пока не заполнены</b><p>Здесь будут схемы receptor → messenger → effect → drug.</p></div>`;return `<div class="list">${arr.map(m=>`<div class="mechanismCard"><h3>${esc(m.title)}</h3><div class="chain">${m.chain.map((v,i)=>`${i?'<div class="chainArrow">→</div>':""}<div class="chainNode">${esc(v)}</div>`).join("")}</div><div class="chips">${m.examples.map(v=>`<span class="chip">${esc(v)}</span>`).join("")}</div></div>`).join("")}</div>`;}
function drugRows(list){return `<div class="list">${list.map(d=>`<div class="drugRow"><div class="drugNum">#${d.n}</div><div class="drugMain" style="flex:1"><b>${esc(d.name)}</b><span>${esc(d.group)}</span><div>${d.topics.map(x=>`<span class="badge">${esc(topicMap[x]?.short||x)}</span>`).join("")}</div></div><button class="drugLink" data-route="#drug/${d.n}">Открыть</button></div>`).join("")}</div>`;}
function renderTopicDrugs(t){const list=DRUGS.filter(d=>d.topics.includes(t.id));return `<div class="toolbar"><input id="topicDrugSearch" placeholder="Поиск в ${esc(t.short)}…"><span class="badge blue">${list.length} препаратов</span></div><div id="topicDrugList">${drugRows(list)}</div>`;}
function abbrRow(a){return `<div class="abbrRow"><b>${esc(a.abbr)}</b><div class="full">${esc(a.full)}</div><div class="ru">${esc(a.ru)}</div><div class="subtopic">${esc(a.subtopic)}</div></div>`;}
function renderAbbr(t){const arr=ABBREVIATIONS[t.id]||[];if(!arr.length)return `<div class="emptyState"><div class="big">🔤</div><b>Словарь этой темы пока не заполнен</b><p>Аббревиатуры будут добавляться внутри темы, а не в один смешанный список.</p></div>`;return `<div class="toolbar"><input id="abbrSearch" placeholder="Поиск по аббревиатурам ${esc(t.short)}…"><span class="badge">${arr.length}</span></div><div id="abbrList" class="list">${arr.map(abbrRow).join("")}</div>`;}
function renderTestsSection(t, analysis=false){
  const arr=(analysis?TEST_ANALYSES:TESTS).filter(x=>x.topic===t.id);
  if(!arr.length) return `<div class="emptyState"><div class="big">${analysis?"✅":"📝"}</div><b>${analysis?"Разборов":"Тестов"} пока нет</b></div>`;
  if(!analysis){
    const sections=SOURCE_SECTIONS.filter(s=>s.topic===t.id);
    return `<div class="card"><h3>Интерактивный тест</h3><p>${arr.length} вопросов из загруженного материала. Результаты сессии нигде не сохраняются.</p>
      <button class="moduleButton" data-start-test="topic:${t.id}">▶ Начать тест по теме (${arr.length})</button></div>
      <div class="sectionTitle"><h2>Блоки источника</h2></div>
      <div class="list">${sections.map(s=>`<div class="theoryCard"><h3>${esc(s.title)}</h3><p>${s.count} вопросов</p><button class="drugLink" data-start-test="section:${s.id}">Начать</button></div>`).join("")}</div>`;
  }
  const qmap=Object.fromEntries(TESTS.map(q=>[q.id,q]));
  return `<div class="list">${arr.map(a=>{
    const q=qmap[a.questionId]; if(!q)return "";
    return `<div class="theoryCard"><div class="resultType">${esc(q.sectionTitle)} · вопрос ${q.number}</div><h3>${esc(q.question)}</h3>
      <div class="answerReview"><b>Правильный ответ: ${esc(q.correct)}. ${esc(q.options.find(o=>o.id===q.correct)?.text||q.correctText||"")}</b></div>
      ${a.explanation?.length?`<div class="reviewText">${a.explanation.map(x=>`<p>${esc(x)}</p>`).join("")}</div>`:""}
      ${q.options.map(o=>`<div class="reviewOption ${o.id===q.correct?"isCorrect":""}"><b>${o.id}. ${esc(o.text)}</b><div>${o.id===q.correct?"Правильный вариант.":esc(a.optionExplanations?.[o.id]||"В исходном материале отдельный комментарий к этому варианту не сохранён.")}</div></div>`).join("")}
      ${renderVisual(q.visual||a.visual||SECTION_VISUALS[q.sectionId])}${a.sourceNotes?.length?`<div class="sourceNote">${a.sourceNotes.map(x=>`<div>⚠ ${esc(x)}</div>`).join("")}</div>`:""}
    </div>`;
  }).join("")}</div>`;
}
function renderHigh(t){const arr=HIGH_YIELD[t.id]||[];if(!arr.length)return `<div class="emptyState"><div class="big">⚡</div><b>High-yield пока не заполнен</b></div>`;return `<div class="list">${arr.map((x,i)=>`<div class="highYieldItem"><b>${i+1}.</b> ${esc(x)}</div>`).join("")}</div>`;}

function renderTopicSection(id,section){const t=topicMap[id];if(!t){location.hash="#topics";return;}const titles={theory:"Теория",mechanisms:"Механизмы",drugs:"Препараты",abbr:"Аббревиатуры",interactions:"Взаимодействия",tests:"Тесты",analysis:"Разбор тестов",high:"High-yield"};let content="";if(section==="theory")content=renderTopicTheory(t);if(section==="mechanisms")content=renderMechanisms(t);if(section==="drugs")content=renderTopicDrugs(t);if(section==="abbr")content=renderAbbr(t);if(section==="interactions")content=renderInteractions(t);if(section==="tests")content=renderTestsSection(t,false);if(section==="analysis")content=renderTestsSection(t,true);if(section==="high")content=renderHigh(t);app.innerHTML=sectionShell(t,titles[section]||section,content);bindNav();bindTestStarters();if(section==="drugs"){const input=document.getElementById("topicDrugSearch"),target=document.getElementById("topicDrugList"),base=DRUGS.filter(d=>d.topics.includes(t.id));input?.addEventListener("input",()=>{const q=input.value.toLowerCase();target.innerHTML=drugRows(base.filter(d=>(d.name+" "+d.group).toLowerCase().includes(q)));bindNav();});}if(section==="abbr"){const input=document.getElementById("abbrSearch"),target=document.getElementById("abbrList"),base=ABBREVIATIONS[t.id]||[];input?.addEventListener("input",()=>{const q=input.value.toLowerCase();target.innerHTML=base.filter(a=>(a.abbr+" "+a.full+" "+a.ru+" "+a.subtopic).toLowerCase().includes(q)).map(abbrRow).join("");});}}

function renderAllDrugs(){const options=TOPICS.map(t=>`<option value="${t.id}">${esc(t.short)}</option>`).join("");app.innerHTML=header()+`<div class="page"><div class="sectionTitle"><h2>170 препаратов</h2><span class="muted">единая база</span></div><div class="toolbar"><input id="drugSearch" placeholder="Название или фармгруппа…"><select id="drugTopic"><option value="">Все темы</option>${options}</select></div><div id="allDrugList">${drugRows(DRUGS)}</div></div>`+bottomNav("study");bindNav();const s=document.getElementById("drugSearch"),f=document.getElementById("drugTopic"),out=document.getElementById("allDrugList");const apply=()=>{const q=s.value.toLowerCase(),topic=f.value;const rows=DRUGS.filter(d=>(!q||(d.name+" "+d.group).toLowerCase().includes(q))&&(!topic||d.topics.includes(topic)));out.innerHTML=drugRows(rows);bindNav();};s.addEventListener("input",apply);f.addEventListener("change",apply);}
function renderDrug(n){
  const d=drugMap[String(n)];if(!d){location.hash="#drugs";return;}
  const cardio=CARDIO49[d.name],k=DRUG_KNOWLEDGE[String(d.n)],relatedTests=TESTS.filter(q=>q.drugIds?.includes(d.n));
  const relatedInteractions=Object.entries(INTERACTIONS).flatMap(([topic,arr])=>arr.map(x=>({...x,topic}))).filter(x=>x.drugIds?.includes(d.n));
  app.innerHTML=header()+`<div class="page drugDetail"><div class="breadcrumb"><button data-route="#drugs">170 препаратов</button><span>›</span><span>#${d.n}</span></div><div class="topicHeader"><div class="iconFrame">💊</div><div><h2>${esc(d.name)}</h2><p>${esc(d.group)}</p></div></div>
  <div class="favoriteBar"><button class="favoriteBtn ${favoriteDrugIds.has(d.n)?"isFav":""}" data-favorite-drug="${d.n}">${favoriteDrugIds.has(d.n)?"★ В избранном":"☆ В избранное"}</button></div><div class="detailBox"><h3>Связанные темы</h3><div class="chips">${d.topics.map(x=>`<button class="chip" data-route="#topic/${x}">${esc(topicMap[x]?.title||x)}</button>`).join("")}</div></div>
  ${k?`<div class="detailBox"><h3>Механизм действия</h3>${k.mechanism?.map(x=>`<p>• ${esc(x)}</p>`).join("")||""}${renderVisual(k.visual)}</div><div class="detailBox"><h3>Экзаменационные комментарии</h3>${k.pearls?.map(x=>`<p>• ${esc(x)}</p>`).join("")||""}</div>`:""}
  ${cardio?`<div class="detailBox noteCardio"><h3>Связь с электрофизиологией ССС</h3><p>${esc(cardio.note)}</p><a class="moduleButton" href="modules/cardio/index.html">🫀 Открыть Cardio-модуль</a></div>`:""}
  ${relatedInteractions.length?`<div class="detailBox"><h3>Взаимодействия</h3>${relatedInteractions.map(x=>`<div class="interactionMini"><b>${esc(x.title)}</b><div>${esc(x.summary)}</div>${renderVisual({title:"Механизм",kind:"flow",steps:x.chain||[]})}</div>`).join("")}</div>`:""}
  <div class="detailBox"><h3>Связанные тесты</h3>${relatedTests.length?`<div class="chips">${relatedTests.slice(0,30).map(q=>`<span class="chip">${esc(q.sectionTitle)} · №${q.number}</span>`).join("")}</div>`:`<p class="smallMuted">Пока связанных вопросов нет.</p>`}</div>
  </div>`+bottomNav("study");bindNav();
}
function renderTests(){
  const topicCounts=TOPICS.map(t=>({...t,count:TESTS.filter(q=>q.topic===t.id).length})).filter(x=>x.count>0);
  app.innerHTML=header()+`<div class="page"><section class="hero"><h2>Экзаменационные тесты</h2><p>${TESTS.length} вопросов из двух загруженных блоков. Неправильный ответ → подсказка → повторная попытка; после правильного ответа — комментарии ко всем вариантам и схема.</p><div class="stats"><div class="stat"><b>${TESTS.length}</b><span>вопросов</span></div><div class="stat"><b>${SOURCE_SECTIONS.length}</b><span>блоков</span></div><div class="stat"><b>${topicCounts.length}</b><span>тем с тестами</span></div><div class="stat"><b>0</b><span>история не хранится</span></div></div><div class="warn">Результаты существуют только в текущей открытой сессии и не записываются в localStorage/cookies.</div></section>
  <div class="sectionTitle"><h2>Начать</h2></div><div class="sectionGrid"><div class="card clickCard"><div class="cardHead"><div class="iconFrame">🎯</div><div><h3>Все вопросы</h3><p>${TESTS.length} подряд.</p><button class="moduleButton" data-start-test="all">Начать</button></div></div></div>${topicCounts.map(t=>`<div class="card clickCard"><div class="cardHead"><div class="iconFrame">${t.icon}</div><div><h3>${esc(t.short)}</h3><p>${t.count} вопросов.</p><button class="moduleButton" data-start-test="topic:${t.id}">Начать</button></div></div></div>`).join("")}</div>
  <div class="sectionTitle"><h2>По блокам источника</h2></div><div class="list">${SOURCE_SECTIONS.map(s=>`<div class="theoryCard"><div class="resultType">${esc(topicMap[s.topic]?.short||s.topic)}</div><h3>${esc(s.title)}</h3><p>${s.count} вопросов</p><button class="drugLink" data-start-test="section:${s.id}">Начать тест</button></div>`).join("")}</div></div>`+bottomNav("study");bindNav();bindTestStarters();
}
function renderSearch(){app.innerHTML=header()+`<div class="page"><div class="sectionTitle"><h2>Глобальный поиск</h2></div><input id="globalSearch" placeholder="Например: SERCA, metoprolol, QT, SGLT2…"><div id="globalResults" class="globalResults" style="margin-top:10px"><div class="emptyState"><div class="big">🔎</div><b>Начни вводить запрос</b><p>Поиск идёт по препаратам, аббревиатурам и теоретическим модулям.</p></div></div></div>`+bottomNav("search");bindNav();const input=document.getElementById("globalSearch"),out=document.getElementById("globalResults");input.addEventListener("input",()=>{const q=input.value.trim().toLowerCase();if(!q){out.innerHTML=`<div class="emptyState"><div class="big">🔎</div><b>Начни вводить запрос</b></div>`;return;}const dr=DRUGS.filter(d=>(d.name+" "+d.group).toLowerCase().includes(q)).slice(0,20);const ab=Object.entries(ABBREVIATIONS).flatMap(([topic,arr])=>arr.map(a=>({...a,topic}))).filter(a=>(a.abbr+" "+a.full+" "+a.ru+" "+a.subtopic).toLowerCase().includes(q)).slice(0,20);const th=Object.entries(THEORY).flatMap(([topic,arr])=>arr.map(x=>({...x,topic}))).filter(x=>(x.title+" "+x.summary).toLowerCase().includes(q)).slice(0,20);const html=[...dr.map(d=>`<div class="drugRow"><div><div class="resultType">Препарат</div><b>${esc(d.name)}</b><div class="smallMuted">${esc(d.group)}</div></div><button class="drugLink" data-route="#drug/${d.n}">Открыть</button></div>`),...ab.map(a=>`<div class="abbrRow"><div class="resultType">Аббревиатура · ${esc(topicMap[a.topic]?.short||a.topic)}</div><b>${esc(a.abbr)}</b><div class="ru">${esc(a.ru)}</div></div>`),...th.map(x=>`<div class="theoryCard"><div class="resultType">Теория · ${esc(topicMap[x.topic]?.short||x.topic)}</div><h3>${esc(x.title)}</h3><p>${esc(x.summary)}</p></div>`)].join("");out.innerHTML=html||`<div class="emptyState"><b>Ничего не найдено</b></div>`;bindNav();});}

function renderTheoryHub(){
 const groups=TOPICS.map(t=>({t,items:THEORY[t.id]||[]})).filter(x=>x.items.length);
 app.innerHTML=header()+`<div class="page"><div class="paperTitle"><span class="handMini">Учёба</span><h2>Теория</h2><p>Конспекты по темам, без смешивания разделов.</p></div><div class="topicGrid">${groups.map(({t,items})=>`<div class="card clickCard softPaper" data-route="#topic/${t.id}/theory"><div class="cardHead"><div class="iconFrame">${t.icon}</div><div><h3>${esc(t.title)}</h3><p>${items.length} материалов</p><span class="badge blue">открыть теорию</span></div></div></div>`).join("")}</div></div>`+bottomNav("study");bindNav();
}
function renderTablesHub(){
 const rows=TOPICS.map(t=>{const c=countsForTopic(t.id);return `<tr><td><b>${t.icon} ${esc(t.short)}</b></td><td>${c.drugs}</td><td>${c.abbr}</td><td>${c.tests}</td><td>${c.interactions}</td></tr>`}).join("");
 app.innerHTML=header()+`<div class="page"><div class="paperTitle"><span class="handMini">Быстрый обзор</span><h2>Таблицы</h2><p>Сводная информация по всем разделам.</p></div><div class="detailBox paperTable"><div class="tableScroll"><table><thead><tr><th>Тема</th><th>Препараты</th><th>Аббр.</th><th>Тесты</th><th>Взаим.</th></tr></thead><tbody>${rows}</tbody></table></div></div><div class="sectionTitle"><h2>Полезные таблицы</h2></div><div class="sectionGrid"><div class="card clickCard" data-route="#drugs"><div class="cardHead"><div class="iconFrame">💊</div><div><h3>170 препаратов</h3><p>Фильтр по темам и группам.</p></div></div></div><div class="card clickCard" data-route="#topics"><div class="cardHead"><div class="iconFrame">🔤</div><div><h3>Аббревиатуры</h3><p>Открываются внутри каждой темы.</p></div></div></div></div></div>`+bottomNav("study");bindNav();
}
function renderSchemesHub(){
 const all=TOPICS.flatMap(t=>(MECHANISMS[t.id]||[]).map(m=>({t,m})));
 app.innerHTML=header()+`<div class="page"><div class="paperTitle"><span class="handMini">Наглядно</span><h2>Схемы</h2><p>${all.length} механизмов и причинно-следственных цепочек.</p></div><div class="list">${all.map(({t,m})=>`<div class="mechanismCard sketchMechanism"><div class="resultType">${t.icon} ${esc(t.short)}</div><h3>${esc(m.title)}</h3><div class="chain">${m.chain.map((v,i)=>`${i?'<div class="chainArrow">→</div>':""}<div class="chainNode">${esc(v)}</div>`).join("")}</div><div class="chips">${m.examples.map(v=>`<span class="chip">${esc(v)}</span>`).join("")}</div></div>`).join("")}</div></div>`+bottomNav("study");bindNav();
}
let flashIndex=0,flashRevealed=false;
function renderCardsHub(){
 const cards=DRUGS;
 const d=cards[flashIndex%cards.length];
 app.innerHTML=header()+`<div class="page"><div class="paperTitle"><span class="handMini">Повторение</span><h2>Карточки</h2><p>Нажми на карточку, чтобы увидеть ответ.</p></div><div class="flashWrap"><button class="flashCard ${flashRevealed?"revealed":""}" id="flashCard"><span class="flashNum">#${d.n}</span><h2>${esc(d.name)}</h2>${flashRevealed?`<div class="flashAnswer"><b>${esc(d.group)}</b><div class="chips">${d.topics.map(x=>`<span class="chip">${esc(topicMap[x]?.short||x)}</span>`).join("")}</div></div>`:`<p>Что это за группа и к каким темам относится?</p><span class="handMini">нажми, чтобы перевернуть ↻</span>`}</button><div class="flashControls"><button id="prevCard">← Назад</button><span>${flashIndex+1} / ${cards.length}</span><button id="nextCard">Дальше →</button></div></div></div>`+bottomNav("study");bindNav();
 document.getElementById("flashCard").onclick=()=>{flashRevealed=!flashRevealed;renderCardsHub()};
 document.getElementById("prevCard").onclick=()=>{flashIndex=(flashIndex-1+cards.length)%cards.length;flashRevealed=false;renderCardsHub()};
 document.getElementById("nextCard").onclick=()=>{flashIndex=(flashIndex+1)%cards.length;flashRevealed=false;renderCardsHub()};
}
function renderProgressHub(){
 const s=testSession;
 const testInfo=s?`<div class="progressBig"><b>${s.answered}</b><span>вопросов отвечено в текущей сессии</span></div><div class="progressBars"><div><span>С первой попытки</span><b>${s.firstTryCorrect}</b></div><div><span>Потребовалась ещё попытка</span><b>${s.retriedQuestions}</b></div><div><span>Неверных выборов</span><b>${s.extraWrongAttempts}</b></div></div>`:`<div class="emptyState"><div class="big">📈</div><b>Сейчас нет активной тестовой сессии</b><p>Результаты тестов по твоему требованию не сохраняются после закрытия сессии.</p><button class="moduleButton" data-route="#tests">Перейти к тестам</button></div>`;
 app.innerHTML=header()+`<div class="page"><div class="paperTitle"><span class="handMini">Шаг за шагом</span><h2>Прогресс</h2><p>Только текущая сессия — без истории результатов.</p></div><div class="detailBox">${testInfo}</div><div class="stats"><div class="stat"><b>${TESTS.length}</b><span>вопросов в базе</span></div><div class="stat"><b>${DRUGS.length}</b><span>препаратов</span></div><div class="stat"><b>${TOPICS.length}</b><span>тем</span></div><div class="stat"><b>${Object.values(THEORY).flat().length}</b><span>теоретических блоков</span></div></div></div>`+bottomNav("profile");bindNav();
}
function renderFavoritesHub(){
 const items=DRUGS.filter(d=>favoriteDrugIds.has(d.n));
 app.innerHTML=header()+`<div class="page"><div class="paperTitle"><span class="handMini">Важно</span><h2>Избранное</h2><p>Сохранённые препараты остаются на этом устройстве.</p></div>${items.length?drugRows(items):`<div class="emptyState"><div class="big">☆</div><b>Избранное пока пусто</b><p>Открой карточку препарата и нажми «☆ В избранное».</p><button class="moduleButton" data-route="#drugs">Открыть 170 препаратов</button></div>`}</div>`+bottomNav("profile");bindNav();
}
function renderSettingsHub(){
 app.innerHTML=header()+`<div class="page"><div class="paperTitle"><span class="handMini">Под себя</span><h2>Настройки</h2><p>Настройки интерфейса не затрагивают результаты тестов.</p></div><div class="settingsList"><label class="settingRow"><span><b>Крупный текст</b><small>Увеличить шрифт интерфейса</small></span><input type="checkbox" id="largeText" ${uiSettings.largeText?"checked":""}></label><label class="settingRow"><span><b>Меньше анимаций</b><small>Уменьшить движение элементов</small></span><input type="checkbox" id="reducedMotion" ${uiSettings.reducedMotion?"checked":""}></label></div></div>`+bottomNav("profile");bindNav();
 document.getElementById("largeText").onchange=e=>{uiSettings.largeText=e.target.checked;localStorage.setItem(UI_SETTINGS_KEY,JSON.stringify(uiSettings));applyUiSettings()};
 document.getElementById("reducedMotion").onchange=e=>{uiSettings.reducedMotion=e.target.checked;localStorage.setItem(UI_SETTINGS_KEY,JSON.stringify(uiSettings));applyUiSettings()};
}
function renderProfile(){
 app.innerHTML=header()+`<div class="page"><div class="paperTitle"><span class="handMini">Мой ProPharm</span><h2>Профиль</h2><p>Быстрый доступ к личным инструментам.</p></div><div class="sectionGrid profileGrid"><div class="card clickCard" data-route="#favorites"><div class="cardHead"><div class="iconFrame">☆</div><div><h3>Избранное</h3><p>${favoriteDrugIds.size} препаратов</p></div></div></div><div class="card clickCard" data-route="#progress"><div class="cardHead"><div class="iconFrame">📈</div><div><h3>Прогресс</h3><p>Текущая тестовая сессия</p></div></div></div><div class="card clickCard" data-route="#settings"><div class="cardHead"><div class="iconFrame">⚙</div><div><h3>Настройки</h3><p>Размер текста и анимации</p></div></div></div><div class="card clickCard" data-route="#drugs"><div class="cardHead"><div class="iconFrame">💊</div><div><h3>170 препаратов</h3><p>Полная экзаменационная база</p></div></div></div></div></div>`+bottomNav("profile");bindNav();
}

let testSession=null;

function bindTestStarters(){
  document.querySelectorAll("[data-start-test]").forEach(b=>b.addEventListener("click",()=>startTestSession(b.dataset.startTest)));
}

function startTestSession(spec){
  let questions=[...TESTS];
  if(spec?.startsWith("topic:")) {
    const topicId=spec.slice("topic:".length);
    questions=questions.filter(q=>q.topic===topicId);
  }
  if(spec?.startsWith("section:")) {
    const sectionId=spec.slice("section:".length);
    questions=questions.filter(q=>q.sectionId===sectionId);
  }
  if(!questions.length){
    const knownSections=[...new Set(TESTS.map(q=>q.sectionId))].filter(Boolean);
    console.error("ProPharm: test selection returned 0 questions", {spec,total:TESTS.length,knownSections});
    alert(`Не удалось загрузить вопросы для этого блока. Всего в базе сейчас: ${TESTS.length}. Обнови страницу — если ошибка повторится, это проблема кэша.`);
    return;
  }
  testSession={
    questions, index:0, firstTryCorrect:0, retriedQuestions:0, extraWrongAttempts:0,
    currentWrong:[], errors:[], answered:0
  };
  if(location.hash==="#quiz") renderQuiz();
  else location.hash="#quiz";
}

function currentQuestion(){return testSession?.questions?.[testSession.index]}

function renderQuiz(){
  if(!testSession){location.hash="#tests";return;}
  if(!testSession.questions?.length){
    console.error("ProPharm: attempted to render an empty test session");
    testSession=null;
    location.hash="#tests";
    return;
  }
  if(testSession.index>=testSession.questions.length){renderQuizResults();return;}
  const q=currentQuestion();
  const progress=Math.round((testSession.index/testSession.questions.length)*100);
  app.innerHTML=header()+`<div class="page quizPage">
    <div class="quizTop"><button class="quizExit" id="quizExit">✕ Закрыть</button><div class="quizCount">${testSession.index+1} / ${testSession.questions.length}</div></div>
    <div class="progressTrack"><div class="progressFill" style="width:${progress}%"></div></div>
    <div class="card quizCard">
      <div class="resultType">${esc(q.sectionTitle)} · вопрос ${q.number}</div>
      <h2>${esc(q.question)}</h2>
      ${q.disputed?`<div class="sourceNote">⚠ В исходном материале этот вопрос отмечен как спорный/исправленный. После ответа покажу примечание.</div>`:""}
      <div class="quizOptions">${q.options.map(o=>`<button class="quizOption" data-option="${o.id}"><span class="optionLetter">${o.id}</span><span>${esc(o.text)}</span></button>`).join("")}</div>
      <div class="smallMuted" style="margin-top:10px">Если ошибёшься, получишь подсказку и сможешь отвечать снова до правильного варианта.</div>
    </div>
  </div>`;
  document.getElementById("quizExit").addEventListener("click",()=>{testSession=null;location.hash="#tests";});
  document.querySelectorAll(".quizOption").forEach(b=>b.addEventListener("click",()=>handleQuizAnswer(b.dataset.option,b)));
}

function handleQuizAnswer(optionId,button){
  const q=currentQuestion();
  if(!q||button.disabled)return;
  if(optionId===q.correct){
    button.classList.add("correctAnswer");
    document.querySelectorAll(".quizOption").forEach(x=>x.disabled=true);
    if(testSession.currentWrong.length===0)testSession.firstTryCorrect++;
    else testSession.retriedQuestions++;
    testSession.answered++;
    showExplanationModal(q);
  }else{
    button.classList.add("wrongAnswer"); button.disabled=true;
    testSession.currentWrong.push(optionId);
    testSession.extraWrongAttempts++;
    let err=testSession.errors.find(e=>e.questionId===q.id);
    if(!err){err={questionId:q.id,sectionTitle:q.sectionTitle,number:q.number,question:q.question,wrong:[],correct:q.correct,correctText:q.options.find(o=>o.id===q.correct)?.text||q.correctText};testSession.errors.push(err);}
    err.wrong.push({id:optionId,text:q.options.find(o=>o.id===optionId)?.text||""});
    showHintModal(q,optionId);
  }
}

function modalShell(inner){
  const el=document.createElement("div"); el.className="modalBackdrop"; el.innerHTML=`<div class="modalSheet">${inner}</div>`; document.body.appendChild(el); return el;
}

function showHintModal(q,optionId){
  const wrong=q.options.find(o=>o.id===optionId);
  const modal=modalShell(`<div class="modalHandle"></div><div class="modalIcon bad">✕</div><h2>Пока неверно</h2><p class="modalWrong"><b>${esc(optionId)}. ${esc(wrong?.text||"")}</b></p><div class="hintBox"><b>Подсказка</b><p>${esc(q.hint)}</p></div><button class="modalPrimary" id="hintClose">Попробовать ещё раз</button>`);
  modal.querySelector("#hintClose").addEventListener("click",()=>modal.remove());
}

function showExplanationModal(q){
  const main=q.explanation?.length?q.explanation.map(x=>`<p>${esc(x)}</p>`).join(""):`<p>Правильный ответ указан в исходном материале.</p>`;
  const opts=q.options.map(o=>{
    const isCorrect=o.id===q.correct;
    const exp=isCorrect?esc(q.optionExplanations?.[o.id]||q.explanation?.join(" ")||"Правильный вариант."):esc(q.optionExplanations?.[o.id]||"В исходном материале отдельный комментарий к этому варианту не сохранён.");
    return `<div class="explainOption ${isCorrect?"good":"badLine"}"><b>${o.id}. ${esc(o.text)}</b><div>${exp}</div></div>`;
  }).join("");
  const notes=q.sourceNotes?.length?`<div class="sourceNote">${q.sourceNotes.map(x=>`<div>⚠ ${esc(x)}</div>`).join("")}</div>`:"";
  const modal=modalShell(`<div class="modalHandle"></div><div class="modalIcon good">✓</div><h2>Правильно</h2><div class="correctBanner"><b>${esc(q.correct)}. ${esc(q.options.find(o=>o.id===q.correct)?.text||q.correctText||"")}</b></div><div class="explanationText">${main}</div><h3>Разбор всех вариантов</h3>${opts}${renderVisual(q.visual||SECTION_VISUALS[q.sectionId])}${notes}<button class="modalPrimary" id="nextQuestion">${testSession.index+1>=testSession.questions.length?"Показать результат":"Следующий вопрос"}</button>`);
  modal.querySelector("#nextQuestion").addEventListener("click",()=>{
    modal.remove(); testSession.index++; testSession.currentWrong=[]; renderQuiz();
  });
}

function normText(s){return String(s||"").toLowerCase().replace(/[^a-zа-я0-9]+/g," ").trim()}

function renderQuizResults(){
  const s=testSession;if(!s){location.hash="#tests";return;}
  const total=s.questions.length;
  app.innerHTML=header()+`<div class="page">
    <section class="hero"><h2>Результат сессии</h2><p>Эта статистика не сохраняется. После закрытия страницы/сессии она исчезнет.</p>
      <div class="stats"><div class="stat"><b>${total}</b><span>вопросов</span></div><div class="stat"><b>${s.firstTryCorrect}</b><span>с 1-й попытки</span></div><div class="stat"><b>${s.retriedQuestions}</b><span>потребовалась ещё попытка</span></div><div class="stat"><b>${s.extraWrongAttempts}</b><span>лишних неверных выборов</span></div></div>
    </section>
    <div class="sectionTitle"><h2>Где были ошибки</h2><span class="muted">${s.errors.length} вопросов</span></div>
    ${s.errors.length?`<div class="list">${s.errors.map(e=>`<div class="theoryCard"><div class="resultType">${esc(e.sectionTitle)} · вопрос ${e.number}</div><h3>${esc(e.question)}</h3><div class="errorChoices"><b>Неверные попытки:</b>${e.wrong.map(w=>`<div class="wrongMini">✕ ${esc(w.id)}. ${esc(w.text)}</div>`).join("")}</div><div class="rightMini">✓ Правильно: ${esc(e.correct)}. ${esc(e.correctText)}</div></div>`).join("")}</div>`:`<div class="emptyState"><div class="big">🏆</div><b>Ни одной ошибки</b><p>Все вопросы были отвечены правильно с первой попытки.</p></div>`}
    <button class="moduleButton" id="closeResults">Закрыть результаты</button>
  </div>`;
  document.getElementById("closeResults").addEventListener("click",()=>{testSession=null;location.hash="#tests";});
}
function router(){const h=(location.hash||"#home").slice(1),parts=h.split("/");if(parts[0]==="home"||!parts[0])return renderHome();if(parts[0]==="topics")return renderTopics();if(parts[0]==="topic"&&parts.length===2)return renderTopic(parts[1]);if(parts[0]==="topic"&&parts.length>=3)return renderTopicSection(parts[1],parts[2]);if(parts[0]==="drugs")return renderAllDrugs();if(parts[0]==="drug")return renderDrug(parts[1]);if(parts[0]==="tests")return renderTests();if(parts[0]==="quiz")return renderQuiz();if(parts[0]==="search")return renderSearch();if(parts[0]==="theory-hub")return renderTheoryHub();if(parts[0]==="tables")return renderTablesHub();if(parts[0]==="schemes")return renderSchemesHub();if(parts[0]==="cards")return renderCardsHub();if(parts[0]==="progress")return renderProgressHub();if(parts[0]==="favorites")return renderFavoritesHub();if(parts[0]==="settings")return renderSettingsHub();if(parts[0]==="profile")return renderProfile();renderHome();}
window.addEventListener("hashchange",router);router();
