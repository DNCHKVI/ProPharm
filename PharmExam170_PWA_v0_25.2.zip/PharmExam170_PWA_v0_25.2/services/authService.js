import { SUPABASE_CONFIG } from "../config/supabase-config.js?v=0.25.2";

const PROFILE_CACHE_KEY="propharm_profile_cache_v1";
const SDK_URL="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.115.0/+esm";
const listeners=new Set();
let supabase=null;
const PROFILE_TIMEOUT_MS=12000;

function withTimeout(promise,ms,message){
  let timer;
  return Promise.race([
    Promise.resolve(promise),
    new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Error(message)),ms)})
  ]).finally(()=>clearTimeout(timer));
}

export const authState={
  initialized:false,loading:true,profileLoading:false,configured:false,session:null,user:null,profile:null,error:null,offlineFallback:false
};

function emit(){for(const fn of listeners){try{fn({...authState})}catch(e){console.error(e)}}}
export function onAuthState(fn){listeners.add(fn);return()=>listeners.delete(fn)}
export function isAuthConfigured(){return !!(SUPABASE_CONFIG.enabled&&SUPABASE_CONFIG.url&&SUPABASE_CONFIG.publishableKey)}
export function getSupabase(){return supabase}
export function currentUserId(){return authState.user?.id||null}
export function isApproved(){return !!(authState.user&&authState.profile?.status==="approved")}
export function isAdmin(){return authState.profile?.role==="admin"&&authState.profile?.status==="approved"}

function cachedProfile(userId){
  try{const x=JSON.parse(localStorage.getItem(PROFILE_CACHE_KEY)||"null");return x?.user_id===userId?x:null}catch{return null}
}
function saveCachedProfile(p){if(p?.user_id)localStorage.setItem(PROFILE_CACHE_KEY,JSON.stringify({...p,last_verified_at:new Date().toISOString()}))}
function cachedProfileIsUsable(p){
  if(!p?.user_id||p.status!=="approved"||!p.last_verified_at)return false;
  const age=Date.now()-Date.parse(p.last_verified_at);
  return Number.isFinite(age)&&age>=0&&age<=7*24*60*60*1000;
}

export async function refreshProfile(){
  if(!supabase||!authState.user){authState.profile=null;authState.profileLoading=false;emit();return null;}
  const expectedUserId=authState.user.id;
  authState.profileLoading=true;
  authState.error=null;
  emit();
  try{
    // Always resolve the profile from the authenticated UUID. Never infer role from email,
    // OAuth metadata, a previous account, or stale local state.
    const {data,error}=await withTimeout(supabase.from("profiles")
      .select("user_id,name,email,avatar_url,provider,role,status,created_at,last_login,updated_at")
      .eq("user_id",expectedUserId)
      .single(),PROFILE_TIMEOUT_MS,"Сервер профилей не ответил за 12 секунд");
    if(error)throw error;
    // Session may have changed while the request was in flight. Ignore a stale response.
    if(authState.user?.id!==expectedUserId)return authState.profile;
    if(!data||data.user_id!==expectedUserId)throw new Error("Профиль не соответствует текущей сессии");
    authState.profile=data;
    authState.offlineFallback=false;
    saveCachedProfile(data);
  }catch(err){
    if(authState.user?.id!==expectedUserId)return authState.profile;
    const cached=cachedProfile(expectedUserId);
    if(cachedProfileIsUsable(cached)&&!navigator.onLine){
      authState.profile=cached;
      authState.offlineFallback=true;
    }else{
      authState.profile=null;
      authState.error=err;
    }
  }finally{
    if(authState.user?.id===expectedUserId)authState.profileLoading=false;
    emit();
  }
  return authState.profile;
}

export async function initAuth(){
  authState.loading=true;authState.configured=isAuthConfigured();emit();
  if(!authState.configured){authState.initialized=true;authState.loading=false;authState.session=null;authState.user=null;authState.profile=null;authState.profileLoading=false;authState.offlineFallback=false;emit();return authState;}
  try{
    const {createClient}=await import(SDK_URL);
    supabase=createClient(SUPABASE_CONFIG.url,SUPABASE_CONFIG.publishableKey,{auth:{persistSession:true,autoRefreshToken:true,detectSessionInUrl:true,flowType:"pkce"}});
    const {data,error}=await supabase.auth.getSession();if(error)throw error;
    authState.session=data.session||null;authState.user=data.session?.user||null;
    if(authState.user)await refreshProfile();
    supabase.auth.onAuthStateChange((_event,session)=>{
      const previousUserId=authState.user?.id||null;
      const nextUser=session?.user||null;
      authState.session=session||null;
      authState.user=nextUser;
      authState.error=null;
      // Critical account-switch fix: never keep the previous user's profile while a new
      // Supabase session is becoming active. This prevented an admin session from inheriting
      // a cached ordinary-user role (and vice versa).
      if(previousUserId!==nextUser?.id){
        authState.profile=null;
        authState.offlineFallback=false;
      }
      if(nextUser){
        authState.profileLoading=true;
        emit();
        setTimeout(()=>refreshProfile(),0);
      }else{
        authState.profile=null;
        authState.profileLoading=false;
        emit();
      }
    });
  }catch(err){authState.error=err;console.error("ProPharm auth init",err)}
  authState.initialized=true;authState.loading=false;emit();return authState;
}

export async function signInWithPassword(email,password){
  if(!supabase)throw new Error("Supabase не настроен");
  // Clear any profile belonging to a previously active account before switching sessions.
  authState.profile=null;authState.offlineFallback=false;authState.profileLoading=true;authState.error=null;emit();
  const {data,error}=await supabase.auth.signInWithPassword({email,password});
  if(error){authState.profileLoading=false;emit();throw error;}
  authState.session=data.session||null;authState.user=data.user||data.session?.user||null;
  if(!authState.user){authState.profileLoading=false;emit();throw new Error("Supabase не вернул пользователя после входа");}
  await refreshProfile();
  if(!authState.profile||authState.profile.user_id!==authState.user.id)throw new Error("Не удалось загрузить профиль текущего аккаунта");
  return data;
}
export async function signUpWithPassword(name,email,password){
  if(!supabase)throw new Error("Supabase не настроен");
  const {data,error}=await supabase.auth.signUp({email,password,options:{data:{full_name:name||""},emailRedirectTo:oauthRedirectUrl()}});if(error)throw error;return data;
}
export async function signInWithOAuth(provider){
  if(!supabase)throw new Error("Supabase не настроен");
  if(!["google","apple"].includes(provider))throw new Error("Неподдерживаемый OAuth provider");
  const {data,error}=await supabase.auth.signInWithOAuth({provider,options:{redirectTo:oauthRedirectUrl()}});if(error)throw error;return data;
}
export async function linkIdentity(provider){
  if(!supabase||!authState.user)throw new Error("Сначала войдите в аккаунт");
  const {data,error}=await supabase.auth.linkIdentity({provider,options:{redirectTo:oauthRedirectUrl()}});if(error)throw error;return data;
}
export async function resetPassword(email){
  if(!supabase)throw new Error("Supabase не настроен");
  const {data,error}=await supabase.auth.resetPasswordForEmail(email,{redirectTo:`${oauthRedirectUrl()}#reset-password`});if(error)throw error;return data;
}
export async function updatePassword(password){
  if(!supabase||!authState.session)throw new Error("Нет активной recovery-сессии");
  if(String(password||"").length<8)throw new Error("Пароль должен содержать не менее 8 символов");
  const {data,error}=await supabase.auth.updateUser({password});if(error)throw error;return data;
}
export async function signOut(){
  if(supabase)await supabase.auth.signOut();
  localStorage.removeItem(PROFILE_CACHE_KEY);
  authState.session=null;authState.user=null;authState.profile=null;authState.profileLoading=false;authState.offlineFallback=false;emit();
}
export async function updateOwnProfile(patch){
  if(!supabase||!authState.user)throw new Error("Нет активного аккаунта");
  const safe={};if(typeof patch.name==="string")safe.name=patch.name.trim().slice(0,120);if(typeof patch.avatar_url==="string")safe.avatar_url=patch.avatar_url.trim().slice(0,1000);safe.updated_at=new Date().toISOString();
  const {data,error}=await supabase.from("profiles").update(safe).eq("user_id",authState.user.id).select().single();if(error)throw error;authState.profile=data;saveCachedProfile(data);emit();return data;
}
export async function listUsersForAdmin(){
  if(!supabase||!isAdmin())throw new Error("Недостаточно прав");
  // Use a SECURITY DEFINER RPC so the admin list works even if an older RLS policy
  // is still active in the project. The SQL patch grants this RPC only to authenticated users
  // and the function itself verifies the bootstrap admin role.
  const {data,error}=await supabase.rpc("admin_list_users");
  if(error)throw error;
  return data||[];
}
export async function adminPendingCount(){
  if(!supabase||!isAdmin())return 0;
  const {data,error}=await supabase.rpc("admin_pending_count");
  if(error)throw error;
  return Number(data||0);
}
export async function listAdminNotifications(limit=30){
  if(!supabase||!isAdmin())return [];
  const {data,error}=await supabase.rpc("admin_list_notifications",{p_limit:Math.max(1,Math.min(100,Number(limit)||30))});
  if(error)throw error;
  return data||[];
}
export async function markAdminNotificationsRead(){
  if(!supabase||!isAdmin())return;
  const {error}=await supabase.rpc("admin_mark_notifications_read");
  if(error)throw error;
}
let adminApplicationsChannel=null;
export async function subscribeAdminApplications(onApplication){
  if(!supabase||!isAdmin())return ()=>{};
  if(adminApplicationsChannel){try{await supabase.removeChannel(adminApplicationsChannel)}catch{} adminApplicationsChannel=null;}
  const channel=supabase.channel(`propharm-admin-applications-${authState.user.id}`)
    .on('postgres_changes',{event:'INSERT',schema:'public',table:'admin_notifications'},payload=>{
      if(payload?.new?.kind==='new_application'){try{onApplication?.(payload.new)}catch(e){console.error(e)}}
    })
    .subscribe();
  adminApplicationsChannel=channel;
  return async()=>{if(adminApplicationsChannel===channel){try{await supabase.removeChannel(channel)}catch{} adminApplicationsChannel=null;}};
}
export async function savePushSubscription(subscription){
  if(!supabase||!isAdmin())throw new Error("Недостаточно прав");
  const json=subscription?.toJSON?subscription.toJSON():subscription;
  const endpoint=json?.endpoint,keys=json?.keys||{};
  if(!endpoint||!keys.p256dh||!keys.auth)throw new Error("Некорректная push-подписка");
  const row={user_id:authState.user.id,endpoint,p256dh:keys.p256dh,auth:keys.auth,user_agent:navigator.userAgent,updated_at:new Date().toISOString()};
  const {error}=await supabase.from('push_subscriptions').upsert(row,{onConflict:'endpoint'});
  if(error)throw error;
}
export async function deletePushSubscription(endpoint){
  if(!supabase||!authState.user||!endpoint)return;
  const {error}=await supabase.from('push_subscriptions').delete().eq('endpoint',endpoint).eq('user_id',authState.user.id);
  if(error)throw error;
}
export async function adminSetStatus(targetUserId,status){
  if(!supabase||!isAdmin())throw new Error("Недостаточно прав");
  if(!["pending","approved","blocked","rejected"].includes(status))throw new Error("Недопустимый статус");
  const {data,error}=await supabase.rpc("admin_set_user_status",{target_user_id:targetUserId,new_status:status});if(error)throw error;return data;
}
export function oauthRedirectUrl(){
  if(SUPABASE_CONFIG.siteUrl)return new URL(SUPABASE_CONFIG.siteUrl).href;
  return `${location.origin}${location.pathname}`;
}
