import { esc } from '../core/shared.js';
import { accordion } from '../ui/shell.js';
import { renderAbbreviationLead } from '../ui/abbreviations.js';
import { SCIENTIFIC_VISUALS, WHITEBOARD_SOURCE_MAP } from '../core/content.js';

export function renderScientificVisual(key){
  const v=SCIENTIFIC_VISUALS[key];if(!v)return "";
  return `<figure class="scientificFigure"><button class="scientificImageButton" type="button" data-scientific-image data-image-url="${esc(v.imageUrl)}" data-image-title="${esc(v.title)}" data-source-url="${esc(v.sourcePage)}"><img ${imageAttributes(v.imageUrl)} alt="${esc(v.title)}" loading="lazy" referrerpolicy="no-referrer"><span class="scientificZoomHint">Открыть схему · увеличить</span></button><figcaption><b>${esc(v.title)}</b><p>${esc(v.note||"")}</p></figcaption>${accordion({id:`source-${key}`,title:'Источник и лицензия',level:3,body:`<div class="sourceMeta"><p><b>Источник:</b> ${esc(v.sourceName)}</p><p><b>Автор:</b> ${esc(v.author)}</p><p><b>Лицензия:</b> ${esc(v.license)}</p><a href="${esc(v.sourcePage)}" target="_blank" rel="noopener noreferrer">Открыть страницу оригинала ↗</a></div>`})}</figure>`;
}

export function renderWhiteboardSources(area='default'){
  const rows=WHITEBOARD_SOURCE_MAP[area]||WHITEBOARD_SOURCE_MAP.default||[];
  if(!rows.length)return '';
  return accordion({id:`wb-sources-${area}-${rows.map(x=>x.name).join('-')}`,title:'Научные источники для проверки механизма',level:3,body:`<div class="sourceMeta">${rows.map(x=>`<p><b>${esc(x.name)}</b> · ${esc(x.license)}<br><a href="${esc(x.url)}" target="_blank" rel="noopener noreferrer">Открыть источник ↗</a></p>`).join('')}</div>`});
}

export function renderLearningWhiteboard({title='',steps=[],area='default',showSources=false}={}){
  const clean=(steps||[]).map(x=>String(x||'').trim()).filter(Boolean);if(!clean.length)return '';
  const nodes=clean.map((x,i)=>`<div class="whiteboardStep"><span class="whiteboardIndex">${i+1}</span><span class="whiteboardNodeText">${esc(x)}</span></div>${i<clean.length-1?'<div class="whiteboardArrow" aria-hidden="true">↓</div>':''}`).join('');
  return `<div class="learningWhiteboard"><div class="whiteboardHeader"><span class="whiteboardTag">Learning Whiteboard</span>${title?`<b>${esc(title)}</b>`:''}</div><div class="whiteboardCanvas">${nodes}</div><p class="whiteboardNote">Схема построена как структурированная HTML-визуализация: без генерации медицинской картинки и без текста, нарисованного image-generation моделью.</p>${showSources?renderWhiteboardSources(area):''}</div>`;
}

export function renderVisual(v){
  if(!v)return "";
  if(v.imageUrl){
    const title=esc(v.title||'Схема к вопросу'),alt=esc(v.alt||v.title||'Схема к вопросу'),note=v.note?`<p>${esc(v.note)}</p>`:'';
    return `<figure class="scientificFigure chemistryQuestionFigure"><button class="scientificImageButton" type="button" data-scientific-image data-image-url="${esc(v.imageUrl)}" data-image-title="${title}" data-source-url=""><img ${imageAttributes(v.imageUrl)} alt="${alt}" loading="lazy"><span class="scientificZoomHint">Открыть схему · увеличить</span></button><figcaption><b>${title}</b>${note}</figcaption></figure>`;
  }
  if(!v.steps?.length)return "";
  const raw=[v.title||"",...(v.steps||[])].join(" ");
  return `${v.skipAbbr?"":renderAbbreviationLead(raw)}${renderLearningWhiteboard({title:v.title||'Процесс',steps:v.steps,area:v.area||'default',showSources:v.showSources!==false})}`;
}

export function imageAttributes(url){return url?.startsWith('protected:')?`data-protected-src="${esc(url)}" src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='640' height='240'/%3E"`:`src="${esc(url)}"`;}
