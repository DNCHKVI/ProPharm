import { renderCardioLab } from '../features/cardio-lab.js';
import { ensureContent } from './content-service.js';
import { canAccessRoute } from './access.js';
import { closeAllModals } from '../ui/modal.js';
import { renderWeakTopics } from '../features/tests.js';
let renderEpoch=0;
import { app, esc } from '../core/shared.js';
import { applyAdminI18nAfterRender } from '../core/settings.js';
import { inferProgressFromRoute } from '../ui/personal.js';
import { header, bottomNav, bindNav } from '../ui/shell.js';
import { renderHome } from '../features/home.js';
import { renderTopic, renderTopicSection } from '../features/topics.js';
import { renderAllDrugs, renderDrug } from '../features/drugs.js';
import { renderTests } from '../features/tests.js';
import { renderMemoryTrainer, renderMemoryLesson } from '../features/memory.js';
import { renderSearch } from '../features/search.js';
import { renderTablesHub, renderSchemesHub, renderSchemesTopic, renderCardsHub } from '../features/study-tools.js';
import { renderSettingsHub, renderAbbrHub, renderProfile, renderMyStudy, renderFavorites, renderReview, renderAuthLoading, renderAuthProfileError, renderAuthUnconfigured, renderLogin, renderRegister, renderResetPassword, renderAccessState } from '../features/account.js';
import { renderAdmin } from '../features/admin.js';
import { renderCardioPathologyDetail } from '../features/cardio.js';
import { renderSystemsHub, renderSystem, renderSystemSection, renderMechanismsHub, renderMechanismDetail, renderDiseasesHub, renderDisease } from '../features/systems.js';
import { renderStudyHub, renderFoundationsHub, renderFoundationDetail } from '../features/foundations.js';
import { renderInteractionsHub } from '../features/interactions.js';
import { renderQuiz } from '../features/quiz.js';
import { authState, isAuthConfigured } from '../../services/authService.js';
import { recordStudyPosition } from '../../services/userData.js';
import { isTestsOnlyUser } from '../core/access.js';

export function routeNeedsGate(parts){return !['login','register','reset-password'].includes(parts[0]);}

export async function router(){
  const epoch=++renderEpoch;
  closeAllModals();
  try{
    const h=(location.hash||"#home").slice(1),parts=h.split("/");
    // Production access gate: no Supabase configuration means no study-content fallback.
    if(!isAuthConfigured())return await renderAuthUnconfigured();
    if(authState.loading||authState.profileLoading||!authState.initialized)return await renderAuthLoading();
    if(!authState.session){
      if(parts[0]==='register')return await renderRegister();
      return await renderLogin();
    }
    if(parts[0]==='reset-password')return await renderResetPassword();
    if(!authState.profile){
      if(authState.error)return await renderAuthProfileError();
      return await renderAuthLoading();
    }
    const status=authState.profile.status||'pending';
    if(status!=='approved')return await renderAccessState(status);
    if(parts[0]==='login'||parts[0]==='register'){location.hash='#home';return;}
    if(!canAccessRoute(parts[0]||'home')){location.hash='#home';return;}
    await ensureContent(parts[0]||'home');
    if(epoch!==renderEpoch)return;
    if(parts[0]=="home"||!parts[0])await renderHome();
    else if(parts[0]=="study"){if(isTestsOnlyUser())await renderTests();else await renderStudyHub();}
    else if(parts[0]=="foundations")await renderFoundationsHub();
    else if(parts[0]=="foundation"&&parts.length>=2)await renderFoundationDetail(parts[1]);
    else if(parts[0]=="systems")await renderSystemsHub();
    else if(parts[0]=="system"&&parts.length===2)await renderSystem(parts[1]);
    else if(parts[0]=="system"&&parts.length>=3)await renderSystemSection(parts[1],parts[2]);
    else if(parts[0]=="diseases")await renderDiseasesHub();
    else if(parts[0]=="cardio-pathology")await renderCardioPathologyDetail(parts[1]);
    else if(parts[0]=="disease")await renderDisease(parts[1]);
    else if(parts[0]=="mechanisms")await renderMechanismsHub();
    else if(parts[0]=="mechanism")await renderMechanismDetail(parts[1]);
    else if(parts[0]=="interactions-hub")await renderInteractionsHub();
    else if(parts[0]=="topics")await renderSystemsHub();
    else if(parts[0]=="topic"&&parts.length===2)await renderTopic(parts[1]);
    else if(parts[0]=="topic"&&parts.length>=3)await renderTopicSection(parts[1],parts[2]);
    else if(parts[0]=="cardio-lab")await renderCardioLab();
    else if(parts[0]=="drugs")await renderAllDrugs();
    else if(parts[0]=="drug")await renderDrug(parts[1]);
    else if(parts[0]=="tests")await renderTests();
    else if(parts[0]=="weak-topics")await renderWeakTopics();
    else if(parts[0]=="memory-trainer")await renderMemoryTrainer();
    else if(parts[0]=="memory-lesson")await renderMemoryLesson();
    else if(parts[0]=="quiz")await renderQuiz();
    else if(parts[0]=="search")await renderSearch();
    else if(parts[0]=="theory-hub")await renderSystemsHub();
    else if(parts[0]=="tables")await renderTablesHub();
    else if(parts[0]=="schemes"&&parts.length===1)await renderSchemesHub();
    else if(parts[0]=="schemes"&&parts.length>=2)await renderSchemesTopic(parts[1]);
    else if(parts[0]=="cards")await renderCardsHub();
    else if(parts[0]=="abbr-hub")await renderAbbrHub();
    else if(parts[0]=="settings")await renderSettingsHub();
    else if(parts[0]=="profile")await renderProfile();
    else if(parts[0]=="my-study")await renderMyStudy();
    else if(parts[0]=="favorites")await renderFavorites();
    else if(parts[0]=="review")await renderReview();
    else if(parts[0]=="admin")await renderAdmin();
    else await renderHome();
    if(epoch!==renderEpoch)return;
    applyAdminI18nAfterRender();
    if(!['quiz','admin','settings','profile','my-study','favorites','review'].includes(parts[0]))recordStudyPosition(inferProgressFromRoute(parts)).catch(()=>{});
  }catch(err){
    if(epoch!==renderEpoch)return;
    console.error("ProPharm render error",err);
    if(!isAuthConfigured()||!authState.session||authState.profile?.status!=='approved')return await renderAuthUnconfigured();
    const safeRoute="#home";
    app.innerHTML=header()+`<div class="page"><div class="emptyState routeError"><div class="big">!</div><b>Не удалось открыть раздел</b><p>${esc(err?.message||String(err))}</p><button class="moduleButton" data-route="${safeRoute}">Вернуться на главную</button></div></div>`+bottomNav("home");bindNav();
  }
}
