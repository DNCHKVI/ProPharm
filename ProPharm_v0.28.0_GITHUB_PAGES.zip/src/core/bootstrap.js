import { syncQuestionEvents } from '../questions/progress.js';
import { clearMemoryLesson } from '../features/memory.js';
import { clearContent,purgeContentCache } from './content-service.js';
import { clearQuizMemory } from '../features/quiz.js';
import { UI_SETTINGS_KEY, applyUiSettings } from '../core/shared.js';
import { adminLanguageLocalKey, applyAdminI18nAfterRender } from '../core/settings.js';
import { refreshAdminPendingCount, startAdminApplicationWatcher } from '../features/admin.js';
import { router } from '../core/router.js';
import { authState, initAuth, onAuthState, isAdmin, refreshProfile } from '../../services/authService.js';
import { loadUserSettings, hydrateFromCloud, syncPending } from '../../services/userData.js';
import { preferences } from '../core/preferences.js';

export async function restoreSyncedSettings(){const row=await loadUserSettings().catch(()=>null);if(row?.settings_json){preferences.ui=Object.assign({},preferences.ui,row.settings_json);localStorage.setItem(UI_SETTINGS_KEY,JSON.stringify(preferences.ui));if(isAdmin()&&preferences.ui.language)localStorage.setItem(adminLanguageLocalKey(),preferences.ui.language);applyUiSettings();applyAdminI18nAfterRender()}}

export async function syncPersonalState(){if(authState.profile?.status!=='approved')return;await syncPending();await syncQuestionEvents();await hydrateFromCloud();await restoreSyncedSettings()}

export let pendingProfileTimer=null;

export function syncPendingProfilePolling(){
  if(pendingProfileTimer){clearInterval(pendingProfileTimer);pendingProfileTimer=null;}
  if(authState.session&&['pending','approved'].includes(authState.profile?.status)){
    pendingProfileTimer=setInterval(()=>{if(document.visibilityState==='visible')refreshProfile().then(router).catch(()=>{})},30000);
  }
}

export async function revalidateVisibleSession(){
  if(!authState.session)return;
  try{await refreshProfile();router();syncPendingProfilePolling()}catch(e){console.warn('ProPharm profile revalidation',e)}
}

export async function boot(){
  applyUiSettings();
  onAuthState(()=>{if(authState.initialized){if(!authState.profileLoading&&(!authState.session||authState.profile?.status!=='approved')){clearContent();clearQuizMemory();clearMemoryLesson();if(!authState.session)purgeContentCache().catch(console.warn);} router();applyAdminI18nAfterRender();syncPendingProfilePolling();if(authState.profile?.status==='approved')syncPersonalState().catch(()=>{});startAdminApplicationWatcher().catch(()=>{})}});
  window.addEventListener("hashchange",router);
  window.addEventListener("online",()=>{revalidateVisibleSession().catch(()=>{});syncPersonalState().catch(()=>{});refreshAdminPendingCount().catch(()=>{})});
  document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible')revalidateVisibleSession().catch(()=>{})});
  navigator.serviceWorker?.addEventListener?.('message',event=>{if(event.data?.type==='PROPHARM_NOTIFICATION_OPEN'){location.hash=event.data.url||'#admin';router();}});
  await initAuth();
  syncPendingProfilePolling();
  if(authState.profile?.status==='approved')await syncPersonalState().catch(()=>{});
  await startAdminApplicationWatcher().catch(()=>{});
  router();
}
