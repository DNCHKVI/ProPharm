import { app,esc } from '../core/shared.js';
import { TESTS,registry,systemMap,diseaseMap } from '../core/content.js';
import { authState } from '../../services/authService.js';
import { getLearningStats,saveTestSession,syncPending } from '../../services/userData.js';
import { header,bottomNav,bindNav,bindScientificImages } from '../ui/shell.js';
import { renderVisual } from '../ui/visuals.js';
import { favoriteButton,reviewButton,bindPersonalActions,toast } from '../ui/personal.js';
import { modalShell } from '../ui/modal.js';
import { createSession,currentEntry,selectAnswer,advance,revealAnswer,sessionSummary,filterQuestions } from '../questions/engine.js';
import { saveDraft,loadDraft,discardDraft } from '../questions/session-store.js';
import { flushSessionEvents } from '../questions/progress.js';
export { modalShell } from '../ui/modal.js';
export const normText=s=>String(s||'').toLowerCase().replace(/[^a-zа-я0-9]+/g,' ').trim();
let session=null,resultSaving=null,flushChain=Promise.resolve();
export function clearQuizMemory(){session=null;}
export function currentQuestion(){return session?registry.get(currentEntry(session)?.questionId):null;}
export function bindTestStarters(root=document){root.querySelectorAll('[data-start-test]').forEach(b=>{if(b.dataset.testBound)return;b.dataset.testBound='1';b.addEventListener('click',()=>startTestSession(b.dataset.startTest).catch(e=>toast(e.message,'bad')));});}
function commit(s){saveDraft(s);session=s;flushChain=flushChain.catch(()=>{}).then(()=>flushSessionEvents(s)).catch(e=>{console.warn('Progress sync',e);toast('Тест сохранён на устройстве; синхронизация пока недоступна.','bad')});}
export function resumeTest(){session=loadDraft(authState.user.id,registry);if(!session)return;commit(session);location.hash='#quiz';renderQuiz();}
function resolveSpec(spec){
 if(spec?.startsWith('system:')){const s=systemMap[spec.slice(7)];return 'ids:'+TESTS.filter(q=>s?.sourceTopics?.includes(q.topic)).map(q=>q.id).join(',');}
 if(spec?.startsWith('disease:')){const d=diseaseMap[spec.slice(8)];return 'sections:'+(d?.sectionIds||[]).join(',');}
 if(spec?.startsWith('cardio-section:')){const area=spec.slice(15);return 'sections:cardio-v012-'+area;}
 return spec||'all';
}
export async function startTestSession(spec='all',preset={}){
 const userId=authState.user?.id;if(!userId||authState.profile?.status!=='approved')return;
 const stats=await getLearningStats();if(authState.user?.id!==userId)return;
 const progress=Object.fromEntries(stats.questions.map(p=>[p.question_id,p]));
 const normalized=resolveSpec(spec);let draft=null,draftError='';try{draft=loadDraft(userId,registry)}catch(e){draftError=e.message}
 const modal=modalShell(`<h2>Настроить тест</h2><form id="quizSetup">
 <div class="quizSetupGrid"><label>Режим<select name="mode"><option value="learn">Обучение</option><option value="exam">Экзамен</option></select></label>
 <label>Вопросов<select name="count"><option>10</option><option selected>20</option><option>30</option><option value="all">Все</option></select></label></div>
 <p id="modeDescription">После ошибки — предметная подсказка. Ошибочные вопросы возвращаются через три задания, если они остались в очереди.</p>
 <fieldset><legend>Порядок</legend><label><input type="checkbox" name="random" checked> Случайные вопросы</label><label><input type="checkbox" name="options" checked> Перемешать варианты</label></fieldset>
 <fieldset><legend>Фильтры (применяются вместе)</legend><div class="filterChoices">${[['new','Новые'],['wrong','Ошибочные'],['mastered','Освоенные'],['images','С изображениями'],['calculation','Расчётные']].map(([value,title])=>`<label><input type="checkbox" name="filter" value="${value}" ${preset.filter===value?'checked':''}> ${title}</label>`).join('')}</div></fieldset>
 <p class="statusMessage" id="poolCount" aria-live="polite"></p><p id="setupError" role="alert"></p>
 ${draft&&!draft.completedAt?'<div class="resumeNotice"><p>Есть незавершённый тест. Новый тест заменит его сохранение.</p><button type="button" id="resumeInstead">Продолжить сохранённый</button></div>':''}
 ${draftError?`<p role="status">${esc(draftError)} Новый тест заменит старое сохранение.</p>`:''}
 <button class="modalPrimary" type="submit">${draft&&!draft.completedAt?'Начать новый тест':'Начать'}</button><button type="button" class="moduleButton secondary" id="setupClose">Отмена</button></form>`,{label:'Настройка теста'});
 const form=modal.querySelector('form');
 function selection(){const fd=new FormData(form);return {userId,mode:fd.get('mode'),count:fd.get('count'),randomOrder:fd.has('random'),shuffleOptions:fd.has('options'),filters:fd.getAll('filter'),spec:normalized};}
 function update(){const o=selection(),pool=filterQuestions(TESTS,o,progress);modal.querySelector('#poolCount').textContent=`Доступно ${pool.length} вопросов${o.mode==='exam'?' · неоднозначные вопросы исключены':''}. Повторные записи одного вопроса выдаются один раз.`;modal.querySelector('[type="submit"]').disabled=!pool.length;modal.querySelector('#modeDescription').textContent=o.mode==='exam'?'Один ответ на вопрос. Подсказки, правильные ответы и разбор появятся после завершения.':'После ошибки — предметная подсказка. Повтор ошибки — через три задания; у конца теста раньше. Максимум два возврата в одной сессии.';}
 form.addEventListener('change',update);update();
 modal.querySelector('#setupClose').onclick=()=>modal.remove();modal.querySelector('#resumeInstead')?.addEventListener('click',()=>{modal.remove();resumeTest()});
 form.onsubmit=e=>{e.preventDefault();try{const o=selection();if(authState.user?.id!==userId)throw new Error('Аккаунт изменился');const s=createSession(filterQuestions(TESTS,o,progress),o);commit(s);modal.remove();location.hash='#quiz';renderQuiz();}catch(err){modal.querySelector('#setupError').textContent=err.message;}};
}
function detailsHTML(q){return `<div class="explanationText">${q.explanation.map(x=>`<p>${esc(x)}</p>`).join('')}</div><h3>Разбор вариантов</h3>${q.options.map(o=>`<div class="explainOption ${o.id===q.correct?'good':'badLine'}"><b>${esc(o.id)}. ${esc(o.text)} ${o.id===q.correct?'— ключ':''}</b><p>${esc(q.optionExplanations[o.id])}</p></div>`).join('')}${q.answerVisual?renderVisual(q.answerVisual):''}${q.sourceNotes?.length?`<aside class="sourceNote"><b>Примечание к исходнику</b>${q.sourceNotes.map(n=>`<p>${esc(n)}</p>`).join('')}</aside>`:''}`;}
export function showExplanationModal(q){const modal=modalShell(`<h2>Разбор вопроса</h2>${detailsHTML(q)}<button class="modalPrimary" data-close>Вернуться к тесту</button>`);modal.querySelector('[data-close]').onclick=()=>modal.remove();bindScientificImages(modal);}
export function renderQuiz(){
 if(!session||session.userId!==authState.user?.id){try{session=loadDraft(authState.user.id,registry)}catch(e){toast(e.message,'bad');location.hash='#tests';return;}}
 if(!session){location.hash='#tests';return;}if(session.completedAt){renderQuizResults();return;}
 const s=session,entry=currentEntry(s),q=registry.get(entry.questionId),answer=s.answers[entry.key],exam=s.mode==='exam',summary=sessionSummary(s);
 app.innerHTML=header()+`<div class="page quizPage"><div class="quizTop"><button class="quizExit" id="quizExit">Сохранить и выйти</button><b>${exam?'Экзамен':'Обучение'}</b><span>${s.index+1} / ${s.queue.length}</span></div>
 <progress class="quizProgress" max="${s.queue.length}" value="${s.index}" aria-label="Завершено заданий"></progress>
 <article class="quizCard card"><div class="resultType">${esc(q.studyTopic||q.sectionTitle)}${entry.repeat?' · повтор ошибки':''}</div><h1 class="questionTitle" tabindex="-1">${esc(q.question)}</h1>${renderVisual(q.visual)}
 ${!exam&&q.examEligible===false?'<p class="sourceNote">Учебный разбор: исходный вопрос требует уточнения. Он не входит в экзаменационную оценку.</p>':''}
 <div class="quizOptions">${entry.options.map(id=>{const o=q.options.find(x=>x.id===id),selected=answer?.selections.includes(id),cls=!exam&&!entry.unscored&&selected?(id===q.correct?' correctAnswer':' wrongAnswer'):selected?' selectedAnswer':'';return `<button class="quizOption${cls}" data-option="${esc(id)}" ${answer?.resolved||selected?'disabled':''}><span class="optionLetter">${esc(id)}</span><span>${esc(o.text)}${selected?`<span class="selectionLabel">${exam||entry.unscored?'Выбран':id===q.correct?'Верно':'Ошибка'}</span>`:''}</span></button>`;}).join('')}</div>
 <div class="quizFeedback" role="status" aria-live="polite">${answer?(entry.unscored?'Ответ записан для разбора; вопрос вне оценки.':exam?'Ответ сохранён.':answer.firstCorrect?'Верно с первой попытки.':answer.resolved?'Вопрос разобран. Результат первой попытки сохранён.':`Пока неверно. Подсказка: ${esc(q.hint)}`):''}</div>
 ${answer?.resolved?`<div class="quizActions">${!exam?'<button id="showExplanation" class="moduleButton secondary">Открыть полный разбор</button>':''}<button id="nextQuestion" class="moduleButton">${s.index+1>=s.queue.length?'Завершить тест':'Следующий вопрос'}</button></div>`:answer&&!exam?'<button id="revealAnswer" class="moduleButton secondary">Показать ответ и разбор</button>':''}
 ${!exam?`<div class="questionPersonalActions">${favoriteButton('question',q.id,'В избранное')}${reviewButton('question',q.id,'Повторить позже')}</div>`:''}
 <details class="questionProvenance"><summary>Номер в исходнике и ID</summary><p>№ ${esc(q.number)} · ${esc(q.sourceSectionTitle||q.sectionTitle)}</p><code>${esc(q.id)}</code></details>
 </article><p class="smallMuted">Сохранено на этом устройстве · ${summary.answered} из ${summary.total} основных вопросов${summary.repeats?' · повторов в очереди: '+summary.repeats:''}</p></div>`;
 bindNav(app);bindScientificImages(app);if(!exam)bindPersonalActions(app);
 document.getElementById('quizExit').onclick=()=>{location.hash='#tests'};
 app.querySelectorAll('[data-option]').forEach(b=>b.onclick=()=>handleQuizAnswer(b.dataset.option));
 document.getElementById('nextQuestion')?.addEventListener('click',()=>{try{commit(advance(session));renderQuiz();app.querySelector('.questionTitle')?.focus()}catch(e){toast(e.message,'bad')}});
 document.getElementById('showExplanation')?.addEventListener('click',()=>showExplanationModal(q));
 document.getElementById('revealAnswer')?.addEventListener('click',()=>{try{commit(revealAnswer(session));renderQuiz();showExplanationModal(q)}catch(e){toast(e.message,'bad')}});
}
export function handleQuizAnswer(optionId){try{const q=currentQuestion();if(!q||session.userId!==authState.user?.id)return;commit(selectAnswer(session,q,optionId));renderQuiz();app.querySelector('#nextQuestion')?.focus();}catch(e){toast('Ответ не сохранён: '+e.message,'bad')}}
export async function renderQuizResults(){
 const s=session;if(!s||s.userId!==authState.user?.id)return;const total=sessionSummary(s),score=total.total?Math.round(100*total.firstCorrect/total.total):0;
 const render=()=>{if(session?.id!==s.id||location.hash!=='#quiz')return;app.innerHTML=header()+`<div class="page quizPage"><h1>${s.mode==='exam'?'Результат экзамена':'Результат обучения'}</h1><p class="resultScore">${total.total?score+'%':'Без оценки'}</p><p>${total.firstCorrect} из ${total.total} с первой попытки. Повторы (${total.repeats}) и вопросы с неоднозначным исходником (${total.unscored}) в оценку не входят.</p><p id="resultSaveStatus" role="status">${s.saved?'Результат сохранён.':'Сохраняем результат…'}</p>
 <div class="quizActions"><button class="moduleButton" id="closeResults">К разделам тестов</button>${total.wrongQuestions.length?'<button class="moduleButton secondary" id="repeatMistakes">Повторить ошибки</button>':''}</div><h2>Ответы и объяснения</h2>${s.queue.filter(e=>e.repeat===0).map((e,i)=>{const q=registry.get(e.questionId),a=s.answers[e.key];return `<details class="resultReview"><summary>${i+1}. ${e.unscored?'Разбор':a?.firstCorrect?'✓':'✕'} ${esc(q.question)}</summary><p>Первый ответ: ${esc(a?.selections[0]||'нет')} · ключ: ${esc(q.correct)}</p>${detailsHTML(q)}</details>`}).join('')}</div>`;bindNav();bindScientificImages(app);
 document.getElementById('closeResults').onclick=()=>{discardDraft(s.userId);session=null;location.hash='#tests';};document.getElementById('repeatMistakes')?.addEventListener('click',()=>startTestSession('ids:'+total.wrongQuestions.join(',')));
 };
 render();if(s.saved||resultSaving===s.id)return;resultSaving=s.id;
 try{await flushChain;if(authState.user?.id!==s.userId)return;await saveTestSession({id:s.id,test_id:s.mode+':'+s.spec,system_id:null,section_id:null,started_at:s.startedAt,completed_at:s.completedAt,questions_total:total.total,first_try_correct:total.firstCorrect,questions_with_retries:total.wrongQuestions.length,wrong_selections:total.wrongSelections,score,duration_seconds:Math.max(0,Math.round((Date.parse(s.completedAt)-Date.parse(s.startedAt))/1000))});s.saved=true;saveDraft(s);render();}catch(e){const el=document.getElementById('resultSaveStatus');if(el)el.textContent='Сессия сохранена на устройстве; историю пока сохранить не удалось: '+e.message;}finally{resultSaving=null;}
}
