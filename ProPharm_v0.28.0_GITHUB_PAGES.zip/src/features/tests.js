import { app,esc } from '../core/shared.js';
import { TESTS,TEST_NAV_STRUCTURE,registry } from '../core/content.js';
import { authState } from '../../services/authService.js';
import { getLearningStats } from '../../services/userData.js';
import { header,bottomNav,bindNav,accordion } from '../ui/shell.js';
import { bindTestStarters,startTestSession,resumeTest } from './quiz.js';
import { loadDraft,discardDraft } from '../questions/session-store.js';
import { isWeak } from '../questions/engine.js';
import { toast } from '../ui/personal.js';
export function testCountForSections(ids=[]){const set=new Set(ids);return TESTS.filter(q=>set.has(q.sectionId)).length;}
export function renderTestLeaf(id,title,sections=[]){const count=testCountForSections(sections);if(!count)return '';return `<div class="testSectionRow"><div><h3>${esc(title)}</h3><p>${count} вопросов</p></div><button class="moduleButton" data-start-test="sections:${esc(sections.join(','))}">Настроить тест</button></div>`;}
export function renderTestNavNode(node){const ids=node.children?node.children.flatMap(x=>x[2]||[]):node.sections||[],count=testCountForSections(ids);if(!count)return '';const body=node.children?node.children.map(([id,title,sections])=>renderTestLeaf(id,title,sections)).join(''):renderTestLeaf(node.id,node.title,node.sections);return accordion({id:'test-nav-'+node.id,title:node.title,count,body,level:1});}
export function renderTests(){
 let draft=null,error='';try{draft=loadDraft(authState.user.id,registry)}catch(e){error=e.message}
 const empty=TEST_NAV_STRUCTURE.flatMap(n=>n.children?n.children.filter(x=>!testCountForSections(x[2])).map(x=>x[1]):!testCountForSections(n.sections||[])?[n.title]:[]);
 app.innerHTML=header()+`<div class="page testsPage"><h1>Тесты</h1><p>${TESTS.length} вопросов · обучение и экзамен</p>
 ${draft?`<section class="resumeNotice"><h2>${draft.completedAt?'Последний результат':'Продолжить тест'}</h2><p>${draft.mode==='exam'?'Экзамен':'Обучение'} · задание ${Math.min(draft.index+1,draft.queue.length)} из ${draft.queue.length}</p><button class="moduleButton" id="resumeTest">${draft.completedAt?'Посмотреть результат':'Продолжить'}</button></section>`:''}
 ${error?`<p role="alert">${esc(error)} <button id="clearDraft">Удалить устаревшую сессию</button></p>`:''}
 <div class="quickStudy"><button class="moduleButton" data-start-test="all">Смешанный тест</button><button class="moduleButton secondary" data-route="#weak-topics">Слабые темы</button><button class="moduleButton secondary" id="onlyMistakes">Мои ошибки</button></div><div class="accordionStack">${TEST_NAV_STRUCTURE.map(renderTestNavNode).join('')}</div>
 ${empty.length?`<details class="comingSoon"><summary>Скоро · ${empty.length} разделов</summary><ul>${empty.map(t=>`<li>${esc(t)}</li>`).join('')}</ul></details>`:''}</div>`+bottomNav('study');bindNav();bindTestStarters();
 document.getElementById('resumeTest')?.addEventListener('click',()=>{try{resumeTest()}catch(e){toast(e.message,'bad')}});document.getElementById('onlyMistakes').onclick=()=>startTestSession('all',{filter:'wrong'});document.getElementById('clearDraft')?.addEventListener('click',()=>{discardDraft(authState.user.id);renderTests()});
}
export async function renderWeakTopics(){
 const uid=authState.user?.id,stats=await getLearningStats();if(uid!==authState.user?.id||location.hash!=='#weak-topics')return;
 const map=new Map();for(const p of stats.questions){const q=registry.get(p.question_id);if(!q||!isWeak(p))continue;const id=q.studyTopicId||q.sectionId;if(!map.has(id))map.set(id,{id,title:q.studyTopic||q.sectionTitle,count:0});map.get(id).count++;}
 const rows=[...map.values()].sort((a,b)=>b.count-a.count);
 app.innerHTML=header()+`<div class="page testsPage"><h1>Слабые темы</h1><p>Тема появляется после ошибки. Вопрос считается освоенным после верных первых ответов в двух разных сессиях подряд. Повторы внутри одного теста не повышают этот статус.</p>${rows.length?rows.map(x=>`<div class="testSectionRow"><div><h2>${esc(x.title)}</h2><p>${x.count} вопросов требуют закрепления</p></div><button class="moduleButton" data-weak-topic="${esc(x.id)}">Тренироваться</button></div>`).join(''):'<p>Пока нет выявленных слабых тем. Пройди тест, чтобы собрать статистику.</p>'}<button class="moduleButton secondary" data-route="#tests">Все тесты</button></div>`+bottomNav('study');bindNav();app.querySelectorAll('[data-weak-topic]').forEach(b=>b.onclick=()=>startTestSession('weak-topic:'+b.dataset.weakTopic,{filter:'wrong'}));
}
