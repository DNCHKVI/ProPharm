import { app, esc } from '../core/shared.js';
import { favoriteButton } from '../ui/personal.js';
import { topicIcon } from '../ui/icons.js';
import { header, bottomNav, bindNav } from '../ui/shell.js';
import { countsForTopic } from '../ui/abbreviations.js';
import { drugSearchText } from '../features/drugs.js';
import { renderVisual } from '../ui/visuals.js';
import { bindTestStarters } from '../features/quiz.js';
import { TOPICS, DRUGS, ABBREVIATIONS, THEORY, MECHANISMS, HIGH_YIELD, INTERACTIONS, SECTION_VISUALS, TESTS, TEST_ANALYSES, ALL_SOURCE_SECTIONS, topicMap } from '../core/content.js';

export function renderTopics(){
 app.innerHTML=header()+`<div class="page"><div class="sectionTitle"><h2>Темы</h2><span class="muted">${TOPICS.length} разделов</span></div><div class="topicGrid">${TOPICS.map(t=>{const c=countsForTopic(t.id);return `<div class="card clickCard" data-route="#topic/${t.id}"><div class="cardHead"><div class="iconFrame topicLineIcon">${topicIcon(t.id)}</div><div><h3>${esc(t.title)}</h3><p>${esc(t.description)}</p><span class="badge">${c.drugs} препаратов</span>${c.abbr?`<span class="badge">${c.abbr} аббр.</span>`:""}${c.theory?`<span class="badge blue">${c.theory} теория</span>`:""}</div></div></div>`;}).join("")}</div></div>`+bottomNav("study");bindNav();
}

export function topicSections(t){const c=countsForTopic(t.id);const defs=[["theory","📘","Теория",c.theory,"Конспекты и интерактивные учебные модули."],["mechanisms","🧬","Механизмы",c.mechanisms,"Сигнальные пути и причинно-следственные цепочки."],["drugs","💊","Препараты",c.drugs,"Препараты, связанные с этой темой."],["abbr","🔤","Аббревиатуры",c.abbr,"Только словарь этой темы — без смешивания."],["interactions","🔗","Взаимодействия",c.interactions,"Лекарственные взаимодействия с механизмом и клиническим следствием."],["tests","📝","Тесты",c.tests,"Вопросы только по выбранной теме."],["analysis","✅","Разбор тестов",c.analyses,"Почему правильный ответ верен и почему остальные неверны."],["high","⚡","High-yield",(HIGH_YIELD[t.id]||[]).length,"Короткий экзаменационный повтор."]];return defs.map(([id,ic,title,count,desc])=>`<div class="card clickCard" data-route="#topic/${t.id}/${id}"><div class="cardHead"><div class="iconFrame">${ic}</div><div><h3>${title}</h3><p>${desc}</p><span class="badge">${count}</span></div></div></div>`).join("");}

export function renderTopic(id){const t=topicMap[id];if(!t){location.hash="#topics";return;}app.innerHTML=header()+`<div class="page"><div class="breadcrumb"><button data-route="#topics">Темы</button><span>›</span><span>${esc(t.short)}</span></div><div class="topicHeader"><div class="iconFrame topicLineIcon">${topicIcon(t.id)}</div><div><h2>${esc(t.title)}</h2><p>${esc(t.description)}</p></div></div><div class="sectionGrid">${topicSections(t)}</div></div>`+bottomNav("study");bindNav();}

export function sectionShell(t,title,content){return header()+`<div class="page"><div class="breadcrumb"><button data-route="#topics">Темы</button><span>›</span><button data-route="#topic/${t.id}">${esc(t.short)}</button><span>›</span><span>${esc(title)}</span></div><div class="topicHeader"><div class="iconFrame topicLineIcon">${topicIcon(t.id)}</div><div><h2>${esc(title)}</h2><p>${esc(t.title)}</p></div></div>${content}</div>`+bottomNav("study");}

export function renderInteractions(t){
  const arr=INTERACTIONS[t.id]||[];
  if(!arr.length)return `<div class="emptyState"><div class="big">🔗</div><b>Взаимодействия пока не заполнены</b><p>Они будут добавляться из комментариев к тестам и теории.</p></div>`;
  return `<div class="list">${arr.map(x=>`<div class="theoryCard"><div class="resultType">${esc(x.type||"Взаимодействие")}</div><h3>${esc(x.title)}</h3><p>${esc(x.summary||"")}</p>${renderVisual({title:"Механизм взаимодействия",kind:"flow",steps:x.chain||[],skipAbbr:true})}${x.note?`<div class="sourceNote">${esc(x.note)}</div>`:""}</div>`).join("")}</div>`;
}

export function renderTopicTheory(t){const items=THEORY[t.id]||[];if(!items.length)return `<div class="emptyState"><div class="big">📘</div><b>Теория пока не заполнена</b><p>Структура уже готова. Следующие конспекты добавим сюда по мере подготовки.</p></div>`;return `<div class="list">${items.map(x=>`<div class="theoryCard"><h3>${esc(x.title)}</h3><p>${esc(x.summary)}</p>${x.type==="interactive"?`<a class="moduleButton" href="${x.url}">📈 Открыть интерактивный модуль</a>`:""}${x.body?.length?`<div class="theoryBody">${x.body.map(v=>`<p>• ${esc(v)}</p>`).join("")}</div>`:""}${renderVisual(x.visual?{...x.visual,skipAbbr:true}:x.visual)}</div>`).join("")}</div>`;}

export function renderMechanisms(t){const arr=MECHANISMS[t.id]||[];if(!arr.length)return `<div class="emptyState"><div class="big">🧬</div><b>Механизмы пока не заполнены</b><p>Здесь будут схемы receptor → messenger → effect → drug.</p></div>`;return `<div class="list">${arr.map(m=>`<div class="mechanismCard"><h3>${esc(m.title)}</h3><div class="chain">${m.chain.map((v,i)=>`${i?'<div class="chainArrow">→</div>':""}<div class="chainNode">${esc(v)}</div>`).join("")}</div><div class="chips">${m.examples.map(v=>`<span class="chip">${esc(v)}</span>`).join("")}</div></div>`).join("")}</div>`;}

export function drugRows(list){return `<div class="list">${list.map(d=>`<div class="drugRow"><div class="drugNum">#${d.n}</div><div class="drugMain" style="flex:1"><b>${esc(d.name)}</b><span>${esc(d.group)}</span><div>${d.topics.map(x=>`<span class="badge">${esc(topicMap[x]?.short||x)}</span>`).join("")}</div><div class="rowActions">${favoriteButton("drug",d.n,"Сохранить")}<button class="drugLink" data-route="#drug/${d.n}">Открыть</button></div></div>`).join("")}</div>`;}

export function renderTopicDrugs(t){const list=DRUGS.filter(d=>d.topics.includes(t.id));return `<div class="toolbar"><input id="topicDrugSearch" placeholder="Поиск в ${esc(t.short)}…"><span class="badge blue">${list.length} препаратов</span></div><div id="topicDrugList">${drugRows(list)}</div>`;}

export function abbrRow(a){return `<div class="abbrRow"><b>${esc(a.abbr)}</b><div class="full">${esc(a.full)}</div><div class="ru">${esc(a.ru)}</div><div class="subtopic">${esc(a.subtopic)}</div></div>`;}

export function renderAbbr(t){const arr=ABBREVIATIONS[t.id]||[];if(!arr.length)return `<div class="emptyState"><div class="big">🔤</div><b>Словарь этой темы пока не заполнен</b><p>Аббревиатуры будут добавляться внутри темы, а не в один смешанный список.</p></div>`;return `<div class="toolbar"><input id="abbrSearch" placeholder="Поиск по аббревиатурам ${esc(t.short)}…"><span class="badge">${arr.length}</span></div><div id="abbrList" class="list">${arr.map(abbrRow).join("")}</div>`;}

export function renderTestsSection(t, analysis=false){
  const arr=(analysis?TEST_ANALYSES:TESTS).filter(x=>x.topic===t.id);
  if(!arr.length) return `<div class="emptyState"><div class="big">${analysis?"✅":"📝"}</div><b>${analysis?"Разборов":"Тестов"} пока нет</b></div>`;
  if(!analysis){
    const sections=ALL_SOURCE_SECTIONS.filter(s=>s.topic===t.id);
    return `<div class="card"><h3>Интерактивный тест</h3><p>${arr.length} вопросов из загруженного материала. Результаты сохраняются в личной истории обучения и синхронизируются при подключённом аккаунте.</p>
      <button class="moduleButton" data-start-test="topic:${t.id}">▶ Начать тест по теме (${arr.length})</button></div>
      <div class="sectionTitle"><h2>Блоки источника</h2></div>
      <div class="list">${sections.map(s=>`<div class="theoryCard"><h3>${esc(s.title)}</h3><p>${s.count} вопросов</p><button class="drugLink" data-start-test="section:${s.id}">Начать</button></div>`).join("")}</div>`;
  }
  const qmap=Object.fromEntries(TESTS.map(q=>[q.id,q]));
  return `<div class="list">${arr.map(a=>{
    const q=qmap[a.questionId]; if(!q)return "";
    return `<div class="theoryCard"><div class="resultType">${esc(q.sectionTitle)} · вопрос ${q.number}</div><h3>${esc(q.question)}</h3>
      <div class="answerReview"><b>Правильный ответ: ${esc(q.correct)}. ${esc(q.options.find(o=>o.id===q.correct)?.text||q.correctText||"")}</b></div>
      ${a.explanation?.length?`<div class="reviewText">${a.explanation.map(x=>`<p>${esc(x)}</p>`).join("")}</div>`:""}
      ${q.options.map(o=>`<div class="reviewOption ${o.id===q.correct?"isCorrect":""}"><b>${o.id}. ${esc(o.text)}</b><div>${o.id===q.correct?"Правильный вариант.":esc(a.optionExplanations?.[o.id]||"В исходном материале отдельный комментарий к этому варианту не сохранён.")}</div></div>`).join("")}
      ${renderVisual(q.visual||a.visual||SECTION_VISUALS[q.sectionId])}${a.sourceNotes?.length?`<div class="sourceNote">${a.sourceNotes.map(x=>`<div>⚠ ${esc(x)}</div>`).join("")}</div>`:""}
    </div>`;
  }).join("")}</div>`;
}

export function renderHigh(t){const arr=HIGH_YIELD[t.id]||[];if(!arr.length)return `<div class="emptyState"><div class="big">⚡</div><b>High-yield пока не заполнен</b></div>`;return `<div class="list">${arr.map((x,i)=>`<div class="highYieldItem"><b>${i+1}.</b> ${esc(x)}</div>`).join("")}</div>`;}

export function renderTopicSection(id,section){const t=topicMap[id];if(!t){location.hash="#topics";return;}const titles={theory:"Теория",mechanisms:"Механизмы",drugs:"Препараты",abbr:"Аббревиатуры",interactions:"Взаимодействия",tests:"Тесты",analysis:"Разбор тестов",high:"High-yield"};let content="";if(section==="theory")content=renderTopicTheory(t);if(section==="mechanisms")content=renderMechanisms(t);if(section==="drugs")content=renderTopicDrugs(t);if(section==="abbr")content=renderAbbr(t);if(section==="interactions")content=renderInteractions(t);if(section==="tests")content=renderTestsSection(t,false);if(section==="analysis")content=renderTestsSection(t,true);if(section==="high")content=renderHigh(t);app.innerHTML=sectionShell(t,titles[section]||section,content);bindNav();bindTestStarters();if(section==="drugs"){const input=document.getElementById("topicDrugSearch"),target=document.getElementById("topicDrugList"),base=DRUGS.filter(d=>d.topics.includes(t.id));input?.addEventListener("input",()=>{const q=input.value.toLowerCase();target.innerHTML=drugRows(base.filter(d=>drugSearchText(d).includes(q)));bindNav();});}if(section==="abbr"){const input=document.getElementById("abbrSearch"),target=document.getElementById("abbrList"),base=ABBREVIATIONS[t.id]||[];input?.addEventListener("input",()=>{const q=input.value.toLowerCase();target.innerHTML=base.filter(a=>(a.abbr+" "+a.full+" "+a.ru+" "+a.subtopic).toLowerCase().includes(q)).map(abbrRow).join("");});}}
