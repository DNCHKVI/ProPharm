import { app, esc } from '../core/shared.js';
import { favoriteButton } from '../ui/personal.js';
import { topicIcon } from '../ui/icons.js';
import { header, bottomNav, bindNav, accordion } from '../ui/shell.js';
import { renderAbbreviationLead } from '../ui/abbreviations.js';
import { drugSearchText } from '../features/drugs.js';
import { renderLearningWhiteboard, renderVisual } from '../ui/visuals.js';
import { drugRows, abbrRow } from '../features/topics.js';
import { buildFlashCards } from '../features/study-tools.js';
import { systemSectionOrder, cardioSectionMeta, renderContextTests, renderCardioPhysiology, renderCardioBiochemistry, renderCardioPathophysiology, renderCardioDiseases, renderCardioTargets, renderCardioDiagnostics, renderCardioCards } from '../features/cardio.js';
import { bindTestStarters } from '../features/quiz.js';
import { DRUGS, ABBREVIATIONS, THEORY, ACADEMIC_SOURCES, MECHANISMS, HIGH_YIELD, INTERACTIONS, SECTION_VISUALS, STUDY_TABLES, SYSTEMS, SYSTEM_SECTION_ORDER, DISEASES, CARDIO_GLOSSARY, CARDIO_PHYSIOLOGY, CARDIO_BIOCHEMISTRY, CARDIO_PATHOLOGIES, CARDIO_TARGETS, CARDIO_DIAGNOSTICS, CARDIO_FLASHCARDS, TESTS, TEST_ANALYSES, drugMap, systemMap, diseaseMap } from '../core/content.js';

export function systemIcon(s){return topicIcon(s?.iconSource||"cardio");}

export function systemSourceTopics(system){return system?.sourceTopics||[];}

export function systemDrugs(system){
 const topics=systemSourceTopics(system),extra=new Set(system?.extraDrugIds||[]);
 return DRUGS.filter(d=>d.topics?.some(t=>topics.includes(t))||extra.has(d.n));
}

export function systemAbbreviations(system){
 const seen=new Set(),arr=[];
 const add=a=>{if(!a?.abbr)return;const k=a.abbr.toLowerCase();if(!seen.has(k)){seen.add(k);arr.push(a)}};
 systemSourceTopics(system).forEach(t=>(ABBREVIATIONS[t]||[]).forEach(add));
 if(system?.id==="cardiovascular")CARDIO_GLOSSARY.forEach(add);
 return arr;
}

export function systemTheory(system){return systemSourceTopics(system).flatMap(t=>(THEORY[t]||[]).map(x=>({...x,topic:t})));}

export function systemMechanisms(system){
 const out=[];systemSourceTopics(system).forEach(t=>(MECHANISMS[t]||[]).forEach((m,i)=>out.push({...m,topic:t,id:`${t}-m${i+1}`})));return out;
}

export function systemDiseases(system){return DISEASES.filter(d=>d.systemId===system.id);}

export function systemTests(system){const topics=systemSourceTopics(system);return TESTS.filter(q=>topics.includes(q.topic));}

export function systemAnalyses(system){const qids=new Set(systemTests(system).map(q=>q.id));return TEST_ANALYSES.filter(a=>qids.has(a.questionId));}

export function systemInteractions(system){
 const topics=systemSourceTopics(system),out=[];
 topics.forEach(t=>(INTERACTIONS[t]||[]).forEach(x=>out.push({...x,topic:t})));
 return out;
}

export function systemTables(system){return systemSourceTopics(system).flatMap(t=>(STUDY_TABLES[t]||[]).map(x=>({...x,topic:t})));}

export function systemHighYield(system){return systemSourceTopics(system).flatMap(t=>(HIGH_YIELD[t]||[]));}

export function countSystemData(system){return {drugs:systemDrugs(system).length,abbr:systemAbbreviations(system).length,tests:systemTests(system).length,mechanisms:systemMechanisms(system).length,diseases:systemDiseases(system).length};}

export function systemSectionMeta(key){return SYSTEM_SECTION_ORDER.find(x=>x[0]===key)||[key,key,""];}

export function renderSystemsHub(){
 app.innerHTML=header()+`<div class="page"><div class="paperTitle"><span class="handMini">Интегрированное обучение</span><h2>Системы</h2><p>В каждой системе физиология, биохимия, патофизиология и фармакология связаны одной причинно-следственной цепочкой.</p></div><div class="topicGrid">${SYSTEMS.map(s=>{const c=countSystemData(s);return `<div class="card clickCard softPaper" data-route="#system/${s.id}"><div class="cardTopActions">${favoriteButton("system",s.id,"Сохранить")}</div><div class="cardHead"><div class="iconFrame topicLineIcon">${systemIcon(s)}</div><div><h3>${esc(s.title)}</h3><p>${esc(s.description)}</p><span class="badge">${c.drugs} препаратов</span><span class="badge blue">${c.tests} тестов</span></div></div></div>`}).join("")}</div></div>`+bottomNav("study");bindNav();
}

export function systemSectionCount(s,key){
 const c=countSystemData(s);
 if(key==="abbr")return systemAbbreviations(s).length;
 if(key==="diseases")return s.id==="cardiovascular"?CARDIO_PATHOLOGIES.length:c.diseases;
 if(key==="targets")return s.id==="cardiovascular"?CARDIO_TARGETS.length:c.mechanisms;
 if(key==="biochemistry")return s.id==="cardiovascular"?CARDIO_BIOCHEMISTRY.length:c.mechanisms;
 if(key==="physiology")return s.id==="cardiovascular"?CARDIO_PHYSIOLOGY.length:systemTheory(s).length;
 if(key==="drugs")return c.drugs;
 if(key==="diagnostics")return s.id==="cardiovascular"?CARDIO_DIAGNOSTICS.length:systemTables(s).length;
 if(key==="cards")return s.id==="cardiovascular"?CARDIO_FLASHCARDS.length:buildFlashCards().filter(x=>systemSourceTopics(s).includes(x.topic)).length;
 if(key==="tests"||key==="analysis")return systemTests(s).length;
 return "";
}

export function renderGenericSystemCards(s){
 const cards=buildFlashCards().filter(x=>systemSourceTopics(s).includes(x.topic)).slice(0,160);
 if(!cards.length)return renderSystemTheoryCards([]);
 return `<div class="accordionStack">${cards.map((c,i)=>accordion({id:`sys-${s.id}-card-${c.id||i}`,title:c.front,level:2,body:`<p>${(c.back||[]).map(esc).join('</p><p>')}</p>${c.drugId?`<button class="drugLink" data-route="#drug/${c.drugId}">Открыть препарат</button>`:''}`})).join('')}</div>`;
}

export function getSystemSectionContent(s,key){
 let content="";
 if(s.id==="cardiovascular"){
   if(key==="abbr"){const a=systemAbbreviations(s);content=`<div class="integratedIntro">Словарь ССС включает не только аббревиатуры, но и белки, ферменты, рецепторы, каналы, транспортёры, ионные токи и биохимические соединения.</div><div class="list">${a.map(abbrRow).join("")}</div>`}
   if(key==="physiology")content=renderCardioPhysiology();
   if(key==="biochemistry")content=renderCardioBiochemistry();
   if(key==="pathophysiology")content=renderCardioPathophysiology();
   if(key==="diseases")content=renderCardioDiseases();
   if(key==="targets")content=renderCardioTargets();
   if(key==="drugs"){const list=systemDrugs(s);content=`<div class="sourceNote">Лекарственные взаимодействия находятся внутри полной карточки каждого препарата.</div><div class="toolbar"><input class="systemDrugSearch" data-system-drug-search="${s.id}" placeholder="Поиск препарата…"><span class="badge blue">${list.length}</span></div><div class="systemDrugList" data-system-drug-list="${s.id}">${drugRows(list)}</div>`}
   if(key==="diagnostics")content=renderCardioDiagnostics();
   if(key==="cards")content=renderCardioCards();
   if(key==="tests")content=`${renderContextTests("physiology")}${renderContextTests("biochemistry")}${renderContextTests("pathophysiology")}${renderContextTests("targets")}${renderContextTests("diagnostics")}<div class="sectionTitle"><h2>Весь тест по ССС</h2></div>${renderSystemTests(s,false)}`;
   if(key==="analysis")content=renderSystemTests(s,true);
 }else{
   if(key==="abbr"){const a=systemAbbreviations(s);content=a.length?`<div class="list">${a.map(abbrRow).join("")}</div>`:renderSystemTheoryCards([])}
   if(key==="physiology"){const all=systemTheory(s),tagged=all.filter(x=>x.section==="physiology"),legacy=all.filter(x=>!x.section&&/electrophysi|электрофизи|базов|кислотност|диабет|физиол|анатом/i.test((x.id||"")+" "+(x.title||"")+" "+(x.summary||"")));content=renderSystemTheoryCards([...tagged,...legacy])}
   if(key==="biochemistry"){const tagged=systemTheory(s).filter(x=>x.section==="biochemistry");content=`${renderSystemTheoryCards(tagged)}${renderBiochemistry(s)}`}
   if(key==="pathophysiology"){const tagged=systemTheory(s).filter(x=>x.section==="pathophysiology");content=`${renderSystemTheoryCards(tagged)}${renderPathophysiology(s)}`}
   if(key==="diseases")content=renderDiseaseCards(s);
   if(key==="targets"){const tagged=systemTheory(s).filter(x=>x.section==="targets");content=`${renderSystemTheoryCards(tagged)}${renderBiochemistry(s)}`}
   if(key==="drugs"){const list=systemDrugs(s);content=`<div class="toolbar"><input class="systemDrugSearch" data-system-drug-search="${s.id}" placeholder="Поиск препарата…"><span class="badge blue">${list.length}</span></div><div class="systemDrugList" data-system-drug-list="${s.id}">${drugRows(list)}</div>`}
   if(key==="diagnostics"){const tagged=systemTheory(s).filter(x=>x.section==="diagnostics");content=`${renderSystemTheoryCards(tagged)}${renderSystemDiagnostics(s)}`}
   if(key==="cards")content=renderGenericSystemCards(s);
   if(key==="tests")content=renderSystemTests(s,false);
   if(key==="analysis")content=renderSystemTests(s,true);
 }
 return content||renderSystemTheoryCards([]);
}

export function bindSystemInlineUI(s,root=document){
 root.querySelectorAll(`[data-system-drug-search="${s.id}"]`).forEach(inp=>{const out=root.querySelector(`[data-system-drug-list="${s.id}"]`),base=systemDrugs(s);inp.oninput=()=>{const q=inp.value.toLowerCase();out.innerHTML=drugRows(base.filter(d=>drugSearchText(d).includes(q)));bindNav(out)}});
 bindTestStarters(root);bindNav(root);
}

export function renderSystem(systemId){
 const s=systemMap[systemId];if(!s){location.hash="#systems";return;}const order=systemSectionOrder(s);
 const sections=order.map(([key,title,desc])=>accordion({id:`system-${s.id}-${key}`,title,subtitle:desc,count:systemSectionCount(s,key),level:1,body:getSystemSectionContent(s,key)})).join("");
 app.innerHTML=header()+`<div class="page"><div class="breadcrumb"><button data-route="#systems">Системы</button><span>›</span><span>${esc(s.short)}</span></div><div class="topicHeader"><div class="iconFrame topicLineIcon">${systemIcon(s)}</div><div><h2>${esc(s.title)}</h2><p>${esc(s.description)}</p></div></div><div class="causalRibbon"><span>Норма</span><b>→</b><span>Биохимия</span><b>→</b><span>Нарушение</span><b>→</b><span>Заболевание</span><b>→</b><span>Мишень</span><b>→</b><span>Препарат</span></div><div class="sourceNote"><b>Навигация:</b> открой нужный раздел, затем тему и её внутренние блоки. По умолчанию большие разделы свёрнуты.</div><div class="accordionStack systemAccordion">${sections}</div></div>`+bottomNav("study");
 bindNav();bindSystemInlineUI(s);
}

export function renderAcademicSourceList(ids=[]){
 const rows=[...new Set(ids)].map(id=>ACADEMIC_SOURCES[id]).filter(Boolean);
 if(!rows.length)return `<p class="smallMuted">Для этого блока отдельные академические источники ещё не привязаны.</p>`;
 return `<div class="academicSources">${rows.map(x=>`<div class="academicSourceRow"><div><b>${esc(x.name)}</b><span class="sourcePriority">${esc(x.priority||"")}</span></div><p>${esc(x.institution||"")}</p><p>${esc(x.use||"")}</p><a href="${esc(x.url)}" target="_blank" rel="noopener noreferrer">Открыть источник ↗</a></div>`).join("")}</div>`;
}

export function renderSystemTheoryCards(items){
 if(!items.length)return `<div class="emptyState"><b>В текущей базе отдельный материал для этого блока ещё не выделен.</b><p>Структура готова; данные будут появляться здесь без дублирования по мере расширения источников.</p></div>`;
 return `<div class="accordionStack">${items.map((x,i)=>{
   const allText=[x.title,x.summary,...(x.body||[]),...(x.visual?.steps||[])].join(" ");
   const sourceIds=x.sources||x.visual?.sourceIds||[];
   const status=x.status==='advanced-theory'?'Продвинуто · теория':'';
   const reviewed=x.lastReviewed?`Проверено: ${x.lastReviewed}`:'';
   const body=[
     accordion({id:`theory-${x.id||i}-terms`,title:'Термины и сокращения',level:3,body:renderAbbreviationLead(allText)||'<p class="smallMuted">Отдельных специальных сокращений нет.</p>'}),
     accordion({id:`theory-${x.id||i}-explain`,title:'Краткое объяснение',level:3,body:`<p>${esc(x.summary||"")}</p>${x.body?.length?`<div class="theoryBody">${x.body.map(v=>`<p>• ${esc(v)}</p>`).join("")}</div>`:""}`}),
     x.visual?.steps?.length?accordion({id:`theory-${x.id||i}-visual`,title:'Схема / Learning Whiteboard',level:3,body:renderLearningWhiteboard({title:x.visual.title||x.title,steps:x.visual.steps,area:x.section==='biochemistry'?'biochemistry':x.section==='pathophysiology'?'pathophysiology':x.section==='diagnostics'?'diagnostics':'physiology',showSources:false})}):'',
     x.visual?.steps?.length?accordion({id:`theory-${x.id||i}-comment`,title:'Что происходит на схеме',level:3,body:`<ol class="processStepsText">${x.visual.steps.map(v=>`<li>${esc(v)}</li>`).join("")}</ol>`}):'',
     accordion({id:`theory-${x.id||i}-sources`,title:'Академические источники',level:3,body:renderAcademicSourceList(sourceIds)}),
     x.type==="interactive"?`<a class="moduleButton" href="${esc(x.url)}">Открыть интерактивный модуль</a>`:''
   ].filter(Boolean).join('');
   return accordion({id:`theory-${x.id||i}`,title:x.title,subtitle:reviewed,count:status,level:2,body});
 }).join("")}</div>`;
}

export function renderBiochemistry(system){
 const ms=systemMechanisms(system);if(!ms.length)return renderSystemTheoryCards([]);
 return `<div class="integratedIntro">Каждый механизм хранится как единая сущность. Процессная визуализация выполняется как Learning Whiteboard с указанием научных источников.</div><div class="accordionStack">${ms.map((m,i)=>accordion({id:`mechanism-${system.id}-${m.id||i}`,title:m.title,level:2,body:`${accordion({id:`mechanism-${system.id}-${m.id||i}-terms`,title:'Термины и сокращения',level:3,body:renderAbbreviationLead([m.title,...(m.chain||[])].join(" "))||'<p class="smallMuted">Нет отдельных сокращений.</p>'})}${accordion({id:`mechanism-${system.id}-${m.id||i}-visual`,title:'Learning Whiteboard',level:3,body:renderLearningWhiteboard({title:m.title,steps:m.chain||[],area:'biochemistry',showSources:true})})}${accordion({id:`mechanism-${system.id}-${m.id||i}-examples`,title:'Связанные препараты / примеры',level:3,body:`<div class="chips">${(m.examples||[]).map(x=>`<span class="chip">${esc(x)}</span>`).join("")}</div><button class="drugLink" data-route="#mechanism/${m.id}">Открыть механизм отдельно</button>`})}`})).join("")}</div>`;
}

export function renderPathophysiology(system){
 const ds=systemDiseases(system),theory=systemTheory(system).filter(x=>ds.some(d=>(d.theoryIds||[]).includes(x.id)));
 return `<div class="integratedIntro">Патофизиология здесь строится из уже имеющихся разборов заболеваний: нормальный механизм → его нарушение → клинический блок → точка приложения терапии.</div>${renderSystemTheoryCards(theory)}`;
}

export function renderDiseaseCards(system){const ds=systemDiseases(system);if(!ds.length)return renderSystemTheoryCards([]);return `<div class="accordionStack">${ds.map((d,i)=>{const cnt=TESTS.filter(q=>(d.sectionIds||[]).includes(q.sectionId)).length;return accordion({id:`disease-${system.id}-${d.id||i}`,title:d.title,count:cnt?`${cnt} тестов`:"",level:2,body:`<p>Связанные теоретические разборы, препараты, механизмы и тесты.</p>${favoriteButton("disease",d.id,"Сохранить")}<button class="drugLink" data-route="#disease/${d.id}">Открыть полный разбор</button>`})}).join("")}</div>`;}

export function renderSystemDiagnostics(system){
 const tables=systemTables(system),diag=(system.diagnostics||[]).map((x,i)=>accordion({id:`diag-${system.id}-${i}`,title:`Диагностический ориентир ${i+1}`,level:2,body:`${renderAbbreviationLead(x)}<p>${esc(x)}</p>`})).join("");
 const tableBlocks=tables.map((tbl,i)=>accordion({id:`diag-table-${system.id}-${i}`,title:tbl.title,level:2,body:`${renderAbbreviationLead([tbl.title,...tbl.columns,...tbl.rows.flat(),tbl.note||""] .join(" "))}<div class="tableScroll"><table><thead><tr>${tbl.columns.map(c=>`<th>${esc(c)}</th>`).join("")}</tr></thead><tbody>${tbl.rows.map(r=>`<tr>${r.map(c=>`<td>${esc(c)}</td>`).join("")}</tr>`).join("")}</tbody></table></div>${tbl.note?`<div class="tableNote">${esc(tbl.note)}</div>`:""}`})).join("");
 return (diag||tableBlocks)?`<div class="accordionStack">${diag}${tableBlocks}</div>`:renderSystemTheoryCards([]);
}

export function renderSystemInteractions(system){const arr=systemInteractions(system);if(!arr.length)return renderSystemTheoryCards([]);return `<div class="list">${arr.map(x=>`<div class="interactionCard"><div class="resultType">${esc(x.type||"Взаимодействие")}</div><h3>${esc(x.title)}</h3>${renderAbbreviationLead([x.title,x.summary,...(x.chain||[])].join(" "))}<p>${esc(x.summary||"")}</p>${renderVisual({title:"Механизм взаимодействия",kind:"flow",steps:x.chain||[],skipAbbr:true})}</div>`).join("")}</div>`;}

export function renderSystemTests(system,analysis=false){
 const q=systemTests(system);if(!q.length)return renderSystemTheoryCards([]);
 if(!analysis)return `<div class="card"><h3>Тест по системе</h3><p>${q.length} вопросов. История сохраняется в личном профиле.</p><button class="moduleButton" data-start-test="system:${system.id}">Начать тест</button></div><div class="sectionTitle"><h2>Клинические блоки</h2></div>${renderDiseaseCards(system)}`;
 const qids=new Set(q.map(x=>x.id));const arr=TEST_ANALYSES.filter(a=>qids.has(a.questionId));const qmap=Object.fromEntries(TESTS.map(x=>[x.id,x]));return `<div class="list">${arr.map(a=>{const x=qmap[a.questionId];if(!x)return "";const raw=[x.question,...(x.options||[]).map(o=>o.text),...(a.explanation||[]),...Object.values(a.optionExplanations||{})].join(" ");return `<div class="theoryCard">${renderAbbreviationLead(raw)}<div class="resultType">${esc(x.sectionTitle)} · вопрос ${x.number}</div><h3>${esc(x.question)}</h3><div class="answerReview"><b>Правильный ответ: ${esc(x.correct)}. ${esc(x.options.find(o=>o.id===x.correct)?.text||"")}</b></div>${(a.explanation||[]).map(z=>`<p>${esc(z)}</p>`).join("")}${x.options.map(o=>`<div class="reviewOption ${o.id===x.correct?"isCorrect":""}"><b>${o.id}. ${esc(o.text)}</b><div>${esc(a.optionExplanations?.[o.id]|| (o.id===x.correct?"Правильный вариант.":"Отдельный комментарий в источнике не сохранён."))}</div></div>`).join("")}${renderVisual(x.visual||a.visual||SECTION_VISUALS[x.sectionId])}</div>`}).join("")}</div>`;
}

export function renderSystemSection(systemId,key){
 const s=systemMap[systemId];if(!s){location.hash="#systems";return;}
 if(key==="interactions"||key==="high"){location.hash=`#system/${s.id}`;return;}
 const [,title]=(s.id==="cardiovascular"?cardioSectionMeta(key):systemSectionMeta(key));
 const content=getSystemSectionContent(s,key);
 app.innerHTML=header()+`<div class="page"><div class="breadcrumb"><button data-route="#systems">Системы</button><span>›</span><button data-route="#system/${s.id}">${esc(s.short)}</button><span>›</span><span>${esc(title)}</span></div><div class="topicHeader"><div class="iconFrame topicLineIcon">${systemIcon(s)}</div><div><h2>${esc(title)}</h2><p>${esc(s.title)}</p></div></div><div class="accordionStack sectionStandalone">${accordion({id:`standalone-${s.id}-${key}`,title,level:1,open:true,body:content})}</div></div>`+bottomNav("study");
 bindNav();bindSystemInlineUI(s);
}

export function allCanonicalMechanisms(){
 const base=SYSTEMS.flatMap(s=>systemMechanisms(s).map(m=>({...m,systemId:s.id})));
 const cv=CARDIO_BIOCHEMISTRY.map(m=>({id:`cv12-${m.id}`,title:m.title,chain:m.steps||[],examples:(m.drugIds||[]).map(id=>drugMap[String(id)]?.name).filter(Boolean),systemId:"cardiovascular",integrated:true,illustration:m.illustration,commentary:m.commentary}));
 return [...cv,...base.filter(m=>!cv.some(x=>x.title===m.title))];
}

export function renderMechanismsHub(){const arr=allCanonicalMechanisms();app.innerHTML=header()+`<div class="page"><div class="paperTitle"><span class="handMini">Единые сущности</span><h2>Механизмы</h2><p>Один механизм используется повторно в физиологии, патологии, препаратах и тестах.</p></div><div class="list">${arr.map(m=>`<div class="mechanismCard clickCard" data-route="#mechanism/${m.id}"><div class="cardTopActions">${favoriteButton("mechanism",m.id,"Сохранить")}</div><div class="resultType">${esc(systemMap[m.systemId]?.short||"")}</div><h3>${esc(m.title)}</h3>${renderAbbreviationLead([m.title,...(m.chain||[])].join(" "))}<p>${esc((m.chain||[]).join(" → "))}</p></div>`).join("")}</div></div>`+bottomNav("study");bindNav();}

export function renderMechanismDetail(id){const m=allCanonicalMechanisms().find(x=>x.id===id);if(!m){location.hash="#mechanisms";return;}const names=new Set((m.examples||[]).map(x=>String(x).split(" — ")[0].trim().toLowerCase()));const ds=DRUGS.filter(d=>names.has(d.name.toLowerCase()));const tests=TESTS.filter(q=>(q.drugIds||[]).some(n=>ds.some(d=>d.n===n))||systemMap[m.systemId]?.sourceTopics?.includes(q.topic));app.innerHTML=header()+`<div class="page"><div class="breadcrumb"><button data-route="#mechanisms">Механизмы</button><span>›</span><span>${esc(m.title)}</span></div><div class="paperTitle"><h2>${esc(m.title)}</h2><p>${esc(systemMap[m.systemId]?.title||"")}</p></div>${renderAbbreviationLead([m.title,...(m.chain||[])].join(" "))}${renderVisual({title:"Процесс",kind:"process",steps:m.chain||[],skipAbbr:true})}<div class="detailBox"><h3>Связанные препараты</h3>${ds.length?drugRows(ds):`<div class="chips">${(m.examples||[]).map(x=>`<span class="chip">${esc(x)}</span>`).join("")}</div>`}</div><div class="detailBox"><h3>Связанные тесты</h3><p>${tests.length} вопросов связаны через систему/препараты. Вопросы физически не копируются.</p><button class="moduleButton" data-route="#system/${m.systemId}/tests">Открыть тесты системы</button></div></div>`+bottomNav("study");bindNav();}

export function renderDiseasesHub(){const legacy=DISEASES.filter(d=>d.systemId!=="cardiovascular");app.innerHTML=header()+`<div class="page"><div class="paperTitle"><span class="handMini">Клиническая навигация</span><h2>По заболеваниям</h2><p>Это альтернативный вход в те же связанные данные. Патологии ССС используют тот же интегрированный слой, что и раздел системы.</p></div><div class="list">${CARDIO_PATHOLOGIES.map(p=>`<div class="card clickCard" data-route="#cardio-pathology/${p.id}"><div class="cardTopActions">${favoriteButton("cardio-pathology",p.id,"Сохранить")}</div><div class="cardHead"><div class="iconFrame topicLineIcon">${systemIcon(systemMap.cardiovascular)}</div><div><h3>${esc(p.title)}</h3><p>Сердечно-сосудистая система</p><span class="badge blue">механизм + терапия + диагностика</span></div></div></div>`).join("")}${legacy.map(d=>{const s=systemMap[d.systemId],cnt=TESTS.filter(q=>(d.sectionIds||[]).includes(q.sectionId)).length;return `<div class="card clickCard" data-route="#disease/${d.id}"><div class="cardTopActions">${favoriteButton("disease",d.id,"Сохранить")}</div><div class="cardHead"><div class="iconFrame topicLineIcon">${systemIcon(s)}</div><div><h3>${esc(d.title)}</h3><p>${esc(s?.title||"")}</p><span class="badge blue">${cnt} тестов</span></div></div></div>`}).join("")}</div></div>`+bottomNav("study");bindNav();}

export function renderDisease(id){const d=diseaseMap[id];if(!d){location.hash="#diseases";return;}const s=systemMap[d.systemId],theory=systemTheory(s).filter(x=>(d.theoryIds||[]).includes(x.id)),qs=TESTS.filter(q=>(d.sectionIds||[]).includes(q.sectionId)),drugIds=new Set(qs.flatMap(q=>q.drugIds||[])),drugs=DRUGS.filter(x=>drugIds.has(x.n));app.innerHTML=header()+`<div class="page"><div class="breadcrumb"><button data-route="#diseases">Заболевания</button><span>›</span><span>${esc(d.title)}</span></div><div class="topicHeader"><div class="iconFrame topicLineIcon">${systemIcon(s)}</div><div><h2>${esc(d.title)}</h2><p>${esc(s.title)}</p></div></div><div class="causalRibbon"><span>Норма</span><b>→</b><span>Нарушение</span><b>→</b><span>${esc(d.title)}</span><b>→</b><span>Мишени</span><b>→</b><span>Препараты</span></div><div class="sectionTitle"><h2>Теория и патофизиология</h2></div>${renderSystemTheoryCards(theory)}<div class="sectionTitle"><h2>Связанные препараты</h2></div>${drugs.length?drugRows(drugs):renderSystemTheoryCards([])}<div class="sectionTitle"><h2>Тесты</h2></div><div class="card"><p>${qs.length} вопросов из существующей базы.</p>${qs.length?`<button class="moduleButton" data-start-test="disease:${d.id}">Начать тест</button>`:""}</div></div>`+bottomNav("study");bindNav();bindTestStarters();}
