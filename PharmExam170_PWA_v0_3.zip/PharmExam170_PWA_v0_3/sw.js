const CACHE="pharmexam170-v0.3.0";
const CORE=["./","./index.html","./styles.css?v=0.3.0","./app.js?v=0.3.0","./manifest.webmanifest","./data/topics.js?v=0.3.0","./data/drugs.js?v=0.3.0","./data/abbreviations.js?v=0.3.0","./data/theory.js?v=0.3.0","./data/mechanisms.js?v=0.3.0","./data/highYield.js?v=0.3.0","./data/tests.js?v=0.3.0","./data/testAnalyses.js?v=0.3.0","./data/sourceSections.js?v=0.3.0","./data/cardio49.js?v=0.3.0","./source/cardio_tests_webarchive_full_text.txt","./modules/cardio/index.html","./modules/cardio/app.js","./icons/icon-180.png","./icons/icon-192.png","./icons/icon-512.png"];
self.addEventListener("install",event=>{
  self.skipWaiting();
  event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(CORE)));
});
self.addEventListener("activate",event=>{
  event.waitUntil(Promise.all([
    caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))),
    self.clients.claim()
  ]));
});
self.addEventListener("fetch",event=>{
  if(event.request.method!=="GET") return;
  const url=new URL(event.request.url);
  const isCode=url.pathname.endsWith(".js") || url.pathname.endsWith(".css") || url.pathname.endsWith(".html") || url.pathname.endsWith(".webmanifest");
  if(isCode){
    event.respondWith(
      fetch(event.request,{cache:"no-store"}).then(response=>{
        const copy=response.clone();
        caches.open(CACHE).then(cache=>cache.put(event.request,copy));
        return response;
      }).catch(()=>caches.match(event.request).then(hit=>hit||caches.match("./index.html")))
    );
    return;
  }
  event.respondWith(caches.match(event.request).then(hit=>hit||fetch(event.request).then(response=>{
    const copy=response.clone(); caches.open(CACHE).then(cache=>cache.put(event.request,copy)); return response;
  })));
});
