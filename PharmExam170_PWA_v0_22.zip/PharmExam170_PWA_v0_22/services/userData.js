import { allForUser,del,get,makeKey,put,randomId } from "./localDb.js?v=0.16.0";
import { authState,currentUserId,getSupabase,isAuthConfigured,isApproved } from "./authService.js?v=0.16.0";

function uid(){const id=currentUserId();if(!id)throw new Error("Нет авторизованного пользователя");return id}
function onlineSyncReady(){return isAuthConfigured()&&isApproved()&&navigator.onLine&&!!getSupabase()}
async function queue(type,payload){const id=randomId("sync");await put("sync_queue",{key:makeKey(uid(),id),id,user_id:uid(),type,payload,created_at:new Date().toISOString()})}

export async function saveTestSession(session){
  const user_id=uid(),id=session.id||randomId("test");
  const row={...session,id,user_id,key:makeKey(user_id,id),created_at:session.created_at||new Date().toISOString()};
  await put("test_sessions",row);
  if(onlineSyncReady()){
    try{const {error}=await getSupabase().from("test_sessions").upsert(stripKey(row),{onConflict:"id"});if(error)throw error}catch(e){await queue("test_session",stripKey(row))}
  }else if(isAuthConfigured())await queue("test_session",stripKey(row));
  return row;
}

export async function recordQuestionResult({question_id,system_id=null,section_id=null,correct=true,first_try=false,wrong_count=0}){
  const user_id=uid(),key=makeKey(user_id,question_id),old=await get("question_progress",key)||{key,user_id,question_id,attempts:0,correct_count:0,wrong_count:0,first_try_correct_count:0};
  const row={...old,attempts:(old.attempts||0)+1,correct_count:(old.correct_count||0)+(correct?1:0),wrong_count:(old.wrong_count||0)+(wrong_count||0),first_try_correct_count:(old.first_try_correct_count||0)+(first_try?1:0),last_seen:new Date().toISOString(),last_result:correct?"correct":"wrong",system_id,section_id,updated_at:new Date().toISOString()};
  await put("question_progress",row);
  const payload={p_question_id:question_id,p_system_id:system_id,p_section_id:section_id,p_correct:correct,p_first_try:first_try,p_wrong_count:wrong_count};
  if(onlineSyncReady()){
    try{const {error}=await getSupabase().rpc("record_question_result",payload);if(error)throw error}catch(e){await queue("question_result",payload)}
  }else if(isAuthConfigured())await queue("question_result",payload);
  return row;
}

export async function setFavorite(entity_type,entity_id,value=true){
  const user_id=uid(),key=makeKey(user_id,entity_type,entity_id);
  if(value)await put("favorites",{key,user_id,entity_type,entity_id:String(entity_id),created_at:new Date().toISOString()});else await del("favorites",key);
  const payload={entity_type,entity_id:String(entity_id),value};
  if(onlineSyncReady()){
    try{const sb=getSupabase();let error;if(value)({error}=await sb.from("favorites").upsert({user_id,entity_type,entity_id:String(entity_id)},{onConflict:"user_id,entity_type,entity_id"}));else ({error}=await sb.from("favorites").delete().eq("user_id",user_id).eq("entity_type",entity_type).eq("entity_id",String(entity_id)));if(error)throw error}catch(e){await queue("favorite",payload)}
  }else if(isAuthConfigured())await queue("favorite",payload);
}
export async function toggleFavorite(type,id){const value=!(await isFavorite(type,id));await setFavorite(type,id,value);return value}
export async function isFavorite(type,id){return !!(await get("favorites",makeKey(uid(),type,id)))}
export async function listFavorites(){return (await allForUser("favorites",uid())).sort((a,b)=>String(b.created_at).localeCompare(String(a.created_at)))}

export async function setReview(entity_type,entity_id,{reason="manual",priority=1,next_review=null}={}){
  const user_id=uid(),key=makeKey(user_id,entity_type,entity_id),row={key,user_id,entity_type,entity_id:String(entity_id),reason,priority,next_review,created_at:new Date().toISOString(),updated_at:new Date().toISOString()};await put("review_queue",row);
  const payload=stripKey(row);if(onlineSyncReady()){try{const {error}=await getSupabase().from("review_queue").upsert(payload,{onConflict:"user_id,entity_type,entity_id"});if(error)throw error}catch(e){await queue("review",{...payload,value:true})}}else if(isAuthConfigured())await queue("review",{...payload,value:true});return row;
}
export async function removeReview(type,id){const user_id=uid();await del("review_queue",makeKey(user_id,type,id));const payload={entity_type:type,entity_id:String(id),value:false};if(onlineSyncReady()){try{const {error}=await getSupabase().from("review_queue").delete().eq("user_id",user_id).eq("entity_type",type).eq("entity_id",String(id));if(error)throw error}catch(e){await queue("review",payload)}}else if(isAuthConfigured())await queue("review",payload)}
export async function listReview(){return (await allForUser("review_queue",uid())).sort((a,b)=>(b.priority||0)-(a.priority||0)||String(b.updated_at).localeCompare(String(a.updated_at)))}

export async function recordStudyPosition({system_id=null,section_id=null,entity_id=null,route=null,completed=false}){
  system_id=system_id||"global";section_id=section_id||"route";entity_id=String(entity_id||route||"");
  const user_id=uid(),id=[system_id,section_id,entity_id].join("/"),key=makeKey(user_id,id),row={key,user_id,system_id,section_id,entity_id,route,viewed:true,completed:!!completed,last_opened:new Date().toISOString(),updated_at:new Date().toISOString()};await put("study_progress",row);localStorage.setItem(`propharm_last_route_${user_id}`,route||location.hash||"#home");
  if(onlineSyncReady()){try{const {error}=await getSupabase().from("study_progress").upsert(stripKey(row),{onConflict:"user_id,system_id,section_id,entity_id"});if(error)throw error}catch(e){await queue("study_progress",stripKey(row))}}else if(isAuthConfigured())await queue("study_progress",stripKey(row));return row;
}
export function lastStudyRoute(){return localStorage.getItem(`propharm_last_route_${uid()}`)||"#systems"}


export async function saveUserSettings(settings){
  const user_id=uid(),key=makeKey(user_id,"settings"),row={key,user_id,settings_json:settings||{},updated_at:new Date().toISOString()};
  await put("user_settings",row);
  const payload=stripKey(row);
  if(onlineSyncReady()){try{const {error}=await getSupabase().from("user_settings").upsert(payload,{onConflict:"user_id"});if(error)throw error}catch(e){await queue("user_settings",payload)}}else if(isAuthConfigured())await queue("user_settings",payload);
  return row;
}
export async function loadUserSettings(){return await get("user_settings",makeKey(uid(),"settings"))}

export async function getLearningStats(){
  const [sessions,questions,favorites,review,progress]=await Promise.all([allForUser("test_sessions",uid()),allForUser("question_progress",uid()),allForUser("favorites",uid()),allForUser("review_queue",uid()),allForUser("study_progress",uid())]);
  const totalAnswered=questions.reduce((s,x)=>s+(x.attempts||0),0),correct=questions.reduce((s,x)=>s+(x.correct_count||0),0),first=questions.reduce((s,x)=>s+(x.first_try_correct_count||0),0),wrong=questions.reduce((s,x)=>s+(x.wrong_count||0),0);
  const totalSelections=correct+wrong;
  return {sessions,questions,favorites,review,progress,totalAnswered,correct,first,wrong,totalSelections,accuracy:totalSelections?Math.round(correct/totalSelections*100):0,firstTryRate:totalAnswered?Math.round(first/totalAnswered*100):0};
}

export async function hydrateFromCloud(){
  if(!onlineSyncReady())return;
  const sb=getSupabase(),user_id=uid();
  const tables=["test_sessions","question_progress","favorites","review_queue","study_progress","user_settings"];
  for(const table of tables){
    try{const {data,error}=await sb.from(table).select("*").eq("user_id",user_id);if(error)throw error;for(const row of data||[]){let key;if(table==="test_sessions")key=makeKey(user_id,row.id);else if(table==="question_progress")key=makeKey(user_id,row.question_id);else if(table==="favorites"||table==="review_queue")key=makeKey(user_id,row.entity_type,row.entity_id);else if(table==="user_settings")key=makeKey(user_id,"settings");else key=makeKey(user_id,[row.system_id||"global",row.section_id||"route",row.entity_id||row.route||"unknown"].join("/"));await put(table,{...row,key})}}catch(e){console.warn("ProPharm hydrate",table,e)}
  }
}

export async function syncPending(){
  if(!onlineSyncReady())return {synced:0,pending:(await allForUser("sync_queue",uid())).length};
  const rows=(await allForUser("sync_queue",uid())).sort((a,b)=>String(a.created_at).localeCompare(String(b.created_at)));let synced=0;
  for(const row of rows){try{await syncOne(row);await del("sync_queue",row.key);synced++}catch(e){console.warn("ProPharm sync pending",row.type,e)}}return {synced,pending:rows.length-synced};
}
async function syncOne(row){
  const sb=getSupabase(),p=row.payload,user_id=uid();
  if(row.type==="test_session"){const {error}=await sb.from("test_sessions").upsert(p,{onConflict:"id"});if(error)throw error;return}
  if(row.type==="question_result"){const {error}=await sb.rpc("record_question_result",p);if(error)throw error;return}
  if(row.type==="favorite"){let error;if(p.value)({error}=await sb.from("favorites").upsert({user_id,entity_type:p.entity_type,entity_id:p.entity_id},{onConflict:"user_id,entity_type,entity_id"}));else({error}=await sb.from("favorites").delete().eq("user_id",user_id).eq("entity_type",p.entity_type).eq("entity_id",p.entity_id));if(error)throw error;return}
  if(row.type==="review"){let error;if(p.value!==false)({error}=await sb.from("review_queue").upsert({...p,user_id},{onConflict:"user_id,entity_type,entity_id"}));else({error}=await sb.from("review_queue").delete().eq("user_id",user_id).eq("entity_type",p.entity_type).eq("entity_id",p.entity_id));if(error)throw error;return}
  if(row.type==="study_progress"){const {error}=await sb.from("study_progress").upsert(p,{onConflict:"user_id,system_id,section_id,entity_id"});if(error)throw error;return}
  if(row.type==="user_settings"){const {error}=await sb.from("user_settings").upsert(p,{onConflict:"user_id"});if(error)throw error;return}
}
function stripKey(x){const {key,...rest}=x;return rest}
