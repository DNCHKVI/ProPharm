export const ACADEMIC_SOURCES = {
  "openstax-ap": {
    "name": "OpenStax Anatomy & Physiology 2e",
    "type": "Университетский учебник",
    "institution": "OpenStax, Rice University",
    "url": "https://openstax.org/details/books/anatomy-and-physiology-2e",
    "use": "Базовая анатомия, физиология, гомеостаз, системы органов.",
    "priority": "A"
  },
  "openstax-micro": {
    "name": "OpenStax Microbiology",
    "type": "Университетский учебник",
    "institution": "OpenStax, Rice University",
    "url": "https://openstax.org/details/books/microbiology",
    "use": "Микробиология, патогенез инфекций, антимикробные мишени и устойчивость.",
    "priority": "A"
  },
  "ncbi-pharm": {
    "name": "Nursing Pharmacology — NCBI Bookshelf",
    "type": "Академический учебник",
    "institution": "NCBI Bookshelf / Open RN",
    "url": "https://www.ncbi.nlm.nih.gov/books/NBK595000/",
    "use": "Системная фармакология и базовые механизмы классов препаратов.",
    "priority": "A"
  },
  "ncbi-books": {
    "name": "NCBI Bookshelf",
    "type": "Академическая библиотека",
    "institution": "NIH / National Library of Medicine",
    "url": "https://www.ncbi.nlm.nih.gov/books/",
    "use": "Углубление физиологии, патофизиологии и механизмов с библиографией.",
    "priority": "A/B"
  },
  "reactome": {
    "name": "Reactome Pathway Database",
    "type": "Экспертно курируемая pathway-база",
    "institution": "Reactome Consortium",
    "url": "https://reactome.org/PathwayBrowser/",
    "use": "Сигнальные пути, рецепторы, ферменты, иммунные и метаболические каскады.",
    "priority": "B"
  },
  "pubmed": {
    "name": "PubMed",
    "type": "Научные публикации",
    "institution": "NIH / National Library of Medicine",
    "url": "https://pubmed.ncbi.nlm.nih.gov/",
    "use": "Проверка сложных/спорных механизмов по обзорам, метаанализам и первичным исследованиям.",
    "priority": "C"
  },
  "ada-2026": {
    "name": "ADA Standards of Care in Diabetes — 2026",
    "type": "Клинический стандарт",
    "institution": "American Diabetes Association",
    "url": "https://diabetesjournals.org/care/issue/49/Supplement_1",
    "use": "Диагностика и современное ведение сахарного диабета.",
    "priority": "Guideline"
  },
  "kdigo": {
    "name": "KDIGO Clinical Practice Guidelines",
    "type": "Клинические рекомендации",
    "institution": "KDIGO",
    "url": "https://kdigo.org/guidelines/",
    "use": "ХБП, электролиты, почечная безопасность и фармакотерапия.",
    "priority": "Guideline"
  },
  "gina": {
    "name": "GINA Strategy Reports",
    "type": "Клинические рекомендации",
    "institution": "Global Initiative for Asthma",
    "url": "https://ginasthma.org/gina-reports/",
    "use": "Астма: патофизиология, контроль, роль противовоспалительной и бронходилатирующей терапии.",
    "priority": "Guideline"
  },
  "gold": {
    "name": "GOLD Reports",
    "type": "Клинические рекомендации",
    "institution": "Global Initiative for Chronic Obstructive Lung Disease",
    "url": "https://goldcopd.org/",
    "use": "ХОБЛ: диагностика, патофизиология и терапевтические подходы.",
    "priority": "Guideline"
  },
  "esc": {
    "name": "ESC Clinical Practice Guidelines",
    "type": "Клинические рекомендации",
    "institution": "European Society of Cardiology",
    "url": "https://www.escardio.org/Guidelines",
    "use": "ССС: сердечная недостаточность, аритмии, ИБС и смежные темы.",
    "priority": "Guideline"
  },
  "idsa": {
    "name": "IDSA Practice Guidelines",
    "type": "Клинические рекомендации",
    "institution": "Infectious Diseases Society of America",
    "url": "https://www.idsociety.org/practice-guideline/practice-guidelines/",
    "use": "Клинические принципы лечения инфекций и антимикробная терапия.",
    "priority": "Guideline"
  },
  "eular": {
    "name": "EULAR Recommendations",
    "type": "Клинические рекомендации",
    "institution": "European Alliance of Associations for Rheumatology",
    "url": "https://www.eular.org/recommendations-management",
    "use": "Ревматология, воспалительные заболевания суставов, иммуномодулирующая терапия.",
    "priority": "Guideline"
  },
  "who-bone": {
    "name": "NIH/NCBI bone physiology resources",
    "type": "Академический референс",
    "institution": "NIH / NCBI",
    "url": "https://www.ncbi.nlm.nih.gov/books/?term=bone+remodeling+physiology",
    "use": "Костное ремоделирование, кальций, витамин D, остеопороз.",
    "priority": "A/C"
  },
  "fda": {
    "name": "FDA / Drugs@FDA",
    "type": "Регуляторный источник",
    "institution": "U.S. Food and Drug Administration",
    "url": "https://www.accessdata.fda.gov/scripts/cder/daf/",
    "use": "Официальные показания, противопоказания, предупреждения, фармакокинетика и взаимодействия.",
    "priority": "Regulatory"
  },
  "israel-drugs": {
    "name": "Israeli Drug Registry",
    "type": "Регуляторный источник",
    "institution": "Israel Ministry of Health",
    "url": "https://israeldrugs.health.gov.il/#!/byDrug",
    "use": "Официальная информация о зарегистрированных препаратах в Израиле.",
    "priority": "Regulatory"
  },
  "grls": {
    "name": "ГРЛС",
    "type": "Регуляторный источник",
    "institution": "Минздрав России",
    "url": "https://grls.rosminzdrav.ru/",
    "use": "Официальные инструкции и регистрационные данные препаратов.",
    "priority": "Regulatory"
  }
};
