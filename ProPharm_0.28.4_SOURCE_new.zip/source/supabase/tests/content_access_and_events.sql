-- Integration gate. Run in the SQL editor of a TEST Supabase project after 001..004.
-- This is intentionally a separate database test; npm test does not execute SQL.
-- All fixtures and audit rows are rolled back. A failure aborts the transaction.
begin;
insert into auth.users(id,email,raw_user_meta_data,raw_app_meta_data) values
('00000000-0280-4000-8000-000000000001','propharm-test-standard@example.invalid','{}','{}'),
('00000000-0280-4000-8000-000000000002','propharm-test-admin@example.invalid','{}','{}'),
('00000000-0280-4000-8000-000000000003','propharm-test-pending@example.invalid','{}','{}');
update public.profiles set status='approved' where user_id in ('00000000-0280-4000-8000-000000000001','00000000-0280-4000-8000-000000000002');
update public.profiles set role='admin' where user_id='00000000-0280-4000-8000-000000000002';
insert into public.content_bundles(build_id,bundle_id,payload) values ('integration-test','drugs','{"allowed":true}'),('integration-test','full','{"private":true}');
set local role authenticated;
select set_config('request.jwt.claim.sub','00000000-0280-4000-8000-000000000001',true);
do $$ begin
 if public.get_content_bundle('drugs','integration-test')<> '{"allowed":true}'::jsonb then raise exception 'standard drug access failed';end if;
 begin perform public.get_content_bundle('full','integration-test');raise exception 'full data leaked';exception when insufficient_privilege then null;end;
 begin perform public.admin_set_content_access('00000000-0280-4000-8000-000000000001','full');raise exception 'role escalation';exception when insufficient_privilege then null;end;
 begin update public.profiles set content_access='full' where user_id=auth.uid();raise exception 'direct role escalation';exception when insufficient_privilege then null;end;
 begin perform public.admin_list_actions();raise exception 'audit data leaked';exception when insufficient_privilege then null;end;
end $$;
-- Deliberately upload out of occurrence order, then retry an event.
select public.record_question_event('{"event_id":"newer","question_id":"integration-q","session_id":"two","correct":true,"first_try":true,"is_repeat":false,"occurred_at":"2025-01-03T00:00:00Z"}');
select public.record_question_event('{"event_id":"older","question_id":"integration-q","session_id":"zero","correct":false,"first_try":false,"is_repeat":false,"occurred_at":"2025-01-01T00:00:00Z"}');
select public.record_question_event('{"event_id":"middle","question_id":"integration-q","session_id":"one","correct":true,"first_try":true,"is_repeat":false,"occurred_at":"2025-01-02T00:00:00Z"}');
select public.record_question_event('{"event_id":"newer","question_id":"integration-q","session_id":"two","correct":true,"first_try":true,"is_repeat":false,"occurred_at":"2025-01-03T00:00:00Z"}');
do $$ declare p public.question_progress%rowtype;begin
 select * into p from public.question_progress where user_id=auth.uid() and question_id='integration-q';
 if p.attempts<>3 or p.wrong_count<>1 or p.mastery_streak<>2 or p.last_result<>'correct' or p.last_seen<>'2025-01-03T00:00:00Z'::timestamptz then raise exception 'event replay/order aggregation failed';end if;
end $$;
select set_config('request.jwt.claim.sub','00000000-0280-4000-8000-000000000003',true);
do $$ begin
 begin perform public.get_content_bundle('drugs','integration-test');raise exception 'pending access leaked';exception when insufficient_privilege then null;end;
end $$;
select set_config('request.jwt.claim.sub','00000000-0280-4000-8000-000000000002',true);
select public.admin_set_content_access('00000000-0280-4000-8000-000000000001','full');
do $$ begin
 if not exists(select 1 from public.admin_list_actions() where target_user_id='00000000-0280-4000-8000-000000000001' and before_state->>'content_access'='standard' and after_state->>'content_access'='full') then raise exception 'administrative audit missing';end if;
end $$;
reset role;
do $$ begin
 begin update public.admin_actions set action='tampered' where resource_id='integration-test:full';raise exception 'audit mutation succeeded';exception when insufficient_privilege then null;end;
end $$;
rollback;
