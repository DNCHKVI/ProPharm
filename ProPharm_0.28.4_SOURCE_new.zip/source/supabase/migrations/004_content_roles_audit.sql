-- ProPharm 0.28: server-issued content access, immutable administrative audit,
-- idempotent learning events. Apply after migrations 001..003.
begin;
alter table public.profiles add column if not exists content_access text not null default 'standard' check (content_access in ('standard','full'));
revoke update on public.profiles from authenticated,anon;
grant update(name,avatar_url,updated_at,last_login) on public.profiles to authenticated;

create schema if not exists propharm_private;
revoke all on schema propharm_private from public;
grant usage on schema propharm_private to authenticated;
create or replace function propharm_private.can_read_content(p_full boolean default false)
returns boolean language sql stable security definer set search_path='' as $$
 select exists(select 1 from public.profiles p where p.user_id=auth.uid() and p.status='approved' and (not p_full or p.role='admin' or p.content_access='full'));
$$;
revoke all on function propharm_private.can_read_content(boolean) from public;
grant execute on function propharm_private.can_read_content(boolean) to authenticated;

create table if not exists public.content_bundles(
 build_id text not null, bundle_id text not null check(bundle_id in ('meta','tests','drugs','interactions','full')),
 payload jsonb not null, updated_at timestamptz not null default now(), primary key(build_id,bundle_id)
);
alter table public.content_bundles enable row level security;
revoke all on public.content_bundles from public,anon,authenticated;
grant all on public.content_bundles to service_role;
create or replace function public.get_content_bundle(p_bundle text,p_build text)
returns jsonb language plpgsql stable security definer set search_path='' as $$
declare v jsonb;
begin
 if p_bundle is null or p_bundle not in ('meta','tests','drugs','interactions','full') then raise exception 'unknown content bundle'; end if;
 if not propharm_private.can_read_content(p_bundle='full') then raise exception 'content access denied' using errcode='42501'; end if;
 select b.payload into v from public.content_bundles b where b.bundle_id=p_bundle and b.build_id=p_build;
 if v is null then raise exception 'content build is not installed: %',p_build;end if;
 return v;
end $$;
revoke all on function public.get_content_bundle(text,text) from public,anon;
grant execute on function public.get_content_bundle(text,text) to authenticated;

-- Illustrations are stored privately; the app downloads only authorized bytes.
insert into storage.buckets(id,name,public) values('propharm-content','propharm-content',false)
on conflict(id) do update set public=false;
drop policy if exists propharm_read_images on storage.objects;
create policy propharm_read_images on storage.objects for select to authenticated using(
 bucket_id='propharm-content' and
 ((name like 'approved/%' and propharm_private.can_read_content(false)) or
  (name like 'full/%' and propharm_private.can_read_content(true)))
);

-- Extend the existing log, retaining all historical records.
alter table public.admin_actions alter column admin_user_id drop not null;
alter table public.admin_actions alter column target_user_id drop not null;
alter table public.admin_actions add column if not exists before_state jsonb;
alter table public.admin_actions add column if not exists after_state jsonb;
alter table public.admin_actions add column if not exists actor_source text not null default 'user';
alter table public.admin_actions add column if not exists resource_id text;
revoke all on public.admin_actions from public,anon,authenticated;
grant select on public.admin_actions to authenticated;
create or replace function propharm_private.audit_profile_access()
returns trigger language plpgsql security definer set search_path='' as $$
begin
 if (old.role,old.status,old.content_access) is distinct from (new.role,new.status,new.content_access) then
  insert into public.admin_actions(admin_user_id,target_user_id,action,before_state,after_state,actor_source,resource_id)
  values(auth.uid(),new.user_id,'profile_access_changed',jsonb_build_object('role',old.role,'status',old.status,'content_access',old.content_access),jsonb_build_object('role',new.role,'status',new.status,'content_access',new.content_access),case when auth.uid() is null then 'database' else 'user' end,new.user_id::text);
 end if;return new;
end $$;
drop trigger if exists propharm_profile_audit on public.profiles;
create trigger propharm_profile_audit after update on public.profiles for each row execute function propharm_private.audit_profile_access();
create or replace function propharm_private.audit_content_change()
returns trigger language plpgsql security definer set search_path='' as $$
begin
 insert into public.admin_actions(admin_user_id,target_user_id,action,actor_source,resource_id,before_state,after_state)
 values(auth.uid(),null,'content_'||lower(tg_op),case when auth.uid() is null then 'database' else 'user' end,coalesce(new.build_id,old.build_id)||':'||coalesce(new.bundle_id,old.bundle_id),case when tg_op<>'INSERT' then jsonb_build_object('bytes',octet_length(old.payload::text)) end,case when tg_op<>'DELETE' then jsonb_build_object('bytes',octet_length(new.payload::text)) end);
 return coalesce(new,old);
end $$;
drop trigger if exists propharm_content_audit on public.content_bundles;
create trigger propharm_content_audit after insert or update or delete on public.content_bundles for each row execute function propharm_private.audit_content_change();
create or replace function propharm_private.prevent_audit_mutation()
returns trigger language plpgsql set search_path='' as $$ begin raise exception 'audit records are immutable' using errcode='42501';end $$;
drop trigger if exists propharm_audit_immutable on public.admin_actions;
create trigger propharm_audit_immutable before update or delete on public.admin_actions for each row execute function propharm_private.prevent_audit_mutation();

create or replace function public.admin_set_user_status(target_user_id uuid,new_status text)
returns void language plpgsql security definer set search_path='' as $$
begin
 if not public.is_propharm_admin() then raise exception 'admin required' using errcode='42501';end if;
 if new_status is null or new_status not in ('pending','approved','blocked','rejected') then raise exception 'invalid status';end if;
 update public.profiles p set status=new_status::public.propharm_status,updated_at=now() where p.user_id=target_user_id and p.role<>'admin';
 if not found then raise exception 'target unavailable or protected administrator';end if;
 -- The trigger records before/after atomically; no duplicate log insert here.
end $$;
create or replace function public.admin_set_content_access(p_target uuid,p_access text)
returns void language plpgsql security definer set search_path='' as $$
begin
 if not public.is_propharm_admin() then raise exception 'admin required' using errcode='42501';end if;
 if p_access is null or p_access not in ('standard','full') then raise exception 'invalid content access';end if;
 update public.profiles p set content_access=p_access,updated_at=now() where p.user_id=p_target and p.role<>'admin';
 if not found then raise exception 'target unavailable or protected administrator';end if;
end $$;
create or replace function public.admin_list_actions(p_limit integer default 100,p_before timestamptz default null)
returns setof public.admin_actions language plpgsql stable security definer set search_path='' as $$
begin
 if not public.is_propharm_admin() then raise exception 'admin required' using errcode='42501';end if;
 return query select a.* from public.admin_actions a where p_before is null or a.created_at<p_before order by a.created_at desc,a.id desc limit greatest(1,least(coalesce(p_limit,100),200));
end $$;
-- Keep the existing admin_list_users signature; add a v2 JSON RPC for access details.
create or replace function public.admin_list_users_v2()
returns jsonb language plpgsql stable security definer set search_path='' as $$
declare v jsonb;
begin
 if not public.is_propharm_admin() then raise exception 'admin required' using errcode='42501';end if;
 select coalesce(jsonb_agg(to_jsonb(p) order by p.created_at desc),'[]'::jsonb) into v from public.profiles p;return v;
end $$;
revoke all on function public.admin_set_user_status(uuid,text),public.admin_set_content_access(uuid,text),public.admin_list_actions(integer,timestamptz),public.admin_list_users_v2() from public,anon;
grant execute on function public.admin_set_user_status(uuid,text),public.admin_set_content_access(uuid,text),public.admin_list_actions(integer,timestamptz),public.admin_list_users_v2() to authenticated;

-- Preserve the existing intended access, now once on the server. This is a migration,
-- not a permanent forced-approval rule: later blocks/revocations remain effective.
create table if not exists propharm_private.migration_seeds(name text primary key);
do $$ begin
 if not exists(select 1 from propharm_private.migration_seeds where name='004_legacy_access') then
update public.profiles set role='admin',status='approved',content_access='full' where user_id='16c47a77-4a81-4ce9-9e5a-57b9b9f06198';
update public.profiles set status='approved',content_access='full' where user_id='e7ad4b01-82af-46af-84ec-a870f0b269e4';
update public.profiles set status='approved' where user_id='52057dae-4c4d-4679-a107-1589016586d8';

 insert into propharm_private.migration_seeds values('004_legacy_access');
 end if;
end $$;

alter table public.question_progress add column if not exists mastery_streak integer not null default 0;
alter table public.question_progress add column if not exists last_mastery_session text;
create table if not exists public.question_events(
 user_id uuid not null references auth.users(id) on delete cascade,event_id text not null,payload jsonb not null,created_at timestamptz not null default now(),primary key(user_id,event_id)
);
alter table public.question_events enable row level security;
revoke all on public.question_events from public,anon,authenticated;
create or replace function public.record_question_event(p_event jsonb)
returns void language plpgsql security definer set search_path='' as $$
declare v_uid uuid:=auth.uid();v_correct boolean;v_first boolean;v_repeat boolean;v_when timestamptz;v_session text;v_q text;v_inserted integer;
begin
 if not propharm_private.can_read_content(false) then raise exception 'approved account required' using errcode='42501';end if;
 if p_event is null or jsonb_typeof(p_event)<>'object' or coalesce(p_event->>'event_id','')='' or length(p_event->>'event_id')>300 or coalesce(p_event->>'question_id','')='' or coalesce(p_event->>'session_id','')='' then raise exception 'invalid learning event';end if;
 v_correct:=coalesce((p_event->>'correct')::boolean,false);v_first:=coalesce((p_event->>'first_try')::boolean,false);v_repeat:=coalesce((p_event->>'is_repeat')::boolean,false);
 v_q:=p_event->>'question_id';v_session:=p_event->>'session_id';v_when:=coalesce((p_event->>'occurred_at')::timestamptz,now());
 if v_when>now()+interval '5 minutes' then raise exception 'event timestamp is in the future';end if;
 p_event:=jsonb_set(p_event,'{occurred_at}',to_jsonb(v_when));
 -- Serialize independent devices answering the same question.
 perform pg_advisory_xact_lock(hashtextextended(v_uid::text||':'||v_q,0));
 insert into public.question_events(user_id,event_id,payload) values(v_uid,p_event->>'event_id',p_event) on conflict do nothing;
 get diagnostics v_inserted=row_count;if v_inserted=0 then return;end if;
 insert into public.question_progress(user_id,question_id,system_id,section_id,attempts,correct_count,wrong_count,first_try_correct_count,last_result,last_seen,updated_at,mastery_streak,last_mastery_session)
 values(v_uid,v_q,p_event->>'system_id',p_event->>'section_id',1,case when v_correct then 1 else 0 end,case when v_correct then 0 else 1 end,case when v_first then 1 else 0 end,case when v_correct then 'correct' else 'wrong' end,v_when,v_when,case when v_first and not v_repeat then 1 else 0 end,case when v_first and not v_repeat then v_session end)
 on conflict(user_id,question_id) do update set
 attempts=public.question_progress.attempts+1,correct_count=public.question_progress.correct_count+excluded.correct_count,wrong_count=public.question_progress.wrong_count+excluded.wrong_count,first_try_correct_count=public.question_progress.first_try_correct_count+excluded.first_try_correct_count,
 mastery_streak=case when not v_correct then 0 when v_first and not v_repeat and public.question_progress.last_mastery_session is distinct from v_session then public.question_progress.mastery_streak+1 else public.question_progress.mastery_streak end,
 last_mastery_session=case when v_first and not v_repeat then v_session else public.question_progress.last_mastery_session end,
 last_result=case when excluded.last_seen>=public.question_progress.last_seen then excluded.last_result else public.question_progress.last_result end,last_seen=greatest(public.question_progress.last_seen,excluded.last_seen),updated_at=now(),section_id=excluded.section_id,system_id=excluded.system_id;
 -- Recompute from occurrence order, so a delayed offline event cannot erase later mastery.
 update public.question_progress p set mastery_streak=(
  select count(distinct e.payload->>'session_id')::integer from public.question_events e
  where e.user_id=v_uid and e.payload->>'question_id'=v_q
   and (e.payload->>'correct')::boolean and (e.payload->>'first_try')::boolean
   and not coalesce((e.payload->>'is_repeat')::boolean,false)
   and (e.payload->>'occurred_at')::timestamptz>coalesce((
    select max((w.payload->>'occurred_at')::timestamptz) from public.question_events w
    where w.user_id=v_uid and w.payload->>'question_id'=v_q and not (w.payload->>'correct')::boolean
   ),'-infinity'::timestamptz)
 ) where p.user_id=v_uid and p.question_id=v_q;
end $$;
revoke all on function public.record_question_event(jsonb) from public,anon;
grant execute on function public.record_question_event(jsonb) to authenticated;
notify pgrst,'reload schema';
commit;
