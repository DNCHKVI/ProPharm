export const BUILD_ID='0.28.4-law-cards-images';
