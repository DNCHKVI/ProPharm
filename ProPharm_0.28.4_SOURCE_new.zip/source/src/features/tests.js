import { app,esc } from '../core/shared.js';
import { TESTS,TEST_NAV_STRUCTURE,registry } from '../core/content.js';
import { authState } from '../../services/authService.js';
import { getLearningStats } from '../../services/userData.js';
import { header,bottomNav,bindNav,accordion } from '../ui/shell.js';
import { bindTestStarters,startTestSession,resumeTest } from './quiz.js';
import { loadDraft,discardDraft } from '../questions/session-store.js';
import { isWeak } from '../questions/engine.js';
import { toast } from '../ui/personal.js';
import {sectionQuestions,questionRanges,testOverview,neverAttempted} from '../questions/overview.js';
let pageProgress=new Map(),statsAvailable=false,renderGeneration=0;
export function testCountForSections(ids=[]){return sectionQuestions(TESTS,ids).length;}
function renderPool(title,pool,spec){if(!pool.length)return '';const untouched=statsAvailable&&neverAttempted(pool,pageProgress);return `<div class="testSectionRow ${untouched?'neverAttempted':''}"><div><h3>${esc(title)}</h3><p>${pool.length} вопросов${untouched?' · ещё не прорешено':''}</p></div><button class="moduleButton" data-start-test="${esc(spec)}">Настроить тест</button></div>`;}
export function renderTestLeaf(id,title,sections=[]){return renderPool(title,sectionQuestions(TESTS,sections),'sections:'+sections.join(','));}
export function renderTestNavNode(node){
 const ids=node.children?node.children.flatMap(x=>x[2]||[]):node.sections||[],pool=sectionQuestions(TESTS,ids);if(!pool.length)return '';
 let body;
 if(node.id==='pharmacology'){
  body=`<button class="moduleButton" data-start-test="ids:${esc(pool.map(q=>q.id).join(','))}">Микс — только фармакология</button><p>Диапазоны относятся к порядку вопросов внутри этого раздела. Номер исходника сохранён в карточке.</p>`+questionRanges(pool).map(r=>renderPool(`Вопросы ${r.start}–${r.end}`,r.questions,'ids:'+r.questions.map(q=>q.id).join(','))).join('');
 }else body=node.children?node.children.map(([id,title,sections])=>renderTestLeaf(id,title,sections)).join(''):renderTestLeaf(node.id,node.title,node.sections);
 return accordion({id:'test-nav-'+node.id,title:node.title,count:pool.length,body,level:1,className:statsAvailable&&neverAttempted(pool,pageProgress)?'neverAttempted':''});
}
export async function renderTests(){
 const generation=++renderGeneration,route=location.hash,uid=authState.user?.id;let stats=null;try{stats=await getLearningStats()}catch(e){console.warn('Test overview unavailable',e)}
 if(generation!==renderGeneration||uid!==authState.user?.id||location.hash!==route)return;
 const overview=testOverview(TESTS,stats?.questions||[]);pageProgress=overview.progress;statsAvailable=!!stats;
 let draft=null,error='';try{draft=loadDraft(uid,registry)}catch(e){error=e.message}
 const empty=TEST_NAV_STRUCTURE.flatMap(n=>n.children?n.children.filter(x=>!testCountForSections(x[2])).map(x=>x[1]):!testCountForSections(n.sections||[])?[n.title]:[]);
 app.innerHTML=header()+`<div class="page testsPage"><h1>Тесты</h1>
 <section class="testOverview" aria-label="Статистика прохождения"><div><strong>${overview.total}</strong><span>Всего вопросов</span></div><div><strong>${stats?overview.solved:'—'}</strong><span>Уже прорешано</span></div><div><strong>${stats&&overview.success!==null?overview.success+'%':'—'}</strong><span>Средняя успешность</span></div></section>
 <p class="overviewExplanation">Прорешано — уникальные вопросы с сохранённым результатом. Успешность — доля верных первых ответов за все попытки, без учебных повторов и заданий без оценки.${stats?'':' Статистика временно недоступна.'}</p>
 ${draft?`<section class="resumeNotice"><h2>${draft.completedAt?'Последний результат':'Продолжить тест'}</h2><p>${draft.mode==='exam'?'Экзамен':'Обучение'} · задание ${Math.min(draft.index+1,draft.queue.length)} из ${draft.queue.length}</p><button class="moduleButton" id="resumeTest">${draft.completedAt?'Посмотреть результат':'Продолжить'}</button></section>`:''}
 ${error?`<p role="alert">${esc(error)} <button id="clearDraft">Удалить устаревшую сессию</button></p>`:''}
 <div class="quickStudy"><button class="moduleButton" data-start-test="all">Смешанный тест</button><button class="moduleButton secondary" data-route="#weak-topics">Слабые темы</button><button class="moduleButton secondary" id="onlyMistakes">Мои ошибки</button><button class="moduleButton unattemptedToggle" id="highlightUnattempted" aria-pressed="false" ${stats?'':'disabled'}>не прорешено</button></div><div class="accordionStack">${TEST_NAV_STRUCTURE.map(renderTestNavNode).join('')}</div>
 ${empty.length?`<details class="comingSoon"><summary>Скоро · ${empty.length} разделов</summary><ul>${empty.map(t=>`<li>${esc(t)}</li>`).join('')}</ul></details>`:''}</div>`+bottomNav('study');bindNav();bindTestStarters();
 document.getElementById('highlightUnattempted').onclick=e=>{const on=e.currentTarget.getAttribute('aria-pressed')!=='true';e.currentTarget.setAttribute('aria-pressed',String(on));app.querySelector('.testsPage').classList.toggle('highlightUnattempted',on)};
 document.getElementById('resumeTest')?.addEventListener('click',()=>{try{resumeTest()}catch(e){toast(e.message,'bad')}});document.getElementById('onlyMistakes').onclick=()=>startTestSession('all',{filter:'wrong'});document.getElementById('clearDraft')?.addEventListener('click',()=>{discardDraft(uid);renderTests()});
}
export async function renderWeakTopics(){
 const uid=authState.user?.id,stats=await getLearningStats();if(uid!==authState.user?.id||location.hash!=='#weak-topics')return;
 const map=new Map();for(const p of stats.questions){const q=registry.get(p.question_id);if(!q||!isWeak(p))continue;const id=q.studyTopicId||q.sectionId;if(!map.has(id))map.set(id,{id,title:q.studyTopic||q.sectionTitle,count:0});map.get(id).count++;}
 const rows=[...map.values()].sort((a,b)=>b.count-a.count);
 app.innerHTML=header()+`<div class="page testsPage"><h1>Слабые темы</h1><p>Тема появляется после ошибки. Вопрос считается освоенным после верных первых ответов в двух разных сессиях подряд. Повторы внутри одного теста не повышают этот статус.</p>${rows.length?rows.map(x=>`<div class="testSectionRow"><div><h2>${esc(x.title)}</h2><p>${x.count} вопросов требуют закрепления</p></div><button class="moduleButton" data-weak-topic="${esc(x.id)}">Тренироваться</button></div>`).join(''):'<p>Пока нет выявленных слабых тем. Пройди тест, чтобы собрать статистику.</p>'}<button class="moduleButton secondary" data-route="#tests">Все тесты</button></div>`+bottomNav('study');bindNav();app.querySelectorAll('[data-weak-topic]').forEach(b=>b.onclick=()=>startTestSession('weak-topic:'+b.dataset.weakTopic,{filter:'wrong'}));
}
