-- ProPharm 0.28.4: reviewed pharmacy-law questions and navigation.
begin;
update public.content_bundles
set payload=jsonb_set(payload,'{TEST_NAV_STRUCTURE}',(
 select jsonb_agg(case when x->>'id'='law' then jsonb_set(x,'{sections}', '["pharmacy-law-2026"]'::jsonb) else x end)
 from jsonb_array_elements(payload->'TEST_NAV_STRUCTURE') x
)),updated_at=now()
where build_id='0.28.2-f130bf3e2e6c' and bundle_id='meta';
commit;
