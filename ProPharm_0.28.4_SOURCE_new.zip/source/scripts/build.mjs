import {serviceWorker} from './service-worker.mjs';
import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';import { validate } from './validate.mjs';
validate();
export function files(dir){return fs.readdirSync(dir,{withFileTypes:true}).flatMap(x=>x.isDirectory()?files(path.join(dir,x.name)):[path.join(dir,x.name)]).sort();}
const publicPaths=['app.js','index.html','styles.css','manifest.webmanifest','src','styles','services','config','i18n','icons'];
const input=[...publicPaths.flatMap(p=>fs.statSync(p).isDirectory()?files(p):[p]),...files('content'),...files('assets'),...files('scripts')].sort();
const hash=crypto.createHash('sha256');input.forEach(p=>{hash.update(p);hash.update(fs.readFileSync(p))});const build=JSON.parse(fs.readFileSync('package.json')).version+'-'+hash.digest('hex').slice(0,12);
fs.rmSync('dist',{recursive:true,force:true});fs.mkdirSync('dist');fs.rmSync('server-bundle',{recursive:true,force:true});fs.mkdirSync('server-bundle/assets',{recursive:true});
for(const p of publicPaths)fs.cpSync(p,path.join('dist',p),{recursive:true});
fs.writeFileSync('dist/src/core/build.js',`export const BUILD_ID=${JSON.stringify(build)};\n`);fs.writeFileSync('dist/.nojekyll','');
const data=JSON.parse(fs.readFileSync('content/catalog.json')),questions=JSON.parse(fs.readFileSync('content/questions.json'));
const sets={meta:['TOPICS','SYSTEMS','SYSTEM_SECTION_ORDER','FOUNDATIONAL_SECTIONS','TEST_NAV_STRUCTURE','SOURCE_SECTIONS','PAST_EXAM_SECTIONS','PAST_EXAM_SOURCES'],drugs:['DRUGS','DRUG_KNOWLEDGE','DRUG_PROFILES','CARDIO49'],interactions:['INTERACTIONS'],tests:['ABBREVIATIONS','GLOSSARY_EXTRAS','CARDIO_GLOSSARY'],full:[]};
const allocated=new Set(Object.values(sets).flat());sets.full=Object.keys(data).filter(k=>!allocated.has(k));
const assetVersion=JSON.parse(fs.readFileSync('content/asset-version.json'));
const assets=new Map(),bundles={};
function transform(v,full){
 if(typeof v==='string'&&/^(?:\.\/)?assets\//.test(v)){const file=v.replace(/^\.\//,'').split(/[?#]/)[0];if(!fs.existsSync(file))throw new Error('Missing asset '+file);const assetBuild=assetVersion.files[file]===crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex')?assetVersion.build:build;const name=(full?'full/':'approved/')+assetBuild+'/'+file;if(!assets.has(name)){assets.set(name,file);const out='server-bundle/assets/'+name;fs.mkdirSync(path.dirname(out),{recursive:true});fs.copyFileSync(file,out);}return 'protected:'+name;}
 if(Array.isArray(v))return v.map(x=>transform(x,full));if(v&&typeof v==='object')return Object.fromEntries(Object.entries(v).map(([k,x])=>[k,transform(x,full)]));return v;
}
for(const [key,keys]of Object.entries(sets)){const payload=Object.fromEntries(keys.map(k=>[k,data[k]]));if(key==='tests')payload.questions=questions;bundles[key]=transform(payload,key==='full');}
fs.writeFileSync('server-bundle/bundles.json',JSON.stringify({build,bundles},null,2));
fs.writeFileSync('server-bundle/assets.json',JSON.stringify([...assets].map(([name,file])=>({name,file:'assets/'+name,contentType:name.endsWith('.svg')?'image/svg+xml':name.endsWith('.png')?'image/png':name.endsWith('.webp')?'image/webp':'image/jpeg'})),null,2));
// A direct SQL option makes the JSON content import reviewable in the SQL editor.
let sql='begin;\n';for(const [key,payload]of Object.entries(bundles)){const text=JSON.stringify(payload),tag='$propharm_content$';if(text.includes(tag))throw new Error('SQL delimiter collision');sql+=`insert into public.content_bundles(build_id,bundle_id,payload) values ('${build}','${key}',${tag}${text}${tag}::jsonb) on conflict(build_id,bundle_id) do update set payload=excluded.payload,updated_at=now();\n`;}
sql+='commit;\n';fs.writeFileSync('server-bundle/005_import_content.sql',sql);
const resources=files('dist').map(p=>p.slice(5)),cache='propharm-shell-'+build;
const manifest=resources.map(file=>({file,sha256:crypto.createHash('sha256').update(fs.readFileSync('dist/'+file)).digest('hex')}));
fs.writeFileSync('dist/asset-manifest.json',JSON.stringify({build,files:manifest},null,2));
const sw=serviceWorker({cache,resources});
fs.writeFileSync('dist/sw.js',sw);
fs.writeFileSync('reports/build.json',JSON.stringify({build,publicFiles:resources.length,privateAssets:assets.size,publicContainsQuestionData:false,publicContainsFullData:false},null,2));
console.log(JSON.stringify({build,publicFiles:resources.length,privateAssets:assets.size}));
