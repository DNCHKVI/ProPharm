import fs from 'node:fs';import { validateRegistry } from '../src/questions/schema.js';
export function validate(){
 const qs=JSON.parse(fs.readFileSync('content/questions.json')),catalog=JSON.parse(fs.readFileSync('content/catalog.json'));
 const result=validateRegistry(qs,catalog.TEST_NAV_STRUCTURE),images=new Set(),errors=[...result.errors];
 function visit(v){if(typeof v==='string'&&/^(?:\.\/)?assets\//.test(v)){const file=v.replace(/^\.\//,'').split(/[?#]/)[0];if(!fs.existsSync(file))errors.push('Нет изображения: '+file);else images.add(file);}else if(v&&typeof v==='object')Object.values(v).forEach(visit);}
 qs.forEach(visit);visit(catalog);
 const known=JSON.parse(fs.readFileSync('content/known-duplicates.json'));
 for(const d of result.duplicates)if(!known.some(k=>k.text===d.text&&JSON.stringify([...k.ids].sort())===JSON.stringify([...d.ids].sort())&&k.reason?.trim()))errors.push('Не разобран дубликат текста: '+d.ids.join(', '));
 const forbidden=[/В исходном материале отдельный комментарий.*не сохранён/i,/Дополнительное объяснение будет добавляться/i,/Правильный вариант подтверждён сохранённым/i,/^Правильный вариант\.?$/i];
 for(const q of qs){for(const [id,e]of Object.entries(q.optionExplanations||{}))if(forbidden.some(p=>p.test(e)))errors.push(`${q.id}:${id}: шаблон вместо объяснения`);if(forbidden.some(p=>p.test(q.hint))||/Связь для решения:|^Правильный вариант|^Правильно\.|^Проследи путь от рецептора\//i.test(q.hint))errors.push(q.id+': шаблон подсказки');}
 const report={questions:qs.length,uniqueIds:new Set(qs.map(q=>q.id)).size,options:qs.reduce((s,q)=>s+q.options.length,0),missingExplanations:qs.reduce((s,q)=>s+q.options.filter(o=>!q.optionExplanations[o.id]?.trim()).length,0),images:images.size,unresolvedAnswerKeys:qs.filter(q=>q.correct===null).length,sharedExplanationQuestions:qs.filter(q=>Object.values(q.optionExplanationScopes||{}).includes('shared')).length,duplicateTextGroups:result.duplicates.length,reviewRequired:qs.filter(q=>!q.examEligible).map(q=>({id:q.id,question:q.question,notes:q.sourceNotes})),examEligible:qs.filter(q=>q.examEligible).length,pkTopics:[...new Set(qs.filter(q=>q.sectionId.startsWith('pk-')).map(q=>q.sectionId))],errors};
 fs.mkdirSync('reports',{recursive:true});fs.writeFileSync('reports/content-validation.json',JSON.stringify(report,null,2));
 if(errors.length)throw new Error(errors.join('\n'));console.log(JSON.stringify({questions:report.questions,uniqueIds:report.uniqueIds,missingExplanations:report.missingExplanations,images:report.images,examEligible:report.examEligible,reviewRequired:report.reviewRequired.length,duplicateTextGroups:report.duplicateTextGroups}));return report;
}
if(import.meta.url===new URL(process.argv[1],'file://'+process.cwd()+'/').href)validate();
