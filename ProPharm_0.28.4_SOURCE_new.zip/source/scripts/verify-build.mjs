import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';
const files=dir=>fs.readdirSync(dir,{withFileTypes:true}).flatMap(x=>x.isDirectory()?files(path.join(dir,x.name)):[path.join(dir,x.name)]);
export function verifyBuild(){
 const errors=[],manifest=JSON.parse(fs.readFileSync('dist/asset-manifest.json')),server=JSON.parse(fs.readFileSync('server-bundle/bundles.json'));
 const publicFiles=files('dist'),textFiles=publicFiles.filter(f=>/\.(js|json|html|css)$/.test(f)),body=textFiles.map(f=>fs.readFileSync(f,'utf8')).join('\n').replace(/\s+/g,' ');
 for(const item of manifest.files){const file='dist/'+item.file;if(!fs.existsSync(file)||crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex')!==item.sha256)errors.push('Missing or changed public file: '+item.file);}
 if(manifest.build!==server.build)errors.push('Client/server build mismatch');
 for(const q of server.bundles.tests.questions)if(body.includes(q.id))errors.push('Question data leaked into public shell: '+q.id);
 function visit(v,p='full'){if(typeof v==='string'){if(v.length>140&&v.split(/\s+/).length>16&&!v.includes('<')&&body.includes(v.replace(/\s+/g,' ')))errors.push('Closed text leaked: '+p);}else if(v&&typeof v==='object')for(const [k,x]of Object.entries(v))visit(x,p+'.'+k);}
 visit(server.bundles.full);
 for(const file of publicFiles){if(/\/(?:content|data|source|server-bundle|supabase|tests|modules)\//.test(file))errors.push('Forbidden public directory: '+file);if(file.endsWith('.js')){const code=fs.readFileSync(file,'utf8');for(const m of code.matchAll(/(?:from\s*|import\s*)["'](\.[^"']+)["']/g))if(!fs.existsSync(path.resolve(path.dirname(file),m[1])))errors.push('Broken module import: '+file+' -> '+m[1]);if(/FULL_ACCESS_USER_IDS|FORCED_APPROVED|service_role.{0,8}(?:eyJ|sb_secret_)/i.test(code))errors.push('Client authorization override or secret: '+file);}}
 const assets=JSON.parse(fs.readFileSync('server-bundle/assets.json')),assetVersion=JSON.parse(fs.readFileSync('content/asset-version.json'));
 for(const a of assets){const match=a.name.match(/^(approved|full)\/([^/]+)\/(assets\/.+)$/),file='server-bundle/'+a.file;if(!match||!fs.existsSync(file)){errors.push('Invalid private illustration: '+a.name);continue;}const digest=crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');if(match[2]!==server.build&&(match[2]!==assetVersion.build||digest!==assetVersion.files[match[3]]))errors.push('Changed asset reused an old URL: '+a.name);if(!fs.existsSync(match[3])||digest!==crypto.createHash('sha256').update(fs.readFileSync(match[3])).digest('hex'))errors.push('Asset content mismatch: '+a.name);}

 if(errors.length)throw new Error(errors.join('\n'));
 const report={build:manifest.build,verifiedPublicFiles:publicFiles.length,privateAssets:assets.length,questionRecordsInPublicShell:0,closedTextLeaks:0,brokenImports:0};fs.writeFileSync('reports/distribution-validation.json',JSON.stringify(report,null,2));console.log(JSON.stringify(report));return report;
}
if(import.meta.url===new URL(process.argv[1],'file://'+process.cwd()+'/').href)verifyBuild();
