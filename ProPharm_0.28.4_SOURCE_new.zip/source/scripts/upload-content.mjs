// Run locally by the project owner. The secret is read from an environment variable,
// never written to files or bundled into the frontend. This script uploads only to
// the Supabase project configured in config/supabase-config.js.
import fs from 'node:fs';import path from 'node:path';import { SUPABASE_CONFIG } from '../config/supabase-config.js';
const secret=process.env.PROPHARM_SERVICE_ROLE_KEY;if(!secret)throw new Error('Set PROPHARM_SERVICE_ROLE_KEY locally before running this script. Never put it in public files.');
const root='server-bundle',headers={apikey:secret,Authorization:'Bearer '+secret};
async function request(endpoint,options){const r=await fetch(SUPABASE_CONFIG.url+endpoint,{...options,headers:{...headers,...options.headers}});if(!r.ok){const msg=await r.text();throw new Error('Supabase '+r.status+': '+msg.slice(0,350))}return r;}
const assets=JSON.parse(fs.readFileSync(root+'/assets.json'));
for(const asset of assets){await request('/storage/v1/object/propharm-content/'+asset.name.split('/').map(encodeURIComponent).join('/'),{method:'POST',headers:{'Content-Type':asset.contentType,'x-upsert':'true'},body:fs.readFileSync(path.join(root,asset.file))});}
const {build,bundles}=JSON.parse(fs.readFileSync(root+'/bundles.json'));
await request('/rest/v1/content_bundles?on_conflict=build_id,bundle_id',{method:'POST',headers:{'Content-Type':'application/json',Prefer:'resolution=merge-duplicates'},body:JSON.stringify(Object.entries(bundles).map(([bundle_id,payload])=>({build_id:build,bundle_id,payload})))});
console.log('Uploaded build '+build+'; '+assets.length+' private illustrations.');
