# Настройка Supabase для ProPharm v0.14

## 1. Создай проект Supabase

Создай новый проект в своём Supabase Dashboard. Все административные секреты остаются только в Supabase/панелях OAuth-провайдеров.

## 2. Выполни SQL migration

Открой SQL Editor и выполни:

`supabase/migrations/001_propharm_accounts.sql`

Migration создаёт:

- `profiles`;
- историю тестов;
- прогресс вопросов;
- favorites;
- review queue;
- study progress;
- user settings;
- admin actions;
- RLS policies;
- trigger создания профиля после `auth.users`.

Каждый новый профиль получает:

```text
role = user
status = pending
```

## 3. Получи публичные параметры

В Supabase найди Project URL и publishable/anon key.

Заполни `config/supabase-config.js`:

```js
export const SUPABASE_CONFIG = Object.freeze({
  enabled: true,
  url: "https://YOUR_PROJECT.supabase.co",
  publishableKey: "YOUR_PUBLIC_KEY",
  siteUrl: "https://dnchkvi.github.io/ProPharm/",
  auth: {
    requireApproval: true,
    allowLocalPreviewWhenDisabled: false,
    google: true,
    apple: true,
    manualIdentityLinking: true
  }
});
```

`publishableKey`/anon key является клиентским ключом. **Service role key сюда не вставлять.**

## 4. Redirect URL

В Supabase Auth URL Configuration укажи Site URL:

`https://dnchkvi.github.io/ProPharm/`

Добавь тот же адрес в разрешённые Redirect URLs.

## 5. Google

В Google Cloud Console создай OAuth web client и используй callback URL, который показывает Supabase для Google provider. Client secret хранится в настройках Supabase provider, не в GitHub Pages.

В Supabase: Authentication → Providers → Google → включить provider и заполнить его server-side credentials.

## 6. Apple

В Apple Developer настрой Sign in with Apple согласно callback/domain, которые требует Supabase. Private key/client secret не добавлять в ProPharm repository.

В Supabase: Authentication → Providers → Apple → заполнить требуемые server-side credentials.

Apple Hide My Email поддерживается: главным идентификатором ProPharm является `auth.users.id`, а не e-mail.

## 7. Создай первого администратора

После настройки зарегистрируй свой аккаунт любым способом: e-mail, Google или Apple.

В таблице `profiles` найди свой `user_id` и один раз выполни:

```sql
update public.profiles
set role = 'admin', status = 'approved'
where user_id = 'ТВОЙ-UUID';
```

После повторного входа/обновления статуса появится раздел **Администрирование**.

## 8. Одобрение пользователей

Новый пользователь после регистрации видит только Pending screen.

В админ-панели можно:

- Одобрить → `approved`;
- Отклонить → `rejected`;
- Заблокировать → `blocked`;
- вернуть в `pending`.

Обычный пользователь не может изменить себе `role` или `status` благодаря RLS и ограничениям SQL privileges.

## 9. Что происходит, пока Supabase не настроен

В v0.14 нет Local Preview и guest mode.

При `enabled: false`, пустом URL или пустом ключе пользователь видит экран:

**ProPharm ещё не подключён**

и не получает учебный UI.

## 10. Проверка

Проверь минимум:

- нет session → только Login;
- новый user → Pending;
- `blocked` → Blocked screen;
- `approved` → учебный интерфейс;
- `admin + approved` → учебный интерфейс + Admin panel;
- direct `#drugs` без session → Login;
- logout → Login;
- offline новый пользователь → нет доступа;
- offline ранее verified approved profile → только предусмотренный ограниченный offline-доступ.
