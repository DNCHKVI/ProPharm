import { sourceAnswerIds } from './source-answer.js';

export function optionFeedback(question,entry,answer,mode,optionId){
 const selected=!!answer?.selections.includes(optionId);
 if(!answer||mode==='exam')return {className:selected?'selectedAnswer':'',label:selected?'Выбран':''};
 if(entry.unscored){
  const sourceKey=sourceAnswerIds(question).includes(optionId);
  return sourceKey
   ?{className:'sourceKeyAnswer',label:selected?'Выбран · ответ по ключу источника':'Ответ по ключу источника'}
   :{className:selected?'wrongAnswer':'',label:selected?'Ошибка':''};
 }
 if(optionId===question.correct&&(selected||answer.resolved))return {className:'correctAnswer',label:selected?'Верно':'Правильный ответ'};
 return {className:selected?'wrongAnswer':'',label:selected?'Ошибка':''};
}
